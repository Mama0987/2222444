package com.facebook.common.appcomponentfactory.fb4a;

import X.AnonymousClass0OK;
import X.AnonymousClass0SN;
import X.AnonymousClass0WY;
import X.AnonymousClass0X6;
import X.AnonymousClass0p7;
import X.AnonymousClass108;
import X.AnonymousClass109;
import X.C06300Vs;
import X.C10640fx;
import X.C11250i0;
import X.C11530ie;
import X.C12300kK;
import X.C12540kj;
import X.C14270pR;
import X.C14330pX;
import X.C14500pq;
import X.C14950qe;
import X.C15090qt;
import X.C15420rR;
import X.C15800sA;
import X.C18550xJ;
import X.C18810yD;
import X.C18820yE;
import X.C198111f;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.ConditionVariable;
import com.facebook.acra.asyncbroadcastreceiver.AsyncBroadcastReceiverObserver;
import com.facebook.base.receiver.AppInitReplayBroadcastReceiver;
import com.facebook.common.dextricks.Experiments;
import com.facebook.common.dextricks.MultiDexClassLoaderLight;
import com.facebook.common.dextricks.ReflectionClassLoader;
import dalvik.system.DelegateLastClassLoader;

public final class Fb4aAppComponentFactory extends C12300kK {
    public static C11250i0 A00;
    public static boolean A01;

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0049, code lost:
        if (X.C12620kw.A01(r0).A41 != false) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0098, code lost:
        if (X.C12620kw.A01(r0).A41 != false) goto L_0x009a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00cb  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x011c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.app.Activity instantiateActivity(java.lang.ClassLoader r10, java.lang.String r11, android.content.Intent r12) {
        /*
            r9 = this;
            r2 = 0
            X.C15800sA.A0D(r10, r2)
            r4 = 1
            X.C15800sA.A0D(r11, r4)
            X.AnonymousClass0OI.A00 = r12
            X.AnonymousClass0OI.A02 = r11
            X.0yE r0 = X.C18820yE.A01
            java.util.concurrent.atomic.AtomicBoolean r7 = X.AnonymousClass0OJ.A01
            boolean r1 = r7.get()
            X.0yE r3 = X.C18820yE.A01
            X.0j5 r0 = r0.A04
            X.0OK r1 = r0.AM6(r12, r10, r1)
            if (r1 == 0) goto L_0x0124
            java.lang.String r0 = r1.A00
        L_0x0020:
            r3.A0C = r0
            if (r1 == 0) goto L_0x0029
            X.0rR r0 = r3.A07
            r1.A00(r0)
        L_0x0029:
            java.lang.Integer r0 = X.AnonymousClass0X6.A00
            X.C18810yD.A02(r12, r3, r0, r11)
            boolean r0 = r7.get()
            r8 = 0
            if (r0 != 0) goto L_0x004b
            java.lang.String r0 = "com.facebook.katana.activity.FbMainTabActivity"
            boolean r0 = r11.equals(r0)
            if (r0 == 0) goto L_0x011f
            java.lang.String r1 = "fbApp"
            X.0i0 r0 = A00
            if (r0 == 0) goto L_0x0187
            X.0l1 r0 = X.C12620kw.A01(r0)
            boolean r0 = r0.A41
            if (r0 == 0) goto L_0x011f
        L_0x004b:
            r6 = 1
            java.lang.String r1 = X.C12300kK.A00(r11, r11)
        L_0x0050:
            com.facebook.perf.background.BackgroundStartupDetector r0 = com.facebook.perf.background.BackgroundStartupDetector.backgroundStartupDetector
            if (r0 == 0) goto L_0x0057
            r0.activityCreateInternal(r1)
        L_0x0057:
            if (r6 != 0) goto L_0x007e
            java.lang.String r5 = "DelayingSplashScreen"
            java.lang.Thread r1 = java.lang.Thread.currentThread()
            android.os.Looper r0 = android.os.Looper.getMainLooper()
            java.lang.Thread r0 = r0.getThread()
            boolean r0 = X.C15800sA.areEqual(r1, r0)
            if (r0 == 0) goto L_0x0077
            android.os.Handler r1 = X.C14950qe.A02
            X.0ql r0 = new X.0ql
            r0.<init>(r1, r5, r4)
            r1.post(r0)
        L_0x0077:
            r0 = 500(0x1f4, double:2.47E-321)
            android.os.ConditionVariable r5 = X.AnonymousClass0OJ.A00
            r5.block(r0)
        L_0x007e:
            boolean r0 = r7.get()
            if (r0 != 0) goto L_0x009a
            java.lang.String r0 = "com.facebook.katana.activity.FbMainTabActivity"
            boolean r0 = r11.equals(r0)
            if (r0 == 0) goto L_0x009b
            java.lang.String r1 = "fbApp"
            X.0i0 r0 = A00
            if (r0 == 0) goto L_0x0187
            X.0l1 r0 = X.C12620kw.A01(r0)
            boolean r0 = r0.A41
            if (r0 == 0) goto L_0x009b
        L_0x009a:
            r8 = 1
        L_0x009b:
            if (r6 == 0) goto L_0x011c
            r5 = r11
        L_0x009e:
            java.lang.Thread r1 = java.lang.Thread.currentThread()
            android.os.Looper r0 = android.os.Looper.getMainLooper()
            java.lang.Thread r0 = r0.getThread()
            boolean r0 = X.C15800sA.areEqual(r1, r0)
            if (r0 == 0) goto L_0x00ba
            android.os.Handler r1 = X.C14950qe.A02
            X.0ql r0 = new X.0ql
            r0.<init>(r1, r5, r4)
            r1.post(r0)
        L_0x00ba:
            java.lang.String r1 = "AppComponentFactory"
            java.lang.String r0 = "Instantiating Activity: "
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r0, r11)
            X.C14270pR.A0G(r1, r0)
            X.0i0 r0 = A00
            java.lang.String r7 = "fbApp"
            if (r0 == 0) goto L_0x0183
            android.content.Context r1 = r0.getApplicationContext()
            X.C15800sA.A09(r1)
            X.0l1 r0 = r3.A00
            if (r0 != 0) goto L_0x00e0
            X.0l1 r0 = X.C12620kw.A01(r1)
            r3.A00 = r0
            boolean r0 = r0.A6a
            r3.A0D = r0
        L_0x00e0:
            X.0l1 r0 = r3.A00
            if (r0 == 0) goto L_0x0103
            boolean r0 = r0.A6a
            if (r0 != r4) goto L_0x0103
        L_0x00e8:
            if (r8 != 0) goto L_0x012c
            java.lang.String r2 = "showingModernSelfHostedSplashScreen"
            X.109 r1 = X.AnonymousClass108.A00
            r0 = 4003988(0x3d1894, float:5.610782E-39)
            r1.markerPoint(r0, r2)
            X.AnonymousClass036.A02 = r11
            java.lang.Class<com.facebook.katana.app.mainactivity.FbMainActivity> r0 = com.facebook.katana.app.mainactivity.FbMainActivity.class
            java.lang.String r0 = r0.getCanonicalName()
            if (r0 == 0) goto L_0x0127
            android.app.Activity r0 = super.instantiateActivity(r10, r0, r12)
            return r0
        L_0x0103:
            X.0rR r6 = X.C11530ie.A00
            if (r8 != 0) goto L_0x0117
            java.lang.String r5 = "Splash"
        L_0x0109:
            int r1 = r3.A00
            int r0 = r1 + 1
            r3.A00 = r0
            java.lang.String r0 = X.AnonymousClass0WY.A0d(r5, r1)
            r6.A07(r0, r11)
            goto L_0x00e8
        L_0x0117:
            java.lang.String r5 = X.C12300kK.A00(r11, r11)
            goto L_0x0109
        L_0x011c:
            java.lang.String r5 = "FbMainActivity"
            goto L_0x009e
        L_0x011f:
            r6 = 0
            java.lang.String r1 = "Splash"
            goto L_0x0050
        L_0x0124:
            r0 = 0
            goto L_0x0020
        L_0x0127:
            java.lang.IllegalStateException r0 = X.AnonymousClass001.A0O()
            throw r0
        L_0x012c:
            java.lang.String r0 = "com.facebook.googleplaystore.GooglePlaystoreOverlayExternalActivity"
            boolean r0 = r0.equals(r11)
            if (r0 == 0) goto L_0x0139
            android.app.Activity r0 = super.instantiateActivity(r10, r11, r12)
            return r0
        L_0x0139:
            X.0i0 r0 = A00
            if (r0 == 0) goto L_0x0183
            android.content.Context r1 = r0.getApplicationContext()
            X.C15800sA.A09(r1)
            X.0l1 r0 = r3.A00
            if (r0 != 0) goto L_0x0152
            X.0l1 r0 = X.C12620kw.A01(r1)
            r3.A00 = r0
            boolean r0 = r0.A6a
            r3.A0D = r0
        L_0x0152:
            X.0l1 r0 = r3.A00
            if (r0 == 0) goto L_0x016b
            boolean r0 = r0.A6a
            if (r0 != r4) goto L_0x016b
        L_0x015a:
            X.0i0 r0 = A00
            if (r0 == 0) goto L_0x0183
            X.0l1 r0 = X.C12620kw.A01(r0)
            boolean r0 = r0.A2B
            if (r0 != 0) goto L_0x016f
            android.app.Activity r0 = super.instantiateActivity(r10, r11, r12)
            return r0
        L_0x016b:
            r3.A04(r12, r2)
            goto L_0x015a
        L_0x016f:
            java.lang.String r0 = "com.facebook.startup.destination.StartupDestinationRouter"
            java.lang.Class r0 = java.lang.Class.forName(r0)
            X.C15800sA.A0C(r0)
            X.C15800sA.A0D(r0, r2)
            java.util.Map r0 = X.C02280Bf.A03
            X.0kz r0 = new X.0kz
            r0.<init>()
            throw r0
        L_0x0183:
            X.C15800sA.A0L(r7)
            goto L_0x018a
        L_0x0187:
            X.C15800sA.A0L(r1)
        L_0x018a:
            X.0Vs r0 = X.C06300Vs.createAndThrow()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.appcomponentfactory.fb4a.Fb4aAppComponentFactory.instantiateActivity(java.lang.ClassLoader, java.lang.String, android.content.Intent):android.app.Activity");
    }

    public final ContentProvider instantiateProvider(ClassLoader classLoader, String str) {
        C15800sA.A0D(classLoader, 0);
        C15800sA.A0D(str, 1);
        C14950qe.A06.A00(str);
        return super.instantiateProvider(classLoader, str);
    }

    public final Application instantiateApplication(ClassLoader classLoader, String str) {
        boolean A0R = C15800sA.A0R(classLoader, str);
        C14950qe.A06.A00(str);
        C14270pR.A0G("AppComponentFactory", "Instantiating Application");
        Application instantiateApplication = super.instantiateApplication(classLoader, str);
        C15800sA.A09(instantiateApplication);
        if (instantiateApplication instanceof C11250i0) {
            A00 = (C11250i0) instantiateApplication;
        } else {
            C14270pR.A0G("AppComponentFactory", "Incorrect instanceof");
        }
        C14500pq.A00 = A0R;
        C10640fx.A04 = C14500pq.A01;
        C14330pX.A00 = A0R;
        return instantiateApplication;
    }

    public final ClassLoader instantiateClassLoader(ClassLoader classLoader, ApplicationInfo applicationInfo) {
        int i;
        boolean A0Q = C15800sA.A0Q(classLoader, applicationInfo);
        C15420rR r2 = C11530ie.A00;
        r2.A00("instantiateClassLoader");
        String[] strArr = applicationInfo.splitSourceDirs;
        if (strArr != null) {
            i = strArr.length;
        } else {
            i = 0;
        }
        r2.A02("splitCount", i);
        if (classLoader instanceof DelegateLastClassLoader) {
            ReflectionClassLoader.install();
        }
        if (C18550xJ.A04(applicationInfo, Experiments.ENABLE_MDCLL, A0Q)) {
            MultiDexClassLoaderLight.install(applicationInfo, classLoader);
        }
        ClassLoader instantiateClassLoader = super.instantiateClassLoader(classLoader, applicationInfo);
        C15800sA.A09(instantiateClassLoader);
        return instantiateClassLoader;
    }

    public final BroadcastReceiver instantiateReceiver(ClassLoader classLoader, String str, Intent intent) {
        String str2;
        String str3;
        String A0i;
        C15800sA.A0F(classLoader, str);
        C15090qt r3 = C14950qe.A06;
        ConditionVariable conditionVariable = AnonymousClass0p7.A00;
        if (conditionVariable.block(-1)) {
            str2 = str;
        } else {
            str2 = "AppInitReplayBroadcastReceiver";
        }
        r3.A00(str2);
        C18820yE r6 = C18820yE.A01;
        AnonymousClass0OK AM6 = r6.A05.AM6(intent, (ClassLoader) null, false);
        if (AM6 != null) {
            r6.A0C = AM6.A00;
            AM6.A00(r6.A07);
        }
        C18810yD.A01(intent, r6);
        r6.A07.A05("intentFlags", C18810yD.A00(intent, r6.A03));
        C18810yD.A02(intent, r6, AnonymousClass0X6.A0C, str);
        if (!conditionVariable.block(-1)) {
            AppInitReplayBroadcastReceiver.A00.push(str);
            AnonymousClass108.A00.markerPoint(4003988, AnonymousClass0WY.A0w("delayingReceiver_", str, "_begin"));
            str = "com.facebook.base.receiver.AppInitReplayBroadcastReceiver";
        } else if (AppInitReplayBroadcastReceiver.A00.remove(str)) {
            AnonymousClass108.A00.markerPoint(4003988, AnonymousClass0WY.A0w("delayingReceiver_", str, "_end"));
        }
        C11250i0 r32 = A00;
        if (r32 != null) {
            if (C14500pq.A00) {
                C14500pq.A00(r32, str, AsyncBroadcastReceiverObserver.RECEIVER);
                if ("com.facebook.base.receiver.AppInitReplayBroadcastReceiver".equals(str)) {
                    A0i = "instantiateReplayReceiverFor_";
                } else {
                    A0i = AnonymousClass0WY.A0i("instantiateReceiver_", str);
                }
                C14500pq.A01(A0i);
            }
            C11250i0 r33 = A00;
            if (r33 != null) {
                if (C14330pX.A00 && C14330pX.A08(str)) {
                    if (C14330pX.A07()) {
                        C14330pX.A06("componentName", str);
                        C14330pX.A06("componentType", AsyncBroadcastReceiverObserver.RECEIVER);
                        if (!C198111f.A0Y(str, "AppInitReplayBroadcastReceiver", false)) {
                            C14330pX.A01(r33);
                        }
                    }
                    String A0i2 = AnonymousClass0WY.A0i(str, " instantiation");
                    if (C14330pX.A00) {
                        AnonymousClass109 r1 = C14330pX.A01.A01;
                        if (A0i2 == null) {
                            C15800sA.A0C(A0i2);
                            throw C06300Vs.createAndThrow();
                        }
                        r1.markerPoint(877009262, A0i2);
                    }
                    if (intent != null) {
                        str3 = intent.getAction();
                    } else {
                        str3 = null;
                    }
                    C14330pX.A06("componentDescription", C14330pX.A00(str, str3));
                }
                C14270pR.A0G("AppComponentFactory", "Instantiating BroadcastReceiver");
                return super.instantiateReceiver(classLoader, str, intent);
            }
        }
        C15800sA.A0L("fbApp");
        throw C06300Vs.createAndThrow();
    }

    public final Service instantiateService(ClassLoader classLoader, String str, Intent intent) {
        String str2;
        boolean A0R = C15800sA.A0R(classLoader, str);
        C18820yE r3 = C18820yE.A01;
        AnonymousClass0OK AM6 = r3.A06.AM6(intent, (ClassLoader) null, false);
        if (AM6 != null) {
            r3.A0C = AM6.A00;
            AM6.A00(r3.A07);
        }
        C18810yD.A01(intent, r3);
        C18810yD.A02(intent, r3, AnonymousClass0X6.A01, str);
        C14950qe.A06.A00(str);
        C11250i0 r1 = A00;
        if (r1 != null) {
            if (C14500pq.A00) {
                C14500pq.A00(r1, str, "service");
                C14500pq.A01(AnonymousClass0WY.A0i("instantiateService_", str));
            }
            C11250i0 r32 = A00;
            if (r32 != null) {
                if (C14330pX.A00 && C14330pX.A08(str)) {
                    if (C14330pX.A07()) {
                        C14330pX.A06("componentName", str);
                        C14330pX.A06("componentType", "service");
                        if (!C198111f.A0Y(str, "AppInitReplayBroadcastReceiver", false)) {
                            C14330pX.A01(r32);
                        }
                    }
                    String A0i = AnonymousClass0WY.A0i(str, " instantiation");
                    if (C14330pX.A00) {
                        AnonymousClass109 r12 = C14330pX.A01.A01;
                        if (A0i == null) {
                            C15800sA.A0C(A0i);
                            throw C06300Vs.createAndThrow();
                        }
                        r12.markerPoint(877009262, A0i);
                    }
                    if (intent != null) {
                        str2 = intent.getAction();
                    } else {
                        str2 = null;
                    }
                    C14330pX.A06("componentDescription", C14330pX.A00(str, str2));
                }
                if (!C12540kj.A00.block(-1)) {
                    if (!A01 || !str.equals("androidx.work.impl.background.systemjob.SystemJobService")) {
                        String A0w = AnonymousClass0WY.A0w("waitingForService_", str, "_begin");
                        AnonymousClass109 r2 = AnonymousClass108.A00;
                        r2.markerPoint(4003988, A0w);
                        C12540kj.A00();
                        r2.markerPoint(4003988, AnonymousClass0WY.A0w("waitingForService_", str, "_end"));
                    } else {
                        C14270pR.A0G("AppComponentFactory", "Skipping waiting for SystemJobService");
                        return super.instantiateService(classLoader, str, intent);
                    }
                }
                if (C15800sA.A0S("org.chromium.content.app.SandboxedProcessService", A0R ? 1 : 0, str)) {
                    C11250i0 r13 = A00;
                    if (r13 != null) {
                        return super.instantiateService(new AnonymousClass0SN(r13).A00(), str, intent);
                    }
                } else {
                    C14270pR.A0G("AppComponentFactory", "Instantiating Service");
                    return super.instantiateService(classLoader, str, intent);
                }
            }
        }
        C15800sA.A0L("fbApp");
        throw C06300Vs.createAndThrow();
    }
}
