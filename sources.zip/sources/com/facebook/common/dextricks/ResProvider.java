package com.facebook.common.dextricks;

import java.io.Closeable;
import java.io.InputStream;

public abstract class ResProvider implements Closeable {
    public abstract InputStream open(String str);

    public void close() {
    }

    public boolean isExoResProvider() {
        return false;
    }

    public void markRootRelative() {
    }

    public boolean shouldMemoizeReturnedData() {
        return true;
    }

    public String getFilePath(String str) {
        return null;
    }
}
