package com.facebook.common.dextricks;

import X.AnonymousClass0WY;

public final class ReflectionClassLoaderJava extends ReflectionClassLoader {
    public Class findClass(String str) {
        Class<?> loadClass;
        ClassLoader classLoader = this.mPutativeLoader;
        if (classLoader != null && (loadClass = classLoader.loadClass(str)) != null) {
            return loadClass;
        }
        throw new ClassNotFoundException(AnonymousClass0WY.A0i("ReflectionClassLoaderJava cannot find ", str));
    }

    public Class loadClass(String str, boolean z) {
        ClassNotFoundException classNotFoundException;
        try {
            if (ReflectionClassLoader.maybeFallbackLoadDexes(str)) {
                try {
                    return findClass(str);
                } catch (ClassNotFoundException unused) {
                    classNotFoundException = new ClassNotFoundException(AnonymousClass0WY.A0i("ReflectionClassLoaderJava cannot find ", str));
                }
            } else {
                classNotFoundException = new ClassNotFoundException(AnonymousClass0WY.A0i("Fallback dex load return false for class ", str));
                throw classNotFoundException;
            }
        } catch (RuntimeException e) {
            throw new ClassNotFoundException(AnonymousClass0WY.A0i("Fallback dex load failed for ", str), e);
        }
    }
}
