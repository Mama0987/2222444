package com.facebook.common.dextricks;

import dalvik.system.DexFile;
import java.util.Iterator;

public class ClassLoaderConfigurationHelper {
    public static volatile Impl sImpl = new Object();
    public static final ClassLoaderConfiguration sMergedConfig = new ClassLoaderConfiguration(0, DalvikConstants.FB_REDEX_COLD_START_SET_DEX_COUNT);

    public class Impl {
        public void clearDexConfig(ClassLoaderConfiguration classLoaderConfiguration) {
            classLoaderConfiguration.mDexFiles.clear();
        }

        public void mergeConfiguration(ClassLoaderConfiguration classLoaderConfiguration) {
            ClassLoaderConfiguration classLoaderConfiguration2 = ClassLoaderConfigurationHelper.sMergedConfig;
            classLoaderConfiguration2.configFlags |= classLoaderConfiguration.configFlags;
            Iterator it = classLoaderConfiguration.mDexFiles.iterator();
            while (it.hasNext()) {
                classLoaderConfiguration2.addDex((DexFile) it.next());
            }
        }

        public ClassLoaderConfiguration getConfig() {
            return ClassLoaderConfigurationHelper.sMergedConfig;
        }

        public /* synthetic */ Impl(AnonymousClass1 r1) {
        }

        public Impl() {
        }
    }

    public class SynchronizedImpl extends Impl {
        public void clearDexConfig(ClassLoaderConfiguration classLoaderConfiguration) {
            synchronized (ClassLoaderConfigurationHelper.sMergedConfig) {
                classLoaderConfiguration.mDexFiles.clear();
            }
        }

        public ClassLoaderConfiguration getConfig() {
            ClassLoaderConfiguration classLoaderConfiguration = ClassLoaderConfigurationHelper.sMergedConfig;
            synchronized (classLoaderConfiguration) {
            }
            return classLoaderConfiguration;
        }

        public void mergeConfiguration(ClassLoaderConfiguration classLoaderConfiguration) {
            synchronized (ClassLoaderConfigurationHelper.sMergedConfig) {
                super.mergeConfiguration(classLoaderConfiguration);
            }
        }

        public /* synthetic */ SynchronizedImpl(AnonymousClass1 r1) {
        }

        public SynchronizedImpl() {
        }
    }

    public static void clearDexConfig(ClassLoaderConfiguration classLoaderConfiguration) {
        sImpl.clearDexConfig(classLoaderConfiguration);
    }

    public static ClassLoaderConfiguration getMergedConfig() {
        return sImpl.getConfig();
    }

    public static void mergeConfiguration(ClassLoaderConfiguration classLoaderConfiguration) {
        sImpl.mergeConfiguration(classLoaderConfiguration);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v4, resolved type: com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized void setIsSynchronized(boolean r2) {
        /*
            java.lang.Class<com.facebook.common.dextricks.ClassLoaderConfigurationHelper> r1 = com.facebook.common.dextricks.ClassLoaderConfigurationHelper.class
            monitor-enter(r1)
            if (r2 == 0) goto L_0x000b
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper$SynchronizedImpl r0 = new com.facebook.common.dextricks.ClassLoaderConfigurationHelper$SynchronizedImpl     // Catch:{ all -> 0x0014 }
            r0.<init>()     // Catch:{ all -> 0x0014 }
            goto L_0x0010
        L_0x000b:
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl r0 = new com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl     // Catch:{ all -> 0x0014 }
            r0.<init>()     // Catch:{ all -> 0x0014 }
        L_0x0010:
            sImpl = r0     // Catch:{ all -> 0x0014 }
            monitor-exit(r1)
            return
        L_0x0014:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0014 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ClassLoaderConfigurationHelper.setIsSynchronized(boolean):void");
    }
}
