package com.facebook.common.dextricks.benchmarkhelper;

import X.AnonymousClass001;
import java.util.Collections;
import java.util.List;

public final class ClassloadNameCollector {
    public static final List A00 = Collections.synchronizedList(AnonymousClass001.A0t());
}
