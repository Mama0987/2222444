package com.facebook.common.dextricks.classifier;

import X.AnonymousClass0WY;
import android.util.Log;
import com.facebook.common.dextricks.StringTreeSet;

public final class NameClassifier {
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x0135, code lost:
        if (r11 >= 12) goto L_0x0137;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0071, code lost:
        if (r11 >= 13) goto L_0x0073;
     */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x014c A[Catch:{ IndexOutOfBoundsException -> 0x014d }, RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean A00(java.lang.String r15) {
        /*
            r3 = 0
            int r11 = r15.length()     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r7 = 6
            if (r11 <= r7) goto L_0x014c
            char r12 = r15.charAt(r3)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r6 = 120(0x78, float:1.68E-43)
            r8 = 117(0x75, float:1.64E-43)
            r14 = 115(0x73, float:1.61E-43)
            r9 = 12
            r1 = 8
            r4 = 46
            r5 = 97
            r2 = 1
            if (r12 == r5) goto L_0x001e
            goto L_0x0088
        L_0x001e:
            java.lang.String r7 = "test."
            r12 = 9
            r10 = 7
            r0 = 10
            if (r11 < r0) goto L_0x00a2
            char r0 = r15.charAt(r10)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r6) goto L_0x0042
            char r0 = r15.charAt(r1)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x0042
            java.lang.String r0 = "ndroidx."
            boolean r0 = r15.startsWith(r0, r2)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 == 0) goto L_0x00a2
            boolean r0 = r15.startsWith(r7, r12)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 == 0) goto L_0x014c
            return r2
        L_0x0042:
            r6 = 16
            if (r11 < r6) goto L_0x006f
            char r0 = r15.charAt(r1)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r14) goto L_0x0073
            char r0 = r15.charAt(r12)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r8) goto L_0x0073
            r0 = 15
            char r0 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x0073
            char r0 = r15.charAt(r10)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x0073
            java.lang.String r0 = "ndroid.support"
            boolean r0 = r15.startsWith(r0, r2)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 == 0) goto L_0x00a2
            boolean r0 = r15.startsWith(r7, r6)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 == 0) goto L_0x014c
            return r2
        L_0x006f:
            r0 = 13
            if (r11 < r0) goto L_0x00a2
        L_0x0073:
            char r0 = r15.charAt(r1)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r5) goto L_0x00a2
            char r0 = r15.charAt(r9)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x00a2
            java.lang.String r0 = "ndroid.arch."
            boolean r0 = r15.startsWith(r0, r2)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = r0 ^ 1
            return r0
        L_0x0088:
            r13 = 106(0x6a, float:1.49E-43)
            if (r12 == r13) goto L_0x00b2
            r0 = 108(0x6c, float:1.51E-43)
            if (r12 == r0) goto L_0x00a2
            r0 = 111(0x6f, float:1.56E-43)
            r10 = 4
            r8 = 5
            if (r12 == r0) goto L_0x00a3
            if (r12 == r14) goto L_0x00f3
            r0 = 99
            if (r12 == r0) goto L_0x00bb
            r0 = 100
            if (r12 != r0) goto L_0x014c
            if (r11 < r1) goto L_0x014c
        L_0x00a2:
            return r2
        L_0x00a3:
            char r1 = r15.charAt(r10)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r1 == r5) goto L_0x0104
            if (r1 == r13) goto L_0x00a2
            r0 = 119(0x77, float:1.67E-43)
            if (r1 == r0) goto L_0x00fb
            if (r1 == r6) goto L_0x00a2
            return r3
        L_0x00b2:
            char r0 = r15.charAt(r2)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 == r5) goto L_0x00a2
            if (r0 == r8) goto L_0x00a2
            return r3
        L_0x00bb:
            r0 = 29
            r6 = 110(0x6e, float:1.54E-43)
            if (r11 < r0) goto L_0x00e6
            char r0 = r15.charAt(r10)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r5) goto L_0x00e6
            char r0 = r15.charAt(r8)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r6) goto L_0x00e6
            char r1 = r15.charAt(r9)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = 105(0x69, float:1.47E-43)
            if (r1 != r0) goto L_0x00e6
            r0 = 27
            char r0 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x00e6
            java.lang.String r0 = "om.android.installreferrer."
            boolean r0 = r15.startsWith(r0, r2)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = r0 ^ 1
            return r0
        L_0x00e6:
            char r0 = r15.charAt(r10)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r5) goto L_0x014c
            char r0 = r15.charAt(r8)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r6) goto L_0x014c
            return r2
        L_0x00f3:
            r0 = 3
            char r0 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x014c
            return r2
        L_0x00fb:
            char r1 = r15.charAt(r8)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = 51
            if (r1 != r0) goto L_0x014c
            return r2
        L_0x0104:
            boolean r0 = com.facebook.common.dextricks.Experiments.NOT_ASK_PARENT_CLASS_LOADER     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r6 = 112(0x70, float:1.57E-43)
            if (r0 == 0) goto L_0x0135
            r0 = 14
            if (r11 < r0) goto L_0x0135
            char r0 = r15.charAt(r8)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r6) goto L_0x0137
            char r0 = r15.charAt(r7)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r5) goto L_0x0137
            r0 = 10
            char r0 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x0137
            r0 = 11
            char r1 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = 104(0x68, float:1.46E-43)
            if (r1 != r0) goto L_0x0137
            char r1 = r15.charAt(r9)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            r0 = 116(0x74, float:1.63E-43)
            if (r1 != r0) goto L_0x0137
            return r3
        L_0x0135:
            if (r11 < r9) goto L_0x014c
        L_0x0137:
            char r0 = r15.charAt(r8)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r6) goto L_0x014c
            char r0 = r15.charAt(r7)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r5) goto L_0x014c
            r0 = 10
            char r0 = r15.charAt(r0)     // Catch:{ IndexOutOfBoundsException -> 0x014d }
            if (r0 != r4) goto L_0x014c
            return r2
        L_0x014c:
            return r3
        L_0x014d:
            r2 = move-exception
            java.lang.String r0 = "Class out of bounds: "
            java.lang.String r1 = X.AnonymousClass0WY.A0i(r0, r15)
            java.lang.String r0 = "NameClassifier"
            android.util.Log.e(r0, r1, r2)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.classifier.NameClassifier.A00(java.lang.String):boolean");
    }

    public static boolean A01(String str, String str2) {
        if (str != null) {
            try {
                if (StringTreeSet.search(str2, str)) {
                    return true;
                }
            } catch (IndexOutOfBoundsException e) {
                Log.e("NameClassifier", AnonymousClass0WY.A0i("StringTreeSet search out of bounds for class: ", str2), e);
            }
        }
        return str2.length() == 38 && str2.charAt(3) == '.' && str2.charAt(13) == 'r' && str2.charAt(19) == 'L' && str2.charAt(23) == 'T' && str2.charAt(27) == 'P';
    }
}
