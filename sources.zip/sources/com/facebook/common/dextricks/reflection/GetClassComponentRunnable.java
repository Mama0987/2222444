package com.facebook.common.dextricks.reflection;

import X.C18440x7;

public class GetClassComponentRunnable implements Runnable {
    public final Class clzz;
    public final int kind;
    public final String name;
    public Object result;
    public final String signature;

    public native void run();

    static {
        C18440x7.loadLibrary("dextricks-reflection");
    }

    public GetClassComponentRunnable(Class cls, String str, String str2, int i) {
        this.clzz = cls;
        this.name = str;
        this.signature = str2;
        this.kind = i;
    }
}
