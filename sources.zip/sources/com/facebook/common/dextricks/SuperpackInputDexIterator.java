package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0N9;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import com.facebook.superpack.SuperpackArchive;
import com.facebook.superpack.SuperpackFile;
import com.facebook.superpack.SuperpackFileInputStream;
import com.facebook.xzdecoder.XzInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.SynchronousQueue;

public final class SuperpackInputDexIterator extends InputDexIterator {
    public final AnonymousClass0N9 mArchiveExtension;
    public final int[] mDexToArchiveMap;
    public final SynchronousQueue[] mFileQueues;
    public int mNextDexIndex;
    public boolean mShuttingDownFlag;
    public final SuperpackArchive mSuperpackArchive;
    public SuperpackFile mSuperpackFileToClose;
    public final Thread[] mThreads;

    public final class Builder {
        public AnonymousClass0N9 archiveExtension = AnonymousClass0N9.NONE;
        public int[] dexToArchive;
        public DexManifest manifest;
        public LightweightQuickPerformanceLogger qplCollector;
        public ArrayList rawArchives;

        public Builder addRawArchive(InputStream inputStream) {
            if (inputStream != null) {
                this.rawArchives.add(inputStream);
                return this;
            }
            throw AnonymousClass001.A0S();
        }

        public Builder assignDexToArchive(int i, int i2) {
            if (i2 < 0 || i2 >= this.rawArchives.size()) {
                throw new IndexOutOfBoundsException();
            }
            this.dexToArchive[i] = i2;
            return this;
        }

        public SuperpackInputDexIterator build() {
            if (this.rawArchives.size() >= 1) {
                return new SuperpackInputDexIterator(this);
            }
            throw AnonymousClass001.A0N();
        }

        public Builder(DexManifest dexManifest, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
            if (dexManifest != null) {
                this.manifest = dexManifest;
                this.dexToArchive = new int[dexManifest.dexes.length];
                this.qplCollector = lightweightQuickPerformanceLogger;
                this.rawArchives = AnonymousClass001.A0t();
                this.archiveExtension = dexManifest.superpackExtension;
                return;
            }
            throw AnonymousClass001.A0S();
        }
    }

    public class UnpackingRunnable implements Runnable {
        public InputStream mInput;
        public SynchronousQueue mOutput;

        public UnpackingRunnable(InputStream inputStream, SynchronousQueue synchronousQueue) {
            this.mInput = inputStream;
            this.mOutput = synchronousQueue;
        }

        public void run() {
            SuperpackFile access$200;
            try {
                SuperpackArchive access$100 = SuperpackInputDexIterator.this.getSuperpackArchive(this.mInput);
                try {
                    this.mInput.close();
                    while (access$100.hasNext()) {
                        access$200 = SuperpackInputDexIterator.this.getNextFileFromSpk(access$100);
                        this.mOutput.put(access$200);
                    }
                    access$100.close();
                } catch (Throwable th) {
                    access$100.close();
                    throw th;
                }
            } catch (IOException e) {
                throw AnonymousClass001.A0X(e);
            } catch (InterruptedException e2) {
                if (!SuperpackInputDexIterator.this.mShuttingDownFlag) {
                    throw AnonymousClass001.A0X(e2);
                }
            } catch (Throwable th2) {
                AnonymousClass0ZM.A00(th, th2);
            }
        }
    }

    public static Builder builder(DexManifest dexManifest, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        return new Builder(dexManifest, lightweightQuickPerformanceLogger);
    }

    public static String getArchiveExtension(Builder builder) {
        AnonymousClass0N9 r2 = builder.manifest.superpackExtension;
        String str = SuperpackArchive.TAG;
        if (r2 == AnonymousClass0N9.NONE) {
            return ".dex.spk.xz";
        }
        if (r2 == AnonymousClass0N9.OB) {
            return ".dex.spo";
        }
        if (r2 == AnonymousClass0N9.XZ) {
            return ".dex.spk.xz";
        }
        if (r2 == AnonymousClass0N9.ZST) {
            return ".dex.spk.zst";
        }
        throw AnonymousClass001.A0V(AnonymousClass002.A0M(r2, "Unknown Superpack Archive Extension ", AnonymousClass001.A0m()));
    }

    /* access modifiers changed from: private */
    public SuperpackFile getNextFileFromSpk(SuperpackArchive superpackArchive) {
        LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
        if (lightweightQuickPerformanceLogger != null) {
            lightweightQuickPerformanceLogger.markerStart(34603016);
        }
        try {
            return superpackArchive.next();
        } finally {
            LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger2 = this.mQplCollector;
            if (lightweightQuickPerformanceLogger2 != null) {
                lightweightQuickPerformanceLogger2.markerEnd(34603016, 2);
            }
        }
    }

    /* access modifiers changed from: private */
    public SuperpackArchive getSuperpackArchive(InputStream inputStream) {
        RuntimeException th;
        SuperpackArchive superpackArchive;
        LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
        if (lightweightQuickPerformanceLogger != null) {
            lightweightQuickPerformanceLogger.markerStart(34603015);
        }
        try {
            AnonymousClass0N9 r4 = this.mArchiveExtension;
            if (r4 == AnonymousClass0N9.NONE) {
                XzInputStream xzInputStream = new XzInputStream(inputStream);
                try {
                    superpackArchive = SuperpackArchive.read(xzInputStream, "spk");
                    xzInputStream.close();
                } catch (Throwable th2) {
                    AnonymousClass0ZM.A00(th, th2);
                }
            } else if (r4 == AnonymousClass0N9.OB) {
                superpackArchive = SuperpackArchive.read(inputStream, "spo");
            } else if (r4 == AnonymousClass0N9.XZ) {
                superpackArchive = SuperpackArchive.read(inputStream, "xz");
            } else if (r4 == AnonymousClass0N9.ZST) {
                superpackArchive = SuperpackArchive.read(inputStream, "zst");
            } else {
                th = AnonymousClass001.A0V(AnonymousClass002.A0M(r4, "Unknown Superpack Archive Extension ", AnonymousClass001.A0m()));
                throw th;
            }
            return superpackArchive;
        } finally {
            LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger2 = this.mQplCollector;
            if (lightweightQuickPerformanceLogger2 != null) {
                lightweightQuickPerformanceLogger2.markerEnd(34603015, 2);
            }
        }
    }

    private void maybeCloseLastSuperpackFile() {
        SuperpackFile superpackFile = this.mSuperpackFileToClose;
        if (superpackFile != null) {
            superpackFile.close();
            this.mSuperpackFileToClose = null;
        }
    }

    private SuperpackFile nextSuperpackFile() {
        int[] iArr = this.mDexToArchiveMap;
        int i = this.mNextDexIndex;
        this.mNextDexIndex = i + 1;
        int i2 = iArr[i];
        if (i2 == 0) {
            return getNextFileFromSpk(this.mSuperpackArchive);
        }
        try {
            return (SuperpackFile) this.mFileQueues[i2 - 1].take();
        } catch (InterruptedException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    private void setLastSuperpackFileToClose(SuperpackFile superpackFile) {
        if (this.mSuperpackFileToClose == null) {
            this.mSuperpackFileToClose = superpackFile;
            return;
        }
        throw AnonymousClass001.A0N();
    }

    public void close() {
        if (!this.mShuttingDownFlag) {
            this.mShuttingDownFlag = true;
            maybeCloseLastSuperpackFile();
            try {
                this.mSuperpackArchive.close();
                for (Thread thread : this.mThreads) {
                    thread.interrupt();
                    thread.join();
                }
                LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
                if (lightweightQuickPerformanceLogger != null) {
                    lightweightQuickPerformanceLogger.markerEnd(34603017, 2);
                }
            } catch (InterruptedException e) {
                throw AnonymousClass001.A0X(e);
            } catch (Throwable th) {
                LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger2 = this.mQplCollector;
                if (lightweightQuickPerformanceLogger2 != null) {
                    lightweightQuickPerformanceLogger2.markerEnd(34603017, 2);
                }
                throw th;
            }
        } else {
            throw AnonymousClass001.A0P("Iterator already closed");
        }
    }

    public InputDex nextImpl(DexManifest.Dex dex) {
        SuperpackFileInputStream superpackFileInputStream;
        maybeCloseLastSuperpackFile();
        SuperpackFile nextSuperpackFile = nextSuperpackFile();
        if (dex.assetName.equals(nextSuperpackFile.getName())) {
            setLastSuperpackFileToClose(nextSuperpackFile);
            synchronized (nextSuperpackFile) {
                if (nextSuperpackFile.mPtr != 0) {
                    superpackFileInputStream = new SuperpackFileInputStream(nextSuperpackFile);
                } else {
                    throw AnonymousClass001.A0N();
                }
            }
            return new InputDex(dex, (InputStream) superpackFileInputStream);
        }
        throw AnonymousClass001.A0V(AnonymousClass0WY.A18("Wrong dex, expected ", dex.assetName, ", got ", nextSuperpackFile.getName()));
    }

    public SuperpackInputDexIterator(Builder builder) {
        super(builder.manifest, builder.qplCollector);
        LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
        if (lightweightQuickPerformanceLogger != null) {
            lightweightQuickPerformanceLogger.markerStart(34603017);
        }
        this.mArchiveExtension = builder.archiveExtension;
        try {
            this.mShuttingDownFlag = false;
            this.mNextDexIndex = 0;
            this.mDexToArchiveMap = builder.dexToArchive;
            int size = builder.rawArchives.size() - 1;
            this.mThreads = new Thread[size];
            this.mFileQueues = new SynchronousQueue[size];
            for (int i = 0; i < size; i++) {
                this.mFileQueues[i] = new SynchronousQueue();
                this.mThreads[i] = new Thread(new UnpackingRunnable((InputStream) builder.rawArchives.get(i + 1), this.mFileQueues[i]));
                this.mThreads[i].start();
            }
            this.mSuperpackArchive = getSuperpackArchive((InputStream) builder.rawArchives.get(0));
        } catch (Throwable th) {
            LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger2 = this.mQplCollector;
            if (lightweightQuickPerformanceLogger2 != null) {
                lightweightQuickPerformanceLogger2.markerEnd(34603017, 2);
            }
            throw th;
        }
    }
}
