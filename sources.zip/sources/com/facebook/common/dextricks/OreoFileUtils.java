package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C18440x7;
import android.content.Context;
import dalvik.system.VMRuntime;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OreoFileUtils {
    public static final OreoFileUtils $redex_init_class = null;

    public static native String getOdexKeyValueNative(String str, String str2);

    static {
        C18440x7.loadLibrary("oreofileutils-jni");
    }

    public static DexErrorRecoveryInfoAsync collectAsyncInfoWithSecondary(Context context, File file) {
        Long l;
        Long l2;
        Long l3;
        Long l4;
        String str;
        Long l5;
        Long l6;
        Context context2 = context;
        File file2 = file;
        List usingOptimizedBaseAndMegazipFiles = usingOptimizedBaseAndMegazipFiles(context2, file2);
        Boolean bool = (Boolean) usingOptimizedBaseAndMegazipFiles.get(0);
        Boolean bool2 = (Boolean) usingOptimizedBaseAndMegazipFiles.get(1);
        Boolean bool3 = (Boolean) usingOptimizedBaseAndMegazipFiles.get(2);
        Boolean bool4 = (Boolean) usingOptimizedBaseAndMegazipFiles.get(3);
        Boolean bool5 = (Boolean) usingOptimizedBaseAndMegazipFiles.get(4);
        DexErrorRecoveryInfoAsync.setAppMetaInfo(DexStoreUtils.getARTVersion(context2), DexStoreUtils.getLastAppInstallOrUpdateTime(context2), DexStoreUtils.getInstallerName(context2));
        Boolean bool6 = Boolean.TRUE;
        Long l7 = null;
        if (bool6.equals(bool)) {
            l = AnonymousClass001.A0R(DexStoreUtils.getBaseOdex(context2));
        } else {
            l = null;
        }
        if (bool6.equals(bool2)) {
            l2 = AnonymousClass001.A0R(DexStoreUtils.getBaseVdex(context2));
        } else {
            l2 = null;
        }
        if (bool6.equals(bool)) {
            l3 = Long.valueOf(DexStoreUtils.getBaseOdex(context2).lastModified());
        } else {
            l3 = null;
        }
        if (bool6.equals(bool2)) {
            l4 = Long.valueOf(DexStoreUtils.getBaseVdex(context2).lastModified());
        } else {
            l4 = null;
        }
        if (bool6.equals(bool)) {
            str = getBaseOdexKeyValue(context2, "dex2oat-cmdline");
        } else {
            str = null;
        }
        if (bool6.equals(bool3)) {
            l5 = AnonymousClass001.A0R(DexStoreUtils.getBaseAppImage(context2));
        } else {
            l5 = null;
        }
        if (bool6.equals(bool3)) {
            l6 = Long.valueOf(DexStoreUtils.getBaseAppImage(context2).lastModified());
        } else {
            l6 = null;
        }
        Long A0R = AnonymousClass001.A0R(DexStoreUtils.getBaseDM(context2));
        Long baselineProfileInDMSize = DexStoreUtils.getBaselineProfileInDMSize(context2);
        Long vDexFileInDMSize = DexStoreUtils.getVDexFileInDMSize(context2);
        String apkDirStr = getApkDirStr(context2);
        if (bool6.equals(bool5)) {
            l7 = Long.valueOf(getImageSize(file2));
        }
        return new DexErrorRecoveryInfoAsync(bool, bool2, bool3, bool4, bool5, l, l2, l3, l4, str, l5, l6, A0R, baselineProfileInDMSize, vDexFileInDMSize, apkDirStr, l7);
    }

    public static DexErrorRecoveryInfoAsync collectBaseAsyncInfo(Context context) {
        Long l;
        Long l2;
        Long l3;
        Long l4;
        String str;
        Long l5;
        Context context2 = context;
        List usingOptimizedBaseFiles = usingOptimizedBaseFiles(context2);
        Boolean bool = (Boolean) usingOptimizedBaseFiles.get(0);
        Boolean bool2 = (Boolean) usingOptimizedBaseFiles.get(1);
        Boolean bool3 = (Boolean) usingOptimizedBaseFiles.get(2);
        DexErrorRecoveryInfoAsync.setAppMetaInfo(DexStoreUtils.getARTVersion(context2), DexStoreUtils.getLastAppInstallOrUpdateTime(context2), DexStoreUtils.getInstallerName(context2));
        Boolean bool4 = Boolean.TRUE;
        Long l6 = null;
        if (bool4.equals(bool)) {
            l = AnonymousClass001.A0R(DexStoreUtils.getBaseOdex(context2));
        } else {
            l = null;
        }
        if (bool4.equals(bool2)) {
            l2 = AnonymousClass001.A0R(DexStoreUtils.getBaseVdex(context2));
        } else {
            l2 = null;
        }
        if (bool4.equals(bool)) {
            l3 = Long.valueOf(DexStoreUtils.getBaseOdex(context2).lastModified());
        } else {
            l3 = null;
        }
        if (bool4.equals(bool2)) {
            l4 = Long.valueOf(DexStoreUtils.getBaseVdex(context2).lastModified());
        } else {
            l4 = null;
        }
        if (bool4.equals(bool)) {
            str = getBaseOdexKeyValue(context2, "dex2oat-cmdline");
        } else {
            str = null;
        }
        if (bool4.equals(bool3)) {
            l5 = AnonymousClass001.A0R(DexStoreUtils.getBaseAppImage(context2));
        } else {
            l5 = null;
        }
        if (bool4.equals(bool3)) {
            l6 = Long.valueOf(DexStoreUtils.getBaseAppImage(context2).lastModified());
        }
        return new DexErrorRecoveryInfoAsync(bool, bool2, bool3, l, l2, l3, l4, str, l5, l6, AnonymousClass001.A0R(DexStoreUtils.getBaseDM(context2)), DexStoreUtils.getBaselineProfileInDMSize(context2), DexStoreUtils.getVDexFileInDMSize(context2), getApkDirStr(context2));
    }

    public static long currentProfileSize(File file) {
        return AnonymousClass001.A0D(file.getParentFile(), AnonymousClass0WY.A0w("oat/", file.getName(), ".cur.prof")).length();
    }

    public static String getBaseOdexDex2OatCmdLine(Context context) {
        return getBaseOdexKeyValue(context, "dex2oat-cmdline");
    }

    public static String getBaseOdexKeyValue(Context context, String str) {
        File baseOdex = DexStoreUtils.getBaseOdex(context);
        if (!baseOdex.exists()) {
            return "";
        }
        try {
            return getOdexKeyValueNative(baseOdex.getCanonicalPath(), str);
        } catch (IOException | RuntimeException unused) {
            return "";
        }
    }

    public static String getFileContents(File file) {
        BufferedReader A08;
        if (file == null || !file.exists()) {
            return "";
        }
        StringBuilder A0m = AnonymousClass001.A0m();
        try {
            A08 = AnonymousClass002.A08(file);
            while (true) {
                String readLine = A08.readLine();
                if (readLine == null) {
                    break;
                }
                A0m.append(readLine);
                A0m.append(10);
            }
            A08.close();
        } catch (IOException unused) {
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
        }
        return A0m.toString();
        throw th;
    }

    public static String getMegazipOdexDex2OatCmdLine(File file) {
        return getMegazipOdexKeyValue(file, "dex2oat-cmdline");
    }

    public static File getReferenceProfile(File file) {
        return AnonymousClass001.A0D(file.getParentFile(), "oat/".concat(file.getName()).concat(".prof"));
    }

    public static boolean alreadyExtractedForCloudPgo(File file) {
        return AnonymousClass001.A1T(file.getParentFile(), "oat/cloud_pgo_extracted");
    }

    public static boolean alreadyPostColdStartSpeedProfile(File file) {
        return AnonymousClass001.A1T(file.getParentFile(), "oat/speed_profile");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        r5.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0059, code lost:
        return r4;
     */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0056 A[EDGE_INSN: B:17:0x0056->B:18:? ?: BREAK  , SYNTHETIC, Splitter:B:17:0x0056] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x002a A[Catch:{ all -> 0x005a, all -> 0x005f, IOException -> 0x0064 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.util.List areFilesMapped(java.util.List r6, java.lang.String r7) {
        /*
            int r1 = r6.size()
            r0 = 0
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            java.util.List r0 = java.util.Collections.nCopies(r1, r0)
            java.util.ArrayList r4 = X.AnonymousClass001.A0v(r0)
            java.io.FileReader r1 = new java.io.FileReader     // Catch:{ IOException -> 0x0064 }
            r1.<init>(r7)     // Catch:{ IOException -> 0x0064 }
            r0 = 128(0x80, float:1.794E-43)
            java.io.BufferedReader r5 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0064 }
            r5.<init>(r1, r0)     // Catch:{ IOException -> 0x0064 }
            r3 = 0
        L_0x001e:
            java.lang.String r2 = r5.readLine()     // Catch:{ all -> 0x005a }
            if (r2 == 0) goto L_0x0056
            int r0 = r6.size()     // Catch:{ all -> 0x005a }
            if (r3 == r0) goto L_0x0056
            r1 = 0
        L_0x002b:
            int r0 = r6.size()     // Catch:{ all -> 0x005a }
            if (r1 >= r0) goto L_0x001e
            java.lang.Object r0 = r4.get(r1)     // Catch:{ all -> 0x005a }
            java.lang.Boolean r0 = (java.lang.Boolean) r0     // Catch:{ all -> 0x005a }
            boolean r0 = r0.booleanValue()     // Catch:{ all -> 0x005a }
            if (r0 != 0) goto L_0x0053
            java.lang.Object r0 = r6.get(r1)     // Catch:{ all -> 0x005a }
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0     // Catch:{ all -> 0x005a }
            boolean r0 = r2.contains(r0)     // Catch:{ all -> 0x005a }
            if (r0 == 0) goto L_0x0053
            r0 = 1
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ all -> 0x005a }
            r4.set(r1, r0)     // Catch:{ all -> 0x005a }
            int r3 = r3 + 1
        L_0x0053:
            int r1 = r1 + 1
            goto L_0x002b
        L_0x0056:
            r5.close()     // Catch:{ IOException -> 0x0064 }
            return r4
        L_0x005a:
            r1 = move-exception
            r5.close()     // Catch:{ all -> 0x005f }
            goto L_0x0063
        L_0x005f:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ IOException -> 0x0064 }
        L_0x0063:
            throw r1     // Catch:{ IOException -> 0x0064 }
        L_0x0064:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.OreoFileUtils.areFilesMapped(java.util.List, java.lang.String):java.util.List");
    }

    public static String getApkDirStr(Context context) {
        File apkDir = DexStoreUtils.getApkDir(context);
        if (apkDir == null) {
            return "";
        }
        try {
            return apkDir.getCanonicalPath();
        } catch (IOException unused) {
            return "";
        }
    }

    public static String getBaseAppImageName(Context context) {
        File apkDir = DexStoreUtils.getApkDir(context);
        if (apkDir == null) {
            return "";
        }
        return apkDir.getName().concat("/oat/").concat(VMRuntime.getRuntime().vmInstructionSet()).concat("/base.art");
    }

    public static String getBaseOdexName(Context context) {
        File apkDir = DexStoreUtils.getApkDir(context);
        if (apkDir == null) {
            return "";
        }
        return apkDir.getName().concat("/oat/").concat(VMRuntime.getRuntime().vmInstructionSet()).concat("/base.odex");
    }

    public static String getBaseVdexName(Context context) {
        File apkDir = DexStoreUtils.getApkDir(context);
        if (apkDir == null) {
            return "";
        }
        return apkDir.getName().concat("/oat/").concat(VMRuntime.getRuntime().vmInstructionSet()).concat("/base.vdex");
    }

    public static long getImageSize(File file) {
        return AnonymousClass001.A0D(getIsaDir(file), getZipNameNoSuffix(file).concat(".art")).length();
    }

    public static File getIsaDir(File file) {
        return AnonymousClass001.A0D(file.getParentFile(), "oat/".concat(VMRuntime.getRuntime().vmInstructionSet()));
    }

    public static String getMegazipAppImageName(File file) {
        return getZipNameNoSuffix(file).concat(".art");
    }

    public static String getMegazipOdexKeyValue(File file, String str) {
        File odex = getOdex(file);
        if (!odex.exists()) {
            return "";
        }
        try {
            return getOdexKeyValueNative(odex.getCanonicalPath(), str);
        } catch (IOException | RuntimeException unused) {
            return "";
        }
    }

    public static File getOdex(File file) {
        return AnonymousClass001.A0D(getIsaDir(file), getOdexName(file));
    }

    public static long getOdexLastModified(File file) {
        return getOdex(file).lastModified();
    }

    public static String getOdexName(File file) {
        return getZipNameNoSuffix(file).concat(DexManifest.ODEX_EXT);
    }

    public static long getOdexSize(File file) {
        return getOdex(file).length();
    }

    public static File getOptLogFile(File file) {
        File file2 = new File(file.getParent(), "oat/opt_log.txt");
        try {
            Files.deleteIfExists(file2.toPath());
            file2.createNewFile();
            return file2;
        } catch (IOException unused) {
            return null;
        }
    }

    public static File getVdex(File file) {
        return AnonymousClass001.A0D(getIsaDir(file), getVdexName(file));
    }

    public static long getVdexLastModified(File file) {
        return getVdex(file).lastModified();
    }

    public static String getVdexName(File file) {
        return getZipNameNoSuffix(file).concat(".vdex");
    }

    public static long getVdexSize(File file) {
        return getVdex(file).length();
    }

    public static String getZipNameNoSuffix(File file) {
        String name = file.getName();
        return name.substring(0, name.lastIndexOf(46));
    }

    public static boolean hasOdex(File file) {
        if (getOdex(file).length() > 0) {
            return true;
        }
        return false;
    }

    public static boolean hasVdexOdex(File file) {
        if (getVdex(file).length() <= 0 || getOdex(file).length() <= 0) {
            return false;
        }
        return true;
    }

    public static boolean isTruncated(File file) {
        if (!file.exists() || file.length() < 102400) {
            return true;
        }
        return false;
    }

    public static void markExtractedForCloudPgo(File file) {
        try {
            AnonymousClass001.A0D(file.getParentFile(), "oat/cloud_pgo_extracted").createNewFile();
        } catch (IOException unused) {
        }
    }

    public static void markPostColdStartSpeedProfile(File file) {
        try {
            AnonymousClass001.A0D(file.getParentFile(), "oat/speed_profile").createNewFile();
        } catch (IOException unused) {
        }
    }

    public static long referenceProfileSize(File file) {
        return getReferenceProfile(file).length();
    }

    public static List usingOptimizedBaseAndMegazipFiles(Context context, File file) {
        String baseOdexName = getBaseOdexName(context);
        String baseVdexName = getBaseVdexName(context);
        String baseAppImageName = getBaseAppImageName(context);
        if (baseOdexName.isEmpty()) {
            return Collections.nCopies(5, false);
        }
        return areFilesMapped(AnonymousClass001.A0v(Arrays.asList(new String[]{baseOdexName, baseVdexName, baseAppImageName, getOdexName(file), getMegazipAppImageName(file)})), "/proc/self/maps");
    }

    public static List usingOptimizedBaseFiles(Context context) {
        String baseOdexName = getBaseOdexName(context);
        String baseVdexName = getBaseVdexName(context);
        String baseAppImageName = getBaseAppImageName(context);
        if (baseOdexName.isEmpty()) {
            return Collections.nCopies(3, false);
        }
        return areFilesMapped(AnonymousClass001.A0v(Arrays.asList(new String[]{baseOdexName, baseVdexName, baseAppImageName})), "/proc/self/maps");
    }

    public static List areFilesMapped(List list) {
        return areFilesMapped(list, "/proc/self/maps");
    }
}
