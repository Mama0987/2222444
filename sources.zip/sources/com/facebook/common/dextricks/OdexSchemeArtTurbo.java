package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0TR;
import X.AnonymousClass0WY;
import android.os.Build;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.DexStore;
import com.facebook.common.dextricks.OdexScheme;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class OdexSchemeArtTurbo extends OdexScheme {
    public static final String OREO_ODEX_DIR = "oat";
    public static boolean sAttemptedArtHackInstallation;

    public final class TurboArtCompiler extends OdexScheme.Compiler {
        public final DexStore mDexStore;
        public final int mFlags;
        public final DexStore.TmpDir mTmpDir;

        public void close() {
            this.mTmpDir.close();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0055, code lost:
            if (r2 == -1) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0057, code lost:
            r10.write(r9, 0, r2);
            r4 = r4 + r2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x005b, code lost:
            if (r4 >= Integer.MAX_VALUE) goto L_0x005e;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void compile(com.facebook.common.dextricks.InputDex r14) {
            /*
                r13 = this;
                com.facebook.common.dextricks.DexManifest$Dex r0 = r14.dex
                java.lang.String r8 = r0.makeDexName()
                com.facebook.common.dextricks.DexStore r0 = r13.mDexStore
                java.io.File r0 = r0.root
                java.io.File r1 = X.AnonymousClass001.A0D(r0, r8)
                int r0 = r13.mFlags
                r0 = r0 & 1
                if (r0 == 0) goto L_0x001b
                boolean r0 = r1.exists()
                if (r0 == 0) goto L_0x001b
                return
            L_0x001b:
                com.facebook.common.dextricks.DexStore$TmpDir r0 = r13.mTmpDir
                java.io.File r0 = r0.directory
                java.io.File r7 = X.AnonymousClass001.A0D(r0, r8)
                java.io.InputStream r6 = r14.getDexContents()
                r14.getSizeHint(r6)     // Catch:{ all -> 0x007c }
                java.io.RandomAccessFile r10 = X.AnonymousClass001.A0I(r7)     // Catch:{ all -> 0x007c }
                r11 = 32768(0x8000, float:4.5918E-41)
                byte[] r9 = new byte[r11]     // Catch:{ all -> 0x0072 }
                r5 = 2147483647(0x7fffffff, float:NaN)
                boolean r0 = X.C13060mv.A00     // Catch:{ all -> 0x0072 }
                r12 = 0
                r4 = 0
            L_0x003a:
                int r0 = r5 - r4
                int r3 = java.lang.Math.min(r11, r0)     // Catch:{ all -> 0x0072 }
                r2 = 0
            L_0x0041:
                if (r2 >= r3) goto L_0x0054
                int r0 = r3 - r2
                int r1 = r6.read(r9, r2, r0)     // Catch:{ all -> 0x0072 }
                if (r1 >= 0) goto L_0x004c
                goto L_0x004e
            L_0x004c:
                int r2 = r2 + r1
                goto L_0x0041
            L_0x004e:
                r0 = -1
                if (r1 != r0) goto L_0x0054
                if (r2 != 0) goto L_0x0054
                goto L_0x005e
            L_0x0054:
                r0 = -1
                if (r2 == r0) goto L_0x005e
                r10.write(r9, r12, r2)     // Catch:{ all -> 0x0072 }
                int r4 = r4 + r2
                if (r4 >= r5) goto L_0x005e
                goto L_0x003a
            L_0x005e:
                r10.close()     // Catch:{ all -> 0x007c }
                if (r6 == 0) goto L_0x0066
                r6.close()
            L_0x0066:
                com.facebook.common.dextricks.DexStore r0 = r13.mDexStore
                java.io.File r0 = r0.root
                java.io.File r0 = X.AnonymousClass001.A0D(r0, r8)
                com.facebook.common.dextricks.Fs.renameOrThrow(r7, r0)
                return
            L_0x0072:
                r1 = move-exception
                r10.close()     // Catch:{ all -> 0x0077 }
                goto L_0x007b
            L_0x0077:
                r0 = move-exception
                X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ all -> 0x007c }
            L_0x007b:
                throw r1     // Catch:{ all -> 0x007c }
            L_0x007c:
                r1 = move-exception
                if (r6 == 0) goto L_0x0087
                r6.close()     // Catch:{ all -> 0x0083 }
                throw r1
            L_0x0083:
                r0 = move-exception
                X.AnonymousClass0ZM.A00(r1, r0)
            L_0x0087:
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.OdexSchemeArtTurbo.TurboArtCompiler.compile(com.facebook.common.dextricks.InputDex):void");
        }

        public TurboArtCompiler(DexStore dexStore, int i) {
            this.mDexStore = dexStore;
            this.mFlags = i;
            this.mTmpDir = dexStore.makeTemporaryDirectory("turbo-art-compiler");
        }
    }

    public static List makeExpectedFileInfoList(DexManifest.Dex[] dexArr, String str) {
        int length = dexArr.length;
        int i = length;
        if (str != null) {
            length++;
        }
        ArrayList A0u = AnonymousClass001.A0u(length);
        for (int i2 = 0; i2 < i; i2++) {
            A0u.add(new ExpectedFileInfo(dexArr[i2]));
        }
        if (str != null) {
            A0u.add(new ExpectedFileInfo(str));
        }
        return A0u;
    }

    public static String getArch() {
        String str = Build.SUPPORTED_32_BIT_ABIS[0];
        if (str.equals("x86")) {
            return "x86";
        }
        if (str.equals("armeabi-v7a")) {
            return "arm";
        }
        throw AnonymousClass0WY.A0A("Unknown ABI ", str);
    }

    public static String getOreoOdexOutputDirectory(File file, boolean z) {
        File A01 = AnonymousClass0WY.A01("oat/", getArch(), file);
        if (z) {
            Fs.mkdirOrThrow(A01);
        }
        return AnonymousClass0WY.A0i(A01.getPath(), "/");
    }

    public static String[] makeExpectedFileListFrom(List list) {
        if (list == null) {
            return null;
        }
        int size = list.size();
        String[] strArr = new String[size];
        for (int i = 0; i < size; i++) {
            strArr[i] = ((ExpectedFileInfo) list.get(i)).toExpectedFileString();
        }
        return strArr;
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
        int i = Build.VERSION.SDK_INT;
        int i2 = 0;
        if (i < 29) {
            i2 = 6;
        }
        if (!sAttemptedArtHackInstallation) {
            sAttemptedArtHackInstallation = true;
            try {
                int installArtHacks = DalvikInternals.installArtHacks(i2, i);
                if ((i2 & 2) != 0 && (installArtHacks & 2) == 0) {
                    AnonymousClass0TR.A00(100, "OdexSchemeArtTurbo", (Throwable) null, AnonymousClass0WY.A0i("Could not install 0x", Integer.toHexString(2)));
                }
            } catch (Exception e) {
                Mlog.w(e, "failed to install verifier-disabling ART hacks; continuing slowly", new Object[0]);
            }
        }
        int enabledThreadArtHacks = DalvikInternals.getEnabledThreadArtHacks();
        DalvikInternals.setEnabledThreadArtHacks(i2 | enabledThreadArtHacks);
        int i3 = 0;
        while (true) {
            try {
                String[] strArr = this.expectedFiles;
                if (i3 < strArr.length) {
                    if (!strArr[i3].equals(OREO_ODEX_DIR)) {
                        classLoaderConfiguration.addDex(AnonymousClass001.A0D(file, strArr[i3]), true);
                    }
                    i3++;
                } else {
                    return;
                }
            } finally {
                DalvikInternals.setEnabledThreadArtHacks(enabledThreadArtHacks);
            }
        }
    }

    public final OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        return new TurboArtCompiler(dexStore, i);
    }

    public static String[] makeExpectedFileList(DexManifest.Dex[] dexArr, String str) {
        return makeExpectedFileListFrom(makeExpectedFileInfoList(dexArr, str));
    }

    public String getSchemeName() {
        return "OdexSchemeArtTurbo";
    }

    public OdexSchemeArtTurbo(int i, String[] strArr) {
        super(i, strArr);
    }

    public OdexSchemeArtTurbo(DexManifest.Dex[] dexArr) {
        super(8, makeExpectedFileListFrom(makeExpectedFileInfoList(dexArr, (String) null)));
    }
}
