package com.facebook.common.dextricks;

import android.content.Context;

public final class MemoryEnlargementHack {
    public static final String TAG = "MemoryEnlargementHack";

    public static void growMyHeap(Context context) {
        if ((context.getApplicationInfo().flags & Constants.LOAD_RESULT_NEED_REOPTIMIZATION) == 0) {
            Class<?> cls = Class.forName("dalvik.system.VMRuntime");
            cls.getMethod("clearGrowthLimit", (Class[]) null).invoke(cls.getMethod("getRuntime", (Class[]) null).invoke((Object) null, (Object[]) null), (Object[]) null);
        }
    }
}
