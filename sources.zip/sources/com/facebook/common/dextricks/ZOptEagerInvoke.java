package com.facebook.common.dextricks;

import X.AnonymousClass001;
import android.content.Context;

public class ZOptEagerInvoke {
    public static void run(Context context) {
        try {
            Class.forName("com.facebook.common.zopt.ZOpt").getMethod("notePostColdStart", new Class[]{Context.class, Boolean.class}).invoke((Object) null, new Object[]{context, null});
        } catch (Exception e) {
            throw AnonymousClass001.A0X(e);
        }
    }
}
