package com.facebook.common.dextricks;

public class DalvikConstants {
    public static final int FB4A_LINEAR_ALLOC_BUFFER_SIZE = 8388608;
    public static int FB_REDEX_COLD_START_SET_DEX_COUNT = 2;
    public static int FB_REDEX_SCROLL_SET_DEX_COUNT = 1;
    public static boolean FB_REDEX_VERIFY_NONE_ENABLED = false;
    public static final int MESSENGER_LINEAR_ALLOC_BUFFER_SIZE = 4194304;
    public static final int SAMPLE_APP_LINEAR_ALLOC_BUFFER_SIZE = 4194304;
}
