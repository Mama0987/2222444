package com.facebook.common.dextricks.fallback;

public abstract class FallbackDexLoader {
    public static volatile FallbackDexLoader A00;

    public abstract boolean A03(String str, String str2);
}
