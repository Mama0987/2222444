package com.facebook.common.dextricks;

public final class FatalDexError extends Error {
    public FatalDexError(Throwable th) {
        super(th);
    }
}
