package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.C12790mK;
import android.app.Application;
import android.os.Process;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class ProcessHelper {
    public static final String TAG = "ProcessHelper";
    public static String cachedProcessName;

    public static synchronized String getProcessNameByPid(int i) {
        String str;
        synchronized (ProcessHelper.class) {
            str = cachedProcessName;
            if (str == null) {
                C12790mK.A01(TAG, "Enter slow path of getProcessNameByPid");
                str = "";
                try {
                    File A0E = AnonymousClass001.A0E(AnonymousClass0WY.A0t("/proc/", "/cmdline", i));
                    if (A0E.exists() && A0E.canRead()) {
                        BufferedReader A08 = AnonymousClass002.A08(A0E);
                        String readLine = A08.readLine();
                        if (readLine != null) {
                            str = readLine.trim();
                        }
                        A08.close();
                    }
                } catch (IOException e) {
                    C12790mK.A02(TAG, AnonymousClass0WY.A0d("Unable to get process name for pid from /proc", i), e);
                }
                cachedProcessName = str;
            }
        }
        return str;
    }

    public static boolean isAppZygoteProcess(int i) {
        String processName = Application.getProcessName();
        if (processName == null) {
            processName = getProcessNameByPid(Process.myPid());
        }
        return processName.contains("_zygote");
    }

    public static boolean isIsolated() {
        return Process.isIsolated();
    }

    public static boolean isIsolatedOrAppZygoteProcess() {
        if (Process.isIsolated() || isAppZygoteProcess(Process.myPid())) {
            return true;
        }
        return false;
    }
}
