package com.facebook.common.dextricks.classid;

import X.AnonymousClass001;
import android.os.Build;
import com.facebook.common.dextricks.DexStore;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

public class ClassId {
    public static Field javaLangClass_dexCache;
    public static Field javaLangClass_dexClassDefIndex;
    public static Method javaLangClass_getDexClassDefIndex;
    public static Field javaLangDexCache_dexFile;
    public static final ConcurrentHashMap sDexKeyToDexSignature;
    public static final boolean sInitialized;

    /*  JADX ERROR: JadxRuntimeException in pass: BlockFinish
        jadx.core.utils.exceptions.JadxRuntimeException: Dominance frontier not set for block: B:19:0x0059
        	at jadx.core.dex.nodes.BlockNode.lock(BlockNode.java:75)
        	at jadx.core.utils.ImmutableList.forEach(ImmutableList.java:108)
        	at jadx.core.dex.nodes.MethodNode.finishBasicBlocks(MethodNode.java:472)
        	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:27)
        */
    static {
        /*
            r3 = 0
            java.lang.String r0 = "classid"
            X.C18440x7.loadLibrary(r0)     // Catch:{ UnsatisfiedLinkError -> 0x0008 }
            r2 = 1
            goto L_0x0011
        L_0x0008:
            r2 = move-exception
            java.lang.String r1 = "ClassId"
            java.lang.String r0 = "Failed to load native library"
            android.util.Log.w(r1, r0, r2)
            r2 = 0
        L_0x0011:
            r1 = 1063675494(0x3f666666, float:0.9)
            java.util.concurrent.ConcurrentHashMap r0 = new java.util.concurrent.ConcurrentHashMap
            r0.<init>(r3, r1)
            sDexKeyToDexSignature = r0
            if (r2 == 0) goto L_0x005e
            java.lang.Class<com.facebook.common.dextricks.classid.ClassId> r5 = com.facebook.common.dextricks.classid.ClassId.class
            monitor-enter(r5)
            java.lang.Class<java.lang.Class> r1 = java.lang.Class.class
            r4 = 1
            java.lang.String r0 = "dexClassDefIndex"
            java.lang.reflect.Field r3 = r1.getDeclaredField(r0)     // Catch:{ Exception -> 0x0056 }
            java.lang.String r0 = "dexCache"
            java.lang.reflect.Field r2 = r1.getDeclaredField(r0)     // Catch:{ Exception -> 0x0056 }
            java.lang.String r0 = "java.lang.DexCache"
            java.lang.Class r1 = java.lang.Class.forName(r0)     // Catch:{ Exception -> 0x0056 }
            r3.setAccessible(r4)     // Catch:{ Exception -> 0x0056 }
            r2.setAccessible(r4)     // Catch:{ Exception -> 0x0056 }
            javaLangClass_dexClassDefIndex = r3     // Catch:{ Exception -> 0x0056 }
            javaLangClass_dexCache = r2     // Catch:{ Exception -> 0x0056 }
            java.lang.String r0 = "dexFile"
            java.lang.reflect.Field r0 = X.AnonymousClass001.A0s(r1, r0)     // Catch:{ Exception -> 0x0056 }
            javaLangDexCache_dexFile = r0     // Catch:{ Exception -> 0x0056 }
            getClassDef(r5)     // Catch:{ Exception -> 0x0056 }
            int r0 = getDexSignature(r5)     // Catch:{ Exception -> 0x0056 }
            if (r0 == 0) goto L_0x0051
            goto L_0x005c
        L_0x0051:
            java.lang.UnsupportedOperationException r0 = X.AnonymousClass001.A0q()     // Catch:{ Exception -> 0x0056 }
            throw r0     // Catch:{ Exception -> 0x0056 }
        L_0x0056:
            monitor-exit(r5)
            r3 = 0
            goto L_0x005e
        L_0x0059:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x0059 }
            throw r0
        L_0x005c:
            monitor-exit(r5)
            r3 = 1
        L_0x005e:
            sInitialized = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.classid.ClassId.<clinit>():void");
    }

    public static native int getSignatureFromDexFile_10_0_0(long j);

    public static native int getSignatureFromDexFile_11_0_0(long j);

    public static native int getSignatureFromDexFile_8_0_0(long j);

    public static native int getSignatureFromDexFile_8_1_0(long j);

    public static native int getSignatureFromDexFile_9_0_0(long j);

    public static int getClassDef(Class cls) {
        try {
            Field field = javaLangClass_dexClassDefIndex;
            if (field != null) {
                return ((Integer) field.get(cls)).intValue();
            }
            Method method = javaLangClass_getDexClassDefIndex;
            if (method != null) {
                return ((Integer) method.invoke(cls, (Object[]) null)).intValue();
            }
            throw AnonymousClass001.A0N();
        } catch (Exception e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public static long getClassId(Class cls) {
        if (!sInitialized) {
            return -1;
        }
        return (((long) getDexSignature(cls)) & 4294967295L) | (((long) getClassDef(cls)) << 32);
    }

    public static int getDexSignature(Class cls) {
        int i;
        try {
            if (javaLangDexCache_dexFile != null) {
                Object obj = javaLangClass_dexCache.get(cls);
                if (obj == null) {
                    return 0;
                }
                ConcurrentHashMap concurrentHashMap = sDexKeyToDexSignature;
                Number number = (Number) concurrentHashMap.get(obj);
                if (number == null) {
                    long j = javaLangDexCache_dexFile.getLong(obj);
                    switch (Build.VERSION.SDK_INT) {
                        case 28:
                            i = getSignatureFromDexFile_9_0_0(j);
                            break;
                        case 29:
                            i = getSignatureFromDexFile_10_0_0(j);
                            break;
                        case 30:
                        case DexStore.Config.FLAGS_CONTROL_UNPACK /*31*/:
                        case 32:
                        case 33:
                        case 34:
                        case 35:
                            i = getSignatureFromDexFile_11_0_0(j);
                            break;
                        default:
                            i = 0;
                            break;
                    }
                    number = Integer.valueOf(i);
                    concurrentHashMap.put(obj, number);
                }
                return number.intValue();
            }
            throw AnonymousClass001.A0N();
        } catch (IOException | IllegalAccessException | InvocationTargetException e) {
            throw AnonymousClass001.A0X(e);
        }
    }
}
