package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.C12790mK;
import android.os.Build;
import com.facebook.common.dextricks.classifier.NameClassifier;
import com.facebook.common.dextricks.fallback.FallbackDexLoader;
import com.facebook.common.dextricks.halfnosis.Halfnosis;
import dalvik.system.BaseDexClassLoader;
import dalvik.system.DelegateLastClassLoader;

public abstract class ReflectionClassLoader extends ClassLoader {
    public static final ClassLoader APP_CLASSLOADER;
    public static final String TAG = "ReflectionClassLoader";
    public static volatile ReflectionClassLoader sInstalledClassLoader;
    public final ClassLoader mPutativeLoader = APP_CLASSLOADER;

    public static boolean allowedVersion(boolean z) {
        return z || Build.VERSION.SDK_INT >= 33;
    }

    static {
        try {
            APP_CLASSLOADER = ReflectionClassLoader.class.getClassLoader();
        } catch (Exception e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public static ReflectionClassLoader createReflectionClassLoader() {
        return new ReflectionClassLoader();
    }

    public static synchronized ReflectionClassLoader install() {
        synchronized (ReflectionClassLoader.class) {
            if (ProcessHelper.isIsolatedOrAppZygoteProcess()) {
                C12790mK.A01(TAG, "Not targeting isolated or app_zyoget process.");
            } else {
                C12790mK.A01(TAG, "Not targeting this build or os version.");
            }
        }
        return null;
    }

    public static boolean isInstalled() {
        if (sInstalledClassLoader != null) {
            return true;
        }
        return false;
    }

    public static boolean isUsingDelegateLastClassLoader() {
        return APP_CLASSLOADER instanceof DelegateLastClassLoader;
    }

    public static final boolean maybeFallbackLoadDexes(String str) {
        String str2;
        FallbackDexLoader fallbackDexLoader = FallbackDexLoader.A00;
        if (fallbackDexLoader == null) {
            return false;
        }
        if (NameClassifier.A01(MultiDexClassLoaderJava.sEncodedLongtailUnrenamedTypes, str)) {
            str2 = Halfnosis.getLongtailModuleName();
        } else {
            str2 = null;
        }
        new ClassNotFoundException(str);
        return fallbackDexLoader.A03(str, str2);
    }

    public void addDexPathFromConfig(ClassLoaderConfiguration classLoaderConfiguration) {
        classLoaderConfiguration.addDexFileToClassLoaderPath((BaseDexClassLoader) this.mPutativeLoader);
    }

    public static boolean isDoppelDexBuild() {
        return false;
    }
}
