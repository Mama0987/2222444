package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import com.facebook.common.dextricks.OdexScheme;
import java.io.File;

public final class OdexSchemeInvalid extends OdexScheme {
    public final long mStatus;

    public OdexSchemeInvalid(long j) {
        super(2, new String[0]);
        this.mStatus = j;
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
        throw AnonymousClass001.A0r(AnonymousClass0WY.A0i("invalid state: ", Long.toHexString(this.mStatus)));
    }

    public OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        throw AnonymousClass001.A0r(AnonymousClass0WY.A0i("invalid state: ", Long.toHexString(this.mStatus)));
    }

    public String getSchemeName() {
        return "OdexSchemeInvalid";
    }
}
