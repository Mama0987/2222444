package com.facebook.common.dextricks;

import X.AnonymousClass0WY;
import com.facebook.common.dextricks.SuperpackInputDexIterator;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;

public class DexIteratorFactory {
    public static final String SECONDARY_XZS_FILENAME = "secondary.dex.jar.xzs";
    public static final String XZS_EXTENSION = ".dex.jar.xzs";
    public final ResProvider mResProvider;

    private SuperpackInputDexIterator openSuperpackDexIterator(DexManifest dexManifest, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        SuperpackInputDexIterator.Builder builder = new SuperpackInputDexIterator.Builder(dexManifest, lightweightQuickPerformanceLogger);
        String archiveExtension = SuperpackInputDexIterator.getArchiveExtension(builder);
        for (int i = 0; i < dexManifest.superpackFiles; i++) {
            builder.addRawArchive(this.mResProvider.open(AnonymousClass0WY.A0t("store-", archiveExtension, i)));
        }
        for (int i2 = 0; i2 < dexManifest.dexes.length; i2++) {
            builder.assignDexToArchive(i2, i2 % dexManifest.superpackFiles);
        }
        return builder.build();
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0025 A[SYNTHETIC, Splitter:B:15:0x0025] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.facebook.common.dextricks.InputDexIterator openDexIterator(java.lang.String r4, com.facebook.common.dextricks.DexManifest r5, com.facebook.quicklog.LightweightQuickPerformanceLogger r6, android.content.Context r7) {
        /*
            r3 = this;
            int r0 = r5.superpackFiles
            if (r0 <= 0) goto L_0x0009
            com.facebook.common.dextricks.SuperpackInputDexIterator r1 = r3.openSuperpackDexIterator(r5, r6)
            return r1
        L_0x0009:
            r2 = 0
            if (r4 == 0) goto L_0x001b
            java.lang.String r0 = "dex"
            boolean r0 = r0.equals(r4)     // Catch:{ all -> 0x003c }
            if (r0 != 0) goto L_0x001b
            java.lang.String r0 = ".dex.jar.xzs"
            java.lang.String r1 = r4.concat(r0)     // Catch:{ all -> 0x003c }
            goto L_0x001d
        L_0x001b:
            java.lang.String r1 = "secondary.dex.jar.xzs"
        L_0x001d:
            com.facebook.common.dextricks.ResProvider r0 = r3.mResProvider     // Catch:{ FileNotFoundException -> 0x002d }
            java.io.InputStream r2 = r0.open(r1)     // Catch:{ FileNotFoundException -> 0x002d }
            if (r2 == 0) goto L_0x002d
            com.facebook.common.dextricks.ResProvider r0 = r3.mResProvider     // Catch:{ all -> 0x0035 }
            com.facebook.common.dextricks.SolidXzInputDexIterator r1 = new com.facebook.common.dextricks.SolidXzInputDexIterator     // Catch:{ all -> 0x0035 }
            r1.<init>(r5, r6, r0, r2)     // Catch:{ all -> 0x0035 }
            return r1
        L_0x002d:
            com.facebook.common.dextricks.ResProvider r0 = r3.mResProvider     // Catch:{ all -> 0x0035 }
            com.facebook.common.dextricks.DiscreteFileInputDexIterator r1 = new com.facebook.common.dextricks.DiscreteFileInputDexIterator     // Catch:{ all -> 0x0035 }
            r1.<init>(r5, r0)     // Catch:{ all -> 0x0035 }
            return r1
        L_0x0035:
            r0 = move-exception
            if (r2 == 0) goto L_0x003b
            com.facebook.common.dextricks.Fs.safeClose((java.io.Closeable) r2)
        L_0x003b:
            throw r0
        L_0x003c:
            r0 = move-exception
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexIteratorFactory.openDexIterator(java.lang.String, com.facebook.common.dextricks.DexManifest, com.facebook.quicklog.LightweightQuickPerformanceLogger, android.content.Context):com.facebook.common.dextricks.InputDexIterator");
    }

    public DexIteratorFactory(ResProvider resProvider) {
        this.mResProvider = resProvider;
    }
}
