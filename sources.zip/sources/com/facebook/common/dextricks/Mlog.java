package com.facebook.common.dextricks;

import X.AnonymousClass0WY;
import X.C12790mK;
import android.util.Log;

public final class Mlog {
    public static final String TAG = "DexLibLoader";
    public static final boolean VERBOSE = true;

    public static void assertThat(boolean z, String str, Object... objArr) {
        if (!z) {
            String A00 = C12790mK.A00(str, objArr);
            Log.e(TAG, A00);
            throw new AssertionError(AnonymousClass0WY.A0w(TAG, ": ", A00));
        }
    }

    public static void e(String str, Object... objArr) {
        Log.e(TAG, C12790mK.A00(str, objArr));
    }

    public static void w(String str, Object... objArr) {
        C12790mK.A02(TAG, str, objArr);
    }

    public static void d(String str, Object... objArr) {
    }

    public static void i(String str, Object... objArr) {
    }

    public static void v(String str, Object... objArr) {
    }

    public static void e(Throwable th, String str, Object... objArr) {
        Log.e(TAG, C12790mK.A00(str, objArr), th);
    }

    public static void w(Throwable th, String str, Object... objArr) {
        C12790mK.A02(TAG, str, objArr, th);
    }

    public static void d(Throwable th, String str, Object... objArr) {
    }

    public static void i(Throwable th, String str, Object... objArr) {
    }

    public static void v(Throwable th, String str, Object... objArr) {
    }
}
