package com.facebook.common.dextricks;

public final /* synthetic */ class ClassLoadsRecorder$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ ClassLoadsRecorder f$0;

    public final void run() {
        this.f$0.writeToFile();
    }

    public /* synthetic */ ClassLoadsRecorder$$ExternalSyntheticLambda0(ClassLoadsRecorder classLoadsRecorder) {
        this.f$0 = classLoadsRecorder;
    }
}
