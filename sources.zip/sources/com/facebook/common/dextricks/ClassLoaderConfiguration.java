package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.C12790mK;
import android.util.Log;
import dalvik.system.BaseDexClassLoader;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;

public class ClassLoaderConfiguration {
    public static final int BASE_DEX_RETRY_WAIT_MS = 500;
    public static final int LOAD_SECONDARY = 4;
    public static final int MAX_LOAD_DEX_RETRY = 3;
    public static final int SUPPORTS_LOCATORS = 2;
    public static final String TAG = "ClassLoaderConfiguration";
    public final ArrayList coldstartDexBaseNames = AnonymousClass001.A0t();
    public final int coldstartDexCount;
    public int configFlags;
    public boolean disableVerifier;
    public final ArrayList mDexFiles = AnonymousClass001.A0t();

    public void addDex(File file, File file2) {
        addDex(file, file2, false);
    }

    private void appendColdstartDexBaseName(File file) {
        if (this.coldstartDexBaseNames.size() < this.coldstartDexCount) {
            String name = file.getName();
            String A0f = AnonymousClass001.A0f(name, name.indexOf(46));
            this.coldstartDexBaseNames.add(A0f);
            DalvikInternals.addDexBaseNames(A0f);
        }
    }

    public void addDexFileToClassLoaderPath(BaseDexClassLoader baseDexClassLoader) {
        ArrayList A0t = AnonymousClass001.A0t();
        Iterator it = this.mDexFiles.iterator();
        while (it.hasNext()) {
            A0t.add(AnonymousClass001.A0E(((DexFile) it.next()).getName()));
        }
        try {
            IOException[] threadSafeAddDexPathSynchronized = OdexSchemeOreo.threadSafeAddDexPathSynchronized(baseDexClassLoader, A0t);
            if (threadSafeAddDexPathSynchronized != null) {
                C12790mK.A02(TAG, "%d suppressed exceptions were found in BaseDexClassLoader.", Integer.valueOf(r5));
                Iterator it2 = A0t.iterator();
                while (it2.hasNext()) {
                    C12790mK.A02(TAG, "Dex file: %s", it2.next());
                }
                for (IOException w : threadSafeAddDexPathSynchronized) {
                    Log.w(TAG, C12790mK.A00("Suppressed exception:", new Object[0]), w);
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | NoSuchFieldException | NoSuchMethodException | InvocationTargetException e) {
            throw AnonymousClass001.A0W("ClassLoaderConfigurationfail to add dex file to class loader path", e);
        }
    }

    public int getNumberConfiguredDexFiles() {
        return this.mDexFiles.size();
    }

    public ClassLoaderConfiguration(int i, int i2) {
        this.configFlags = i;
        this.coldstartDexCount = i2;
        this.disableVerifier = false;
    }

    public int getConfigFlags() {
        return this.configFlags;
    }

    public boolean getDisableVerifier() {
        return this.disableVerifier;
    }

    public void setConfigFlags(int i) {
        this.configFlags = i;
    }

    public void setDisableVerifier(boolean z) {
        this.disableVerifier = z;
    }

    public ClassLoaderConfiguration(int i, int i2, boolean z) {
        this.configFlags = i;
        this.coldstartDexCount = i2;
        this.disableVerifier = z;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0024, code lost:
        if (r1 != null) goto L_0x0026;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0026, code lost:
        r8.mDexFiles.add(r1);
        appendColdstartDexBaseName(r9);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002e, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void addDex(java.io.File r9, java.io.File r10, boolean r11) {
        /*
            r8 = this;
            java.lang.String r4 = r9.getCanonicalPath()
            r5 = 0
            if (r10 == 0) goto L_0x000b
            java.lang.String r5 = r10.getCanonicalPath()
        L_0x000b:
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 33
            r6 = 0
            if (r1 < r0) goto L_0x0015
            r9.setWritable(r6)
        L_0x0015:
            r3 = 0
        L_0x0016:
            int r3 = r3 + 1
            r7 = 3
            java.lang.String r0 = r9.getCanonicalPath()     // Catch:{ IOException -> 0x003e }
            dalvik.system.DexFile r1 = dalvik.system.DexFile.loadDex(r0, r5, r6)     // Catch:{ IOException -> 0x003e }
            if (r11 == 0) goto L_0x0024
            goto L_0x002f
        L_0x0024:
            if (r1 == 0) goto L_0x0033
        L_0x0026:
            java.util.ArrayList r0 = r8.mDexFiles
            r0.add(r1)
            r8.appendColdstartDexBaseName(r9)
            return
        L_0x002f:
            if (r1 != 0) goto L_0x0026
            if (r3 <= r7) goto L_0x004c
        L_0x0033:
            java.lang.String r0 = "Could not load dex file "
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r0, r4)
            java.io.IOException r0 = X.AnonymousClass001.A0G(r0)
            throw r0
        L_0x003e:
            r2 = move-exception
            java.lang.Object[] r1 = new java.lang.Object[]{r4, r2}
            java.lang.String r0 = "ClassLoaderConfiguration Failed loading dex ( %s )"
            com.facebook.common.dextricks.Mlog.w(r0, r1)
            if (r11 == 0) goto L_0x005d
            if (r7 < r3) goto L_0x005d
        L_0x004c:
            if (r3 <= 0) goto L_0x0016
            int r0 = r3 * 500
            long r0 = (long) r0
            java.lang.Thread.sleep(r0)     // Catch:{ InterruptedException -> 0x0055 }
            goto L_0x0016
        L_0x0055:
            java.lang.Thread r0 = java.lang.Thread.currentThread()
            r0.interrupt()
            goto L_0x0016
        L_0x005d:
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ClassLoaderConfiguration.addDex(java.io.File, java.io.File, boolean):void");
    }

    public void addDex(File file, boolean z) {
        addDex(file, (File) null, z);
    }

    public void addDex(File file) {
        addDex(file, (File) null, false);
    }

    public void addDex(DexFile dexFile) {
        this.mDexFiles.add(dexFile);
    }
}
