package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import com.facebook.xzdecoder.XzInputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStream;
import java.io.InputStreamReader;

public final class SolidXzInputDexIterator extends InputDexIterator {
    public boolean mConsumingStream;
    public SliceInputStream mLastPartIs;
    public final ResProvider mResProvider;
    public final XzInputStream mXzs;

    public final class SliceInputStream extends InputStream {
        public int mBytesRead = 0;
        public int mBytesToRead;

        public SliceInputStream(int i) {
            this.mBytesToRead = i;
            SolidXzInputDexIterator.this.mConsumingStream = true;
        }

        public int available() {
            return this.mBytesToRead - this.mBytesRead;
        }

        public void close() {
            SolidXzInputDexIterator.this.mConsumingStream = false;
        }

        public int read(byte[] bArr, int i, int i2) {
            if (i2 > 0 && this.mBytesRead == this.mBytesToRead) {
                return -1;
            }
            int read = SolidXzInputDexIterator.this.mXzs.read(bArr, i, Math.min(i2, this.mBytesToRead - this.mBytesRead));
            if (read <= 0) {
                return read;
            }
            this.mBytesRead += read;
            return read;
        }

        public int read() {
            if (this.mBytesRead == this.mBytesToRead) {
                return -1;
            }
            int read = SolidXzInputDexIterator.this.mXzs.read();
            if (read != -1) {
                this.mBytesRead++;
                return read;
            }
            throw AnonymousClass001.A0V("truncated xzs stream");
        }
    }

    public void close() {
        try {
            Fs.safeClose((Closeable) this.mXzs);
        } finally {
            LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
            if (lightweightQuickPerformanceLogger != null) {
                lightweightQuickPerformanceLogger.markerEnd(34603012, 2);
            }
        }
    }

    public InputDex nextImpl(DexManifest.Dex dex) {
        if (!this.mConsumingStream) {
            SliceInputStream sliceInputStream = this.mLastPartIs;
            if (sliceInputStream != null) {
                int available = sliceInputStream.available();
                if (available > 0) {
                    Fs.discardFromInputStream(sliceInputStream, (long) available);
                }
                this.mLastPartIs = null;
            }
            SliceInputStream sliceInputStream2 = new SliceInputStream(getJarFileSizeFromMeta(this.mResProvider, AnonymousClass0WY.A0i(dex.assetName, ".meta")));
            this.mLastPartIs = sliceInputStream2;
            return new InputDex(dex, (InputStream) sliceInputStream2);
        }
        throw AnonymousClass001.A0V("previous InputDex not closed");
    }

    public SolidXzInputDexIterator(DexManifest dexManifest, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger, ResProvider resProvider, InputStream inputStream) {
        super(dexManifest, lightweightQuickPerformanceLogger);
        this.mResProvider = resProvider;
        this.mXzs = new XzInputStream(inputStream);
        if (lightweightQuickPerformanceLogger != null) {
            lightweightQuickPerformanceLogger.markerStart(34603012);
        }
    }

    private int getJarFileSizeFromMeta(ResProvider resProvider, String str) {
        BufferedReader bufferedReader;
        InputStream open = resProvider.open(str);
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(open);
            try {
                bufferedReader = new BufferedReader(inputStreamReader);
                String readLine = bufferedReader.readLine();
                String A0f = AnonymousClass001.A0f(readLine, readLine.indexOf(32));
                int parseInt = Integer.parseInt(AnonymousClass001.A0Z(A0f.indexOf(58), A0f));
                bufferedReader.close();
                inputStreamReader.close();
                if (open != null) {
                    open.close();
                }
                return parseInt;
            } catch (Throwable th) {
                inputStreamReader.close();
                throw th;
            }
            throw th;
        } catch (Throwable th2) {
            if (open != null) {
                try {
                    open.close();
                    throw th2;
                } catch (Throwable th3) {
                    AnonymousClass0ZM.A00(th2, th3);
                    throw th2;
                }
            }
            throw th2;
        }
    }
}
