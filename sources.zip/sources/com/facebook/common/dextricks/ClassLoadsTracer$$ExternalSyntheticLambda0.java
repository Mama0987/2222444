package com.facebook.common.dextricks;

public final /* synthetic */ class ClassLoadsTracer$$ExternalSyntheticLambda0 {
    public final /* synthetic */ boolean f$0;

    public final void onInitializationFinished(boolean z) {
        ClassLoadsTracer.lambda$install$0(this.f$0, z);
    }

    public /* synthetic */ ClassLoadsTracer$$ExternalSyntheticLambda0(boolean z) {
        this.f$0 = z;
    }
}
