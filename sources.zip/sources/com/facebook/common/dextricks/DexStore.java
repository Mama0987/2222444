package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0TR;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C08060bQ;
import X.C13230nO;
import X.C18550xJ;
import X.C18590xN;
import android.content.Context;
import android.os.Build;
import android.os.Parcel;
import com.facebook.common.build.BuildConstants;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.OdexScheme;
import com.facebook.common.dextricks.ReentrantLockFile;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class DexStore {
    public static final String CONFIG_FILENAME = "config";
    public static final String CONFIG_TMP_FILENAME = "config.tmp";
    public static final long CS_DEX0OPT = 16;
    public static final long CS_STATE_MASK = 15;
    public static final byte CS_STATE_SHIFT = 4;
    public static final int DAYS_TO_MS_FACTOR = 86400000;
    public static final byte DEFAULT_MULTIDEX_COMPILATION_STRATEGY = 0;
    public static final byte DEFAULT_PGO_COMPILER_FILTER = 0;
    public static final String DEPS_FILENAME = "deps";
    public static final int DS_ASYNC = 4;
    public static final int DS_DO_NOT_OPTIMIZE = 1;
    public static final int DS_FORCE_SYNC = 8;
    public static final int DS_LOAD_SECONDARY = 16;
    public static final int DS_NO_RETRY = 2;
    public static final int DS_UNPACK_ONLY = 32;
    public static final int LA_LOAD_EXISTING = 0;
    public static final int LA_REGEN_ALL = 2;
    public static final int LA_REGEN_MISSING = 1;
    public static final String MDEX_LOCK_FILENAME = "mdex_lock";
    public static final String MDEX_STATUS_FILENAME = "mdex_status2";
    public static final long MDEX_STATUS_XOR = -374168170706063353L;
    public static final byte MULTIDEX_COMPILATION_STRATEGY_EVERY_COLDSTART_DEX = 2;
    public static final byte MULTIDEX_COMPILATION_STRATEGY_EVERY_DEX = 1;
    public static final byte MULTIDEX_COMPILATION_STRATEGY_FIRST_COLDSTART_DEX = 0;
    public static final String ODEX_LOCK_FILENAME = "odex_lock";
    public static final String OPTIMIZATION_HISTORY_LOG_FILENAME = "optimization_history_log";
    public static final String OPTIMIZATION_LOG_FILENAME = "optimization_log";
    public static final byte PGO_COMPILER_FILTER_EVERYTHING_PROFILE = 2;
    public static final byte PGO_COMPILER_FILTER_SPACE_PROFILE = 1;
    public static final byte PGO_COMPILER_FILTER_SPEED_PROFILE = 0;
    public static final byte PGO_COMPILER_FILTER_VERIFY_PROFILE = 3;
    public static final String REGEN_STAMP_FILENAME = "regen_stamp";
    public static final byte STATE_ART_TURBO = 7;
    public static final byte STATE_ART_XDEX = 8;
    public static final byte STATE_BAD_GEN = 5;
    public static final byte STATE_FALLBACK = 2;
    public static final byte STATE_INVALID = 0;
    public static final byte STATE_NOOP = 9;
    public static final byte STATE_REGEN_FORCED = 6;
    public static final byte STATE_RESERVED1 = 10;
    public static final byte STATE_TX_FAILED = 1;
    public static final String TMPDIR_LOCK_SUFFIX = ".tmpdir_lock";
    public static final String TMPDIR_SUFFIX = ".tmpdir";
    public static boolean logDexAddPageFaults;
    public static long majPageFaultsDelta;
    public static long pageInBytesDelta;
    public static DexStoreClock sDexStoreClock = new Object();
    public static DexStore sListHead;
    public static boolean sLoadedCompressedOreo;
    public final ArrayList auxiliaryDexes;
    public String id;
    public final File mApk;
    public final List mChildStores = AnonymousClass001.A0t();
    public DexIteratorFactory mDexIteratorFactory;
    public boolean mDisableVerifier = false;
    public boolean mIsArtMainStore = false;
    public DexErrorRecoveryInfo mLastDeri;
    public ArrayList mLoadedDexFiles;
    public DexManifest mLoadedManifest;
    public final ReentrantLockFile mLockFile;
    public DexManifest mManifest;
    public String mMegaZipPath = null;
    public final List mParentStores = AnonymousClass001.A0t();
    public ResProvider mResProvider;
    public boolean mUseBgDexOpt = false;
    public boolean mUseEagerDexOpt = false;
    public final DexStore next = sListHead;
    public final ArrayList primaryDexes;
    public final File root;

    public final class Config {
        public static final byte ART_FILTER_BALANCED = 4;
        public static final byte ART_FILTER_DEFAULT = 0;
        public static final byte ART_FILTER_EVERYTHING = 6;
        public static final byte ART_FILTER_INTERPRET_ONLY = 2;
        public static final byte ART_FILTER_SPACE = 3;
        public static final byte ART_FILTER_SPEED = 5;
        public static final byte ART_FILTER_TIME = 7;
        public static final byte ART_FILTER_VERIFY_NONE = 1;
        public static final byte DALVIK_OPT_ALL = 3;
        public static final byte DALVIK_OPT_DEFAULT = 0;
        public static final byte DALVIK_OPT_FULL = 4;
        public static final byte DALVIK_OPT_NONE = 1;
        public static final byte DALVIK_OPT_VERIFIED = 2;
        public static final byte DALVIK_REGISTER_MAPS_DEFAULT = 0;
        public static final byte DALVIK_REGISTER_MAPS_NO = 1;
        public static final byte DALVIK_REGISTER_MAPS_YES = 2;
        public static final byte DALVIK_VERIFY_ALL = 3;
        public static final byte DALVIK_VERIFY_DEFAULT = 0;
        public static final byte DALVIK_VERIFY_NONE = 1;
        public static final byte DALVIK_VERIFY_REMOTE = 2;
        public static final int FLAGS_CONTROL_UNPACK = 31;
        public static final byte MODE_DEFAULT = 0;
        public static final byte MODE_FORCE_FALLBACK = 1;
        public static final byte MODE_FORCE_TURBO = 2;
        public static final byte MODE_FORCE_XDEX = 3;
        public static final byte SYNC_CONTROL_ASYNC = 1;
        public static final byte SYNC_CONTROL_DEFAULT = 0;
        public static final byte SYNC_CONTROL_SYNC = 2;
        public static final byte VERSION = 9;
        public final byte artFilter;
        public final int artHugeMethodMax;
        public final int artLargeMethodMax;
        public final int artSmallMethodMax;
        public final int artTinyMethodMax;
        public final int artTruncatedDexSize;
        public final byte dalvikOptimize;
        public final byte dalvikRegisterMaps;
        public final byte dalvikVerify;
        public final boolean enableArtVerifyNone;
        public final boolean enableDex2OatQuickening;
        public final boolean enableMixedMode;
        public final boolean enableMixedModeClassPath;
        public final boolean enableMixedModePgo;
        public final boolean enableQuickening;
        public final int henosisFlags;
        public final int legacyFlags;
        public final long minTimeBetweenPgoCompilationMs;
        public final byte mode;
        public final byte multidexCompilationStrategy;
        public final byte pgoCompilerFilter;
        public final byte sync;
        public final boolean tryPeriodicPgoCompilation;

        public final class Builder {
            public byte mArtFilter;
            public int mArtHugeMethodMax;
            public int mArtLargeMethodMax;
            public int mArtSmallMethodMax;
            public int mArtTinyMethodMax;
            public int mArtTruncatedDexSize;
            public byte mDalvikOptimize;
            public byte mDalvikRegisterMaps;
            public byte mDalvikVerify;
            public boolean mDoPeriodicPgoCompilation;
            public boolean mEnableArtVerifyNone;
            public boolean mEnableDex2OatQuickening;
            public boolean mEnableMixedMode;
            public boolean mEnableMixedModeClassPath;
            public boolean mEnableMixedModePgo;
            public boolean mEnableQuickening;
            public int mHenosisFlags;
            public int mLegacyFlags;
            public long mMinTimeBetweenPgoCompilationMs;
            public byte mMode;
            public byte mMultidexCompilationStrategy;
            public byte mPgoCompilerFilter;
            public byte mSync;

            public Config build() {
                byte b = this.mMode;
                byte b2 = this.mSync;
                byte b3 = this.mDalvikVerify;
                byte b4 = this.mDalvikOptimize;
                byte b5 = this.mDalvikRegisterMaps;
                byte b6 = this.mArtFilter;
                int i = this.mArtHugeMethodMax;
                int i2 = this.mArtLargeMethodMax;
                int i3 = this.mArtSmallMethodMax;
                int i4 = this.mArtTinyMethodMax;
                int i5 = this.mArtTruncatedDexSize;
                boolean z = this.mEnableArtVerifyNone;
                boolean z2 = this.mEnableDex2OatQuickening;
                boolean z3 = this.mEnableQuickening;
                boolean z4 = this.mEnableMixedMode;
                int i6 = i;
                int i7 = i2;
                return new Config(b, b2, b3, b4, b5, b6, i6, i7, i3, i4, i5, z, z2, z3, z4, this.mEnableMixedModeClassPath, this.mEnableMixedModePgo, this.mPgoCompilerFilter, this.mDoPeriodicPgoCompilation, this.mMinTimeBetweenPgoCompilationMs, this.mMultidexCompilationStrategy, this.mLegacyFlags, this.mHenosisFlags);
            }

            public Builder(Config config) {
                AnonymousClass002.A0c(this);
                this.mMode = config.mode;
                this.mSync = config.sync;
                this.mDalvikVerify = config.dalvikVerify;
                this.mDalvikOptimize = config.dalvikOptimize;
                this.mDalvikRegisterMaps = config.dalvikRegisterMaps;
                this.mArtFilter = config.artFilter;
                this.mArtHugeMethodMax = config.artHugeMethodMax;
                this.mArtLargeMethodMax = config.artLargeMethodMax;
                this.mArtSmallMethodMax = config.artSmallMethodMax;
                this.mArtTinyMethodMax = config.artTinyMethodMax;
                this.mArtTruncatedDexSize = config.artTruncatedDexSize;
                this.mEnableArtVerifyNone = config.enableArtVerifyNone;
                this.mEnableDex2OatQuickening = config.enableDex2OatQuickening;
                this.mEnableQuickening = config.enableQuickening;
                this.mEnableMixedMode = config.enableMixedMode;
                this.mEnableMixedModeClassPath = config.enableMixedModeClassPath;
                this.mEnableMixedModePgo = config.enableMixedModePgo;
                this.mPgoCompilerFilter = config.pgoCompilerFilter;
                this.mDoPeriodicPgoCompilation = config.tryPeriodicPgoCompilation;
                this.mMinTimeBetweenPgoCompilationMs = config.minTimeBetweenPgoCompilationMs;
                this.mMultidexCompilationStrategy = config.multidexCompilationStrategy;
                this.mLegacyFlags = config.legacyFlags;
                this.mHenosisFlags = config.henosisFlags;
            }

            private long convertDaysToMs(double d) {
                return Math.round(d * 8.64E7d);
            }

            public Builder setArtFilter(byte b) {
                this.mArtFilter = b;
                return this;
            }

            public Builder setArtHugeMethodMax(int i) {
                this.mArtHugeMethodMax = i;
                return this;
            }

            public Builder setArtLargeMethodMax(int i) {
                this.mArtLargeMethodMax = i;
                return this;
            }

            public Builder setArtSmallMethodMax(int i) {
                this.mArtSmallMethodMax = i;
                return this;
            }

            public Builder setArtTinyMethodMax(int i) {
                this.mArtTinyMethodMax = i;
                return this;
            }

            public Builder setArtTruncatedDexSize(int i) {
                this.mArtTruncatedDexSize = i;
                return this;
            }

            public Builder setDalvikOptimize(byte b) {
                this.mDalvikOptimize = b;
                return this;
            }

            public Builder setDalvikRegisterMaps(byte b) {
                this.mDalvikRegisterMaps = b;
                return this;
            }

            public Builder setDalvikVerify(byte b) {
                this.mDalvikVerify = b;
                return this;
            }

            public Builder setDoPeriodicPgoCompilation(boolean z) {
                this.mDoPeriodicPgoCompilation = z;
                return this;
            }

            public Builder setEnableArtVerifyNone(boolean z) {
                this.mEnableArtVerifyNone = z;
                return this;
            }

            public Builder setEnableDex2OatQuickening(boolean z) {
                this.mEnableDex2OatQuickening = z;
                return this;
            }

            public Builder setEnableMixedMode(boolean z) {
                this.mEnableMixedMode = z;
                return this;
            }

            public Builder setEnableMixedModeClassPath(boolean z) {
                this.mEnableMixedModeClassPath = z;
                return this;
            }

            public Builder setEnableMixedModePgo(boolean z) {
                this.mEnableMixedModePgo = z;
                return this;
            }

            public Builder setEnableQuickening(boolean z) {
                this.mEnableQuickening = z;
                return this;
            }

            public Builder setHenosisFlags(int i) {
                this.mHenosisFlags = i;
                return this;
            }

            public Builder setLegacyFlags(int i) {
                this.mLegacyFlags = i;
                return this;
            }

            public Builder setMinTimeBetweenPgoCompilationDays(double d) {
                this.mMinTimeBetweenPgoCompilationMs = Math.round(d * 8.64E7d);
                return this;
            }

            public Builder setMinTimeBetweenPgoCompilationMs(long j) {
                this.mMinTimeBetweenPgoCompilationMs = j;
                return this;
            }

            public Builder setMode(byte b) {
                this.mMode = b;
                return this;
            }

            public Builder setMultidexCompilationStrategy(byte b) {
                this.mMultidexCompilationStrategy = b;
                return this;
            }

            public Builder setPgoCompilerFilter(byte b) {
                this.mPgoCompilerFilter = b;
                return this;
            }

            public Builder setSync(byte b) {
                this.mSync = b;
                return this;
            }

            public Builder() {
                AnonymousClass002.A0c(this);
            }
        }

        public boolean equals(Object obj) {
            if (this != obj) {
                if (obj != null && getClass() == obj.getClass()) {
                    Config config = (Config) obj;
                    if (!(this.mode == config.mode && this.sync == config.sync && this.dalvikVerify == config.dalvikVerify && this.dalvikOptimize == config.dalvikOptimize && this.dalvikRegisterMaps == config.dalvikRegisterMaps && this.artFilter == config.artFilter && this.artHugeMethodMax == config.artHugeMethodMax && this.artLargeMethodMax == config.artLargeMethodMax && this.artSmallMethodMax == config.artSmallMethodMax && this.artTinyMethodMax == config.artTinyMethodMax && this.artTruncatedDexSize == config.artTruncatedDexSize && this.enableArtVerifyNone == config.enableArtVerifyNone && this.enableDex2OatQuickening == config.enableDex2OatQuickening && this.enableQuickening == config.enableQuickening && this.enableMixedMode == config.enableMixedMode && this.enableMixedModeClassPath == config.enableMixedModeClassPath && this.enableMixedModePgo == config.enableMixedModePgo && this.pgoCompilerFilter == config.pgoCompilerFilter && this.multidexCompilationStrategy == config.multidexCompilationStrategy && this.tryPeriodicPgoCompilation == config.tryPeriodicPgoCompilation && this.minTimeBetweenPgoCompilationMs == config.minTimeBetweenPgoCompilationMs && this.legacyFlags == config.legacyFlags && this.henosisFlags == config.henosisFlags)) {
                        return false;
                    }
                }
                return false;
            }
            return true;
        }

        public static File getConfigFileName(File file) {
            return AnonymousClass001.A0D(file, DexStore.CONFIG_FILENAME);
        }

        public static Config readFromRoot(File file) {
            return read(AnonymousClass001.A0D(file, DexStore.CONFIG_FILENAME));
        }

        public boolean equalsForBootstrapPurposes(Config config) {
            if (config != null && config.mode == this.mode && config.sync == this.sync && config.artFilter == this.artFilter && config.enableArtVerifyNone == this.enableArtVerifyNone && config.enableDex2OatQuickening == this.enableDex2OatQuickening && config.enableMixedMode == this.enableMixedMode && config.enableMixedModeClassPath == this.enableMixedModeClassPath && config.enableMixedModePgo == this.enableMixedModePgo && config.pgoCompilerFilter == this.pgoCompilerFilter && config.multidexCompilationStrategy == this.multidexCompilationStrategy && config.tryPeriodicPgoCompilation == this.tryPeriodicPgoCompilation && config.legacyFlags == this.legacyFlags && config.henosisFlags == this.henosisFlags) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            return ((((((((((((((((((((((((((((((((((((((((((((10571 + this.mode) * 31) + this.sync) * 31) + this.dalvikVerify) * 31) + this.dalvikOptimize) * 31) + this.dalvikRegisterMaps) * 31) + this.artFilter) * 31) + this.artHugeMethodMax) * 31) + this.artLargeMethodMax) * 31) + this.artSmallMethodMax) * 31) + this.artTinyMethodMax) * 31) + this.artTruncatedDexSize) * 31) + (this.enableArtVerifyNone ? 1 : 0)) * 31) + (this.enableDex2OatQuickening ? 1 : 0)) * 31) + (this.enableQuickening ? 1 : 0)) * 31) + (this.enableMixedMode ? 1 : 0)) * 31) + (this.enableMixedModeClassPath ? 1 : 0)) * 31) + (this.enableMixedModePgo ? 1 : 0)) * 31) + this.pgoCompilerFilter) * 31) + this.multidexCompilationStrategy) * 31) + (this.tryPeriodicPgoCompilation ? 1 : 0)) * 31) + ((int) this.minTimeBetweenPgoCompilationMs)) * 31) + this.legacyFlags) * 31) + this.henosisFlags;
        }

        public boolean isDefault() {
            return equals(new Builder().build());
        }

        public Config(byte b, byte b2, byte b3, byte b4, byte b5, byte b6, int i, int i2, int i3, int i4, int i5, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, byte b7, boolean z7, long j, byte b8, int i6, int i7) {
            this.mode = b;
            this.sync = b2;
            this.dalvikVerify = b3;
            this.dalvikOptimize = b4;
            this.dalvikRegisterMaps = b5;
            this.artFilter = b6;
            this.artHugeMethodMax = i;
            this.artLargeMethodMax = i2;
            this.artSmallMethodMax = i3;
            this.artTinyMethodMax = i4;
            this.artTruncatedDexSize = i5;
            this.enableArtVerifyNone = z;
            this.enableDex2OatQuickening = z2;
            this.enableQuickening = z3;
            this.enableMixedMode = z4;
            this.enableMixedModeClassPath = z5;
            this.enableMixedModePgo = z6;
            this.pgoCompilerFilter = b7;
            this.tryPeriodicPgoCompilation = z7;
            this.minTimeBetweenPgoCompilationMs = j;
            this.multidexCompilationStrategy = b8;
            this.legacyFlags = i6;
            this.henosisFlags = i7;
        }

        public static Config read(File file) {
            RandomAccessFile A0H = AnonymousClass001.A0H(file);
            try {
                if (A0H.readByte() == 9) {
                    Config config = new Config(A0H.readByte(), A0H.readByte(), A0H.readByte(), A0H.readByte(), A0H.readByte(), A0H.readByte(), A0H.readInt(), A0H.readInt(), A0H.readInt(), A0H.readInt(), A0H.readInt(), A0H.readBoolean(), A0H.readBoolean(), A0H.readBoolean(), A0H.readBoolean(), A0H.readBoolean(), A0H.readBoolean(), A0H.readByte(), A0H.readBoolean(), A0H.readLong(), A0H.readByte(), A0H.readInt(), A0H.readInt());
                    A0H.close();
                    return config;
                }
                throw AnonymousClass001.A0r("unexpected version");
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
                throw th;
            }
        }

        public byte[] readDepBlock() {
            Parcel obtain = Parcel.obtain();
            try {
                obtain.writeByte(this.mode);
                obtain.writeByte(this.sync);
                obtain.writeByte(this.dalvikVerify);
                obtain.writeByte(this.dalvikOptimize);
                obtain.writeByte(this.dalvikRegisterMaps);
                obtain.writeByte(this.artFilter);
                obtain.writeInt(this.artHugeMethodMax);
                obtain.writeInt(this.artLargeMethodMax);
                obtain.writeInt(this.artSmallMethodMax);
                obtain.writeInt(this.artTinyMethodMax);
                obtain.writeBooleanArray(new boolean[]{this.enableArtVerifyNone, this.enableDex2OatQuickening, this.enableQuickening, this.enableMixedMode, this.enableMixedModeClassPath, this.enableMixedModePgo});
                obtain.writeByte(this.pgoCompilerFilter);
                obtain.writeByte(this.tryPeriodicPgoCompilation ? (byte) 1 : 0);
                obtain.writeLong(this.minTimeBetweenPgoCompilationMs);
                obtain.writeByte(this.multidexCompilationStrategy);
                obtain.writeInt(this.legacyFlags);
                obtain.writeInt(this.henosisFlags);
                return obtain.marshall();
            } finally {
                obtain.recycle();
            }
        }

        public void writeAndSync(File file) {
            RandomAccessFile A0I = AnonymousClass001.A0I(file);
            try {
                A0I.writeByte(9);
                A0I.writeByte(this.mode);
                A0I.writeByte(this.sync);
                A0I.writeByte(this.dalvikVerify);
                A0I.writeByte(this.dalvikOptimize);
                A0I.writeByte(this.dalvikRegisterMaps);
                A0I.writeByte(this.artFilter);
                A0I.writeInt(this.artHugeMethodMax);
                A0I.writeInt(this.artLargeMethodMax);
                A0I.writeInt(this.artSmallMethodMax);
                A0I.writeInt(this.artTinyMethodMax);
                A0I.writeInt(this.artTruncatedDexSize);
                A0I.writeBoolean(this.enableArtVerifyNone);
                A0I.writeBoolean(this.enableDex2OatQuickening);
                A0I.writeBoolean(this.enableQuickening);
                A0I.writeBoolean(this.enableMixedMode);
                A0I.writeBoolean(this.enableMixedModeClassPath);
                A0I.writeBoolean(this.enableMixedModePgo);
                A0I.writeByte(this.pgoCompilerFilter);
                A0I.writeBoolean(this.tryPeriodicPgoCompilation);
                A0I.writeLong(this.minTimeBetweenPgoCompilationMs);
                A0I.writeByte(this.multidexCompilationStrategy);
                A0I.writeInt(this.legacyFlags);
                A0I.writeInt(this.henosisFlags);
                A0I.setLength(A0I.getFilePointer());
                A0I.getFD().sync();
                A0I.close();
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
                throw th;
            }
        }
    }

    public interface DexStoreClock {
        long now();
    }

    public final class FinishRegenerationThread extends Thread {
        public final ReentrantLockFile.Lock mHeldLock;
        public final long mNewStatus;
        public final OdexScheme mOdexScheme;

        public FinishRegenerationThread(OdexScheme odexScheme, ReentrantLockFile.Lock lock, long j) {
            super(AnonymousClass0WY.A0i("TxFlush-", DexStore.this.root.getName()));
            this.mHeldLock = lock;
            this.mNewStatus = j;
            this.mOdexScheme = odexScheme;
        }

        public void run() {
            try {
                for (String A0D : this.mOdexScheme.expectedFiles) {
                    File A0D2 = AnonymousClass001.A0D(DexStore.this.root, A0D);
                    if (A0D2.exists()) {
                        DalvikInternals.fsyncNamed(A0D2.getCanonicalPath(), -1);
                    }
                }
                DexStore.this.writeStatusLocked(this.mNewStatus);
                this.mHeldLock.close();
            } catch (IOException e) {
                throw AnonymousClass001.A0X(e);
            } catch (Throwable th) {
                this.mHeldLock.close();
                throw th;
            }
        }
    }

    public class PreviewSdkHelper {
        public static boolean isPreviewSdk() {
            if (Build.VERSION.PREVIEW_SDK_INT != 0) {
                return true;
            }
            return false;
        }
    }

    public final class TmpDir implements Closeable {
        public File directory;
        public ReentrantLockFile.Lock mTmpDirLock;

        public TmpDir(ReentrantLockFile.Lock lock, File file) {
            this.mTmpDirLock = lock;
            this.directory = file;
        }

        public void close() {
            if (this.mTmpDirLock != null) {
                ReentrantLockFile.Lock acquire = DexStore.this.mLockFile.acquire(0);
                try {
                    ReentrantLockFile.Lock lock = this.mTmpDirLock;
                    File file = ReentrantLockFile.this.lockFileName;
                    lock.close();
                    this.mTmpDirLock = null;
                    Fs.deleteRecursiveNoThrow(file);
                    Fs.deleteRecursiveNoThrow(this.directory);
                    this.directory = null;
                    if (acquire != null) {
                        acquire.close();
                    }
                } catch (Throwable th) {
                    AnonymousClass0ZM.A00(th, th);
                    throw th;
                }
            }
        }
    }

    public static boolean checkAndClearGk(Context context, String str) {
        try {
            return C18550xJ.A03(context, str);
        } finally {
            C18550xJ.A02(context, str, false);
        }
    }

    private void deleteFiles(String[] strArr) {
        for (int i = 0; i < strArr.length; i++) {
            if (strArr[i] != null) {
                Fs.deleteRecursive(AnonymousClass001.A0D(this.root, strArr[i]));
            }
        }
    }

    private int findInArray(String[] strArr, String str) {
        for (int i = 0; i < strArr.length; i++) {
            if (str.equals(strArr[i])) {
                return i;
            }
        }
        return -1;
    }

    public static long getBaseApkIdentifier(File file) {
        return getApkIdentifier(file, false);
    }

    private synchronized DexStore[] getParents() {
        List list;
        DexManifest loadManifest = loadManifest();
        if (this.mParentStores.isEmpty() && !DexStoreUtils.MAIN_DEX_STORE_ID.equals(loadManifest.id)) {
            for (String str : loadManifest.requires) {
                if (!DexStoreUtils.MAIN_DEX_STORE_ID.equals(str)) {
                    DexStore dexStoreListHead = dexStoreListHead();
                    while (true) {
                        if (dexStoreListHead != null) {
                            String str2 = dexStoreListHead.id;
                            if (str2 != null && str2.equals(str)) {
                                this.mParentStores.add(dexStoreListHead);
                                dexStoreListHead.addChild(this);
                                break;
                            }
                            dexStoreListHead = dexStoreListHead.next;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        list = this.mParentStores;
        return (DexStore[]) list.toArray(new DexStore[list.size()]);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:0|(3:1|2|(1:4)(1:5))|8|(3:10|11|(10:13|14|(1:16)|34|17|22|(1:24)|25|26|27))|18|19|(6:21|22|(0)|25|26|27)(3:28|29|30)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x0046 */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0052 A[Catch:{ all -> 0x0093 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0069 A[Catch:{ all -> 0x0093 }] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x007f A[SYNTHETIC, Splitter:B:28:0x007f] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private byte[] readCurrentDepBlock() {
        /*
            r8 = this;
            r1 = 0
            r6 = 1
            java.io.File r2 = r8.mApk     // Catch:{ Exception -> 0x000f }
            boolean r0 = X.C13230nO.A00     // Catch:{ Exception -> 0x000f }
            if (r0 == 0) goto L_0x000a
            r7 = 0
            goto L_0x001a
        L_0x000a:
            java.io.File r7 = determineOdexCacheName(r2)     // Catch:{ Exception -> 0x000f }
            goto L_0x001a
        L_0x000f:
            r3 = move-exception
            r7 = 0
            java.lang.Object[] r2 = new java.lang.Object[]{r7}
            java.lang.String r0 = "error reading odex cache file %s"
            com.facebook.common.dextricks.Mlog.w(r3, r0, r2)
        L_0x001a:
            android.os.Parcel r2 = android.os.Parcel.obtain()
            if (r7 == 0) goto L_0x0046
            boolean r0 = r7.exists()     // Catch:{ all -> 0x0093 }
            if (r0 == 0) goto L_0x0046
            com.facebook.common.dextricks.DexStore[] r5 = r8.getParents()     // Catch:{ Exception -> 0x0046 }
            int r4 = r5.length     // Catch:{ Exception -> 0x0046 }
            r3 = 0
        L_0x002c:
            if (r3 >= r4) goto L_0x003a
            r0 = r5[r3]     // Catch:{ Exception -> 0x0046 }
            byte[] r0 = r0.readCurrentDepBlock()     // Catch:{ Exception -> 0x0046 }
            r2.writeByteArray(r0)     // Catch:{ Exception -> 0x0046 }
            int r3 = r3 + 1
            goto L_0x002c
        L_0x003a:
            java.lang.String r0 = r7.getPath()     // Catch:{ Exception -> 0x0046 }
            byte[] r0 = com.facebook.common.dextricks.DalvikInternals.readOdexDepBlock(r0)     // Catch:{ Exception -> 0x0046 }
            r2.writeByteArray(r0)     // Catch:{ Exception -> 0x0046 }
            goto L_0x0063
        L_0x0046:
            java.io.File r0 = r8.mApk     // Catch:{ all -> 0x0093 }
            long r3 = getApkIdentifier(r0, r6)     // Catch:{ all -> 0x0093 }
            r5 = 0
            int r0 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r0 == 0) goto L_0x007f
            java.io.File r0 = r8.mApk     // Catch:{ all -> 0x0093 }
            java.lang.String r0 = r0.getName()     // Catch:{ all -> 0x0093 }
            r2.writeString(r0)     // Catch:{ all -> 0x0093 }
            r2.writeLong(r3)     // Catch:{ all -> 0x0093 }
            java.lang.String r0 = android.os.Build.FINGERPRINT     // Catch:{ all -> 0x0093 }
            r2.writeString(r0)     // Catch:{ all -> 0x0093 }
        L_0x0063:
            boolean r0 = com.facebook.endtoend.EndToEnd.A04()     // Catch:{ all -> 0x0093 }
            if (r0 == 0) goto L_0x006c
            r2.writeByte(r1)     // Catch:{ all -> 0x0093 }
        L_0x006c:
            com.facebook.common.dextricks.DexStore$Config r0 = r8.readConfig()     // Catch:{ all -> 0x0093 }
            byte[] r0 = r0.readDepBlock()     // Catch:{ all -> 0x0093 }
            r2.writeByteArray(r0)     // Catch:{ all -> 0x0093 }
            byte[] r0 = r2.marshall()     // Catch:{ all -> 0x0093 }
            r2.recycle()
            return r0
        L_0x007f:
            java.lang.StringBuilder r1 = X.AnonymousClass001.A0m()     // Catch:{ all -> 0x0093 }
            java.lang.String r0 = "unable to get identifier of "
            r1.append(r0)     // Catch:{ all -> 0x0093 }
            java.io.File r0 = r8.mApk     // Catch:{ all -> 0x0093 }
            java.lang.String r0 = X.AnonymousClass001.A0d(r0, r1)     // Catch:{ all -> 0x0093 }
            java.io.IOException r0 = X.AnonymousClass001.A0G(r0)     // Catch:{ all -> 0x0093 }
            throw r0     // Catch:{ all -> 0x0093 }
        L_0x0093:
            r0 = move-exception
            r2.recycle()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.readCurrentDepBlock():byte[]");
    }

    private void setDifference(String[] strArr, String[] strArr2) {
        for (int i = 0; i < strArr.length; i++) {
            String str = strArr[i];
            if (str != null) {
                int i2 = 0;
                while (true) {
                    if (i2 < strArr2.length) {
                        String str2 = strArr2[i2];
                        if (str2 != null && str.equals(str2)) {
                            strArr[i] = null;
                            break;
                        }
                        i2++;
                    } else {
                        break;
                    }
                }
            }
        }
    }

    private void writeTxFailedStatusLocked(long j) {
        writeStatusLocked((j << 4) | 1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x003a, code lost:
        if (attemptedOptimizationSinceRegeneration() != false) goto L_0x003c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean atomicReplaceConfig(com.facebook.common.dextricks.DexStore.Config r7) {
        /*
            r6 = this;
            r3 = 0
            if (r7 == 0) goto L_0x0006
            r7.isDefault()
        L_0x0006:
            com.facebook.common.dextricks.ReentrantLockFile r0 = r6.mLockFile
            com.facebook.common.dextricks.ReentrantLockFile$Lock r5 = r0.acquire(r3)
            java.io.File r1 = r6.root     // Catch:{ all -> 0x007d }
            java.lang.String r0 = "config"
            java.io.File r4 = X.AnonymousClass001.A0D(r1, r0)     // Catch:{ all -> 0x007d }
            com.facebook.common.dextricks.DexStore$Config r1 = r6.readConfig()     // Catch:{ all -> 0x007d }
            boolean r2 = r7.equals(r1)     // Catch:{ all -> 0x007d }
            boolean r0 = r6.attemptedOptimizationSinceRegeneration()     // Catch:{ all -> 0x007d }
            if (r0 == 0) goto L_0x0023
            goto L_0x0028
        L_0x0023:
            boolean r1 = r7.equalsForBootstrapPurposes(r1)     // Catch:{ all -> 0x007d }
            goto L_0x0029
        L_0x0028:
            r1 = r2
        L_0x0029:
            if (r1 == 0) goto L_0x0034
            if (r2 != 0) goto L_0x0034
            boolean r0 = r6.checkDeps()     // Catch:{ all -> 0x007d }
            if (r0 != 0) goto L_0x0036
            r1 = 0
        L_0x0034:
            r3 = r1
            goto L_0x003c
        L_0x0036:
            boolean r0 = r6.attemptedOptimizationSinceRegeneration()     // Catch:{ all -> 0x007d }
            if (r0 == 0) goto L_0x0034
        L_0x003c:
            boolean r0 = r7.isDefault()     // Catch:{ all -> 0x007d }
            if (r0 == 0) goto L_0x0046
            com.facebook.common.dextricks.Fs.deleteRecursive(r4)     // Catch:{ all -> 0x007d }
            goto L_0x0054
        L_0x0046:
            java.io.File r1 = r6.root     // Catch:{ all -> 0x007d }
            java.lang.String r0 = "config.tmp"
            java.io.File r0 = X.AnonymousClass001.A0D(r1, r0)     // Catch:{ all -> 0x007d }
            r7.writeAndSync(r0)     // Catch:{ all -> 0x007d }
            com.facebook.common.dextricks.Fs.renameOrThrow(r0, r4)     // Catch:{ all -> 0x007d }
        L_0x0054:
            if (r3 != 0) goto L_0x0070
            java.io.File r0 = r6.root     // Catch:{ all -> 0x007d }
            java.lang.String r1 = r0.getAbsolutePath()     // Catch:{ all -> 0x007d }
            r0 = -1
            com.facebook.common.dextricks.DalvikInternals.fsyncNamed(r1, r0)     // Catch:{ all -> 0x007d }
            monitor-enter(r6)     // Catch:{ all -> 0x007d }
            java.io.File r0 = r6.getRegenFile()     // Catch:{ all -> 0x006d }
            r0.delete()     // Catch:{ all -> 0x006d }
            r6.touchRegenStamp()     // Catch:{ all -> 0x006d }
            monitor-exit(r6)     // Catch:{ all -> 0x006d }
            goto L_0x0075
        L_0x006d:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x006d }
            throw r0     // Catch:{ all -> 0x007d }
        L_0x0070:
            if (r2 != 0) goto L_0x0075
            r6.saveDeps()     // Catch:{ all -> 0x007d }
        L_0x0075:
            r0 = r3 ^ 1
            if (r5 == 0) goto L_0x007c
            r5.close()
        L_0x007c:
            return r0
        L_0x007d:
            r1 = move-exception
            if (r5 == 0) goto L_0x0088
            r5.close()     // Catch:{ all -> 0x0084 }
            throw r1
        L_0x0084:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)
        L_0x0088:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.atomicReplaceConfig(com.facebook.common.dextricks.DexStore$Config):boolean");
    }

    public synchronized boolean isLoaded() {
        return AnonymousClass001.A1U(this.mLoadedManifest);
    }

    public synchronized DexErrorRecoveryInfo loadAll(int i, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger, Context context) {
        DexErrorRecoveryInfo dexErrorRecoveryInfo;
        int i2;
        C08060bQ.A01(AnonymousClass0WY.A0w("DexStore.loadAll[", getIdForTracing(this.root), "]"), -1978926528);
        try {
            dexErrorRecoveryInfo = loadAllImpl(i, lightweightQuickPerformanceLogger, context);
            i2 = 1014126979;
        } catch (RecoverableDexException e) {
            try {
                dexErrorRecoveryInfo = loadAllImpl(i | 2, lightweightQuickPerformanceLogger, context);
                dexErrorRecoveryInfo.regenRetryCause = e;
                i2 = -1618922394;
            } catch (RecoverableDexException e2) {
                throw new AssertionError(e2);
            } catch (Throwable th) {
                C08060bQ.A00(1430984941);
                throw th;
            }
        }
        C08060bQ.A00(i2);
        dexErrorRecoveryInfo.loadAllTime = sDexStoreClock.now();
        return dexErrorRecoveryInfo;
    }

    public long reportStatus() {
        ReentrantLockFile.Lock acquire;
        long j = 0;
        try {
            acquire = this.mLockFile.acquire(0);
            j = readStatusLocked();
            if (acquire != null) {
                acquire.close();
                return j;
            }
        } catch (Throwable unused) {
        }
        return j;
        throw th;
    }

    public class NormalDexStoreClock implements DexStoreClock {
        public long now() {
            return System.currentTimeMillis();
        }

        public /* synthetic */ NormalDexStoreClock(AnonymousClass1 r1) {
        }

        public NormalDexStoreClock() {
        }
    }

    private byte adjustDesiredStateForConfig(byte b, Config config) {
        Object[] objArr;
        String str;
        byte b2 = config.mode;
        if (b2 != 0) {
            if (b2 == 1) {
                return 2;
            }
            if (b2 == 2) {
                if (b != 2) {
                    if (b == 7 || b == 8) {
                        return 7;
                    }
                    if (b != 9) {
                        objArr = new Object[]{Byte.valueOf(b)};
                        str = "ignoring configured turbo mode: state not whitelisted: %s";
                    }
                }
            } else if (b2 != 3) {
                objArr = new Object[]{Byte.valueOf(b2)};
                str = "ignoring unknown configured dex mode %s";
            } else if (b != 2) {
                if (b == 7 || b == 8) {
                    return 8;
                }
                if (b != 9) {
                    objArr = new Object[]{Byte.valueOf(b)};
                    str = "ignoring configured xdex mode: state not whitelisted: %s";
                }
            }
            Mlog.w(str, objArr);
            return b;
        }
        return b;
    }

    private void appendDexHashForMegaZip(Context context, StringBuilder sb, DexManifest dexManifest) {
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA");
            instance.update(OdexSchemeOreo.getPrimaryDexIdentifierString(context).getBytes());
            int i = 0;
            while (true) {
                DexManifest.Dex[] dexArr = dexManifest.dexes;
                if (i < dexArr.length) {
                    instance.update(dexArr[i].hash.getBytes());
                    i++;
                } else {
                    instance.update(readCurrentDepBlock());
                    sb.append(DexStoreUtils.toHex(instance.digest()));
                    return;
                }
            }
        } catch (NoSuchAlgorithmException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    private void assertLockHeld() {
        boolean z = false;
        if (this.mLockFile.mLockOwner == Thread.currentThread()) {
            z = true;
        }
        Mlog.assertThat(z, "lock req", new Object[0]);
    }

    private byte determineDesiredState(byte b, DexManifest dexManifest, boolean z) {
        if (dexManifest.dexes.length == 0) {
            return 9;
        }
        if (b == 5 || (("Amazon".equals(Build.BRAND) && !C13230nO.A00) || !C13230nO.A00)) {
            return 2;
        }
        if (z || !dexManifest.canLoadCanaryClass()) {
            return 8;
        }
        return 9;
    }

    public static File determineOdexCacheName(File file) {
        if (C13230nO.A00) {
            return null;
        }
        String path = file.getPath();
        if (path.endsWith(".apk")) {
            File A0E = AnonymousClass001.A0E(AnonymousClass0WY.A0i(AnonymousClass001.A0f(path, path.length() - 4), DexManifest.ODEX_EXT));
            if (A0E.exists()) {
                return A0E;
            }
        }
        return Fs.dexOptGenerateCacheFileName(Fs.findSystemDalvikCache(), file, "classes.dex");
    }

    public static synchronized DexStore dexStoreListHead() {
        DexStore dexStore;
        synchronized (DexStore.class) {
            dexStore = sListHead;
        }
        return dexStore;
    }

    /* JADX WARNING: CFG modification limit reached, blocks count: 127 */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0018, code lost:
        return r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized com.facebook.common.dextricks.DexStore findOpened(java.lang.String r3) {
        /*
            java.lang.Class<com.facebook.common.dextricks.DexStore> r2 = com.facebook.common.dextricks.DexStore.class
            monitor-enter(r2)
            com.facebook.common.dextricks.DexStore r1 = dexStoreListHead()     // Catch:{ all -> 0x001f }
        L_0x0007:
            if (r1 == 0) goto L_0x001c
            java.lang.String r0 = r1.id     // Catch:{ all -> 0x001f }
            if (r0 != 0) goto L_0x000e
            goto L_0x0015
        L_0x000e:
            boolean r0 = r0.equals(r3)     // Catch:{ all -> 0x001f }
            if (r0 == 0) goto L_0x0019
            goto L_0x0017
        L_0x0015:
            if (r3 != 0) goto L_0x0019
        L_0x0017:
            monitor-exit(r2)
            return r1
        L_0x0019:
            com.facebook.common.dextricks.DexStore r1 = r1.next     // Catch:{ all -> 0x001f }
            goto L_0x0007
        L_0x001c:
            monitor-exit(r2)
            r1 = 0
            return r1
        L_0x001f:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x001f }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.findOpened(java.lang.String):com.facebook.common.dextricks.DexStore");
    }

    public static Long getBaseApkDexFilesIdentifier(File file) {
        ZipFile zipFile = new ZipFile(file);
        try {
            ZipEntry entry = zipFile.getEntry("classes.dex");
            if (entry != null) {
                Long valueOf = Long.valueOf(entry.getCrc());
                zipFile.close();
                return valueOf;
            }
            zipFile.close();
            return null;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public static DexStoreClock getClock(Class cls) {
        DexStoreClock dexStoreClock = sDexStoreClock;
        if (dexStoreClock == null) {
            return null;
        }
        return dexStoreClock;
    }

    private String getMegaZipName(Context context, DexManifest dexManifest) {
        StringBuilder A0n = AnonymousClass001.A0n(46);
        A0n.append("z-");
        appendDexHashForMegaZip(context, A0n, dexManifest);
        return AnonymousClass001.A0g(".zip", A0n);
    }

    public static String getStatusDescription(long j) {
        String str;
        int i = (int) (j & 15);
        if (i == 0) {
            str = "STATE_INVALID";
        } else if (i == 1) {
            str = "STATE_TX_FAILED";
        } else if (i != 2) {
            switch (i) {
                case 5:
                    str = "STATE_BAD_GEN";
                    break;
                case 6:
                    str = "STATE_REGEN_FORCED";
                    break;
                case 7:
                    str = "STATE_ART_TURBO";
                    break;
                case 8:
                    str = "STATE_ART_XDEX";
                    break;
                case 9:
                    str = "STATE_NOOP";
                    break;
                default:
                    str = AnonymousClass0WY.A0d("BAD STATE ", i);
                    break;
            }
        } else {
            str = "STATE_FALLBACK";
        }
        return AnonymousClass001.A0o(str).toString();
    }

    /* JADX WARNING: type inference failed for: r0v15, types: [X.0xK, X.0xM, java.lang.Object] */
    private void installArtHacks(Context context, DexErrorRecoveryInfo dexErrorRecoveryInfo) {
        int i;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 <= 32) {
            context.getPackageName();
            i = DalvikInternals.ART_HACK_DEX_PC_LINENUM;
        } else {
            i = 0;
        }
        boolean checkAndClearGk = checkAndClearGk(context, Experiments.DISABLE_DEX_VERIFIER);
        this.mDisableVerifier = checkAndClearGk;
        if (checkAndClearGk) {
            i |= 4;
        }
        boolean checkAndClearGk2 = checkAndClearGk(context, Experiments.DISABLE_DEX_COLLISION_CHECK);
        if (!MultiDexClassLoaderLight.isInstalled() && checkAndClearGk2) {
            i |= 32;
        }
        if (!sLoadedCompressedOreo) {
            if (checkAndClearGk(context, Experiments.DISABLE_DEX_ISUPTODATE_CHECK)) {
                i |= 64;
            }
            ? obj = new Object();
            obj.A00 = context;
            if (C18590xN.A00(obj, Experiments.DISABLE_MONITOR_VISITLOCKS, 0) == 1) {
                i |= DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS;
            }
        }
        int installArtHacks = DalvikInternals.installArtHacks(i, i2);
        if (i2 <= 31) {
            if ((i & 4) != 0 && (installArtHacks & 4) == 0) {
                AnonymousClass0TR.A01("dex_tricks::art_disable_verifier::failed_install", DalvikInternals.getLastInstallFailures(), (Throwable) null);
            }
            if ((i & DalvikInternals.ART_HACK_DEX_PC_LINENUM) != 0 && (installArtHacks & DalvikInternals.ART_HACK_DEX_PC_LINENUM) == 0) {
                AnonymousClass0TR.A01("dex_tricks::pc_line_num::failed_install", DalvikInternals.getLastInstallFailures(), (Throwable) null);
            }
        }
        DalvikInternals.setEnabledThreadArtHacks(i);
        dexErrorRecoveryInfo.hacksDesired = i;
        dexErrorRecoveryInfo.hacksInstalled = installArtHacks;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0152, code lost:
        if (r12 == false) goto L_0x0154;
     */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0059 A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x005b A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0064 A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00e7 A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00f2 A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0129 A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x015b A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x018e A[Catch:{ all -> 0x00f6, all -> 0x01aa }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.facebook.common.dextricks.DexErrorRecoveryInfo loadAllCompressedOreoImpl(com.facebook.common.dextricks.DexErrorRecoveryInfo r20, com.facebook.common.dextricks.DexManifest r21, int r22, com.facebook.quicklog.LightweightQuickPerformanceLogger r23, android.content.Context r24) {
        /*
            r19 = this;
            java.lang.String r3 = "DexStore.loadAllOreo"
            r2 = 646280348(0x2685749c, float:9.260336E-16)
            r0 = 32
            X.C004802v.A02(r0, r3, r2)
            r11 = r22 & -2
            r13 = r19
            java.io.File r3 = r13.root     // Catch:{ all -> 0x01aa }
            r14 = r21
            r7 = r24
            java.lang.String r2 = r13.getMegaZipName(r7, r14)     // Catch:{ all -> 0x01aa }
            java.io.File r4 = X.AnonymousClass001.A0D(r3, r2)     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = r4.getPath()     // Catch:{ all -> 0x01aa }
            r13.mMegaZipPath = r2     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.DexManifest$Dex[] r2 = r14.dexes     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.OdexSchemeOreo r15 = new com.facebook.common.dextricks.OdexSchemeOreo     // Catch:{ all -> 0x01aa }
            r10 = r23
            r15.<init>(r2, r4, r7, r10)     // Catch:{ all -> 0x01aa }
            int r3 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x01aa }
            r5 = 29
            r16 = 0
            if (r3 > r5) goto L_0x0046
            if (r3 != r5) goto L_0x0044
            boolean r2 = com.facebook.common.dextricks.DexStore.PreviewSdkHelper.isPreviewSdk()     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x0046
            android.content.pm.ApplicationInfo r2 = r7.getApplicationInfo()     // Catch:{ all -> 0x01aa }
            int r2 = r2.targetSdkVersion     // Catch:{ all -> 0x01aa }
            if (r2 < r5) goto L_0x0044
            goto L_0x0046
        L_0x0044:
            r2 = 0
            goto L_0x0047
        L_0x0046:
            r2 = 1
        L_0x0047:
            r13.mUseBgDexOpt = r2     // Catch:{ all -> 0x01aa }
            if (r3 == r5) goto L_0x0059
            r2 = 30
            if (r3 == r2) goto L_0x0059
            boolean r2 = com.facebook.common.dextricks.DexStore.PreviewSdkHelper.isPreviewSdk()     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x005b
            r2 = 31
            if (r3 < r2) goto L_0x005b
        L_0x0059:
            r2 = 1
            goto L_0x005c
        L_0x005b:
            r2 = 0
        L_0x005c:
            r13.mUseEagerDexOpt = r2     // Catch:{ all -> 0x01aa }
            boolean r2 = r15.needsUnpack()     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x00e7
            java.io.File r2 = r13.root     // Catch:{ all -> 0x01aa }
            java.lang.String[] r9 = r2.list()     // Catch:{ all -> 0x01aa }
            if (r9 == 0) goto L_0x017a
            int r8 = r9.length     // Catch:{ all -> 0x01aa }
            r6 = 0
        L_0x006e:
            if (r6 >= r8) goto L_0x00c7
            r5 = r9[r6]     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = ".dex"
            boolean r2 = r5.endsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = ".zlock"
            boolean r2 = r5.endsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = ".prof"
            boolean r2 = r5.endsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = ".zip"
            boolean r2 = r5.endsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x00a2
            java.lang.String r2 = "z-"
            boolean r2 = r5.startsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = "p-"
            boolean r2 = r5.startsWith(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
        L_0x00a2:
            java.lang.String r2 = "oat"
            boolean r2 = r5.equals(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = "foreign-dex"
            boolean r2 = r5.equals(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x00ba
            java.lang.String r2 = "regen_stamp"
            boolean r2 = r2.equals(r5)     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x00c4
        L_0x00ba:
            java.io.File r3 = r13.root     // Catch:{ all -> 0x01aa }
            java.io.File r2 = new java.io.File     // Catch:{ all -> 0x01aa }
            r2.<init>(r3, r5)     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.Fs.deleteRecursiveNoThrow(r2)     // Catch:{ all -> 0x01aa }
        L_0x00c4:
            int r6 = r6 + 1
            goto L_0x006e
        L_0x00c7:
            r17 = r10
            r18 = r7
            r13.runCompiler(r14, r15, r16, r17, r18)     // Catch:{ all -> 0x01aa }
            boolean r2 = r13.mUseEagerDexOpt     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x00df
            java.lang.String r3 = r13.id     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = "dex"
            boolean r2 = r2.equals(r3)     // Catch:{ all -> 0x01aa }
            if (r2 == 0) goto L_0x00df
            r15.addEmptyDex(r7)     // Catch:{ all -> 0x01aa }
        L_0x00df:
            r15.finalizeZip()     // Catch:{ all -> 0x01aa }
            r13.touchRegenStamp()     // Catch:{ all -> 0x01aa }
            r5 = 1
            goto L_0x00e8
        L_0x00e7:
            r5 = 0
        L_0x00e8:
            r6 = r20
            r13.installArtHacks(r7, r6)     // Catch:{ all -> 0x01aa }
            r15.initializeClassLoader()     // Catch:{ all -> 0x00f6 }
            if (r5 == 0) goto L_0x0121
            r14.verifyCanaryClasses()     // Catch:{ all -> 0x00f6 }
            goto L_0x0121
        L_0x00f6:
            r8 = move-exception
            r2 = r11 & 2
            boolean r7 = X.AnonymousClass001.A1R(r2)
            java.lang.String r6 = "Failed to teach app classloader about secondary dex files (%s); fatal: %b, regenerated: %b"
            java.io.File r4 = r13.root     // Catch:{ all -> 0x01aa }
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r7)     // Catch:{ all -> 0x01aa }
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r5)     // Catch:{ all -> 0x01aa }
            java.lang.Object[] r2 = new java.lang.Object[]{r4, r3, r2}     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.Mlog.e(r8, r6, r2)     // Catch:{ all -> 0x01aa }
            if (r7 == 0) goto L_0x0118
            com.facebook.common.dextricks.FatalDexError r2 = new com.facebook.common.dextricks.FatalDexError     // Catch:{ all -> 0x01aa }
            r2.<init>(r8)     // Catch:{ all -> 0x01aa }
            goto L_0x018d
        L_0x0118:
            r15.requestDexUnpack()     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.DexStore$RecoverableDexException r2 = new com.facebook.common.dextricks.DexStore$RecoverableDexException     // Catch:{ all -> 0x01aa }
            r2.<init>(r8)     // Catch:{ all -> 0x01aa }
            goto L_0x018d
        L_0x0121:
            r13.setUsingAppImageForMainDexStore(r7, r4)     // Catch:{ all -> 0x01aa }
            java.io.IOException[] r10 = r15.mSuppressedExceptions     // Catch:{ all -> 0x01aa }
            r7 = 0
            if (r10 == 0) goto L_0x0154
            java.lang.String r2 = "ClassLoader suppressed exceptions"
            java.lang.RuntimeException r4 = X.AnonymousClass001.A0V(r2)     // Catch:{ all -> 0x01aa }
            r9 = 0
            r12 = 0
        L_0x0131:
            int r2 = r10.length     // Catch:{ all -> 0x01aa }
            if (r9 >= r2) goto L_0x0152
            r8 = r10[r9]     // Catch:{ all -> 0x01aa }
            java.lang.String r11 = r8.getMessage()     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = "No original dex files found for dex location"
            int r2 = r11.indexOf(r2)     // Catch:{ all -> 0x01aa }
            r3 = -1
            if (r2 == r3) goto L_0x014b
            java.lang.String r2 = "/split_"
            int r2 = r11.indexOf(r2)     // Catch:{ all -> 0x01aa }
            if (r2 != r3) goto L_0x014f
        L_0x014b:
            com.facebook.androidcompat.AndroidCompat$Api19Utils.addSuppressed(r4, r8)     // Catch:{ all -> 0x01aa }
            r12 = 1
        L_0x014f:
            int r9 = r9 + 1
            goto L_0x0131
        L_0x0152:
            if (r12 != 0) goto L_0x0155
        L_0x0154:
            r4 = r7
        L_0x0155:
            boolean r2 = r14.canLoadCanaryClass()     // Catch:{ all -> 0x01aa }
            if (r2 != 0) goto L_0x018e
            if (r4 != 0) goto L_0x0163
            java.lang.String r2 = "Failed to load canary class after classloader init"
            java.lang.RuntimeException r4 = X.AnonymousClass001.A0V(r2)     // Catch:{ all -> 0x01aa }
        L_0x0163:
            if (r5 == 0) goto L_0x0168
            java.lang.String r3 = "OdexSchemeOreo reunpack after unpack"
            goto L_0x016a
        L_0x0168:
            java.lang.String r3 = "OdexSchemeOreo reunpack"
        L_0x016a:
            java.lang.String r2 = "Failed to load canary class, reunpacking"
            X.AnonymousClass0TR.A01(r3, r2, r4)     // Catch:{ all -> 0x01aa }
            r15.requestDexUnpack()     // Catch:{ all -> 0x01aa }
            r13.mLoadedManifest = r7     // Catch:{ all -> 0x01aa }
            com.facebook.common.dextricks.DexStore$RecoverableDexException r2 = new com.facebook.common.dextricks.DexStore$RecoverableDexException     // Catch:{ all -> 0x01aa }
            r2.<init>(r4)     // Catch:{ all -> 0x01aa }
            goto L_0x018d
        L_0x017a:
            java.lang.StringBuilder r3 = X.AnonymousClass001.A0m()     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = "unable to list directory "
            r3.append(r2)     // Catch:{ all -> 0x01aa }
            java.io.File r2 = r13.root     // Catch:{ all -> 0x01aa }
            java.lang.String r2 = X.AnonymousClass001.A0d(r2, r3)     // Catch:{ all -> 0x01aa }
            java.io.IOException r2 = X.AnonymousClass001.A0G(r2)     // Catch:{ all -> 0x01aa }
        L_0x018d:
            throw r2     // Catch:{ all -> 0x01aa }
        L_0x018e:
            if (r4 == 0) goto L_0x0197
            java.lang.String r3 = "OdexSchemeOreo suppressed"
            java.lang.String r2 = "OdexSchemeOreo found suppressed exceptions when initializing classloader"
            X.AnonymousClass0TR.A01(r3, r2, r4)     // Catch:{ all -> 0x01aa }
        L_0x0197:
            r13.mLoadedManifest = r14     // Catch:{ all -> 0x01aa }
            boolean r2 = r13.mUseBgDexOpt     // Catch:{ all -> 0x01aa }
            r15.registerCodeAndProfile(r2, r5)     // Catch:{ all -> 0x01aa }
            r13.setCompressedOreoDexErrorRecoveryInfo(r6, r15, r5)     // Catch:{ all -> 0x01aa }
            r13.mLastDeri = r6     // Catch:{ all -> 0x01aa }
            r2 = 167347100(0x9f9839c, float:6.0068334E-33)
            X.C004802v.A01(r0, r2)
            return r20
        L_0x01aa:
            r3 = move-exception
            r2 = -96810712(0xfffffffffa3ac928, float:-2.4246179E35)
            X.C004802v.A01(r0, r2)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.loadAllCompressedOreoImpl(com.facebook.common.dextricks.DexErrorRecoveryInfo, com.facebook.common.dextricks.DexManifest, int, com.facebook.quicklog.LightweightQuickPerformanceLogger, android.content.Context):com.facebook.common.dextricks.DexErrorRecoveryInfo");
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [java.lang.Object, com.facebook.common.dextricks.DexErrorRecoveryInfo] */
    /* JADX WARNING: Removed duplicated region for block: B:135:0x029f A[Catch:{ Exception -> 0x014d, all -> 0x02db }] */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x02a7 A[Catch:{ Exception -> 0x014d, all -> 0x02db }] */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x02bf  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00d2 A[Catch:{ Exception -> 0x014d, all -> 0x02db }] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00dd A[Catch:{ Exception -> 0x014d, all -> 0x02db }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.facebook.common.dextricks.DexErrorRecoveryInfo loadAllImpl(int r57, com.facebook.quicklog.LightweightQuickPerformanceLogger r58, android.content.Context r59) {
        /*
            r56 = this;
            r10 = r57
            com.facebook.common.dextricks.DexErrorRecoveryInfo r7 = new com.facebook.common.dextricks.DexErrorRecoveryInfo
            r7.<init>()
            r9 = r56
            boolean r0 = r9.isLoaded()
            r13 = 1
            r12 = 0
            if (r0 == 0) goto L_0x0023
            com.facebook.common.dextricks.DexErrorRecoveryInfo r0 = r9.mLastDeri
            if (r0 != 0) goto L_0x02c3
            java.io.File r0 = r9.root
            java.lang.Object[] r1 = new java.lang.Object[]{r0}
            java.lang.String r0 = "dex store %s has already been loaded, but did not save recovery info"
            com.facebook.common.dextricks.Mlog.w(r0, r1)
            r9.mLastDeri = r7
        L_0x0022:
            return r7
        L_0x0023:
            com.facebook.common.dextricks.DexManifest r6 = r9.loadManifest()
            com.facebook.common.dextricks.DexStore[] r4 = r9.getParents()
            int r3 = r4.length
            r2 = 0
        L_0x002d:
            r19 = 2
            r46 = r58
            r8 = r59
            if (r2 >= r3) goto L_0x0045
            r1 = r4[r2]
            boolean r0 = r1.isLoaded()
            if (r0 != 0) goto L_0x0042
            r0 = r46
            r1.loadAll(r10, r0, r8)
        L_0x0042:
            int r2 = r2 + 1
            goto L_0x002d
        L_0x0045:
            com.facebook.common.dextricks.ReentrantLockFile r0 = r9.mLockFile
            com.facebook.common.dextricks.ReentrantLockFile$Lock r53 = r0.acquire(r12)
            r0 = r57 & 32
            r11 = 0
            if (r0 == 0) goto L_0x0052
            r11 = 1
            goto L_0x006f
        L_0x0052:
            boolean r0 = r9.shouldLoadCompressedOreoImpl(r8, r6)     // Catch:{ all -> 0x02db }
            if (r0 == 0) goto L_0x006f
            java.lang.String r1 = "Loading %s with compressed oreo startup logic"
            java.io.File r0 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r1, r0)     // Catch:{ all -> 0x02db }
            r0 = r9
            r1 = r7
            r2 = r6
            r3 = r10
            r4 = r46
            r5 = r8
            r0.loadAllCompressedOreoImpl(r1, r2, r3, r4, r5)     // Catch:{ all -> 0x02db }
            goto L_0x02bd
        L_0x006f:
            long r0 = r9.readStatusLocked()     // Catch:{ all -> 0x02db }
            r17 = 15
            long r2 = r0 & r17
            int r4 = (int) r2     // Catch:{ all -> 0x02db }
            byte r5 = (byte) r4     // Catch:{ all -> 0x02db }
            r2 = 10
            if (r5 < r2) goto L_0x008d
            java.lang.String r4 = "found invalid state %s: nuking dex store %s"
            java.lang.Byte r3 = java.lang.Byte.valueOf(r5)     // Catch:{ all -> 0x02db }
            java.io.File r2 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.Object[] r2 = new java.lang.Object[]{r3, r2}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r4, r2)     // Catch:{ all -> 0x02db }
            goto L_0x00aa
        L_0x008d:
            if (r5 != r13) goto L_0x00aa
            java.lang.String r4 = "found abandoned transaction (prev stateno %s status %x) on dex store %s: nuking store"
            r2 = 4
            long r15 = r0 >> r2
            long r2 = r15 & r17
            java.lang.Long r14 = java.lang.Long.valueOf(r2)     // Catch:{ all -> 0x02db }
            java.lang.Long r3 = java.lang.Long.valueOf(r15)     // Catch:{ all -> 0x02db }
            java.io.File r2 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.Object[] r2 = new java.lang.Object[]{r14, r3, r2}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r4, r2)     // Catch:{ all -> 0x02db }
            r4 = 16
            goto L_0x00c0
        L_0x00aa:
            r4 = 0
            r2 = 5
            if (r5 != r2) goto L_0x00b6
            java.lang.String r2 = "crashed last time while loading generated files; trying fallback"
            X.AnonymousClass001.A1I(r2)     // Catch:{ all -> 0x02db }
            r4 = 64
            goto L_0x00c0
        L_0x00b6:
            r2 = 6
            if (r5 != r2) goto L_0x00c0
            java.lang.String r2 = "force dex regeneration requested"
            X.AnonymousClass001.A1I(r2)     // Catch:{ all -> 0x02db }
            r4 = 32
        L_0x00c0:
            com.facebook.common.dextricks.OdexScheme r3 = r9.schemeForState(r8, r6, r0)     // Catch:{ all -> 0x02db }
            java.lang.String[] r17 = r9.listAndPruneRootFiles(r8)     // Catch:{ all -> 0x02db }
            r2 = r17
            int r2 = r9.checkDirty(r3, r2)     // Catch:{ all -> 0x02db }
            boolean r14 = r3 instanceof com.facebook.common.dextricks.OdexSchemeUncompressedExo     // Catch:{ all -> 0x02db }
            if (r14 == 0) goto L_0x00dd
            r0 = r9
            r1 = r7
            r2 = r12
            r4 = r6
            r5 = r8
            r6 = r10
            r0.loadDexFiles(r1, r2, r3, r4, r5, r6)     // Catch:{ all -> 0x02db }
            goto L_0x02bd
        L_0x00dd:
            if (r2 != 0) goto L_0x00e4
            r49 = r10
            r45 = 0
            goto L_0x015c
        L_0x00e4:
            if (r2 != r13) goto L_0x00ed
            int r14 = r3.flags     // Catch:{ all -> 0x02db }
            r14 = r14 & 1
            if (r14 == 0) goto L_0x00ed
            r2 = 2
        L_0x00ed:
            com.facebook.common.dextricks.DexManifest$Dex[] r14 = r6.dexes     // Catch:{ all -> 0x02db }
            int r15 = r14.length     // Catch:{ all -> 0x02db }
            r14 = 58
            if (r15 <= r14) goto L_0x0109
            java.lang.String r16 = "too many dexes, forcing turbo mode: have %s but maximum per dex store is %s"
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)     // Catch:{ all -> 0x02db }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ all -> 0x02db }
            java.lang.Object[] r15 = new java.lang.Object[]{r15, r14}     // Catch:{ all -> 0x02db }
            r14 = r16
            com.facebook.common.dextricks.Mlog.w(r14, r15)     // Catch:{ all -> 0x02db }
            r10 = r57 | 1
        L_0x0109:
            r9.writeTxFailedStatusLocked(r0)     // Catch:{ all -> 0x02db }
            java.io.File r15 = r9.getRegenFile()     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Fs.deleteRecursive(r15)     // Catch:{ all -> 0x02db }
            java.io.FileOutputStream r14 = new java.io.FileOutputStream     // Catch:{ all -> 0x02db }
            r14.<init>(r15)     // Catch:{ all -> 0x02db }
            r14.close()     // Catch:{ all -> 0x02db }
            java.io.File r15 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.String r14 = "odex_lock"
            java.io.File r15 = X.AnonymousClass001.A0D(r15, r14)     // Catch:{ all -> 0x02db }
            boolean r14 = r15.exists()     // Catch:{ all -> 0x02db }
            if (r14 == 0) goto L_0x0137
            com.facebook.common.dextricks.ReentrantLockFile r14 = com.facebook.common.dextricks.ReentrantLockFile.open(r15)     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.ReentrantLockFile$Lock r15 = r14.acquire(r12)     // Catch:{ all -> 0x02c4 }
            r15.close()     // Catch:{ all -> 0x02c4 }
            r14.close()     // Catch:{ all -> 0x02db }
        L_0x0137:
            r49 = r10
            r45 = 1
            if (r2 != r13) goto L_0x015c
            r20 = r9
            r21 = r6
            r22 = r3
            r23 = r13
            r24 = r46
            r25 = r8
            r20.runCompiler(r21, r22, r23, r24, r25)     // Catch:{ Exception -> 0x014d }
            goto L_0x015b
        L_0x014d:
            r15 = move-exception
            java.lang.String r14 = "incremental regeneration error in dex store %s: regenerating"
            java.io.File r2 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.Object[] r2 = new java.lang.Object[]{r2}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r15, r14, r2)     // Catch:{ all -> 0x02db }
            r2 = 2
            goto L_0x015c
        L_0x015b:
            r2 = 0
        L_0x015c:
            java.io.File r14 = r9.root     // Catch:{ FileNotFoundException -> 0x0163 }
            com.facebook.common.dextricks.DexStore$Config r14 = com.facebook.common.dextricks.DexStore.Config.readFromRoot(r14)     // Catch:{ FileNotFoundException -> 0x0163 }
            goto L_0x0198
        L_0x0163:
            r27 = -1
            r40 = 0
            com.facebook.common.dextricks.DexStore$Config r14 = new com.facebook.common.dextricks.DexStore$Config     // Catch:{ all -> 0x02db }
            r22 = r12
            r23 = r12
            r24 = r12
            r25 = r12
            r26 = r12
            r28 = r27
            r29 = r27
            r30 = r27
            r31 = r27
            r32 = r12
            r33 = r12
            r34 = r12
            r35 = r12
            r36 = r12
            r37 = r12
            r38 = r12
            r39 = r12
            r42 = r12
            r43 = r12
            r44 = r12
            r20 = r14
            r21 = r12
            r20.<init>(r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40, r42, r43, r44)     // Catch:{ all -> 0x02db }
        L_0x0198:
            r15 = 8
            if (r2 == 0) goto L_0x0221
            r9.saveDeps()     // Catch:{ all -> 0x02db }
            byte r0 = r9.determineDesiredState(r5, r6, r11)     // Catch:{ all -> 0x02db }
            r1 = r10 & 1
            if (r1 == 0) goto L_0x01aa
            if (r0 != r15) goto L_0x01aa
            r0 = 7
        L_0x01aa:
            byte r1 = r14.sync     // Catch:{ all -> 0x02db }
            if (r1 == 0) goto L_0x01cf
            if (r1 == r13) goto L_0x01ba
            r3 = r19
            if (r1 == r3) goto L_0x01b5
            goto L_0x01c2
        L_0x01b5:
            r1 = r10 & -5
            r49 = r1 | 8
            goto L_0x01cf
        L_0x01ba:
            java.lang.String r1 = "forcing async optimization mode from config file: dangerous!"
            X.AnonymousClass001.A1I(r1)     // Catch:{ all -> 0x02db }
            r49 = r10 | 4
            goto L_0x01cf
        L_0x01c2:
            java.lang.String r3 = "config file has unknown sync control mode %s: ignoring"
            java.lang.Byte r1 = java.lang.Byte.valueOf(r1)     // Catch:{ all -> 0x02db }
            java.lang.Object[] r1 = new java.lang.Object[]{r1}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r3, r1)     // Catch:{ all -> 0x02db }
        L_0x01cf:
            byte r5 = r9.adjustDesiredStateForConfig(r0, r14)     // Catch:{ all -> 0x02db }
        L_0x01d3:
            r3 = 0
            r0 = r19
            if (r2 < r0) goto L_0x01d9
            r3 = 1
        L_0x01d9:
            java.lang.String r1 = "incremental regen already handled"
            java.lang.Object[] r0 = new java.lang.Object[r12]     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.assertThat(r3, r1, r0)     // Catch:{ all -> 0x02db }
            long r0 = (long) r5     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.OdexScheme r3 = r9.schemeForState(r8, r6, r0)     // Catch:{ all -> 0x02db }
            r0 = r17
            r9.deleteFiles(r0)     // Catch:{ Exception -> 0x0208 }
            java.io.File r1 = r9.root     // Catch:{ Exception -> 0x0208 }
            java.lang.String r0 = "optimization_log"
            java.io.File r0 = X.AnonymousClass001.A0D(r1, r0)     // Catch:{ Exception -> 0x0208 }
            r0.delete()     // Catch:{ Exception -> 0x0208 }
            int r0 = r3.flags     // Catch:{ Exception -> 0x0208 }
            r0 = r0 & 16
            if (r0 != 0) goto L_0x0220
            r13 = r9
            r14 = r6
            r15 = r3
            r16 = r12
            r17 = r46
            r18 = r8
            r13.runCompiler(r14, r15, r16, r17, r18)     // Catch:{ Exception -> 0x0208 }
            goto L_0x0220
        L_0x0208:
            r1 = move-exception
            r0 = r19
            if (r5 == r0) goto L_0x02da
            java.lang.String r3 = "dex store %s: failed turbodex: using fallback"
            java.io.File r0 = r9.root     // Catch:{ all -> 0x02db }
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.w(r1, r3, r0)     // Catch:{ all -> 0x02db }
            r7.fallbackCause = r1     // Catch:{ all -> 0x02db }
            java.lang.String[] r17 = r9.listAndPruneRootFiles(r8)     // Catch:{ all -> 0x02db }
            r5 = 2
            goto L_0x01d3
        L_0x0220:
            long r0 = (long) r5     // Catch:{ all -> 0x02db }
        L_0x0221:
            r2 = r49 & 4
            r10 = 0
            if (r2 == 0) goto L_0x0236
            r10 = 1
            if (r11 != 0) goto L_0x0236
            r43 = r9
            r44 = r7
            r46 = r3
            r47 = r6
            r48 = r8
            r43.loadDexFiles(r44, r45, r46, r47, r48, r49)     // Catch:{ all -> 0x02db }
        L_0x0236:
            if (r45 == 0) goto L_0x025f
            if (r10 == 0) goto L_0x0253
            com.facebook.common.dextricks.DexStore$FinishRegenerationThread r5 = new com.facebook.common.dextricks.DexStore$FinishRegenerationThread     // Catch:{ all -> 0x02db }
            r50 = r5
            r51 = r9
            r52 = r3
            r54 = r0
            r50.<init>(r52, r53, r54)     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.ReentrantLockFile r2 = r9.mLockFile     // Catch:{ all -> 0x02db }
            r2.donateLock(r5)     // Catch:{ all -> 0x02db }
            r5.start()     // Catch:{ all -> 0x02cb }
            r2 = 0
            r53 = 0
            goto L_0x0260
        L_0x0253:
            java.io.File r5 = r9.root     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Prio r2 = com.facebook.common.dextricks.Prio.unchanged()     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Fs.fsyncRecursive(r5, r2)     // Catch:{ all -> 0x02db }
            r9.writeStatusLocked(r0)     // Catch:{ all -> 0x02db }
        L_0x025f:
            r2 = 0
        L_0x0260:
            r9.setUsingAppImageForMainDexStore(r8, r2)     // Catch:{ all -> 0x02db }
            if (r10 != 0) goto L_0x0274
            if (r11 != 0) goto L_0x0274
            r43 = r9
            r44 = r7
            r46 = r3
            r47 = r6
            r48 = r8
            r43.loadDexFiles(r44, r45, r46, r47, r48, r49)     // Catch:{ all -> 0x02db }
        L_0x0274:
            java.lang.String r2 = "dexopt"
            com.facebook.common.dextricks.DexStore$TmpDir r5 = r9.makeTemporaryDirectory(r2)     // Catch:{ all -> 0x028f }
            java.io.File r2 = r9.root     // Catch:{ all -> 0x0285 }
            int r0 = r3.loadInformationalStatus(r2, r0)     // Catch:{ all -> 0x0285 }
            r4 = r4 | r0
            r5.close()     // Catch:{ all -> 0x028f }
            goto L_0x0297
        L_0x0285:
            r1 = move-exception
            r5.close()     // Catch:{ all -> 0x028a }
            goto L_0x028e
        L_0x028a:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ all -> 0x028f }
        L_0x028e:
            throw r1     // Catch:{ all -> 0x028f }
        L_0x028f:
            r2 = move-exception
            java.lang.String r1 = "Failure while checking oat file provenance."
            java.lang.Object[] r0 = new java.lang.Object[r12]     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.Mlog.e(r2, r1, r0)     // Catch:{ all -> 0x02db }
        L_0x0297:
            java.lang.String r0 = r3.getSchemeName()     // Catch:{ all -> 0x02db }
            r7.odexSchemeName = r0     // Catch:{ all -> 0x02db }
            if (r45 == 0) goto L_0x02a1
            r4 = r4 | 1
        L_0x02a1:
            int r0 = r3.flags     // Catch:{ all -> 0x02db }
            r0 = r0 & 8
            if (r0 == 0) goto L_0x02a9
            r4 = r4 | 8
        L_0x02a9:
            r7.loadResult = r4     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.OreoFileUtils r0 = com.facebook.common.dextricks.OreoFileUtils.$redex_init_class     // Catch:{ all -> 0x02db }
            java.lang.String r0 = "dex2oat-cmdline"
            java.lang.String r0 = com.facebook.common.dextricks.OreoFileUtils.getBaseOdexKeyValue(r8, r0)     // Catch:{ all -> 0x02db }
            r7.dex2oatCmdLine = r0     // Catch:{ all -> 0x02db }
            int r0 = com.facebook.common.dextricks.DexStoreUtils.getBaseApkStorageKind(r8)     // Catch:{ all -> 0x02db }
            r7.storageKind = r0     // Catch:{ all -> 0x02db }
            r9.mLastDeri = r7     // Catch:{ all -> 0x02db }
        L_0x02bd:
            if (r53 == 0) goto L_0x0022
            r53.close()
            return r7
        L_0x02c3:
            return r0
        L_0x02c4:
            r1 = move-exception
            r14.close()     // Catch:{ all -> 0x02c9 }
            goto L_0x02da
        L_0x02c9:
            r0 = move-exception
            goto L_0x02d7
        L_0x02cb:
            r1 = move-exception
            java.lang.String r0 = "failed to start syncer thread"
            X.AnonymousClass001.A1I(r0)     // Catch:{ all -> 0x02db }
            com.facebook.common.dextricks.ReentrantLockFile r0 = r9.mLockFile     // Catch:{ all -> 0x02db }
            r0.stealLock()     // Catch:{ all -> 0x02db }
            goto L_0x02da
        L_0x02d7:
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ all -> 0x02db }
        L_0x02da:
            throw r1     // Catch:{ all -> 0x02db }
        L_0x02db:
            r0 = move-exception
            if (r53 == 0) goto L_0x02e1
            r53.close()
        L_0x02e1:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.loadAllImpl(int, com.facebook.quicklog.LightweightQuickPerformanceLogger, android.content.Context):com.facebook.common.dextricks.DexErrorRecoveryInfo");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00af, code lost:
        if (com.facebook.common.dextricks.ClassLoaderConfigurationHelper.sImpl.getConfig().mDexFiles.size() != r1) goto L_0x00b1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void loadDexFiles(com.facebook.common.dextricks.DexErrorRecoveryInfo r7, boolean r8, com.facebook.common.dextricks.OdexScheme r9, com.facebook.common.dextricks.DexManifest r10, android.content.Context r11, int r12) {
        /*
            r6 = this;
            boolean r0 = r10.locators
            r4 = 0
            if (r0 == 0) goto L_0x0006
            r4 = 2
        L_0x0006:
            r0 = r12 & 16
            if (r0 == 0) goto L_0x000c
            r4 = r4 | 4
        L_0x000c:
            r6.installArtHacks(r11, r7)
            java.lang.String r0 = "fb4a_enable_io_logging_across_add_dexes"
            boolean r0 = checkAndClearGk(r11, r0)
            logDexAddPageFaults = r0
            if (r0 == 0) goto L_0x0025
            X.0iN r2 = X.C11420iO.A00()
            long r0 = r2.A03
            majPageFaultsDelta = r0
            long r0 = r2.A02
            pageInBytesDelta = r0
        L_0x0025:
            int r1 = com.facebook.common.dextricks.DalvikConstants.FB_REDEX_COLD_START_SET_DEX_COUNT
            boolean r0 = r6.mDisableVerifier
            com.facebook.common.dextricks.ClassLoaderConfiguration r3 = new com.facebook.common.dextricks.ClassLoaderConfiguration
            r3.<init>(r4, r1, r0)
            java.util.ArrayList r0 = r3.mDexFiles
            int r1 = r0.size()
            java.io.File r0 = r6.root
            r9.configureClassLoader(r0, r3)
            java.util.ArrayList r0 = r3.mDexFiles
            java.util.ArrayList r0 = X.AnonymousClass001.A0v(r0)
            r6.mLoadedDexFiles = r0
            java.lang.String r2 = "MDCL.install"
            r0 = 1224522321(0x48fcba51, float:517586.53)
            X.C08060bQ.A01(r2, r0)
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper.mergeConfiguration(r3)     // Catch:{ all -> 0x009d }
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl r0 = com.facebook.common.dextricks.ClassLoaderConfigurationHelper.sImpl     // Catch:{ all -> 0x009d }
            com.facebook.common.dextricks.ClassLoaderConfiguration r2 = r0.getConfig()     // Catch:{ all -> 0x009d }
            boolean r0 = r6.mDisableVerifier     // Catch:{ all -> 0x009d }
            r2.disableVerifier = r0     // Catch:{ all -> 0x009d }
            java.lang.ClassLoader r0 = com.facebook.common.dextricks.ReflectionClassLoader.APP_CLASSLOADER     // Catch:{ all -> 0x009d }
            boolean r0 = r0 instanceof dalvik.system.DelegateLastClassLoader     // Catch:{ all -> 0x009d }
            if (r0 == 0) goto L_0x005f
            com.facebook.common.dextricks.ReflectionClassLoader.install()     // Catch:{ all -> 0x009d }
        L_0x005f:
            java.util.ArrayList r2 = r6.primaryDexes     // Catch:{ all -> 0x009d }
            java.util.ArrayList r0 = r6.auxiliaryDexes     // Catch:{ all -> 0x009d }
            java.lang.ClassLoader r2 = com.facebook.common.dextricks.MultiDexClassLoader.install(r11, r2, r0)     // Catch:{ all -> 0x009d }
            boolean r0 = r2 instanceof com.facebook.common.dextricks.MultiDexClassLoader     // Catch:{ all -> 0x009d }
            if (r0 == 0) goto L_0x0076
            com.facebook.common.dextricks.MultiDexClassLoader r2 = (com.facebook.common.dextricks.MultiDexClassLoader) r2     // Catch:{ all -> 0x009d }
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl r0 = com.facebook.common.dextricks.ClassLoaderConfigurationHelper.sImpl     // Catch:{ all -> 0x009d }
            com.facebook.common.dextricks.ClassLoaderConfiguration r0 = r0.getConfig()     // Catch:{ all -> 0x009d }
            r2.configure(r0)     // Catch:{ all -> 0x009d }
        L_0x0076:
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper.clearDexConfig(r3)     // Catch:{ all -> 0x009d }
            if (r8 == 0) goto L_0x007e
            r10.verifyCanaryClasses()     // Catch:{ all -> 0x009d }
        L_0x007e:
            r6.mLoadedManifest = r10     // Catch:{ all -> 0x009d }
            r0 = 368336853(0x15f45fd5, float:9.870201E-26)
            X.C08060bQ.A00(r0)
            boolean r0 = logDexAddPageFaults
            if (r0 == 0) goto L_0x009c
            X.0iN r4 = X.C11420iO.A00()
            long r2 = r4.A03
            long r0 = majPageFaultsDelta
            long r2 = r2 - r0
            majPageFaultsDelta = r2
            long r2 = r4.A02
            long r0 = pageInBytesDelta
            long r2 = r2 - r0
            pageInBytesDelta = r2
        L_0x009c:
            return
        L_0x009d:
            r5 = move-exception
            r0 = r12 & 2
            if (r0 != 0) goto L_0x00b1
            com.facebook.common.dextricks.ClassLoaderConfigurationHelper$Impl r0 = com.facebook.common.dextricks.ClassLoaderConfigurationHelper.sImpl     // Catch:{ all -> 0x00e6 }
            com.facebook.common.dextricks.ClassLoaderConfiguration r0 = r0.getConfig()     // Catch:{ all -> 0x00e6 }
            java.util.ArrayList r0 = r0.mDexFiles     // Catch:{ all -> 0x00e6 }
            int r0 = r0.size()     // Catch:{ all -> 0x00e6 }
            r4 = 0
            if (r0 == r1) goto L_0x00b2
        L_0x00b1:
            r4 = 1
        L_0x00b2:
            java.lang.String r3 = "%s error in store %s scheme %s regen %s"
            if (r4 == 0) goto L_0x00c6
            java.lang.String r2 = "fatal"
        L_0x00b8:
            java.io.File r1 = r6.root     // Catch:{ all -> 0x00e6 }
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r8)     // Catch:{ all -> 0x00e6 }
            java.lang.Object[] r0 = new java.lang.Object[]{r2, r1, r9, r0}     // Catch:{ all -> 0x00e6 }
            com.facebook.common.dextricks.Mlog.e(r5, r3, r0)     // Catch:{ all -> 0x00e6 }
            goto L_0x00c9
        L_0x00c6:
            java.lang.String r2 = "recoverable"
            goto L_0x00b8
        L_0x00c9:
            if (r8 == 0) goto L_0x00ce
            r0 = 5
            goto L_0x00d0
        L_0x00ce:
            r0 = 0
        L_0x00d0:
            r6.writeStatusLocked(r0)     // Catch:{ all -> 0x00e6 }
            if (r4 == 0) goto L_0x00db
            com.facebook.common.dextricks.FatalDexError r0 = new com.facebook.common.dextricks.FatalDexError     // Catch:{ all -> 0x00e6 }
            r0.<init>(r5)     // Catch:{ all -> 0x00e6 }
            goto L_0x00e5
        L_0x00db:
            java.lang.String r0 = "retrying dex store load after reset"
            X.AnonymousClass001.A1I(r0)     // Catch:{ all -> 0x00e6 }
            com.facebook.common.dextricks.DexStore$RecoverableDexException r0 = new com.facebook.common.dextricks.DexStore$RecoverableDexException     // Catch:{ all -> 0x00e6 }
            r0.<init>(r5)     // Catch:{ all -> 0x00e6 }
        L_0x00e5:
            throw r0     // Catch:{ all -> 0x00e6 }
        L_0x00e6:
            r1 = move-exception
            r0 = 729215959(0x2b76f3d7, float:8.773515E-13)
            X.C08060bQ.A00(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.loadDexFiles(com.facebook.common.dextricks.DexErrorRecoveryInfo, boolean, com.facebook.common.dextricks.OdexScheme, com.facebook.common.dextricks.DexManifest, android.content.Context, int):void");
    }

    public static long nowTimestamp() {
        return sDexStoreClock.now();
    }

    private byte[] readSavedDepBlock() {
        File A0D = AnonymousClass001.A0D(this.root, DEPS_FILENAME);
        if (!A0D.exists()) {
            return null;
        }
        try {
            RandomAccessFile A0H = AnonymousClass001.A0H(A0D);
            try {
                long length = A0H.length();
                if (length <= 16777216) {
                    byte[] bArr = new byte[((int) length)];
                    if (((long) A0H.read(bArr)) >= length) {
                        return bArr;
                    }
                }
                Fs.safeClose((Closeable) A0H);
                return null;
            } finally {
                Fs.safeClose((Closeable) A0H);
            }
        } catch (FileNotFoundException e) {
            Mlog.w(e, "unable to open deps file %s", A0D);
            return null;
        }
    }

    private void setCompressedOreoDexErrorRecoveryInfo(DexErrorRecoveryInfo dexErrorRecoveryInfo, OdexSchemeOreo odexSchemeOreo, int i) {
        File file = odexSchemeOreo.mZipFile;
        int markLoadResult = odexSchemeOreo.markLoadResult(i, this.mUseEagerDexOpt);
        dexErrorRecoveryInfo.loadResult = markLoadResult;
        dexErrorRecoveryInfo.odexSize = OreoFileUtils.getOdex(file).length();
        dexErrorRecoveryInfo.odexLastModified = OreoFileUtils.getOdex(file).lastModified();
        dexErrorRecoveryInfo.odexSchemeName = "OdexSchemeOreo";
        boolean z = true;
        if ((markLoadResult & 1) == 0) {
            z = false;
        }
        dexErrorRecoveryInfo.dexoptDuringColdStart = z;
        dexErrorRecoveryInfo.dex2oatCmdLine = OreoFileUtils.getMegazipOdexKeyValue(file, "dex2oat-cmdline");
        dexErrorRecoveryInfo.vdexSize = OreoFileUtils.getVdex(file).length();
        dexErrorRecoveryInfo.vdexLastModified = OreoFileUtils.getVdex(file).lastModified();
    }

    private void setUsingAppImageForMainDexStore(final Context context, final File file) {
        Runnable r1;
        String str = this.id;
        if (str != null && DexStoreUtils.MAIN_DEX_STORE_ID.equals(str)) {
            if (file != null) {
                r1 = new Runnable() {
                    public void run() {
                        DexErrorRecoveryInfoAsync.setMainDexStoreLoadInformation(OreoFileUtils.collectAsyncInfoWithSecondary(context, file));
                    }
                };
            } else {
                r1 = new Runnable() {
                    public void run() {
                        DexErrorRecoveryInfoAsync.setMainDexStoreLoadInformation(OreoFileUtils.collectBaseAsyncInfo(context));
                    }
                };
            }
            new Thread(r1).start();
        }
    }

    private boolean shouldLoadCompressedOreoImpl(Context context, DexManifest dexManifest) {
        if (!sLoadedCompressedOreo) {
            if ((context.getApplicationInfo().flags & Constants.LOAD_RESULT_DEX2OAT_CLASSPATH_SET) != 0 || dexManifest.canLoadCanaryClass()) {
                return false;
            }
            sLoadedCompressedOreo = true;
        }
        return true;
    }

    public void addChild(DexStore dexStore) {
        if (!this.mChildStores.contains(dexStore)) {
            this.mChildStores.add(dexStore);
        }
    }

    public boolean attemptedOptimizationSinceRegeneration() {
        return AnonymousClass001.A1T(this.root, OPTIMIZATION_LOG_FILENAME);
    }

    public void forceRegenerateOnNextLoad() {
        ReentrantLockFile.Lock acquire = this.mLockFile.acquire(0);
        try {
            writeStatusLocked(6);
            if (acquire != null) {
                acquire.close();
            }
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public long getApkLastModified() {
        return this.mApk.lastModified();
    }

    public Map getDiagnostics(Context context) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        long reportStatus = reportStatus();
        Config readConfig = readConfig();
        schemeForState(context, loadManifest(), reportStatus);
        linkedHashMap.put("loadNotOptimized", Boolean.toString(true));
        linkedHashMap.put("scheme", getStatusDescription(reportStatus));
        linkedHashMap.put("status", Long.toHexString(reportStatus));
        linkedHashMap.put("config.enablePgoCompile", Boolean.toString(readConfig.tryPeriodicPgoCompilation));
        if (readConfig.tryPeriodicPgoCompilation) {
            linkedHashMap.put("config.minPgoDuration", Long.toString(readConfig.minTimeBetweenPgoCompilationMs));
            linkedHashMap.put("config.timeleft", "<no info>");
        }
        return linkedHashMap;
    }

    public File getRegenFile() {
        return AnonymousClass001.A0D(this.root, REGEN_STAMP_FILENAME);
    }

    public boolean hasChildren() {
        return this.mChildStores.isEmpty();
    }

    public DexManifest loadManifest() {
        DexManifest loadManifestFrom;
        C08060bQ.A01("DexStore.loadManifest", -1473556854);
        if (this.mManifest == null) {
            synchronized (this) {
                if (this.mManifest == null) {
                    if (this.mIsArtMainStore) {
                        loadManifestFrom = new DexManifest(this.mResProvider.isExoResProvider());
                    } else {
                        loadManifestFrom = DexManifest.loadManifestFrom(this.mResProvider, DexStoreUtils.SECONDARY_DEX_MANIFEST, true);
                    }
                    this.id = loadManifestFrom.id;
                    this.mManifest = loadManifestFrom;
                }
            }
        }
        C08060bQ.A00(-235082202);
        return this.mManifest;
    }

    public TmpDir makeTemporaryDirectory(String str) {
        File file;
        File file2;
        ReentrantLockFile reentrantLockFile;
        ReentrantLockFile.Lock acquire = this.mLockFile.acquire(0);
        ReentrantLockFile.Lock lock = null;
        try {
            file = File.createTempFile(str, TMPDIR_LOCK_SUFFIX, this.root);
            try {
                file2 = AnonymousClass0WY.A01(Fs.stripLastExtension(file.getName()), TMPDIR_SUFFIX, this.root);
                Fs.mkdirOrThrow(file2);
                try {
                    reentrantLockFile = ReentrantLockFile.open(file);
                } catch (Throwable th) {
                    th = th;
                    reentrantLockFile = null;
                    try {
                        Fs.safeClose((Closeable) lock);
                        Fs.safeClose((Closeable) reentrantLockFile);
                        Fs.deleteRecursiveNoThrow(file);
                        Fs.deleteRecursiveNoThrow(file2);
                        throw th;
                    } catch (Throwable th2) {
                        AnonymousClass0ZM.A00(th, th2);
                        throw th;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                file2 = null;
                reentrantLockFile = null;
                Fs.safeClose((Closeable) lock);
                Fs.safeClose((Closeable) reentrantLockFile);
                Fs.deleteRecursiveNoThrow(file);
                Fs.deleteRecursiveNoThrow(file2);
                throw th;
            }
            try {
                lock = reentrantLockFile.tryAcquire(1);
                if (lock != null) {
                    TmpDir tmpDir = new TmpDir(lock, file2);
                    if (acquire != null) {
                        acquire.close();
                    }
                    return tmpDir;
                }
                throw AnonymousClass001.A0V("should have been able to acquire tmpdir lock");
            } catch (Throwable th4) {
                th = th4;
                Fs.safeClose((Closeable) lock);
                Fs.safeClose((Closeable) reentrantLockFile);
                Fs.deleteRecursiveNoThrow(file);
                Fs.deleteRecursiveNoThrow(file2);
                throw th;
            }
        } catch (Throwable th5) {
            th = th5;
            file = null;
            file2 = null;
            reentrantLockFile = null;
            Fs.safeClose((Closeable) lock);
            Fs.safeClose((Closeable) reentrantLockFile);
            Fs.deleteRecursiveNoThrow(file);
            Fs.deleteRecursiveNoThrow(file2);
            throw th;
        }
    }

    public void markArtMainStore(Context context) {
        if (C18550xJ.A03(context, Experiments.SKIP_MANIFEST_RELEASE) || C18550xJ.A03(context, Experiments.SKIP_MANIFEST)) {
            Mlog.w("Marking ArtMainStore true!", new Object[0]);
            this.mIsArtMainStore = true;
        }
    }

    public Config readConfig() {
        File A0D;
        Config config;
        ReentrantLockFile.Lock acquire = this.mLockFile.acquire(0);
        try {
            A0D = AnonymousClass001.A0D(this.root, CONFIG_FILENAME);
            config = Config.read(A0D);
        } catch (FileNotFoundException unused) {
            config = new Config.Builder().build();
        } catch (UnsupportedOperationException unused2) {
            Fs.deleteRecursive(A0D);
            config = new Config.Builder().build();
        } catch (Exception e) {
            Mlog.w(e, "error reading dex store config file %s: deleting and proceeding", new Object[0]);
            Fs.deleteRecursive(A0D);
            config = new Config.Builder().build();
        } catch (Throwable th) {
            if (acquire != null) {
                try {
                    acquire.close();
                    throw th;
                } catch (Throwable th2) {
                    AnonymousClass0ZM.A00(th, th2);
                    throw th;
                }
            }
            throw th;
        }
        if (acquire != null) {
            acquire.close();
        }
        return config;
    }

    public void setResProvider(ResProvider resProvider) {
        this.mResProvider = resProvider;
        this.mDexIteratorFactory = new DexIteratorFactory(resProvider);
    }

    public DexStore(File file, File file2, ResProvider resProvider, ArrayList arrayList, ArrayList arrayList2) {
        this.mApk = file2;
        this.root = file;
        Fs.mkdirOrThrow(file);
        this.mLockFile = ReentrantLockFile.open(AnonymousClass001.A0D(file, MDEX_LOCK_FILENAME));
        this.mResProvider = resProvider;
        this.mDexIteratorFactory = new DexIteratorFactory(resProvider);
        this.primaryDexes = arrayList;
        this.auxiliaryDexes = arrayList2;
    }

    private boolean checkDeps() {
        byte[] readCurrentDepBlock = readCurrentDepBlock();
        byte[] readSavedDepBlock = readSavedDepBlock();
        if (readSavedDepBlock == null || !Arrays.equals(readCurrentDepBlock, readSavedDepBlock)) {
            return false;
        }
        return true;
    }

    private int checkDirty(OdexScheme odexScheme, String[] strArr) {
        ArrayList A0t = AnonymousClass001.A0t();
        int checkDirty = checkDirty(odexScheme, strArr, A0t);
        Iterator it = A0t.iterator();
        while (it.hasNext()) {
            Fs.deleteRecursive((File) it.next());
        }
        return checkDirty;
    }

    public static long getApkIdentifier(File file, boolean z) {
        int A01 = BuildConstants.A01();
        if (A01 > 1) {
            AnonymousClass001.A1I("Build id used for apk identification");
            return (long) A01;
        }
        try {
            Long baseApkDexFilesIdentifier = getBaseApkDexFilesIdentifier(file);
            if (baseApkDexFilesIdentifier != null) {
                AnonymousClass001.A1I("CRC used for apk identification");
                return baseApkDexFilesIdentifier.longValue();
            }
            if (z) {
                long lastModified = file.lastModified();
                if (lastModified > 0) {
                    return lastModified;
                }
            }
            throw AnonymousClass0WY.A0A("No usable identifier for apk ", file.getPath());
        } catch (IOException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public static String getIdForTracing(File file) {
        int i;
        String path = file.getPath();
        int length = path.length();
        if (length <= 64) {
            return path;
        }
        if (path.startsWith("/data/data/")) {
            i = path.indexOf(47, 11) + 1;
            if (length <= i + 64) {
                return path.substring(i);
            }
        } else {
            i = 0;
        }
        return path.substring(i, i + 64);
    }

    public static boolean isDoppelDexBuild() {
        return false;
    }

    private String[] listAndPruneRootFiles(Context context) {
        ArrayList A0t = AnonymousClass001.A0t();
        String[] listRootFilesForPruningLocked = listRootFilesForPruningLocked(context, A0t);
        Iterator it = A0t.iterator();
        while (it.hasNext()) {
            Fs.deleteRecursive((File) it.next());
        }
        return listRootFilesForPruningLocked;
    }

    private String[] listRootFilesForPruningLocked(Context context, List list) {
        int length;
        String str;
        ReentrantLockFile.Lock tryAcquire;
        assertLockHeld();
        String[] list2 = this.root.list();
        if (list2 != null) {
            int i = 0;
            while (true) {
                length = list2.length;
                if (i >= length) {
                    break;
                }
                String str2 = list2[i];
                if (str2.equals(MDEX_LOCK_FILENAME) || str2.equals(MDEX_STATUS_FILENAME) || str2.equals(ODEX_LOCK_FILENAME) || str2.equals(DEPS_FILENAME) || str2.equals(REGEN_STAMP_FILENAME) || str2.equals(OPTIMIZATION_LOG_FILENAME) || str2.equals(OPTIMIZATION_HISTORY_LOG_FILENAME) || str2.equals(CONFIG_FILENAME)) {
                    list2[i] = null;
                }
                if (str2.equals(CONFIG_TMP_FILENAME)) {
                    list.add(AnonymousClass001.A0D(this.root, str2));
                    list2[i] = null;
                }
                i++;
            }
            for (int i2 = 0; i2 < length; i2++) {
                String str3 = list2[i2];
                if (str3 != null) {
                    if (str3.endsWith(TMPDIR_LOCK_SUFFIX)) {
                        list2[i2] = null;
                        int findInArray = findInArray(list2, AnonymousClass0WY.A0i(Fs.stripLastExtension(str3), TMPDIR_SUFFIX));
                        if (findInArray >= 0) {
                            str = list2[findInArray];
                            list2[findInArray] = null;
                        } else {
                            str = null;
                        }
                    } else if (str3.endsWith(TMPDIR_SUFFIX)) {
                        list2[i2] = null;
                        int findInArray2 = findInArray(list2, AnonymousClass0WY.A0i(Fs.stripLastExtension(str3), TMPDIR_LOCK_SUFFIX));
                        if (findInArray2 >= 0) {
                            String str4 = list2[findInArray2];
                            list2[findInArray2] = null;
                            str = str3;
                            str3 = str4;
                        } else {
                            str = str3;
                            str3 = null;
                        }
                    } else {
                        str3 = null;
                        str = null;
                    }
                    if (str3 != null && str != null) {
                        File A0D = AnonymousClass001.A0D(this.root, str3);
                        ReentrantLockFile open = ReentrantLockFile.open(A0D);
                        try {
                            tryAcquire = open.tryAcquire(0);
                            if (tryAcquire != null) {
                                list.add(A0D);
                                list.add(AnonymousClass001.A0D(this.root, str));
                                tryAcquire.close();
                            }
                            open.close();
                        } catch (Throwable th) {
                            try {
                                open.close();
                                throw th;
                            } catch (Throwable th2) {
                                AnonymousClass0ZM.A00(th, th2);
                                throw th;
                            }
                        }
                    } else if (str3 != null) {
                        list.add(AnonymousClass001.A0D(this.root, str3));
                    } else if (str != null) {
                        list.add(AnonymousClass001.A0D(this.root, str));
                    }
                }
            }
            return list2;
        }
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("unable to list directory ");
        throw AnonymousClass001.A0G(AnonymousClass001.A0d(this.root, A0m));
    }

    public static DexStore open(File file, File file2, ResProvider resProvider) {
        return open(file, file2, resProvider, AnonymousClass001.A0t(), AnonymousClass001.A0t());
    }

    private long readStatusLocked() {
        assertLockHeld();
        File A0D = AnonymousClass001.A0D(this.root, MDEX_STATUS_FILENAME);
        try {
            FileInputStream A0F = AnonymousClass001.A0F(A0D);
            try {
                byte[] bArr = new byte[16];
                if (A0F.read(bArr, 0, 16) >= 16) {
                    ByteBuffer wrap = ByteBuffer.wrap(bArr);
                    long j = wrap.getLong();
                    long j2 = wrap.getLong();
                    Long valueOf = Long.valueOf(j);
                    Long valueOf2 = Long.valueOf(j2);
                    long j3 = j ^ MDEX_STATUS_XOR;
                    if (j3 != j2) {
                        Mlog.e("check mismatch: status:%x expected-check:%x actual-check:%x", valueOf, Long.valueOf(j3), valueOf2);
                    } else {
                        Fs.safeClose((Closeable) A0F);
                        return j;
                    }
                }
                Fs.deleteRecursiveNoThrow(A0D);
                return 0;
            } finally {
                Fs.safeClose((Closeable) A0F);
            }
        } catch (FileNotFoundException unused) {
            return 0;
        }
    }

    private void runCompiler(DexManifest dexManifest, OdexScheme odexScheme, int i, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger, Context context) {
        InputDex next2;
        OdexScheme.Compiler makeCompiler = odexScheme.makeCompiler(this, i);
        try {
            InputDexIterator openDexIterator = this.mDexIteratorFactory.openDexIterator(this.id, dexManifest, lightweightQuickPerformanceLogger, context);
            while (openDexIterator.hasNext()) {
                try {
                    next2 = openDexIterator.next();
                    makeCompiler.compile(next2);
                    next2.close();
                } catch (Throwable th) {
                    openDexIterator.close();
                    throw th;
                }
            }
            makeCompiler.performFinishActions();
            openDexIterator.close();
            makeCompiler.close();
            return;
            throw th;
        } catch (Throwable th2) {
            if (makeCompiler != null) {
                try {
                    makeCompiler.close();
                    throw th2;
                } catch (Throwable th3) {
                    AnonymousClass0ZM.A00(th2, th3);
                    throw th2;
                }
            }
            throw th2;
        }
    }

    private void saveDeps() {
        byte[] readCurrentDepBlock = readCurrentDepBlock();
        RandomAccessFile A0I = AnonymousClass001.A0I(AnonymousClass001.A0D(this.root, DEPS_FILENAME));
        try {
            A0I.write(readCurrentDepBlock);
            A0I.setLength(A0I.getFilePointer());
            A0I.close();
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    private OdexScheme schemeForState(Context context, DexManifest dexManifest, long j, int i) {
        return schemeForState(context, dexManifest, j);
    }

    private void touchRegenStamp() {
        File regenFile = getRegenFile();
        regenFile.createNewFile();
        if (!regenFile.setLastModified(sDexStoreClock.now())) {
            throw AnonymousClass001.A0G(AnonymousClass002.A0M(regenFile, "could not set modtime of ", AnonymousClass001.A0m()));
        }
    }

    public List getLoadedDexFiles() {
        return this.mLoadedDexFiles;
    }

    public DexManifest getLoadedManifest() {
        return this.mLoadedManifest;
    }

    public String getMegaZipPath() {
        return this.mMegaZipPath;
    }

    public String[] getParentNames() {
        return loadManifest().requires;
    }

    public ResProvider getResProvider() {
        return this.mResProvider;
    }

    public boolean isArtMainStore() {
        return this.mIsArtMainStore;
    }

    public boolean useBgDexOpt() {
        return this.mUseBgDexOpt;
    }

    public boolean useEagerDexOpt() {
        return this.mUseEagerDexOpt;
    }

    public void writeStatusLocked(long j) {
        assertLockHeld();
        if (((byte) ((int) (15 & j))) != 1) {
            DalvikInternals.fsyncNamed(this.root.getAbsolutePath(), -1);
        }
        File A0D = AnonymousClass001.A0D(this.root, MDEX_STATUS_FILENAME);
        long j2 = MDEX_STATUS_XOR ^ j;
        byte[] bArr = new byte[16];
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        wrap.putLong(j);
        wrap.putLong(j2);
        FileOutputStream fileOutputStream = new FileOutputStream(A0D);
        try {
            fileOutputStream.write(bArr, 0, 16);
            fileOutputStream.getFD().sync();
            fileOutputStream.close();
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public final class RecoverableDexException extends Exception {
        public RecoverableDexException(Throwable th) {
            super(th);
        }
    }

    public static void setClock(DexStoreClock dexStoreClock) {
        sDexStoreClock = dexStoreClock;
    }

    public static void setIsSynchronizedDexConfig(boolean z) {
        ClassLoaderConfigurationHelper.setIsSynchronized(z);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x005b, code lost:
        if (r0.mIsOptional == false) goto L_0x005d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int checkDirty(com.facebook.common.dextricks.OdexScheme r8, java.lang.String[] r9, java.util.List r10) {
        /*
            r7 = this;
            java.lang.String[] r2 = r8.expectedFiles
            int r0 = r8.flags
            r0 = r0 & 2
            r5 = 0
            if (r0 == 0) goto L_0x000a
            r5 = 2
        L_0x000a:
            java.lang.Object r6 = r9.clone()
            java.lang.String[] r6 = (java.lang.String[]) r6
            r7.setDifference(r6, r2)
            r4 = 0
            r3 = 0
        L_0x0015:
            int r0 = r6.length
            r1 = 1
            if (r4 >= r0) goto L_0x0032
            r0 = r6[r4]
            if (r0 == 0) goto L_0x002f
            boolean r0 = com.facebook.common.dextricks.DexStoreUtils.isIgnoreDirtyFileName(r0)
            if (r0 != 0) goto L_0x002f
            java.io.File r1 = r7.root
            r0 = r6[r4]
            java.io.File r0 = X.AnonymousClass001.A0D(r1, r0)
            r10.add(r0)
            r3 = 1
        L_0x002f:
            int r4 = r4 + 1
            goto L_0x0015
        L_0x0032:
            if (r3 == 0) goto L_0x003b
            int r0 = r8.flags
            r0 = r0 & 1
            if (r0 == 0) goto L_0x003b
            r5 = 2
        L_0x003b:
            boolean r0 = r7.checkDeps()
            if (r0 != 0) goto L_0x0043
            r5 = 2
        L_0x0042:
            return r5
        L_0x0043:
            if (r5 >= r1) goto L_0x0042
            com.facebook.common.dextricks.ExpectedFileInfo[] r4 = r8.expectedFileInfos
            java.lang.Object r3 = r2.clone()
            java.lang.String[] r3 = (java.lang.String[]) r3
            r7.setDifference(r3, r9)
            r2 = 0
        L_0x0051:
            int r0 = r3.length
            if (r2 >= r0) goto L_0x0042
            r0 = r4[r2]
            if (r0 == 0) goto L_0x005d
            boolean r0 = r0.mIsOptional
            r1 = 1
            if (r0 != 0) goto L_0x005e
        L_0x005d:
            r1 = 0
        L_0x005e:
            r0 = r3[r2]
            if (r0 == 0) goto L_0x0065
            if (r1 != 0) goto L_0x0065
            r5 = 1
        L_0x0065:
            int r2 = r2 + 1
            goto L_0x0051
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStore.checkDirty(com.facebook.common.dextricks.OdexScheme, java.lang.String[], java.util.List):int");
    }

    public static synchronized DexStore findOpened(File file) {
        synchronized (DexStore.class) {
            File absoluteFile = file.getAbsoluteFile();
            for (DexStore dexStoreListHead = dexStoreListHead(); dexStoreListHead != null; dexStoreListHead = dexStoreListHead.next) {
                if (dexStoreListHead.root.equals(absoluteFile)) {
                    return dexStoreListHead;
                }
            }
            return null;
        }
    }

    /* JADX INFO: finally extract failed */
    public static synchronized DexStore open(File file, File file2, ResProvider resProvider, ArrayList arrayList, ArrayList arrayList2) {
        DexStore dexStoreListHead;
        int i;
        synchronized (DexStore.class) {
            C08060bQ.A01(AnonymousClass0WY.A0w("DexStore.open[", getIdForTracing(file), "]"), 1483972656);
            try {
                File absoluteFile = file.getAbsoluteFile();
                dexStoreListHead = dexStoreListHead();
                while (true) {
                    if (dexStoreListHead == null) {
                        dexStoreListHead = new DexStore(absoluteFile, file2, resProvider, arrayList, arrayList2);
                        sListHead = dexStoreListHead;
                        i = -125056790;
                        break;
                    } else if (dexStoreListHead.root.equals(absoluteFile)) {
                        i = -974165148;
                        break;
                    } else {
                        dexStoreListHead = dexStoreListHead.next;
                    }
                }
                C08060bQ.A00(i);
            } catch (Throwable th) {
                C08060bQ.A00(-320691276);
                throw th;
            }
        }
        return dexStoreListHead;
    }

    private OdexScheme schemeForState(Context context, DexManifest dexManifest, long j) {
        if (dexManifest.isUncompressedExo()) {
            AnonymousClass001.A1I("Uncompressed exo package detected, using OdexSchemeUncompressedExo scheme");
            return new OdexSchemeUncompressedExo(dexManifest, this.mResProvider);
        }
        if (dexManifest.isArtMainStore) {
            AnonymousClass001.A1I("This is the main store for art builds, using noop scheme");
        } else {
            DexManifest.Dex[] dexArr = dexManifest.dexes;
            byte b = (byte) ((int) (15 & j));
            if (b == 2) {
                return new OdexSchemeBoring(dexArr);
            }
            if (b == 7) {
                return new OdexSchemeArtTurbo(dexArr);
            }
            if (b == 8) {
                return new OdexSchemeArtXdex(dexArr, j);
            }
            if (b != 9) {
                return new OdexSchemeInvalid(j);
            }
        }
        return new OdexSchemeNoop();
    }
}
