package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.C12760mF;
import X.C12790mK;
import com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger;
import com.facebook.common.dextricks.coverage.logger.ClassCoverageLogger;
import com.facebook.common.dextricks.stats.ClassLoadingStats;
import com.facebook.profilo.logger.api.ProfiloClassLoadTracer;
import com.facebook.profilo.logger.api.ProfiloLogger;

public class ClassLoadsTracer implements ClassLoadsListener {
    public static final String TAG = "ClassLoadsTracer";
    public static final ClassLoadingStats mClassLoadingStats = ClassLoadingStatsHolder.sClassLoadingStats;
    public static final ClassLoadsTracer sInstance = new Object();
    public static volatile boolean sTracingLoggerInitialized;

    public static boolean preloadClasses() {
        try {
            Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger");
            Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerNativeHolder");
            Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerLite");
            Class.forName("com.facebook.common.dextricks.classid.ClassId");
            Class.forName("com.facebook.profilo.logger.api.ProfiloClassLoadTracer");
            return true;
        } catch (ClassNotFoundException e) {
            C12790mK.A02(TAG, "Could not preload class", e);
            return false;
        }
    }

    public static synchronized void install(boolean z, ClassLoadsLoggingProvider classLoadsLoggingProvider) {
        String str;
        String str2;
        Object[] objArr;
        synchronized (ClassLoadsTracer.class) {
            if (!C12760mF.A01) {
                C12790mK.A01(TAG, "ClassTracingLogger not initialized, waiting for callback.");
                ClassLoadsTracer$$ExternalSyntheticLambda0 classLoadsTracer$$ExternalSyntheticLambda0 = new ClassLoadsTracer$$ExternalSyntheticLambda0(z);
                boolean z2 = ClassTracingLogger.A04;
                synchronized (ClassTracingLogger.class) {
                    ClassTracingLogger.A00.add(classLoadsTracer$$ExternalSyntheticLambda0);
                }
            } else if (!z || preloadClasses()) {
                sTracingLoggerInitialized = true;
            } else {
                str = TAG;
                str2 = "Failed to install ClassLoadsTracer, could not preload class.";
                objArr = new Object[0];
                C12790mK.A02(str, str2, objArr);
            }
            classLoadsLoggingProvider.addListener(sInstance);
            str = TAG;
            str2 = "Installed ClassLoadsTracer to %s.";
            objArr = new Object[]{classLoadsLoggingProvider};
            C12790mK.A02(str, str2, objArr);
        }
    }

    public static /* synthetic */ void lambda$install$0(boolean z, boolean z2) {
        String A0i;
        if (!z || preloadClasses()) {
            sTracingLoggerInitialized = z2;
            A0i = AnonymousClass0WY.A0i("ClassTracingLogger initialized=", String.valueOf(sTracingLoggerInitialized));
        } else {
            A0i = "Failed to preload classes, could not initialize ClassTracingLogger.";
        }
        C12790mK.A01(TAG, A0i);
    }

    public void onClassLoadBegin(String str) {
        if (sTracingLoggerInitialized) {
            if (ProfiloClassLoadTracer.sTracer != null) {
                ProfiloLogger.classLoadStart();
            }
            ClassTracingLogger.beginClassLoad(str);
        }
        mClassLoadingStats.incrementClassLoadsAttempted();
    }

    public void onClassLoaded(Class cls) {
        if (sTracingLoggerInitialized) {
            ClassTracingLogger.classLoaded(cls);
            if (ProfiloClassLoadTracer.sTracer != null) {
                ProfiloLogger.classLoadEnd(cls);
            }
        }
        boolean z = ClassCoverageLogger.A02;
        String name = cls.getName();
        if (!ClassCoverageLogger.A01.isEmpty() && name.startsWith(ClassCoverageLogger.A01)) {
            throw AnonymousClass001.A0r(AnonymousClass0WY.A0i("Class load disallowed: ", name));
        } else if (ClassCoverageLogger.A02) {
            ClassCoverageLogger.A00.add(name);
        }
    }

    public void onClassNotFound(String str) {
        if (sTracingLoggerInitialized) {
            ClassTracingLogger.classNotFound();
            if (ProfiloClassLoadTracer.sTracer != null) {
                ProfiloLogger.classLoadFailed();
            }
        }
        mClassLoadingStats.incrementClassLoadsFailed();
    }

    public static synchronized void install(ClassLoadsLoggingProvider classLoadsLoggingProvider) {
        synchronized (ClassLoadsTracer.class) {
            install(false, classLoadsLoggingProvider);
        }
    }
}
