package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import dalvik.system.VMRuntime;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class DexStoreUtils {
    public static Long ART_VERSION_CODE = null;
    public static final String BASELINE_PROFILE_NAME = "primary.prof";
    public static Long BP_VARIANT_FILE_SIZE = -1L;
    public static int CANARY_IDX = 2;
    public static Long DM_BASELINE_PROFILE_SIZE = null;
    public static Long DM_VDEX_FILE_SIZE = null;
    public static int HASH_IDX = 1;
    public static final String IGNORE_DIRTY_CHECK_PREFIX = "IGNORE_DIRTY_";
    public static String INSTALLER_NAME = null;
    public static Long LAST_APP_INSTALL_OR_UPDATE_TIME = null;
    public static final String MAIN_DEX_STORE_ID = "dex";
    public static final boolean OREO_OR_NEWER = true;
    public static final String SECONDARY_DEX_MANIFEST = "metadata.txt";
    public static final int STORAGE_KIND_ASEC = 3;
    public static final int STORAGE_KIND_EXPAND = 2;
    public static final int STORAGE_KIND_INTERNAL = 1;
    public static final int STORAGE_KIND_OTHER = 0;
    public static final String VDEX_FILE_NAME_IN_BASE_DM = "primary.vdex";

    public static synchronized boolean checkBPVariantFileExistInDM(Context context, String str) {
        boolean z;
        int i;
        synchronized (DexStoreUtils.class) {
            z = true;
            try {
                String A0i = AnonymousClass0WY.A0i(sha256(str), ".name");
                long longValue = BP_VARIANT_FILE_SIZE.longValue();
                if (longValue > -1) {
                    i = (longValue > 0 ? 1 : (longValue == 0 ? 0 : -1));
                } else {
                    File baseDM = getBaseDM(context);
                    if (baseDM.length() > 0) {
                        try {
                            ZipEntry entry = new ZipFile(baseDM).getEntry(A0i);
                            if (entry != null) {
                                BP_VARIANT_FILE_SIZE = Long.valueOf(entry.getSize());
                            }
                        } catch (IOException e) {
                            Mlog.w("error reading DM file as zip %s", e);
                        }
                    }
                    i = (BP_VARIANT_FILE_SIZE.longValue() > 0 ? 1 : (BP_VARIANT_FILE_SIZE.longValue() == 0 ? 0 : -1));
                }
                if (i <= 0) {
                    z = false;
                }
            } catch (Exception e2) {
                Mlog.w("error getting sha256 for variant %s", e2);
                return false;
            }
        }
        return z;
    }

    public static synchronized long getARTVersion(Context context) {
        long j;
        String str;
        Object[] objArr;
        synchronized (DexStoreUtils.class) {
            Long l = ART_VERSION_CODE;
            if (l != null) {
                j = l.longValue();
            } else {
                PackageManager packageManager = context.getPackageManager();
                j = -1;
                if (packageManager == null) {
                    str = "Could not get package manager";
                    objArr = new Object[0];
                } else {
                    try {
                        int i = 0;
                        if (Build.VERSION.SDK_INT >= 29) {
                            i = 1073741824;
                        }
                        PackageInfo packageInfo = packageManager.getPackageInfo("com.google.android.art", i);
                        if (packageInfo != null) {
                            long longVersionCode = packageInfo.getLongVersionCode();
                            Long valueOf = Long.valueOf(longVersionCode);
                            ART_VERSION_CODE = valueOf;
                            if (valueOf != null) {
                                j = longVersionCode;
                            }
                        } else {
                            Mlog.e("Could not get pacakge info for com.google.android.art", new Object[0]);
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        str = "could not find package com.google.android.art %s";
                        objArr = new Object[]{e};
                    }
                }
                Mlog.e(str, objArr);
            }
        }
        return j;
    }

    public static synchronized Long getBaselineProfileInDMSize(Context context) {
        Long l;
        synchronized (DexStoreUtils.class) {
            l = DM_BASELINE_PROFILE_SIZE;
            if (l == null) {
                File baseDM = getBaseDM(context);
                if (baseDM.length() > 0) {
                    obtainInfoFromDMFile(baseDM);
                }
                l = DM_BASELINE_PROFILE_SIZE;
            }
        }
        return l;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized java.lang.String getInstallerName(android.content.Context r5) {
        /*
            java.lang.Class<com.facebook.common.dextricks.DexStoreUtils> r4 = com.facebook.common.dextricks.DexStoreUtils.class
            monitor-enter(r4)
            java.lang.String r0 = INSTALLER_NAME     // Catch:{ all -> 0x0043 }
            if (r0 != 0) goto L_0x0041
            android.content.pm.PackageManager r3 = r5.getPackageManager()     // Catch:{ all -> 0x0043 }
            r2 = 0
            r0 = 0
            if (r3 != 0) goto L_0x0017
            java.lang.String r1 = "Could not get package manager"
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ all -> 0x0043 }
        L_0x0013:
            com.facebook.common.dextricks.Mlog.e(r1, r0)     // Catch:{ all -> 0x0043 }
            goto L_0x003f
        L_0x0017:
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ NameNotFoundException -> 0x0037 }
            r0 = 30
            if (r1 < r0) goto L_0x002c
            java.lang.String r0 = r5.getPackageName()     // Catch:{ NameNotFoundException -> 0x0037 }
            android.content.pm.InstallSourceInfo r0 = r3.getInstallSourceInfo(r0)     // Catch:{ NameNotFoundException -> 0x0037 }
            java.lang.String r0 = r0.getInstallingPackageName()     // Catch:{ NameNotFoundException -> 0x0037 }
            INSTALLER_NAME = r0     // Catch:{ NameNotFoundException -> 0x0037 }
            goto L_0x0041
        L_0x002c:
            java.lang.String r0 = r5.getPackageName()     // Catch:{ NameNotFoundException -> 0x0037 }
            java.lang.String r0 = r3.getInstallerPackageName(r0)     // Catch:{ NameNotFoundException -> 0x0037 }
            INSTALLER_NAME = r0     // Catch:{ NameNotFoundException -> 0x0037 }
            goto L_0x0041
        L_0x0037:
            r0 = move-exception
            java.lang.String r1 = "Could not find package name %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x0043 }
            goto L_0x0013
        L_0x003f:
            monitor-exit(r4)
            return r2
        L_0x0041:
            monitor-exit(r4)
            return r0
        L_0x0043:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0043 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStoreUtils.getInstallerName(android.content.Context):java.lang.String");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0035, code lost:
        if (r0 == null) goto L_0x0037;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized long getLastAppInstallOrUpdateTime(android.content.Context r6) {
        /*
            java.lang.Class<com.facebook.common.dextricks.DexStoreUtils> r5 = com.facebook.common.dextricks.DexStoreUtils.class
            monitor-enter(r5)
            java.lang.Long r0 = LAST_APP_INSTALL_OR_UPDATE_TIME     // Catch:{ all -> 0x0039 }
            r3 = -1
            if (r0 != 0) goto L_0x0030
            android.content.pm.PackageManager r1 = r6.getPackageManager()     // Catch:{ all -> 0x0039 }
            r0 = 0
            if (r1 != 0) goto L_0x0018
            java.lang.String r1 = "Could not get package manager"
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ all -> 0x0039 }
        L_0x0014:
            com.facebook.common.dextricks.Mlog.e(r1, r0)     // Catch:{ all -> 0x0039 }
            goto L_0x0037
        L_0x0018:
            java.lang.String r2 = r6.getPackageName()     // Catch:{ all -> 0x0039 }
            android.content.pm.PackageInfo r0 = r1.getPackageInfo(r2, r0)     // Catch:{ NameNotFoundException -> 0x0029 }
            long r0 = r0.lastUpdateTime     // Catch:{ NameNotFoundException -> 0x0029 }
            java.lang.Long r0 = java.lang.Long.valueOf(r0)     // Catch:{ NameNotFoundException -> 0x0029 }
            LAST_APP_INSTALL_OR_UPDATE_TIME = r0     // Catch:{ NameNotFoundException -> 0x0029 }
            goto L_0x0035
        L_0x0029:
            java.lang.String r1 = "Could not get package info for %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r2}     // Catch:{ all -> 0x0039 }
            goto L_0x0014
        L_0x0030:
            long r3 = r0.longValue()     // Catch:{ all -> 0x0039 }
            goto L_0x0037
        L_0x0035:
            if (r0 != 0) goto L_0x0030
        L_0x0037:
            monitor-exit(r5)
            return r3
        L_0x0039:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x0039 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexStoreUtils.getLastAppInstallOrUpdateTime(android.content.Context):long");
    }

    public static DexManifest getSecondaryDexManifest(ResProvider resProvider, boolean z) {
        return DexManifest.loadManifestFrom(resProvider, SECONDARY_DEX_MANIFEST, z);
    }

    public static int getStorageKind(String str) {
        if (str.startsWith("/data/app/")) {
            return 1;
        }
        if (str.startsWith("/mnt/expand/")) {
            return 2;
        }
        if (str.startsWith("/mnt/asec/")) {
            return 3;
        }
        return 0;
    }

    public static synchronized Long getVDexFileInDMSize(Context context) {
        Long l;
        synchronized (DexStoreUtils.class) {
            l = DM_VDEX_FILE_SIZE;
            if (l == null) {
                File baseDM = getBaseDM(context);
                if (baseDM.length() > 0) {
                    obtainInfoFromDMFile(baseDM);
                }
                l = DM_VDEX_FILE_SIZE;
            }
        }
        return l;
    }

    public static boolean isIgnoreDirtyFileName(String str) {
        if (str == null || !str.startsWith(IGNORE_DIRTY_CHECK_PREFIX)) {
            return false;
        }
        return true;
    }

    public static boolean isMainDexStoreId(String str) {
        return MAIN_DEX_STORE_ID.equals(str);
    }

    public static boolean isSecondaryDexManifest(String str) {
        return SECONDARY_DEX_MANIFEST.equals(str);
    }

    public static File makeIgnoreDirtyCheckFile(File file, String str) {
        return AnonymousClass0WY.A01(IGNORE_DIRTY_CHECK_PREFIX, str, file);
    }

    public static synchronized void obtainInfoFromDMFile(File file) {
        synchronized (DexStoreUtils.class) {
            try {
                ZipFile zipFile = new ZipFile(file);
                ZipEntry entry = zipFile.getEntry(VDEX_FILE_NAME_IN_BASE_DM);
                if (entry != null) {
                    DM_VDEX_FILE_SIZE = Long.valueOf(entry.getSize());
                }
                ZipEntry entry2 = zipFile.getEntry(BASELINE_PROFILE_NAME);
                if (entry2 != null) {
                    DM_BASELINE_PROFILE_SIZE = Long.valueOf(entry2.getSize());
                }
            } catch (IOException e) {
                Mlog.w("error reading DM file as zip %s", e);
            }
        }
    }

    public static InputStream openSecondaryDexManifest(ResProvider resProvider) {
        return resProvider.open(SECONDARY_DEX_MANIFEST);
    }

    public static String sha1ForFile(String str) {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        FileInputStream fileInputStream = new FileInputStream(str);
        try {
            byte[] bArr = new byte[Constants.LOAD_RESULT_MIXED_MODE_ATTEMPTED];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    instance.update(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    return toHex(instance.digest());
                }
            }
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public static String sha256(String str) {
        return toHex(MessageDigest.getInstance("SHA-256").digest(str.getBytes()));
    }

    public static File getApkDir(Context context) {
        return new File(context.getApplicationInfo().publicSourceDir).getParentFile();
    }

    public static int getBaseApkStorageKind(Context context) {
        return getStorageKind(context.getApplicationInfo().publicSourceDir);
    }

    public static File getBaseAppImage(Context context) {
        return AnonymousClass001.A0D(getBaseIsaDir(context), "base.art");
    }

    public static long getBaseAppImageLastModifield(Context context) {
        return getBaseAppImage(context).lastModified();
    }

    public static long getBaseAppImageSize(Context context) {
        return getBaseAppImage(context).length();
    }

    public static File getBaseDM(Context context) {
        return AnonymousClass001.A0D(getApkDir(context), "base.dm");
    }

    public static Long getBaseDMSize(Context context) {
        return AnonymousClass001.A0R(getBaseDM(context));
    }

    public static File getBaseIsaDir(Context context) {
        File apkDir = getApkDir(context);
        if (apkDir == null) {
            return null;
        }
        return AnonymousClass001.A0D(apkDir, "oat/".concat(VMRuntime.getRuntime().vmInstructionSet()));
    }

    public static File getBaseOdex(Context context) {
        return AnonymousClass001.A0D(getBaseIsaDir(context), "base.odex");
    }

    public static long getBaseOdexLastModifield(Context context) {
        return getBaseOdex(context).lastModified();
    }

    public static long getBaseOdexSize(Context context) {
        return getBaseOdex(context).length();
    }

    public static File getBaseVdex(Context context) {
        return AnonymousClass001.A0D(getBaseIsaDir(context), "base.vdex");
    }

    public static long getBaseVdexLastModifield(Context context) {
        return getBaseVdex(context).lastModified();
    }

    public static long getBaseVdexSize(Context context) {
        return getBaseVdex(context).length();
    }

    public static String getMainDexStoreId() {
        return MAIN_DEX_STORE_ID;
    }

    public static File getMainDexStoreLocation(Context context) {
        String A0a = AnonymousClass001.A0a(context);
        if (!OREO_OR_NEWER) {
            A0a = DalvikInternals.realpath(A0a);
        }
        return new File(A0a, MAIN_DEX_STORE_ID);
    }

    public static String toHex(byte[] bArr) {
        StringBuilder A0m = AnonymousClass001.A0m();
        char[] charArray = "0123456789abcdef".toCharArray();
        for (byte b : bArr) {
            A0m.append(charArray[(b >> 4) & 15]);
            A0m.append(charArray[b & 15]);
        }
        return A0m.toString();
    }
}
