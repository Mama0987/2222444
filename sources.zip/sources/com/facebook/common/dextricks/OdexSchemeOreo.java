package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0TR;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C004802v;
import X.C14060oy;
import X.C14080p0;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.OdexScheme;
import com.facebook.common.dextricks.achilles.Achilles;
import com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger;
import com.facebook.common.dextricks.storer.Storer;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import dalvik.system.BaseDexClassLoader;
import dalvik.system.VMRuntime;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

public class OdexSchemeOreo extends OdexScheme {
    public static final Set sForceUnpackSet = AnonymousClass001.A0x();
    public static final Map sOurAddedDexElements = AnonymousClass001.A0w();
    public static final Object sPathListLock = AnonymousClass001.A0U();
    public static C14060oy sRegisteredClassLoaderCallback;
    public Context mContext;
    public HashMap mDexNameMap;
    public int mNumDexes;
    public LightweightQuickPerformanceLogger mQplCollector;
    public long mStorer;
    public IOException[] mSuppressedExceptions;
    public File mZipFile;

    public final class OreoCompiler extends OdexScheme.Compiler {
        public HashMap mDexNameMap;
        public long mStorer;

        public void compile(InputDex inputDex) {
            C004802v.A02(32, "OdexSchemeOreo.compile", 180903662);
            try {
                String str = (String) this.mDexNameMap.get(inputDex.dex.hash);
                if (str != null) {
                    Storer.start(this.mStorer, str, 4);
                    long j = this.mStorer;
                    InputStream dexContents = inputDex.getDexContents();
                    byte[] bArr = new byte[Constants.LOAD_RESULT_PGO];
                    while (true) {
                        int read = dexContents.read(bArr);
                        if (read >= 0) {
                            Storer.write(j, bArr, read);
                        } else {
                            Storer.finish(this.mStorer);
                            return;
                        }
                    }
                } else {
                    throw AnonymousClass001.A0V("Unexpected input dex!");
                }
            } finally {
                C004802v.A01(32, -2078960940);
            }
        }

        public OreoCompiler(long j, HashMap hashMap) {
            this.mStorer = j;
            this.mDexNameMap = hashMap;
        }
    }

    public OdexSchemeOreo(DexManifest.Dex[] dexArr, File file, Context context, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        super(1, new String[]{file.getName()});
        this.mContext = context;
        this.mZipFile = file;
        this.mQplCollector = lightweightQuickPerformanceLogger;
        this.mDexNameMap = makeNameMap(dexArr);
        this.mNumDexes = dexArr.length;
    }

    public static HashMap makeNameMap(DexManifest.Dex[] dexArr) {
        String str;
        int length = dexArr.length;
        HashMap hashMap = new HashMap(length);
        for (int i = 0; i < length; i++) {
            String str2 = dexArr[i].hash;
            if (i != 0) {
                str = AnonymousClass0WY.A0t("classes", DexManifest.DEX_EXT, i + 1);
            } else {
                str = "classes.dex";
            }
            hashMap.put(str2, str);
        }
        return hashMap;
    }

    public void serializeDex2ChecksumMap(File file) {
        Object[] objArr;
        String str;
        try {
            ZipFile zipFile = new ZipFile(this.mZipFile);
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            HashMap A0w = AnonymousClass001.A0w();
            while (entries.hasMoreElements()) {
                ZipEntry zipEntry = (ZipEntry) entries.nextElement();
                if (zipEntry != null) {
                    A0w.put(zipEntry.getName(), Integer.valueOf((int) zipEntry.getCrc()));
                }
            }
            zipFile.close();
            if (!A0w.isEmpty()) {
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(AnonymousClass0WY.A01(this.mZipFile.getName(), ".checksum", file.getParentFile()));
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                    objectOutputStream.writeObject(A0w);
                    objectOutputStream.close();
                    fileOutputStream.close();
                } catch (IOException unused) {
                    AnonymousClass001.A1I("fail to write checksum file ");
                }
            } else {
                str = "dexname2ChecksumMap has nothing";
                objArr = new Object[0];
                Mlog.w(str, objArr);
            }
        } catch (ZipException e) {
            objArr = new Object[]{e};
            str = "Megazip file cannot be opened as a ZipFile, exception %s";
        } catch (IOException e2) {
            objArr = new Object[]{e2};
            str = "Megazip file io failed in serializeDex2ChecksumMap %s";
        }
    }

    private String buildPrimaryDexDecoyFilename() {
        return AnonymousClass0WY.A0w("p-", getPrimaryDexIdentifierString(this.mContext), ".zip");
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [X.0oy, java.lang.Object] */
    public static void enableTracingIfNeeded() {
        C14080p0 A00;
        if (ClassTracingLogger.A01 && (A00 = C14080p0.A00()) != null && sRegisteredClassLoaderCallback == null) {
            ? obj = new Object();
            sRegisteredClassLoaderCallback = obj;
            A00.A05(obj);
        }
    }

    private File getProfileFileAndInfo(boolean z) {
        File parentFile = this.mZipFile.getParentFile();
        if (parentFile == null) {
            return null;
        }
        File profileFile = getProfileFile(parentFile);
        if (profileFile != null && z && Build.VERSION.SDK_INT <= 30) {
            serializeDex2ChecksumMap(profileFile);
        }
        return profileFile;
    }

    public static boolean isUnpackRequested(String str) {
        Set set = sForceUnpackSet;
        if (!set.contains(str)) {
            return false;
        }
        set.remove(str);
        return true;
    }

    private void registerCodeAndProfileBgDexopt() {
        if (Build.VERSION.SDK_INT == 29) {
            registerCodeAndProfileBgDexoptWithPrimary();
            return;
        }
        BaseDexClassLoader baseDexClassLoader = (BaseDexClassLoader) OdexSchemeOreo.class.getClassLoader();
        boolean isXiaomiDevice = isXiaomiDevice();
        if (isXiaomiDevice) {
            Achilles.simulateReportClassLoaderChainR(baseDexClassLoader, this.mContext.getPackageName(), VMRuntime.getRuntime().vmInstructionSet(), this.mContext.getPackageManager(), isXiaomiDevice);
        } else {
            Achilles.reportClassLoaderChain(baseDexClassLoader);
        }
    }

    private void registerCodeAndProfileBgDexoptWithPrimary() {
        BaseDexClassLoader baseDexClassLoader = (BaseDexClassLoader) OdexSchemeOreo.class.getClassLoader();
        File A0D = AnonymousClass001.A0D(getMainDexStoreLocation(), buildPrimaryDexDecoyFilename());
        if (!A0D.exists()) {
            try {
                createDecoy(A0D, this.mContext.getApplicationInfo().publicSourceDir);
            } catch (IOException e) {
                Mlog.w(e, "Unable to unpack decoy, continuing without!!!!", new Object[0]);
            }
        }
        String A0w = AnonymousClass0WY.A0w(A0D.getAbsolutePath(), File.pathSeparator, this.mZipFile.getAbsolutePath());
        ArrayList A0t = AnonymousClass001.A0t();
        A0t.add(baseDexClassLoader);
        ArrayList A0t2 = AnonymousClass001.A0t();
        A0t2.add(A0w);
        Achilles.simulateReportClassLoaderChainQ(new String[]{this.mZipFile.getAbsolutePath()}, baseDexClassLoader, A0t, A0t2, this.mContext.getPackageName(), VMRuntime.getRuntime().vmInstructionSet(), this.mContext.getPackageManager(), isXiaomiDevice());
    }

    public static Object[] removeFromOldElements(Class cls, Object[] objArr, Object obj) {
        int length;
        if (obj == null || objArr == null || (length = objArr.length) == 0) {
            return objArr;
        }
        int i = 0;
        int i2 = 0;
        while (obj != objArr[i2]) {
            i2++;
            if (i2 >= length) {
                return objArr;
            }
        }
        Object[] objArr2 = (Object[]) Array.newInstance(cls, length - 1);
        int i3 = 0;
        do {
            Object obj2 = objArr[i];
            if (obj != obj2) {
                objArr2[i3] = obj2;
                i3++;
            }
            i++;
        } while (i < length);
        return objArr2;
    }

    public static void requestUnpack(String str) {
        sForceUnpackSet.add(str);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001b, code lost:
        if (r2.A01 == false) goto L_0x001d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void setupErrorReportingFields() {
        /*
            X.0u0 r3 = X.C14790qN.A00
            if (r3 == 0) goto L_0x0032
            com.facebook.errorreporting.field.ReportFieldString r1 = X.C14990qj.A7q
            com.facebook.common.dextricks.OdexSchemeOreo$1 r0 = new com.facebook.common.dextricks.OdexSchemeOreo$1
            r0.<init>()
            r3.A02(r1, r0)
            X.0p0 r2 = X.C14080p0.A07
            if (r2 == 0) goto L_0x001d
            r1 = r2
            monitor-enter(r1)
            boolean r0 = r2.A01     // Catch:{ all -> 0x0017 }
            goto L_0x001a
        L_0x0017:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0017 }
            throw r0
        L_0x001a:
            monitor-exit(r1)
            if (r0 != 0) goto L_0x0023
        L_0x001d:
            java.lang.Class<com.facebook.common.dextricks.OdexSchemeOreo> r0 = com.facebook.common.dextricks.OdexSchemeOreo.class
            java.lang.ClassLoader r2 = r0.getClassLoader()
        L_0x0023:
            com.facebook.errorreporting.field.ReportFieldString r1 = X.C14990qj.A8t
            if (r2 != 0) goto L_0x002d
            java.lang.String r0 = ""
        L_0x0029:
            r3.A01(r1, r0)
            return
        L_0x002d:
            java.lang.String r0 = r2.toString()
            goto L_0x0029
        L_0x0032:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.OdexSchemeOreo.setupErrorReportingFields():void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v1, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v2, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v24, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v3, resolved type: java.lang.Object[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.io.IOException[] threadSafeAddDexPath(dalvik.system.BaseDexClassLoader r11, java.io.File r12) {
        /*
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 33
            r6 = 0
            if (r1 < r0) goto L_0x000a
            r12.setWritable(r6)
        L_0x000a:
            java.lang.String r0 = "dalvik.system.DexPathList"
            java.lang.Class r5 = java.lang.Class.forName(r0)
            java.lang.String r0 = "dalvik.system.DexPathList$Element"
            java.lang.Class r10 = java.lang.Class.forName(r0)
            java.lang.Class<dalvik.system.BaseDexClassLoader> r3 = dalvik.system.BaseDexClassLoader.class
            java.lang.Class<java.util.List> r4 = java.util.List.class
            java.lang.Class<java.io.File> r2 = java.io.File.class
            r7 = 1
            java.lang.Class<java.lang.ClassLoader> r1 = java.lang.ClassLoader.class
            r0 = r4
            java.lang.Class r0 = (java.lang.Class) r0
            java.lang.Class r2 = (java.lang.Class) r2
            java.lang.Class r4 = (java.lang.Class) r4
            java.lang.Class r1 = (java.lang.Class) r1
            java.lang.Class[] r1 = new java.lang.Class[]{r0, r2, r4, r1}
            java.lang.String r0 = "makeDexElements"
            java.lang.reflect.Method r2 = r5.getDeclaredMethod(r0, r1)
            r2.setAccessible(r7)
            java.util.ArrayList r8 = X.AnonymousClass001.A0t()
            java.util.ArrayList r0 = X.AnonymousClass001.A0u(r7)
            r0.add(r12)
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[]{r0, r1, r8, r11}
            java.lang.Object r9 = r2.invoke(r1, r0)
            java.lang.Object[] r9 = (java.lang.Object[]) r9
            if (r9 == 0) goto L_0x00c1
            int r4 = r9.length
            if (r4 != r7) goto L_0x00c1
            r0 = r9[r6]
            java.lang.Object r1 = recordAddedDexElement(r12, r0)
            java.lang.String r0 = "pathList"
            java.lang.reflect.Field r0 = X.AnonymousClass001.A0s(r3, r0)
            java.lang.Object r7 = r0.get(r11)
            java.lang.String r0 = "dexElements"
            java.lang.reflect.Field r3 = X.AnonymousClass001.A0s(r5, r0)
            java.lang.Object r2 = r3.get(r7)
            java.lang.Object[] r2 = (java.lang.Object[]) r2
            if (r2 == 0) goto L_0x0089
            int r0 = r2.length
            if (r0 <= 0) goto L_0x0079
            if (r1 == 0) goto L_0x0079
            java.lang.Object[] r2 = removeFromOldElements(r10, r2, r1)
            if (r2 == 0) goto L_0x0089
        L_0x0079:
            int r1 = r2.length
            if (r1 <= 0) goto L_0x0089
            int r0 = r1 + 1
            java.lang.Object r0 = java.lang.reflect.Array.newInstance(r10, r0)
            java.lang.System.arraycopy(r2, r6, r0, r6, r1)
            java.lang.System.arraycopy(r9, r6, r0, r1, r4)
            r9 = r0
        L_0x0089:
            r3.set(r7, r9)
            java.lang.String r0 = "dexElementsSuppressedExceptions"
            java.lang.reflect.Field r5 = X.AnonymousClass001.A0s(r5, r0)
            int r4 = r8.size()
            if (r4 <= 0) goto L_0x00ba
            java.io.IOException[] r0 = new java.io.IOException[r4]
            java.lang.Object[] r0 = r8.toArray(r0)
            java.io.IOException[] r0 = (java.io.IOException[]) r0
            java.lang.Object r3 = r5.get(r7)
            java.io.IOException[] r3 = (java.io.IOException[]) r3
            if (r3 == 0) goto L_0x00b6
            int r2 = r3.length
            if (r2 <= 0) goto L_0x00b6
            int r1 = r2 + r4
            java.io.IOException[] r1 = new java.io.IOException[r1]
            java.lang.System.arraycopy(r3, r6, r1, r6, r2)
            java.lang.System.arraycopy(r0, r6, r1, r2, r4)
            r0 = r1
        L_0x00b6:
            r5.set(r7, r0)
            return r0
        L_0x00ba:
            java.lang.Object r0 = r5.get(r7)
            java.io.IOException[] r0 = (java.io.IOException[]) r0
            return r0
        L_0x00c1:
            java.lang.String r0 = "got null or too large array"
            java.lang.IllegalStateException r0 = X.AnonymousClass001.A0P(r0)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.OdexSchemeOreo.threadSafeAddDexPath(dalvik.system.BaseDexClassLoader, java.io.File):java.io.IOException[]");
    }

    public static IOException[] threadSafeAddDexPathSynchronized(BaseDexClassLoader baseDexClassLoader, List list) {
        IOException[] iOExceptionArr;
        int length;
        int length2;
        if (Build.VERSION.SDK_INT >= 33) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                ((File) it.next()).setWritable(false);
            }
        }
        Class<?> cls = Class.forName("dalvik.system.DexPathList");
        Class<?> cls2 = Class.forName("dalvik.system.DexPathList$Element");
        Class<BaseDexClassLoader> cls3 = BaseDexClassLoader.class;
        Class<List> cls4 = List.class;
        Method declaredMethod = cls.getDeclaredMethod("makeDexElements", new Class[]{cls4, File.class, cls4, ClassLoader.class});
        declaredMethod.setAccessible(true);
        ArrayList A0t = AnonymousClass001.A0t();
        Object[] objArr = (Object[]) declaredMethod.invoke((Object) null, new Object[]{list, null, A0t, baseDexClassLoader});
        if (objArr == null || objArr.length != list.size()) {
            throw AnonymousClass001.A0P("got null or wrong size array");
        }
        Object obj = AnonymousClass001.A0s(cls3, "pathList").get(baseDexClassLoader);
        if (obj != null) {
            Field A0s = AnonymousClass001.A0s(cls, "dexElements");
            synchronized (sPathListLock) {
                Object[] objArr2 = (Object[]) A0s.get(obj);
                if (objArr2 != null) {
                    objArr = filterDexElements(objArr2, objArr);
                }
                int length3 = objArr.length;
                if (length3 < 1) {
                    AnonymousClass001.A1I("No new dex elements to add, as they may already be present in the pathlist.");
                    iOExceptionArr = new IOException[0];
                } else {
                    if (objArr2 != null && (length2 = objArr2.length) > 0) {
                        Object[] objArr3 = (Object[]) Array.newInstance(cls2, length3 + length2);
                        System.arraycopy(objArr2, 0, objArr3, 0, length2);
                        System.arraycopy(objArr, 0, objArr3, length2, length3);
                        objArr = objArr3;
                    }
                    A0s.set(obj, objArr.clone());
                    Field A0s2 = AnonymousClass001.A0s(cls, "dexElementsSuppressedExceptions");
                    int size = A0t.size();
                    if (size > 0) {
                        iOExceptionArr = (IOException[]) A0t.toArray(new IOException[size]);
                        IOException[] iOExceptionArr2 = (IOException[]) A0s2.get(obj);
                        if (iOExceptionArr2 != null && (length = iOExceptionArr2.length) > 0) {
                            IOException[] iOExceptionArr3 = new IOException[(length + size)];
                            System.arraycopy(iOExceptionArr2, 0, iOExceptionArr3, 0, length);
                            System.arraycopy(iOExceptionArr, 0, iOExceptionArr3, length, size);
                            iOExceptionArr = iOExceptionArr3;
                        }
                        A0s2.set(obj, iOExceptionArr);
                    } else {
                        iOExceptionArr = (IOException[]) A0s2.get(obj);
                    }
                }
            }
            return iOExceptionArr;
        }
        throw AnonymousClass001.A0P("pathList is null");
    }

    public void finalizeZip() {
        long j = this.mStorer;
        if (j != 0) {
            Storer.cleanup(j);
            this.mStorer = 0;
        }
    }

    public File getMainDexStoreLocation() {
        try {
            return DexStoreUtils.getMainDexStoreLocation(this.mContext);
        } catch (IOException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public File getProfileFile(File file) {
        File A0D = AnonymousClass001.A0D(file, OdexSchemeArtTurbo.OREO_ODEX_DIR);
        if (A0D.exists() || A0D.mkdir()) {
            File A01 = AnonymousClass0WY.A01(this.mZipFile.getName(), ".cur.prof", A0D);
            try {
                if (A01.createNewFile()) {
                    Mlog.w("Created new profile file: %s", A01);
                }
                return A01;
            } catch (IOException e) {
                AnonymousClass0TR.A01("RegisterProf", "Failed to touch new profile file", e);
                return null;
            }
        } else {
            AnonymousClass0TR.A01("RegisterProf", AnonymousClass002.A0M(A0D, "Failed to mkdir for prof dir: ", AnonymousClass001.A0m()), (Throwable) null);
            return null;
        }
    }

    public void initializeClassLoader() {
        RuntimeException th;
        Throwable e;
        Object obj;
        ClassLoader classLoader = OdexSchemeOreo.class.getClassLoader();
        if (classLoader instanceof BaseDexClassLoader) {
            if (!DalvikInternals.toggleBlockDex2Oat(true)) {
                AnonymousClass0TR.A01("FBDex101", "Failed to block dex2oat", (Throwable) null);
            }
            try {
                LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = this.mQplCollector;
                if (lightweightQuickPerformanceLogger != null) {
                    lightweightQuickPerformanceLogger.markerStart(8914508);
                }
                boolean isXiaomiDevice = isXiaomiDevice();
                if (isXiaomiDevice) {
                    try {
                        obj = Achilles.getDexLoadReporter();
                        Achilles.setDexLoadReporter((Object) null);
                    } catch (Throwable th2) {
                        th = th2;
                        obj = null;
                    }
                } else {
                    obj = null;
                }
                try {
                    this.mSuppressedExceptions = threadSafeAddDexPath((BaseDexClassLoader) classLoader, this.mZipFile);
                    LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger2 = this.mQplCollector;
                    if (lightweightQuickPerformanceLogger2 != null) {
                        lightweightQuickPerformanceLogger2.markerEnd(8914508, 2);
                    }
                    if (isXiaomiDevice) {
                        Achilles.setDexLoadReporter(obj);
                    }
                    if (!DalvikInternals.toggleBlockDex2Oat(false)) {
                        AnonymousClass0TR.A01("FBDex101", "Failed to unblock dex2oat", (Throwable) null);
                    }
                    enableTracingIfNeeded();
                    setupErrorReportingFields();
                } catch (Throwable th3) {
                    th = th3;
                    LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger3 = this.mQplCollector;
                    if (lightweightQuickPerformanceLogger3 != null) {
                        lightweightQuickPerformanceLogger3.markerEnd(8914508, 2);
                    }
                    if (isXiaomiDevice) {
                        Achilles.setDexLoadReporter(obj);
                    }
                    throw th;
                }
            } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | NoSuchFieldException | NoSuchMethodException | InvocationTargetException e2) {
                e = e2;
                AnonymousClass0TR.A01("FBDex101", "Failed to merge dex elements", e);
                if (!DalvikInternals.toggleBlockDex2Oat(false)) {
                    AnonymousClass0TR.A01("FBDex101", "Failed to unblock dex2oat", (Throwable) null);
                }
            } catch (Throwable th4) {
                th = th4;
                if (!DalvikInternals.toggleBlockDex2Oat(false)) {
                    AnonymousClass0TR.A01("FBDex101", "Failed to unblock dex2oat", (Throwable) null);
                    throw th;
                }
            }
        } else {
            String A0i = AnonymousClass0WY.A0i("Unknown Application ClassLoader: ", classLoader.toString());
            AnonymousClass0TR.A01("FBDex101", A0i, (Throwable) null);
            e = AnonymousClass001.A0V(A0i);
            th = AnonymousClass001.A0W("[FBDex101] Unknown Application ClassLoader or failed to merge dex, app bound to crash with NoClassDef", e);
            throw th;
        }
    }

    public boolean isXiaomiDevice() {
        int i = Build.VERSION.SDK_INT;
        if (i < 29 || i > 30) {
            return false;
        }
        return Achilles.existsNotifyDexLoadWithStatus();
    }

    public OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        long open = Storer.open(this.mZipFile.getPath(), 420);
        this.mStorer = open;
        return new OreoCompiler(open, this.mDexNameMap);
    }

    public int markLoadResult(int i, boolean z) {
        int i2 = i | 8;
        if (OreoFileUtils.hasVdexOdex(this.mZipFile)) {
            i2 = i | 512 | Constants.LOAD_RESULT_WITH_VDEX_ODEX;
        }
        File file = this.mZipFile;
        if (z) {
            if (OreoFileUtils.getOdex(file).length() < 4194304) {
                return i2;
            }
        } else if (!OreoFileUtils.getReferenceProfile(file).exists()) {
            return i2;
        }
        return i2 | Constants.LOAD_RESULT_PGO;
    }

    public boolean needsUnpack() {
        if (isUnpackRequested(this.mZipFile.getAbsolutePath()) || !this.mZipFile.exists()) {
            return true;
        }
        if (!OreoFileUtils.isTruncated(this.mZipFile)) {
            return false;
        }
        return !OreoFileUtils.hasVdexOdex(this.mZipFile);
    }

    public void requestDexUnpack() {
        requestUnpack(this.mZipFile.getAbsolutePath());
    }

    public static void createDecoy(File file, String str) {
        InputStream inputStream;
        long open = Storer.open(file.getPath(), 420);
        Storer.start(open, "classes.dex", 4);
        ZipFile zipFile = new ZipFile(str);
        try {
            inputStream = zipFile.getInputStream(new ZipEntry("classes.dex"));
            byte[] bArr = new byte[Constants.LOAD_RESULT_PGO];
            while (true) {
                int read = inputStream.read(bArr);
                if (read >= 0) {
                    Storer.write(open, bArr, read);
                } else {
                    inputStream.close();
                    zipFile.close();
                    Storer.finish(open);
                    Storer.cleanup(open);
                    return;
                }
            }
        } catch (Throwable th) {
            try {
                zipFile.close();
                throw th;
            } catch (Throwable th2) {
                AnonymousClass0ZM.A00(th, th2);
                throw th;
            }
        }
        throw th;
    }

    private Object disableReporter() {
        Object dexLoadReporter = Achilles.getDexLoadReporter();
        Achilles.setDexLoadReporter((Object) null);
        return dexLoadReporter;
    }

    public static Object[] filterDexElements(Object[] objArr, Object[] objArr2) {
        ArrayList A0t = AnonymousClass001.A0t();
        for (Object obj : objArr2) {
            int length = objArr.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    A0t.add(obj);
                    break;
                }
                if (obj.toString().equals(objArr[i].toString())) {
                    break;
                }
                i++;
            }
        }
        return A0t.toArray();
    }

    public static String getPrimaryDexIdentifierString(Context context) {
        return String.valueOf(DexStore.getApkIdentifier(AnonymousClass001.A0E(context.getApplicationInfo().publicSourceDir), false));
    }

    public static Object recordAddedDexElement(File file, Object obj) {
        return sOurAddedDexElements.put(file.getAbsolutePath(), obj);
    }

    public void addEmptyDex(Context context) {
        AssetManager assets = context.getAssets();
        String A0t = AnonymousClass0WY.A0t("classes", DexManifest.DEX_EXT, this.mNumDexes + 1);
        InputStream open = assets.open("secondary-program-dex-jars/empty.dex");
        try {
            Storer.start_unaligned(this.mStorer, A0t, 4);
            long j = this.mStorer;
            byte[] bArr = new byte[Constants.LOAD_RESULT_PGO];
            while (true) {
                int read = open.read(bArr);
                if (read >= 0) {
                    Storer.write(j, bArr, read);
                } else {
                    Storer.finish(this.mStorer);
                    open.close();
                    return;
                }
            }
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public String getSchemeName() {
        return "OdexSchemeOreo";
    }

    public IOException[] getSuppressedExceptions() {
        return this.mSuppressedExceptions;
    }

    public void registerCodeAndProfile(boolean z, boolean z2) {
        File profileFileAndInfo = getProfileFileAndInfo(z2);
        if (z) {
            registerCodeAndProfileBgDexopt();
        } else if (profileFileAndInfo != null) {
            String path = profileFileAndInfo.getPath();
            String[] strArr = {this.mZipFile.getPath()};
            try {
                Method declaredMethod = VMRuntime.class.getDeclaredMethod("registerAppInfo", new Class[]{String.class, String[].class});
                declaredMethod.setAccessible(true);
                declaredMethod.invoke((Object) null, new Object[]{path, strArr});
            } catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | InvocationTargetException unused) {
                Achilles.registerAppInfo(path, strArr);
            }
        }
    }

    private void enableReporter(Object obj) {
        Achilles.setDexLoadReporter(obj);
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
    }
}
