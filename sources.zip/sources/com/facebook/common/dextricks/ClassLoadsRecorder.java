package com.facebook.common.dextricks;

import X.AnonymousClass0ZM;
import X.C12790mK;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ClassLoadsRecorder implements ClassLoadsListener {
    public static final String TAG = "ClassLoadsRecorder";
    public static final ExecutorService sExecutorService = Executors.newSingleThreadExecutor();
    public static ClassLoadsRecorder sInstance = null;
    public static final int sMinPreloadClassCount = 200;
    public final AtomicInteger classLoadsFailureCount = new AtomicInteger(0);
    public final ClassPreloader classPreloader;
    public volatile boolean mIsWriting = false;
    public final boolean mPreloadClass;
    public final int mRecordingThreshold;
    public final ClassLoadsRecordsManager mRecordsManager;
    public final ConcurrentLinkedQueue recordedClasses = new ConcurrentLinkedQueue();
    public final AtomicInteger recordedClassesCount = new AtomicInteger(0);
    public volatile RecorderState state;

    public enum RecorderState {
        REPLAYING,
        RECORDING,
        STOPPED
    }

    private synchronized void stop() {
        this.state = RecorderState.STOPPED;
    }

    private synchronized void stopWriting() {
        this.mIsWriting = false;
    }

    public synchronized void startWriting() {
        if (this.state != RecorderState.RECORDING) {
            C12790mK.A01(TAG, "Skip writing request because recording is not in progress.");
        } else if (this.recordedClasses.isEmpty()) {
            C12790mK.A01(TAG, "Nothing to write.");
        } else if (this.mIsWriting) {
            C12790mK.A01(TAG, "Skip writing request because writing is already in progress.");
        } else {
            stop();
            sExecutorService.execute(new ClassLoadsRecorder$$ExternalSyntheticLambda0(this));
        }
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [X.0xK, X.0xL, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v4, types: [X.0xK, X.0xL, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0071, code lost:
        return r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized com.facebook.common.dextricks.ClassLoadsRecorder install(android.content.pm.ApplicationInfo r11, java.lang.ClassLoader r12, com.facebook.common.dextricks.ClassLoadsLoggingProvider r13) {
        /*
            java.lang.Class<com.facebook.common.dextricks.ClassLoadsRecorder> r4 = com.facebook.common.dextricks.ClassLoadsRecorder.class
            monitor-enter(r4)
            boolean r0 = com.facebook.common.dextricks.ProcessHelper.isIsolatedOrAppZygoteProcess()     // Catch:{ all -> 0x0072 }
            r5 = 0
            r3 = 0
            if (r0 == 0) goto L_0x0013
            java.lang.String r1 = "ClassLoadsRecorder"
            java.lang.String r0 = "ClassLoadsRecorder is not initialized for isolated or app zygote process"
            X.C12790mK.A01(r1, r0)     // Catch:{ all -> 0x0072 }
            goto L_0x0070
        L_0x0013:
            com.facebook.common.dextricks.ClassLoadsRecorder r0 = sInstance     // Catch:{ all -> 0x0072 }
            if (r0 == 0) goto L_0x0022
            java.lang.String r1 = "ClassLoadsRecorder"
            java.lang.String r0 = "ClassLoadsRecorder is already installed"
            X.C12790mK.A01(r1, r0)     // Catch:{ all -> 0x0072 }
            com.facebook.common.dextricks.ClassLoadsRecorder r0 = sInstance     // Catch:{ all -> 0x0072 }
            monitor-exit(r4)
            return r0
        L_0x0022:
            java.lang.String r1 = "class_recorder_coinflip_rate"
            X.0xL r0 = new X.0xL     // Catch:{ all -> 0x0072 }
            r0.<init>()     // Catch:{ all -> 0x0072 }
            r6 = r11
            r0.A00 = r11     // Catch:{ all -> 0x0072 }
            int r8 = X.C18590xN.A00(r0, r1, r3)     // Catch:{ all -> 0x0072 }
            if (r8 > 0) goto L_0x003a
            java.lang.String r1 = "ClassLoadsRecorder"
            java.lang.String r0 = "ClassLoadsRecorder is not initialized because coinflip rate <= 0"
            X.C12790mK.A01(r1, r0)     // Catch:{ all -> 0x0072 }
            goto L_0x0070
        L_0x003a:
            java.lang.String r2 = "class_recorder_threshold"
            r1 = 25000(0x61a8, float:3.5032E-41)
            X.0xL r0 = new X.0xL     // Catch:{ all -> 0x0072 }
            r0.<init>()     // Catch:{ all -> 0x0072 }
            r0.A00 = r11     // Catch:{ all -> 0x0072 }
            int r9 = X.C18590xN.A00(r0, r2, r1)     // Catch:{ all -> 0x0072 }
            java.lang.String r1 = "class_recorder_preload_class"
            r0 = 1
            boolean r1 = X.C18550xJ.A04(r11, r1, r0)     // Catch:{ all -> 0x0072 }
            java.lang.String r0 = "class_recorder_run_initializer"
            boolean r0 = X.C18550xJ.A04(r11, r0, r3)     // Catch:{ all -> 0x0072 }
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r1)     // Catch:{ all -> 0x0072 }
            java.lang.Boolean r11 = java.lang.Boolean.valueOf(r0)     // Catch:{ all -> 0x0072 }
            com.facebook.common.dextricks.ClassLoadsRecorder r5 = new com.facebook.common.dextricks.ClassLoadsRecorder     // Catch:{ all -> 0x0072 }
            r7 = r12
            r5.<init>(r6, r7, r8, r9, r10, r11)     // Catch:{ all -> 0x0072 }
            r13.addListener(r5)     // Catch:{ all -> 0x0072 }
            java.lang.String r1 = "ClassLoadsRecorder"
            java.lang.String r0 = "ClassLoadsRecorder installed"
            X.C12790mK.A01(r1, r0)     // Catch:{ all -> 0x0072 }
            sInstance = r5     // Catch:{ all -> 0x0072 }
        L_0x0070:
            monitor-exit(r4)
            return r5
        L_0x0072:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0072 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ClassLoadsRecorder.install(android.content.pm.ApplicationInfo, java.lang.ClassLoader, com.facebook.common.dextricks.ClassLoadsLoggingProvider):com.facebook.common.dextricks.ClassLoadsRecorder");
    }

    public static boolean isInstalled() {
        if (sInstance != null) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: private */
    public void writeToFile() {
        BufferedWriter bufferedWriter;
        String recordFilePath = this.mRecordsManager.getRecordFilePath();
        if (recordFilePath == null) {
            stopWriting();
            C12790mK.A01(TAG, "Record file path is null, could not start writing.");
            return;
        }
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(recordFilePath));
            int i = 0;
            while (true) {
                String str = (String) this.recordedClasses.poll();
                if (str == null) {
                    break;
                }
                bufferedWriter.write(str);
                bufferedWriter.newLine();
                i++;
            }
            C12790mK.A02(TAG, "%d of classes written to file.", Integer.valueOf(i));
            bufferedWriter.close();
        } catch (IOException e) {
            try {
                Log.e(TAG, C12790mK.A00("Failed to write to file", e));
            } catch (Throwable th) {
                stopWriting();
                throw th;
            }
        } catch (Throwable th2) {
            AnonymousClass0ZM.A00(th, th2);
        }
        stopWriting();
        return;
        throw th;
    }

    public boolean isRecording() {
        if (this.state == RecorderState.RECORDING) {
            return true;
        }
        return false;
    }

    public void onClassLoaded(Class cls) {
        if (this.state == RecorderState.RECORDING) {
            int andIncrement = this.recordedClassesCount.getAndIncrement();
            if (andIncrement >= this.mRecordingThreshold) {
                this.recordedClassesCount.set(andIncrement);
                startWriting();
                return;
            }
            this.recordedClasses.add(cls.getName());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:43:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void replayRecordedClassLoads() {
        /*
            r5 = this;
            com.facebook.common.dextricks.ClassLoadsRecordsManager r0 = r5.mRecordsManager
            java.lang.String r1 = r0.getRecordFilePath()
            java.lang.String r3 = "ClassLoadsRecorder"
            if (r1 == 0) goto L_0x0082
            boolean r0 = r0.recordFileExist()
            if (r0 == 0) goto L_0x0082
            java.io.FileReader r0 = new java.io.FileReader     // Catch:{ IOException -> 0x0046 }
            r0.<init>(r1)     // Catch:{ IOException -> 0x0046 }
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0046 }
            r2.<init>(r0)     // Catch:{ IOException -> 0x0046 }
            r4 = 0
        L_0x001b:
            java.lang.String r1 = r2.readLine()     // Catch:{ all -> 0x003a }
            if (r1 == 0) goto L_0x0036
            boolean r0 = r5.mPreloadClass     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x0033
            com.facebook.common.dextricks.ClassPreloader r0 = r5.classPreloader     // Catch:{ all -> 0x003a }
            java.lang.Class r0 = r0.preloadClass(r1)     // Catch:{ all -> 0x003a }
            if (r0 != 0) goto L_0x0033
            java.util.concurrent.atomic.AtomicInteger r0 = r5.classLoadsFailureCount     // Catch:{ all -> 0x003a }
            r0.incrementAndGet()     // Catch:{ all -> 0x003a }
            goto L_0x001b
        L_0x0033:
            int r4 = r4 + 1
            goto L_0x001b
        L_0x0036:
            r2.close()     // Catch:{ IOException -> 0x0044 }
            goto L_0x005a
        L_0x003a:
            r1 = move-exception
            r2.close()     // Catch:{ all -> 0x003f }
            goto L_0x0043
        L_0x003f:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ IOException -> 0x0044 }
        L_0x0043:
            throw r1     // Catch:{ IOException -> 0x0044 }
        L_0x0044:
            r2 = move-exception
            goto L_0x0048
        L_0x0046:
            r2 = move-exception
            r4 = 0
        L_0x0048:
            com.facebook.common.dextricks.ClassLoadsRecordsManager r0 = r5.mRecordsManager     // Catch:{ all -> 0x007d }
            r0.deleteRecordFile()     // Catch:{ all -> 0x007d }
            java.lang.String r1 = "Failed to read file"
            java.lang.Object[] r0 = new java.lang.Object[]{r2}     // Catch:{ all -> 0x007d }
            java.lang.String r0 = X.C12790mK.A00(r1, r0)     // Catch:{ all -> 0x007d }
            android.util.Log.e(r3, r0)     // Catch:{ all -> 0x007d }
        L_0x005a:
            r5.stop()
            java.lang.Object[] r1 = X.AnonymousClass001.A1a(r4)
            java.lang.String r0 = "%d of classes preloaded"
            X.C12790mK.A02(r3, r0, r1)
            java.util.concurrent.atomic.AtomicInteger r0 = r5.classLoadsFailureCount
            int r0 = r0.get()
            if (r0 > r4) goto L_0x0072
            r0 = 200(0xc8, float:2.8E-43)
            if (r4 >= r0) goto L_0x008a
        L_0x0072:
            java.lang.String r0 = "Something is wrong with the recorded classes, deleting the file"
            X.C12790mK.A01(r3, r0)
            com.facebook.common.dextricks.ClassLoadsRecordsManager r0 = r5.mRecordsManager
            r0.deleteRecordFile()
            return
        L_0x007d:
            r0 = move-exception
            r5.stop()
            throw r0
        L_0x0082:
            java.lang.String r0 = "Record file does not exist"
            X.C12790mK.A01(r3, r0)
            r5.stop()
        L_0x008a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ClassLoadsRecorder.replayRecordedClassLoads():void");
    }

    public ClassLoadsRecorder(ApplicationInfo applicationInfo, ClassLoader classLoader, int i, int i2, Boolean bool, Boolean bool2) {
        RecorderState recorderState;
        this.mPreloadClass = bool.booleanValue();
        this.classPreloader = new ClassPreloader(applicationInfo, classLoader, bool2.booleanValue());
        ClassLoadsRecordsManager classLoadsRecordsManager = new ClassLoadsRecordsManager(applicationInfo, i, false);
        this.mRecordsManager = classLoadsRecordsManager;
        this.mRecordingThreshold = i2;
        if (classLoadsRecordsManager.shouldRecord()) {
            recorderState = RecorderState.RECORDING;
        } else {
            recorderState = RecorderState.REPLAYING;
        }
        this.state = recorderState;
    }

    public static ClassLoadsRecorder getInstance() {
        return sInstance;
    }

    public void onClassLoadBegin(String str) {
    }

    public void onClassNotFound(String str) {
    }
}
