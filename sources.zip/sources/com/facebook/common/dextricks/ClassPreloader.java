package com.facebook.common.dextricks;

import android.content.pm.ApplicationInfo;
import dalvik.system.DexFile;

public class ClassPreloader {
    public DexFile mPrimaryDex;
    public final ClassLoader mPutativeLoader;
    public final boolean mRunInitializer;

    public Class preloadClass(String str) {
        DexFile dexFile = this.mPrimaryDex;
        if (dexFile != null) {
            return DexFileLoadNew.loadClassBinaryName(dexFile, str, this.mPutativeLoader);
        }
        try {
            if (this.mRunInitializer) {
                return Class.forName(str);
            }
            return Class.forName(str, false, this.mPutativeLoader);
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }

    public ClassPreloader(ApplicationInfo applicationInfo, ClassLoader classLoader, boolean z) {
        DexFile primaryDex;
        this.mPutativeLoader = classLoader;
        this.mRunInitializer = z;
        if (MultiDexClassLoaderLight.isInstalled()) {
            primaryDex = MultiDexClassLoaderLight.INSTANCE.mBaseApkDex;
        } else {
            ClassLoader classLoader2 = MultiDexClassLoader.sInstalledClassLoader;
            if (classLoader2 instanceof MultiDexClassLoaderJava) {
                primaryDex = ((MultiDexClassLoaderJava) classLoader2).getPrimaryDex();
            } else {
                return;
            }
        }
        this.mPrimaryDex = primaryDex;
    }
}
