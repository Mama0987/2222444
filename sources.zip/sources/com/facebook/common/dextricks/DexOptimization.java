package com.facebook.common.dextricks;

public interface DexOptimization {
    public static final String PROCESS_NAME = "optsvc";
}
