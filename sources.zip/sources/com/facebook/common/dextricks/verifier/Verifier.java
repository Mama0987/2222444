package com.facebook.common.dextricks.verifier;

import X.C18440x7;
import android.util.Log;

public class Verifier {
    public static boolean sDisabledRuntimeVerification;
    public static Boolean sHasNativeCode;
    public static boolean sTriedDisableRuntimeVerification;

    public static native boolean disableRuntimeVerificationWithInpainter();

    public static native boolean disableRuntimeVerification_6_0_1();

    public static native boolean disableRuntimeVerification_7_0_0();

    public static native boolean disableRuntimeVerification_7_1_2();

    public static native boolean disableRuntimeVerification_8_0_0();

    public static native boolean disableRuntimeVerification_8_1_0();

    public static native boolean disableRuntimeVerification_9_plus();

    public static synchronized void disableRuntimeVerification(boolean z) {
        boolean z2;
        synchronized (Verifier.class) {
            Boolean bool = sHasNativeCode;
            if (bool == null) {
                try {
                    C18440x7.loadLibrary("verifier");
                    z2 = true;
                } catch (Throwable unused) {
                    z2 = false;
                }
                bool = Boolean.valueOf(z2);
                sHasNativeCode = bool;
            }
            boolean booleanValue = bool.booleanValue();
            if (!sTriedDisableRuntimeVerification && booleanValue) {
                boolean disableRuntimeVerification_9_plus = disableRuntimeVerification_9_plus();
                sDisabledRuntimeVerification = disableRuntimeVerification_9_plus;
                if (!disableRuntimeVerification_9_plus && z) {
                    forceDisableRuntimeVerificationWithInpainter();
                }
                sTriedDisableRuntimeVerification = true;
                if (!sDisabledRuntimeVerification) {
                    Log.w("Verifier", "Could not disable RTV");
                }
            }
        }
    }

    public static synchronized void forceDisableRuntimeVerificationWithInpainter() {
        synchronized (Verifier.class) {
            if (!sDisabledRuntimeVerification) {
                sDisabledRuntimeVerification = disableRuntimeVerificationWithInpainter();
                sTriedDisableRuntimeVerification = true;
            }
        }
    }
}
