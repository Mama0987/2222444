package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.C12790mK;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import java.io.File;
import java.util.Random;

public class ClassLoadsRecordsManager {
    public static final String DIR = "class_loads_records";
    public static final String RECORD_FILE_PATH = "recording.txt";
    public static final String TAG = "ClassLoadsRecordsManager";
    public static final Random mRandom = new Random();
    public final ApplicationInfo mApplicationInfo;
    public final int mCoinflipRate;
    public final boolean mIsDebugMode;

    public String getRecordDirPath() {
        return AnonymousClass0WY.A0w(this.mApplicationInfo.dataDir, "/", DIR);
    }

    public boolean shouldRecord() {
        boolean z = this.mIsDebugMode;
        boolean recordFileExist = recordFileExist();
        if (z) {
            return !recordFileExist;
        }
        if (!recordFileExist) {
            clean();
        } else if (mRandom.nextInt(this.mCoinflipRate) != 0) {
            return false;
        }
        return true;
    }

    public ClassLoadsRecordsManager(ApplicationInfo applicationInfo, int i, boolean z) {
        this.mApplicationInfo = applicationInfo;
        this.mCoinflipRate = i;
        this.mIsDebugMode = z;
        File A0E = AnonymousClass001.A0E(AnonymousClass0WY.A0w(applicationInfo.dataDir, "/", DIR));
        if (!A0E.exists()) {
            A0E.mkdirs();
        }
    }

    private void clean() {
        File A0E = AnonymousClass001.A0E(getRecordDirPath());
        if (!A0E.exists() || !A0E.isDirectory()) {
            C12790mK.A02(TAG, "The specified directory does not exist.", new Object[0]);
            return;
        }
        File[] listFiles = A0E.listFiles();
        if (listFiles != null) {
            for (File file : listFiles) {
                if (file.isFile()) {
                    file.delete();
                    System.out.println(AnonymousClass0WY.A0i("Deleted file: ", file.getName()));
                }
            }
        }
    }

    private String getAppVersionName() {
        return "524.0.0.52.44";
    }

    public boolean deleteRecordFile() {
        String recordFilePath = getRecordFilePath();
        if (recordFilePath == null) {
            return false;
        }
        try {
            return AnonymousClass001.A0E(recordFilePath).delete();
        } catch (Exception e) {
            Log.e(TAG, C12790mK.A00("Failed to delete class loads record file", e));
            return false;
        }
    }

    public String getRecordFilePath() {
        return AnonymousClass0WY.A18(getRecordDirPath(), "/", "524.0.0.52.44", RECORD_FILE_PATH);
    }

    public boolean recordFileExist() {
        String recordFilePath = getRecordFilePath();
        if (recordFilePath == null) {
            return false;
        }
        return AnonymousClass001.A1X(recordFilePath);
    }
}
