package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C13060mv;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.xzdecoder.XzInputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class InputDex implements Closeable {
    public static final byte STATE_RAW = 0;
    public static final byte STATE_USED = 2;
    public static final byte STATE_ZIPPED = 1;
    public static final String XZS_ASSET_SUFFIX = ".xzs.tmp~";
    public final DexManifest.Dex dex;
    public final String filePath;
    public InputStream mContents;
    public byte mState;
    public int sizeHint;

    private void synthesizeDexJarFile(OutputStream outputStream) {
        InputStream inputStream;
        CheckedInputStream checkedInputStream;
        InputStream inputStream2 = this.mContents;
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
        try {
            ZipEntry zipEntry = new ZipEntry("classes.dex");
            if (inputStream2 instanceof FileInputStream) {
                FileInputStream fileInputStream = (FileInputStream) inputStream2;
                FileChannel channel = fileInputStream.getChannel();
                if (channel.position() == 0) {
                    InputStream fileInputStream2 = new FileInputStream(fileInputStream.getFD());
                    try {
                        checkedInputStream = fileInputStream2;
                        InputStream bufferedInputStream = new BufferedInputStream(fileInputStream2);
                        checkedInputStream = fileInputStream2;
                        try {
                            CheckedInputStream checkedInputStream2 = new CheckedInputStream(bufferedInputStream, new CRC32());
                            checkedInputStream = checkedInputStream2;
                            zipEntry.setSize(checkedInputStream2.skip(Long.MAX_VALUE));
                            zipEntry.setCrc(checkedInputStream2.getChecksum().getValue());
                            zipEntry.setMethod(0);
                            zipEntry.getSize();
                            zipEntry.getCrc();
                            checkedInputStream = checkedInputStream2;
                            Fs.safeClose((Closeable) checkedInputStream2);
                            channel.position(0);
                        } catch (Throwable th) {
                            th = th;
                            inputStream = bufferedInputStream;
                            Fs.safeClose((Closeable) inputStream);
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        inputStream = checkedInputStream;
                    }
                }
            }
            zipOutputStream.putNextEntry(zipEntry);
            C13060mv.A05(inputStream2, zipOutputStream, Integer.MAX_VALUE);
            zipOutputStream.finish();
            zipOutputStream.close();
        } catch (Throwable th3) {
            AnonymousClass0ZM.A00(th, th3);
            throw th;
        }
    }

    public void close() {
        Fs.safeClose((Closeable) this.mContents);
    }

    public void extract(File file) {
        InputStream inputStream;
        byte b = this.mState;
        this.mState = 2;
        if (b == 0 || b == 1) {
            String name = file.getName();
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            try {
                if (name.endsWith(".dex.jar")) {
                    if (b == 1) {
                        inputStream = this.mContents;
                    } else {
                        synthesizeDexJarFile(fileOutputStream);
                        fileOutputStream.close();
                    }
                } else if (name.endsWith(DexManifest.DEX_EXT)) {
                    this.mState = b;
                    inputStream = getDexContents();
                } else {
                    throw AnonymousClass0WY.A0A("don't know how to make this kind of file: ", name);
                }
                C13060mv.A05(inputStream, fileOutputStream, Integer.MAX_VALUE);
                fileOutputStream.close();
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
                throw th;
            }
        } else {
            throw AnonymousClass001.A0V("InputDex already used");
        }
    }

    public InputStream getDexContents() {
        ZipEntry nextEntry;
        int i;
        byte b = this.mState;
        this.mState = 2;
        if (b == 1) {
            ZipInputStream zipInputStream = new ZipInputStream(this.mContents);
            this.mContents = zipInputStream;
            do {
                nextEntry = zipInputStream.getNextEntry();
                if (nextEntry == null) {
                    throw AnonymousClass001.A0G(String.format("zip file %s did not contain a classes.dex", new Object[]{this.dex}));
                }
            } while (!nextEntry.getName().equals("classes.dex"));
            long size = nextEntry.getSize();
            if (size > 2147483647L) {
                i = Integer.MAX_VALUE;
            } else {
                i = (int) size;
            }
            this.sizeHint = i;
        } else if (b != 0) {
            throw AnonymousClass001.A0V("InputDex already used");
        }
        return this.mContents;
    }

    public int getSizeHint(InputStream inputStream) {
        int i = this.sizeHint;
        if (i > 0) {
            return i;
        }
        int available = inputStream.available();
        if (available <= 1) {
            return -1;
        }
        return available;
    }

    public String toString() {
        return String.format("InputDex:[%s]", new Object[]{this.dex.assetName});
    }

    public InputDex(DexManifest.Dex dex2, InputStream inputStream) {
        this.dex = dex2;
        String str = dex2.assetName;
        this.filePath = null;
        try {
            str = str.endsWith(XZS_ASSET_SUFFIX) ? str.substring(0, str.length() - 9) : str;
            if (str.endsWith(".xz")) {
                str = str.substring(0, str.length() - 3);
                inputStream = new XzInputStream(inputStream);
            }
            if (str.endsWith(".jar")) {
                str = str.substring(0, str.length() - 4);
                this.mState = 1;
            }
            if (str.endsWith(DexManifest.DEX_EXT)) {
                this.mContents = inputStream;
                return;
            }
            throw AnonymousClass0WY.A0A("malformed dex asset name: ", dex2.assetName);
        } catch (IOException e) {
            throw AnonymousClass001.A0X(e);
        } catch (Throwable th) {
            Fs.safeClose((Closeable) inputStream);
            throw th;
        }
    }

    public String getFilePath() {
        return this.filePath;
    }

    public InputDex(DexManifest.Dex dex2, String str) {
        this.dex = dex2;
        this.filePath = str;
        this.mContents = new ByteArrayInputStream(new byte[0]);
    }
}
