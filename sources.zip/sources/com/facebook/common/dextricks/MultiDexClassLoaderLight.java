package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import com.facebook.common.dextricks.classifier.NameClassifier;
import com.facebook.common.dextricks.fallback.FallbackDexLoader;
import com.facebook.common.dextricks.halfnosis.Halfnosis;
import com.facebook.common.dextricks.halfnosis.HalfnosisClassNotFoundException;
import dalvik.system.DexFile;

public class MultiDexClassLoaderLight extends ClassLoader implements ClassLoadsLoggingProvider {
    public static volatile MultiDexClassLoaderLight INSTANCE = null;
    public static final String[] REQUIRED_PRELOAD_CLASSES = {"com.facebook.common.dextricks.DexFileLoadNew", "com.facebook.common.dextricks.classifier.NameClassifier", "com.facebook.common.dextricks.StringTreeSet", "com.facebook.common.dextricks.MultiDexClassLoaderJava", "com.facebook.common.dextricks.halfnosis.Halfnosis", "com.facebook.common.dextricks.halfnosis.HalfnosisClassNotFoundException", "com.facebook.common.build.BuildConstants", "android.util.Log", "java.lang.StringBuilder", "com.facebook.common.dextricks.ClassLoadsListener", "com.facebook.common.dextricks.ClassLoadsLoggingProvider", "com.facebook.common.dextricks.ClassLoadsTracer", "com.facebook.common.dextricks.ClassLoadsNotifier", "com.facebook.common.dextricks.ClassLoadingStatsHolder", "com.facebook.common.dextricks.stats.ClassLoadingStats", "com.facebook.common.dextricks.stats.ClassLoadingStatsJava", "com.facebook.common.dextricks.stats.ClassLoadingStats$SnapshotStats", "com.facebook.common.dextricks.coverage.logger.ClassCoverageLogger", "com.facebook.common.dextricks.benchmarkhelper.ClassloadNameCollector"};
    public static final String TAG = "MDCLLight";
    public final DexFile mBaseApkDex;
    public final ClassLoadsNotifier mClassLoadsNotifier = new ClassLoadsNotifier();
    public final ClassLoader mPutativeLoader;

    public static synchronized boolean install(ApplicationInfo applicationInfo, ClassLoader classLoader) {
        synchronized (MultiDexClassLoaderLight.class) {
            if (ProcessHelper.isIsolatedOrAppZygoteProcess()) {
                Log.w(TAG, "Not targeting isolated processes.");
            } else {
                Log.w(TAG, "Not targeting this build or os version.");
            }
        }
        return false;
    }

    public static boolean isInstalled() {
        if (INSTANCE != null) {
            return true;
        }
        return false;
    }

    private Class maybeFallbackLoadClass(String str) {
        try {
            if (maybeFallbackLoadDexes(str)) {
                ClassLoader classLoader = MultiDexClassLoader.sInstalledClassLoader;
                if (classLoader != null) {
                    return classLoader.loadClass(str);
                }
                Log.e(TAG, AnonymousClass0WY.A0w("MDCL wasn't installed although fallback load dexes for ", str, " had succeeded!"));
                return null;
            }
            Log.e(TAG, AnonymousClass0WY.A0i("Fallback load dex failed for ", str));
            return null;
        } catch (ClassNotFoundException | RuntimeException e) {
            Log.e(TAG, AnonymousClass0WY.A0i("Failed to load class from MDCL: ", str), e);
            return null;
        }
    }

    private boolean maybeFallbackLoadDexes(String str) {
        boolean A01 = NameClassifier.A01(MultiDexClassLoaderJava.sEncodedLongtailUnrenamedTypes, str);
        FallbackDexLoader fallbackDexLoader = FallbackDexLoader.A00;
        if (fallbackDexLoader != null) {
            String str2 = null;
            if (A01) {
                str2 = Halfnosis.getLongtailModuleName();
            }
            Log.w(TAG, AnonymousClass0WY.A18("Trying to fallback load dex", str, " moduleHint = ", str2));
            return fallbackDexLoader.A03(str, str2);
        } else if (!A01) {
            Log.w(TAG, AnonymousClass0WY.A0i("tryFallbackLoadDex: fallbackLoader is null, unable to fallback load dex for ", str));
            return false;
        } else {
            HalfnosisClassNotFoundException halfnosisClassNotFoundException = new HalfnosisClassNotFoundException(str);
            Log.e(TAG, AnonymousClass0WY.A0w("Halfnosis class load attempts ", str, " before fallback loader is setup, this needs to be fixed!"), halfnosisClassNotFoundException);
            throw halfnosisClassNotFoundException;
        }
    }

    public static void preloadRequiredClasses() {
        try {
            for (String cls : REQUIRED_PRELOAD_CLASSES) {
                Class.forName(cls);
            }
        } catch (ClassNotFoundException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public void addListener(ClassLoadsListener classLoadsListener) {
        this.mClassLoadsNotifier.addListener(classLoadsListener);
    }

    public Class findClass(String str) {
        Class loadClassBinaryName = DexFileLoadNew.loadClassBinaryName(this.mBaseApkDex, str, this.mPutativeLoader);
        if (loadClassBinaryName != null) {
            return loadClassBinaryName;
        }
        throw new ClassNotFoundException(str);
    }

    public MultiDexClassLoaderLight(ClassLoader classLoader, DexFile dexFile, ClassLoader classLoader2) {
        super(classLoader);
        this.mBaseApkDex = dexFile;
        this.mPutativeLoader = classLoader2;
    }

    public static MultiDexClassLoaderLight getInstance() {
        return INSTANCE;
    }

    private Class loadFromParent(String str) {
        try {
            return getParent().loadClass(str);
        } catch (ClassNotFoundException e) {
            Log.w(TAG, AnonymousClass0WY.A0i("Failed to load class from parent: ", str), e);
            return null;
        }
    }

    public DexFile getBaseApkDex() {
        return this.mBaseApkDex;
    }

    public Class loadClass(String str, boolean z) {
        Class cls;
        boolean z2;
        Class loadFromParent;
        if (NameClassifier.A00(str)) {
            cls = loadFromParent(str);
            if (cls == null) {
                z2 = true;
            }
            return cls;
        }
        z2 = false;
        this.mClassLoadsNotifier.notifyClassLoadBegin(str);
        Class loadClassBinaryName = DexFileLoadNew.loadClassBinaryName(this.mBaseApkDex, str, this.mPutativeLoader);
        if (loadClassBinaryName != null) {
            this.mClassLoadsNotifier.notifyClassLoaded(loadClassBinaryName);
            return loadClassBinaryName;
        } else if (z2 || (loadFromParent = loadFromParent(str)) == null) {
            cls = maybeFallbackLoadClass(str);
            if (cls == null) {
                this.mClassLoadsNotifier.notifyClassNotFound(str);
                throw new ClassNotFoundException(str);
            }
            return cls;
        } else {
            Log.w(TAG, AnonymousClass0WY.A0w("Class ", str, " was loaded on parent fallback. This should be fixed and added to the shouldAskParent method."));
            return loadFromParent;
        }
    }
}
