package com.facebook.common.dextricks;

import X.AnonymousClass001;
import com.facebook.common.dextricks.DexManifest;
import java.io.File;

public class ExpectedFileInfo {
    public final boolean coldstart;
    public final DexManifest.Dex dex;
    public final File dexFile;
    public final String dexName;
    public final boolean extended;
    public CompilationType mCompType;
    public boolean mIsOptional;
    public final int ordinal;
    public final boolean primary;
    public final String rawFile;
    public final boolean scroll;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ExpectedFileInfo(com.facebook.common.dextricks.DexManifest.Dex r7, com.facebook.common.dextricks.ExpectedFileInfo.CompilationType r8) {
        /*
            r6 = this;
            r1 = r7
            if (r7 == 0) goto L_0x000f
            java.lang.String r2 = r7.makeDexName()
        L_0x0007:
            r3 = 0
            r0 = r6
            r5 = r8
            r4 = r3
            r0.<init>(r1, r2, r3, r4, r5)
            return
        L_0x000f:
            r2 = 0
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ExpectedFileInfo.<init>(com.facebook.common.dextricks.DexManifest$Dex, com.facebook.common.dextricks.ExpectedFileInfo$CompilationType):void");
    }

    public static ExpectedFileInfo[] convertTo(String[] strArr) {
        ExpectedFileInfo expectedFileInfo;
        if (strArr == null) {
            return null;
        }
        int length = strArr.length;
        ExpectedFileInfo[] expectedFileInfoArr = new ExpectedFileInfo[length];
        for (int i = 0; i < length; i++) {
            String str = strArr[i];
            if (str != null) {
                expectedFileInfo = new ExpectedFileInfo(str);
            } else {
                expectedFileInfo = null;
            }
            expectedFileInfoArr[i] = expectedFileInfo;
        }
        return expectedFileInfoArr;
    }

    public enum CompilationType {
        ALL("all"),
        PGO("pgo"),
        NONE("none"),
        UNKNOWN("unknown");
        
        public final String mFriendlyName;

        /* access modifiers changed from: public */
        CompilationType(String str) {
            this.mFriendlyName = str;
        }

        public String getFriendlyName() {
            return this.mFriendlyName;
        }

        public String toString() {
            return getFriendlyName();
        }
    }

    public static CompilationType checkIsValidCompType(CompilationType compilationType) {
        if (compilationType != null) {
            return compilationType;
        }
        Mlog.w("Comp type cannot be null defaulting to unknown", new Object[0]);
        return CompilationType.UNKNOWN;
    }

    public static ExpectedFileInfo makeOdexFromName(String str) {
        return new ExpectedFileInfo(str);
    }

    public boolean isNonRootDex() {
        if (this.dex == null || this.dexFile == null) {
            return false;
        }
        return true;
    }

    public boolean isRawFile() {
        if (this.rawFile != null) {
            return true;
        }
        return false;
    }

    public boolean isRootDex() {
        if (this.dex == null || this.dexName == null) {
            return false;
        }
        return true;
    }

    public String toString() {
        String str;
        String path;
        StringBuilder A0p = AnonymousClass001.A0p("[Expected File Info: ");
        if (isRawFile()) {
            A0p.append("Raw File: ");
            str = this.rawFile;
        } else {
            if (isRootDex()) {
                A0p.append("Dex Name: ");
                path = this.dexName;
            } else if (isNonRootDex()) {
                A0p.append("Dex File: ");
                path = this.dexFile.getPath();
            } else {
                str = "ERROR!";
            }
            A0p.append(path);
            A0p.append("Compilation Type: ");
            A0p.append(this.mCompType);
            return AnonymousClass001.A0g(" ]", A0p);
        }
        A0p.append(str);
        return AnonymousClass001.A0g(" ]", A0p);
    }

    public DexManifest.Dex getDex() {
        return this.dex;
    }

    public boolean isOptional() {
        return this.mIsOptional;
    }

    public String toExpectedFileString() {
        if (isRawFile()) {
            return this.rawFile;
        }
        if (isRootDex()) {
            return this.dexName;
        }
        throw AnonymousClass001.A0P("Cannot generated an expected string");
    }

    public ExpectedFileInfo setIsOptional(boolean z) {
        this.mIsOptional = z;
        return this;
    }

    public ExpectedFileInfo(DexManifest.Dex dex2, String str, CompilationType compilationType) {
        this(dex2, str, (File) null, (String) null, compilationType);
    }

    public static String[] convertTo(ExpectedFileInfo[] expectedFileInfoArr) {
        String str;
        if (expectedFileInfoArr == null) {
            return null;
        }
        int length = expectedFileInfoArr.length;
        String[] strArr = new String[length];
        for (int i = 0; i < length; i++) {
            ExpectedFileInfo expectedFileInfo = expectedFileInfoArr[i];
            if (expectedFileInfo != null) {
                str = expectedFileInfo.toExpectedFileString();
            } else {
                str = null;
            }
            strArr[i] = str;
        }
        return strArr;
    }

    public ExpectedFileInfo setIsOptional() {
        this.mIsOptional = true;
        return this;
    }

    public ExpectedFileInfo(DexManifest.Dex dex2, String str, File file, String str2, CompilationType compilationType, int i, boolean z, boolean z2, boolean z3, boolean z4, boolean z5) {
        this.dex = dex2;
        this.dexName = str;
        this.dexFile = file;
        this.rawFile = str2;
        this.mCompType = compilationType == null ? checkIsValidCompType(compilationType) : compilationType;
        this.ordinal = i;
        this.primary = z;
        this.coldstart = z2;
        this.extended = z3;
        this.scroll = z4;
        this.mIsOptional = z5;
    }

    public ExpectedFileInfo(DexManifest.Dex dex2, String str, File file, String str2, CompilationType compilationType) {
        this(dex2, str, file, str2, compilationType, -1, false, false, false, false, false);
    }

    public ExpectedFileInfo(DexManifest.Dex dex2, String str) {
        this(dex2, str, (File) null, (String) null, CompilationType.UNKNOWN);
    }

    public ExpectedFileInfo(String str) {
        this((DexManifest.Dex) null, (String) null, (File) null, str, CompilationType.NONE);
    }

    public ExpectedFileInfo(DexManifest.Dex dex2) {
        this(dex2, CompilationType.UNKNOWN);
    }
}
