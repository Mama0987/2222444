package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.util.zip.ZipFile;

public final class Fs {
    public static File sDalvikCacheDirectory;

    public static void deleteRecursiveNoThrow(File file) {
        if (file != null) {
            try {
                deleteRecursive(file);
            } catch (Exception e) {
                Mlog.w(e, "error deleting %s", file);
            }
        }
    }

    public static File findSystemDalvikCache() {
        File file = sDalvikCacheDirectory;
        if (file != null) {
            return file;
        }
        String lowerCase = System.getProperty("os.arch").toLowerCase();
        String str = "arm";
        if (!lowerCase.startsWith(str)) {
            str = "x86";
            if (!lowerCase.startsWith(str) && (!lowerCase.startsWith("i") || !lowerCase.endsWith("86"))) {
                throw AnonymousClass0WY.A0A("unknown arch: ", lowerCase);
            }
        }
        String str2 = System.getenv("ANDROID_DATA");
        if (str2 == null) {
            str2 = "/data";
        }
        String format = String.format("%s/dalvik-cache/%s", new Object[]{str2, str});
        if (!AnonymousClass001.A0E(format).isDirectory()) {
            format = String.format("%s/dalvik-cache", new Object[]{str2});
        }
        File A0E = AnonymousClass001.A0E(format);
        sDalvikCacheDirectory = A0E;
        return A0E;
    }

    public static RuntimeException runtimeExFrom(Throwable th) {
        if (th == null) {
            return AnonymousClass001.A0V("missing exception object");
        }
        if (th instanceof RuntimeException) {
            return (RuntimeException) th;
        }
        return AnonymousClass001.A0X(th);
    }

    public static void safeClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Exception e) {
                Mlog.w(e, "error closing %s", closeable);
            }
        }
    }

    public static String stripLastExtension(String str) {
        int lastIndexOf = str.lastIndexOf(46);
        if (lastIndexOf != -1) {
            return AnonymousClass001.A0f(str, lastIndexOf);
        }
        return str;
    }

    public static void deleteRecursive(File file) {
        DalvikInternals.deleteRecursive(file.getAbsolutePath());
    }

    public static File dexOptGenerateCacheFileName(File file, File file2, String str) {
        String absolutePath = file2.getAbsolutePath();
        if (str != null) {
            absolutePath = AnonymousClass0WY.A0w(absolutePath, "@", str);
        }
        return AnonymousClass001.A0D(file, absolutePath.substring(1).replace("/", "@"));
    }

    public static long discardFromInputStream(InputStream inputStream, long j) {
        int read;
        byte[] bArr = new byte[Constants.LOAD_RESULT_PGO];
        long j2 = 0;
        while (j2 < j && (read = inputStream.read(bArr, 0, (int) Math.min(OdexSchemeArtXdex.STATE_DO_PERIODIC_PGO_COMP_ATTEMPTED, j - j2))) != -1) {
            j2 += (long) read;
        }
        return j2;
    }

    public static void fsyncRecursive(File file, Prio prio) {
        if (!file.getPath().endsWith("_lock")) {
            if (file.isDirectory()) {
                for (File fsyncRecursive : file.listFiles()) {
                    fsyncRecursive(fsyncRecursive, prio);
                }
            }
            if (file.exists()) {
                DalvikInternals.fsyncNamed(file.getAbsolutePath(), prio.ioPriority);
            }
        }
    }

    public static void mkdirOrThrow(File file) {
        if (!file.mkdirs() && !file.isDirectory()) {
            throw AnonymousClass001.A0G(AnonymousClass002.A0M(file, "cannot mkdir: ", AnonymousClass001.A0m()));
        }
    }

    public static void renameOrThrow(File file, File file2) {
        if (!file.exists()) {
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append("Cannot rename ");
            A0m.append(file);
            throw AnonymousClass001.A0G(AnonymousClass001.A0g(" because it doesn't exist", A0m));
        } else if (!file.renameTo(file2)) {
            StringBuilder A0m2 = AnonymousClass001.A0m();
            A0m2.append("rename of ");
            A0m2.append(file);
            A0m2.append(" to ");
            A0m2.append(file2);
            throw AnonymousClass001.A0G(AnonymousClass001.A0g(" failed", A0m2));
        }
    }

    public static void safeClose(ZipFile zipFile) {
        if (zipFile != null) {
            try {
                zipFile.close();
            } catch (Exception e) {
                Mlog.w(e, "error closing %s", zipFile);
            }
        }
    }
}
