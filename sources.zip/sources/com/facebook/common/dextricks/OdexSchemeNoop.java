package com.facebook.common.dextricks;

import com.facebook.common.dextricks.OdexScheme;
import java.io.File;

public final class OdexSchemeNoop extends OdexScheme {
    public OdexSchemeNoop() {
        super(16, new String[0]);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.facebook.common.dextricks.OdexScheme$Compiler] */
    public OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        return new Object();
    }

    public String getSchemeName() {
        return "OdexSchemeNoop";
    }

    public final class NoopCompiler extends OdexScheme.Compiler {
        public void compile(InputDex inputDex) {
        }
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
    }
}
