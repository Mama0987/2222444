package com.facebook.common.dextricks;

import dalvik.system.DexFile;
import java.lang.reflect.Method;

public final class DexFileLoad {
    public static boolean sUseLazyLoadDexMethod;

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x002a A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static dalvik.system.DexFile loadDex(java.lang.String r5, java.lang.String r6, java.lang.ClassLoader r7) {
        /*
            r4 = 0
            r3 = 0
            if (r7 == 0) goto L_0x0022
            boolean r0 = sUseLazyLoadDexMethod     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            if (r0 == 0) goto L_0x000b
            java.lang.reflect.Method r2 = com.facebook.common.dextricks.DexFileLoad.LoadDexMethodHolder.sLoadDexMethod     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            goto L_0x000f
        L_0x000b:
            java.lang.reflect.Method r2 = getLoadMethodWithClassLoader()     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
        L_0x000f:
            if (r2 == 0) goto L_0x0022
            r1 = 1
            java.lang.Integer r0 = java.lang.Integer.valueOf(r4)     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            java.lang.Object[] r0 = new java.lang.Object[]{r5, r6, r0, r7, r3}     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            java.lang.Object r0 = r2.invoke(r3, r0)     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            dalvik.system.DexFile r0 = (dalvik.system.DexFile) r0     // Catch:{ IllegalAccessException | IllegalArgumentException | InvocationTargetException -> 0x0022 }
            r3 = r0
            goto L_0x0023
        L_0x0022:
            r1 = 0
        L_0x0023:
            if (r1 != 0) goto L_0x002a
            dalvik.system.DexFile r0 = dalvik.system.DexFile.loadDex(r5, r6, r4)
            return r0
        L_0x002a:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.DexFileLoad.loadDex(java.lang.String, java.lang.String, java.lang.ClassLoader):dalvik.system.DexFile");
    }

    public class LoadDexMethodHolder {
        public static final Method sLoadDexMethod;

        static {
            Method method;
            try {
                method = DexFileLoad.getLoadMethodWithClassLoader();
            } catch (SecurityException unused) {
                method = null;
            }
            sLoadDexMethod = method;
        }

        public static Method safeGetLoadMethodWithClassLoader() {
            try {
                return DexFileLoad.getLoadMethodWithClassLoader();
            } catch (SecurityException unused) {
                return null;
            }
        }
    }

    public static Method getLoadMethodWithClassLoader() {
        Method[] declaredMethods = DexFile.class.getDeclaredMethods();
        int length = declaredMethods.length;
        int i = 0;
        while (i < length) {
            Method method = declaredMethods[i];
            if (!method.getName().equals("loadDex") || method.getParameterTypes().length < 5) {
                i++;
            } else {
                method.setAccessible(true);
                return method;
            }
        }
        return null;
    }

    public static void init() {
    }

    public static void setUseLazyLoadDexMethod(boolean z) {
        sUseLazyLoadDexMethod = z;
    }
}
