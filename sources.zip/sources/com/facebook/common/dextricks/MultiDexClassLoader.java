package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.C12700le;
import X.C14790qN;
import X.C14990qj;
import X.C16770u0;
import android.content.Context;
import android.os.Build;
import android.os.SystemProperties;
import android.util.Log;
import com.facebook.common.dextricks.classifier.NameClassifier;
import com.facebook.common.dextricks.fallback.FallbackDexLoader;
import com.facebook.common.dextricks.halfnosis.Halfnosis;
import com.facebook.errorreporting.field.ReportFieldString;
import dalvik.system.DexFile;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;

public abstract class MultiDexClassLoader extends ClassLoader implements ColdStartAwareClassLoader, DexFileAccessLoggingClassLoader {
    public static final ClassLoader APP_CLASSLOADER;
    public static final int BASE_DEX_RETRY_WAIT_MS = 500;
    public static final Field CLASSLOADER_PARENT_FIELD;
    public static final Object INSTALL_LOCK = AnonymousClass001.A0U();
    public static final int MAX_LOAD_DEX_RETRY = 3;
    public static final ClassLoader SYSTEM_CLASSLOADER;
    public static final String TAG = "MultiDexClassLoader";
    public static boolean sHadFancyLoaderFailure;
    public static volatile ClassLoader sInstalledClassLoader;
    public DexFileAccessListener dexFileAccessListener = null;
    public ClassLoaderConfiguration mConfig;
    public final ClassLoader mPutativeLoader = APP_CLASSLOADER;
    public DexFile[] subscribedDexFiles = null;

    public abstract void configure(ClassLoaderConfiguration classLoaderConfiguration);

    public abstract DexFile[] doGetConfiguredDexFiles();

    public abstract String[] getRecentFailedClasses();

    public abstract String verboseDescription();

    public MultiDexClassLoader() {
        super(SYSTEM_CLASSLOADER);
    }

    public static boolean classInLongtailModule(String str) {
        if (sInstalledClassLoader instanceof MultiDexClassLoaderJava) {
            return NameClassifier.A01(MultiDexClassLoaderJava.sEncodedLongtailUnrenamedTypes, str);
        }
        return false;
    }

    public static ClassLoader createMultiDexClassLoader(Context context, ArrayList arrayList, ArrayList arrayList2) {
        SystemProperties.get("com.facebook.force_mdclj");
        return new MultiDexClassLoaderJava(context, arrayList, arrayList2);
    }

    public static void forceLoadProfiloIfPresent() {
        try {
            Class.forName("com.facebook.profilo.logger.api.ProfiloClassLoadTracer");
        } catch (ClassNotFoundException unused) {
        }
    }

    public static ClassLoaderConfiguration getConfiguration() {
        ClassLoader classLoader = sInstalledClassLoader;
        if (!(classLoader instanceof MultiDexClassLoader)) {
            return null;
        }
        return ((MultiDexClassLoader) classLoader).mConfig;
    }

    public static DexFile[] getConfiguredDexFiles() {
        ClassLoader classLoader = sInstalledClassLoader;
        if (!(classLoader instanceof MultiDexClassLoader)) {
            return new DexFile[0];
        }
        return ((MultiDexClassLoader) classLoader).doGetConfiguredDexFiles();
    }

    public static ClassLoader install(Context context, ArrayList arrayList, ArrayList arrayList2) {
        ClassLoader classLoader;
        RuntimeException runtimeException;
        ClassLoader classLoader2 = sInstalledClassLoader;
        if (classLoader2 != null) {
            return classLoader2;
        }
        synchronized (INSTALL_LOCK) {
            classLoader = sInstalledClassLoader;
            if (classLoader == null) {
                try {
                    Class.forName("com.facebook.common.dextricks.FatalDexError");
                    Class.forName("com.facebook.common.dextricks.DexFileLoadOld");
                    Class.forName("com.facebook.common.dextricks.DexFileLoadNew");
                    Class.forName("com.facebook.common.dextricks.classifier.NameClassifier");
                    Class.forName("com.facebook.common.dextricks.ClassLoadingStatsHolder");
                    Class.forName("com.facebook.common.dextricks.stats.ClassLoadingStatsJava");
                    Class.forName("com.facebook.common.dextricks.stats.ClassLoadingStats");
                    Class.forName("com.facebook.common.dextricks.stats.ClassLoadingStats$SnapshotStats");
                    Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger");
                    Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerNativeHolder");
                    Class.forName("com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerLite");
                    Class.forName("com.facebook.common.dextricks.coverage.logger.ClassCoverageLogger");
                    Class.forName("com.facebook.common.dextricks.benchmarkhelper.ClassloadNameCollector");
                    Class.forName("com.facebook.common.dextricks.classid.ClassId");
                    Class.forName("com.facebook.common.dextricks.StringTreeSet");
                    Class.forName("com.facebook.common.dextricks.fallback.FallbackDexLoader");
                    Class.forName("com.facebook.common.dextricks.ClassLoadsListener");
                    Class.forName("com.facebook.common.dextricks.ClassLoadsLoggingProvider");
                    Class.forName("com.facebook.common.dextricks.ClassLoadsTracer");
                    Class.forName("com.facebook.common.dextricks.ClassLoadsNotifier");
                    forceLoadProfiloIfPresent();
                    C16770u0 r4 = C14790qN.A00;
                    if (r4 != null) {
                        r4.A02(new ReportFieldString(-2, "recentClassLoadFailures", true), new C12700le() {
                            public String get() {
                                ClassLoader classLoader = MultiDexClassLoader.sInstalledClassLoader;
                                if (classLoader instanceof MultiDexClassLoader) {
                                    return Arrays.toString(((MultiDexClassLoader) classLoader).getRecentFailedClasses());
                                }
                                return "";
                            }
                        });
                        r4.A02(C14990qj.A7q, new C12700le() {
                            public String get() {
                                return AnonymousClass002.A0M(MultiDexClassLoader.sInstalledClassLoader, "", AnonymousClass001.A0m());
                            }
                        });
                    }
                    classLoader = createMultiDexClassLoader(context, arrayList, arrayList2);
                    try {
                        ClassLoadsTracer.install((MultiDexClassLoaderJava) classLoader);
                        CLASSLOADER_PARENT_FIELD.set(((MultiDexClassLoader) classLoader).mPutativeLoader, classLoader);
                        sInstalledClassLoader = classLoader;
                    } catch (IllegalAccessException e) {
                        runtimeException = AnonymousClass001.A0X(e);
                    }
                } catch (ClassNotFoundException e2) {
                    runtimeException = AnonymousClass001.A0X(e2);
                    throw runtimeException;
                }
            }
        }
        return classLoader;
    }

    public static final boolean maybeFallbackLoadDexes(String str, Throwable th) {
        String str2;
        FallbackDexLoader fallbackDexLoader = FallbackDexLoader.A00;
        if (fallbackDexLoader == null) {
            return false;
        }
        if (classInLongtailModule(str)) {
            str2 = Halfnosis.getLongtailModuleName();
        } else {
            str2 = null;
        }
        return fallbackDexLoader.A03(str, str2);
    }

    public void configureArtHacks(ClassLoaderConfiguration classLoaderConfiguration) {
        if (classLoaderConfiguration.disableVerifier) {
            DalvikInternals.installArtHacks(4, Build.VERSION.SDK_INT);
        }
    }

    public void observeDexFileLoad(DexFile dexFile, Class cls) {
        DexFile[] dexFileArr;
        DexFileAccessListener dexFileAccessListener2;
        if (cls != null && (dexFileArr = this.subscribedDexFiles) != null && (dexFileAccessListener2 = this.dexFileAccessListener) != null) {
            for (DexFile dexFile2 : dexFileArr) {
                if (dexFile == dexFile2) {
                    dexFileAccessListener2.onClassLoadedFromDexFile(cls, dexFile);
                    return;
                }
            }
        }
    }

    public void subscribeToDexFileAccesses(DexFile[] dexFileArr, DexFileAccessListener dexFileAccessListener2) {
        this.subscribedDexFiles = dexFileArr;
        this.dexFileAccessListener = dexFileAccessListener2;
    }

    static {
        try {
            ClassLoader classLoader = MultiDexClassLoader.class.getClassLoader();
            APP_CLASSLOADER = classLoader;
            Field declaredField = ClassLoader.class.getDeclaredField("parent");
            CLASSLOADER_PARENT_FIELD = declaredField;
            declaredField.setAccessible(true);
            SYSTEM_CLASSLOADER = (ClassLoader) declaredField.get(classLoader);
        } catch (Exception e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public static ClassLoader get() {
        return sInstalledClassLoader;
    }

    public static ClassLoader getSysClassloader() {
        return SYSTEM_CLASSLOADER;
    }

    public static boolean hadFancyLoaderFailure() {
        return sHadFancyLoaderFailure;
    }

    public static boolean isArt() {
        return true;
    }

    public static boolean isNativeHookUseable() {
        return false;
    }

    public ClassLoaderConfiguration getConfig() {
        return this.mConfig;
    }

    public final Class maybeFallbackLoadClass(String str, Throwable th) {
        try {
            if (maybeFallbackLoadDexes(str, th)) {
                Class<?> findClass = findClass(str);
                if (findClass != null) {
                    return findClass;
                }
                Log.w(TAG, AnonymousClass0WY.A0i("findClass failed without throwing for ", str));
            }
            if (th instanceof ClassNotFoundException) {
                throw ((ClassNotFoundException) th);
            }
            throw new ClassNotFoundException(str, th);
        } catch (RuntimeException e) {
            throw new ClassNotFoundException(AnonymousClass0WY.A0i("Fallback class load failed for ", str), e);
        }
    }

    public void onColdstartDone() {
    }
}
