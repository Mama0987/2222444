package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C12830mT;
import X.C12840mU;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.DexStore;
import com.facebook.endtoend.EndToEnd;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import dalvik.system.DexFile;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class DexLibLoader {
    public static final int LOAD_ALL_ASYNC_OPTIMIZATION = 4;
    public static final int LOAD_ALL_BETA_BUILD = 1;
    public static final int LOAD_ALL_INSTRUMENTATION_TEST = 16;
    public static final int LOAD_ALL_OPEN_ONLY = 2;
    public static final int LOAD_SECONDARY = 8;
    public static DexStore sMainDexStore;

    public final class ApkResProvider extends ResProvider {
        public static final String SECONDARY_PROGRAM_DEX_JARS = "secondary-program-dex-jars";
        public ZipFile mApkZip;
        public final Context mContext;

        public void close() {
            ZipFile zipFile = this.mApkZip;
            if (zipFile != null) {
                Fs.safeClose(zipFile);
            }
        }

        public void markRootRelative() {
            if (this.mApkZip == null) {
                Context context = this.mContext;
                try {
                    context = context.createPackageContext(context.getPackageName(), 0);
                } catch (PackageManager.NameNotFoundException unused) {
                }
                this.mApkZip = new ZipFile(context.getApplicationInfo().sourceDir);
            }
        }

        public InputStream open(String str) {
            ZipFile zipFile = this.mApkZip;
            if (zipFile == null || DexStoreUtils.SECONDARY_DEX_MANIFEST.equals(str)) {
                return this.mContext.getAssets().open(AnonymousClass0WY.A0i("secondary-program-dex-jars/", str));
            }
            ZipEntry entry = zipFile.getEntry(str);
            if (entry != null) {
                return this.mApkZip.getInputStream(entry);
            }
            throw new FileNotFoundException(AnonymousClass0WY.A0i("cannot find root-relative resource: ", str));
        }

        public ApkResProvider(Context context) {
            this.mContext = context;
        }
    }

    public final class ExoPackageResProvider extends ResProvider {
        public static final String EXOPACKAGE_DIR = "/data/local/tmp/exopackage";
        public final File mDirectory;

        public InputStream open(String str) {
            return AnonymousClass001.A0F(AnonymousClass001.A0D(this.mDirectory, str));
        }

        public ExoPackageResProvider(Context context) {
            this.mDirectory = AnonymousClass001.A0E(AnonymousClass0WY.A0w("/data/local/tmp/exopackage/", context.getPackageName(), "/secondary-dex"));
        }

        public String getFilePath(String str) {
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append(this.mDirectory);
            A0m.append("/");
            return AnonymousClass001.A0g(str, A0m);
        }

        public boolean isExoResProvider() {
            return true;
        }
    }

    public interface ResProviderShim {
        ResProvider install(ResProvider resProvider);
    }

    public static int loadAll(Context context, boolean z) {
        return loadAll(context, 1, (LightweightQuickPerformanceLogger) null);
    }

    public static ResProvider obtainResProvider(Context context, boolean z) {
        return obtainResProvider(context, (ResProviderShim) null, z);
    }

    public static ResProvider obtainResProviderInternal(Context context, boolean z) {
        ApkResProvider apkResProvider = new ApkResProvider(context);
        try {
            apkResProvider.open(DexStoreUtils.SECONDARY_DEX_MANIFEST).close();
            return apkResProvider;
        } catch (Resources.NotFoundException | FileNotFoundException unused) {
            if (z) {
                ExoPackageResProvider exoPackageResProvider = new ExoPackageResProvider(context);
                try {
                    exoPackageResProvider.open(DexStoreUtils.SECONDARY_DEX_MANIFEST).close();
                    return exoPackageResProvider;
                } catch (FileNotFoundException unused2) {
                    return null;
                }
            }
            return null;
        }
    }

    public class CanaryLoaderImpl implements Runnable {
        public void run() {
            try {
                for (DexStore dexStoreListHead = DexStore.dexStoreListHead(); dexStoreListHead != null; dexStoreListHead = dexStoreListHead.next) {
                    DexManifest dexManifest = dexStoreListHead.mLoadedManifest;
                    if (dexManifest != null) {
                        for (DexManifest.Dex dex : dexManifest.dexes) {
                            Class.forName(dex.canaryClass);
                        }
                    }
                }
            } catch (Throwable th) {
                throw Fs.runtimeExFrom(th);
            }
        }
    }

    public static synchronized DexStore getMainDexStore() {
        DexStore dexStore;
        synchronized (DexLibLoader.class) {
            dexStore = sMainDexStore;
        }
        return dexStore;
    }

    /* JADX WARNING: type inference failed for: r0v16, types: [java.lang.Object, com.facebook.common.dextricks.DexErrorRecoveryInfo] */
    public static int loadAllImpl(Context context, int i, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger, ResProviderShim resProviderShim, DexStore.Config config) {
        IllegalArgumentException th;
        DexErrorRecoveryInfo dexErrorRecoveryInfo;
        int i2 = i & 1;
        boolean A1R = AnonymousClass001.A1R(i2);
        if ((i & 16) != 0) {
            setupMainDexStoreConfigForInstrumentationTests(context, config);
        } else if (config != null) {
            th = AnonymousClass001.A0L("Do not specify a config outside of test mode.");
            throw th;
        }
        ArrayList A0t = AnonymousClass001.A0t();
        ArrayList A0t2 = AnonymousClass001.A0t();
        Context context2 = context;
        try {
            context2 = context.createPackageContext(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException unused) {
        }
        try {
            C12840mU.A00(context2, DexLibLoader.class.getClassLoader(), A0t, A0t2);
        } catch (C12830mT e) {
            Mlog.w(e, "failure to locate primary/auxiliary dexes: perf loss", new Object[0]);
            A0t.clear();
            A0t2.clear();
        }
        File mainDexStoreLocation = DexStoreUtils.getMainDexStoreLocation(context);
        File A0A = AnonymousClass002.A0A(context2);
        if (!A0A.exists()) {
            if (!A0t.isEmpty()) {
                A0A = AnonymousClass001.A0E(((DexFile) A0t.get(0)).getName());
                Mlog.w("Main store will use %s as apk file.", A0A.getPath());
            } else {
                throw AnonymousClass001.A0V("Cannot determine base.apk");
            }
        }
        ResProvider obtainResProvider = obtainResProvider(context, resProviderShim, A1R);
        if (obtainResProvider == null) {
            try {
                DexErrorRecoveryInfo.setMainDexStoreLoadInformation(new Object());
                return 0;
            } catch (Throwable th2) {
                AnonymousClass0ZM.A00(th, th2);
                throw th;
            }
        } else {
            DexStore open = DexStore.open(mainDexStoreLocation, A0A, obtainResProvider, A0t, A0t2);
            sMainDexStore = open;
            if ((i & 2) == 0) {
                boolean A1R2 = AnonymousClass001.A1R(i2);
                if ((i & 8) != 0) {
                    A1R2 |= true;
                }
                if ((i & 4) != 0) {
                    A1R2 |= true;
                }
                EndToEnd.A04();
                AnonymousClass001.A1I("disabling background optimization");
                dexErrorRecoveryInfo = open.loadAll(((A1R2 & true) | true) | true ? 1 : 0, lightweightQuickPerformanceLogger, context);
                if ((dexErrorRecoveryInfo.loadResult & 8) != 0) {
                    DexErrorRecoveryInfo.sDeoptTaint = true;
                }
                dexErrorRecoveryInfo.storeRegenFilename = open.getRegenFile().getAbsolutePath();
            } else {
                dexErrorRecoveryInfo = null;
            }
            DexErrorRecoveryInfo.setMainDexStoreLoadInformation(dexErrorRecoveryInfo);
            obtainResProvider.close();
            return 0;
        }
    }

    public static void ensureConfig(Context context, DexStore.Config config, boolean z) {
        File mainDexStoreLocation = DexStoreUtils.getMainDexStoreLocation(context);
        Fs.mkdirOrThrow(mainDexStoreLocation);
        if (config != null) {
            File A0D = AnonymousClass001.A0D(mainDexStoreLocation, DexStore.CONFIG_FILENAME);
            if (!A0D.exists() || z) {
                config.writeAndSync(A0D);
            }
        }
    }

    public static DexErrorRecoveryInfo getMainDexStoreLoadInformation() {
        return DexErrorRecoveryInfo.getMainDexStoreLoadInformation();
    }

    public static void handleUnoptimizedCodeForPerftest(Context context) {
        if (EndToEnd.A04()) {
            ZOptEagerInvoke.run(context);
            Mlog.w("App running unoptimized code, restart is required!", new Object[0]);
        }
    }

    public static void setupMainDexStoreConfigForInstrumentationTests(Context context, DexStore.Config config) {
        File mainDexStoreLocation = DexStoreUtils.getMainDexStoreLocation(context);
        Fs.deleteRecursive(mainDexStoreLocation);
        Fs.mkdirOrThrow(mainDexStoreLocation);
        if (config != null) {
            config.writeAndSync(AnonymousClass001.A0D(mainDexStoreLocation, DexStore.CONFIG_FILENAME));
        }
    }

    public static boolean shouldSynchronouslyGenerateOatFiles() {
        EndToEnd.A04();
        return true;
    }

    public static boolean wasMainDexStoreRegenerated() {
        if ((DexErrorRecoveryInfo.getMainDexStoreLoadInformation().loadResult & 1) == 0) {
            return false;
        }
        return true;
    }

    public static int loadAll(Context context, boolean z, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        return loadAll(context, 1, lightweightQuickPerformanceLogger);
    }

    public static ResProvider obtainResProvider(Context context, ResProviderShim resProviderShim, boolean z) {
        try {
            ResProvider obtainResProviderInternal = obtainResProviderInternal(context, z);
            if (resProviderShim != null) {
                return resProviderShim.install(obtainResProviderInternal);
            }
            return obtainResProviderInternal;
        } catch (IOException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public static synchronized int loadAll(Context context, int i, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        int loadAll;
        synchronized (DexLibLoader.class) {
            loadAll = loadAll(context, i, lightweightQuickPerformanceLogger, (ResProviderShim) null, (DexStore.Config) null);
        }
        return loadAll;
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [java.lang.Object, java.lang.Runnable] */
    public static synchronized int loadAll(Context context, int i, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger, ResProviderShim resProviderShim, DexStore.Config config) {
        Throwable th;
        int loadAllImpl;
        synchronized (DexLibLoader.class) {
            if (DexErrorRecoveryInfo.getMainDexStoreLoadInformationNoThrow() == null) {
                try {
                    loadAllImpl = loadAllImpl(context, i, lightweightQuickPerformanceLogger, resProviderShim, config);
                    CanaryLoader.setInstance(new Object());
                    if (DexErrorRecoveryInfo.sDeoptTaint) {
                        handleUnoptimizedCodeForPerftest(context);
                    }
                } catch (IOException e) {
                    th = AnonymousClass001.A0X(e);
                }
            } else {
                th = new AssertionError("loadAll already loaded dex files");
                throw th;
            }
        }
        return loadAllImpl;
    }

    public static int loadAll(Context context) {
        return loadAll(context, 1, (LightweightQuickPerformanceLogger) null);
    }
}
