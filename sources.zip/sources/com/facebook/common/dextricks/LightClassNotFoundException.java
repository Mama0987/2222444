package com.facebook.common.dextricks;

public class LightClassNotFoundException extends ClassNotFoundException {
    public synchronized Throwable fillInStackTrace() {
        return this;
    }

    public LightClassNotFoundException(String str, Throwable th) {
        super(str, th);
    }

    public LightClassNotFoundException(String str) {
        super(str);
    }
}
