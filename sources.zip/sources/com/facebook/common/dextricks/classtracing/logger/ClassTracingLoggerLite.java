package com.facebook.common.dextricks.classtracing.logger;

import X.AnonymousClass17G;
import X.C10990hS;
import com.facebook.common.dextricks.classid.ClassId;
import com.facebook.systrace.Systrace;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ClassTracingLoggerLite {
    public static final ConcurrentLinkedQueue A00 = new ConcurrentLinkedQueue();
    public static volatile boolean A01;
    public static volatile boolean A02;

    static {
        AnonymousClass17G r1 = new AnonymousClass17G(1);
        String[][] strArr = Systrace.A03;
        C10990hS.A02(r1);
    }

    public static void beginClassLoad(String str) {
        if (A01) {
            boolean z = ClassId.sInitialized;
        }
    }

    public static void classLoaded(Class cls) {
        if (A01 && ClassId.sInitialized) {
            A00.add(Long.valueOf(ClassId.getClassId(cls)));
        }
    }

    public static void classNotFound() {
        if (A01 && ClassId.sInitialized) {
            A00.add(-1L);
        }
    }
}
