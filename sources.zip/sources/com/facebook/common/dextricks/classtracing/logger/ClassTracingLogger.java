package com.facebook.common.dextricks.classtracing.logger;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass17G;
import X.C10990hS;
import X.C18550xJ;
import android.content.Context;
import com.facebook.common.dextricks.classid.ClassId;
import com.facebook.profilo.provider.qpl.QplEventsProvider;
import com.facebook.systrace.Systrace;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public final class ClassTracingLogger {
    public static final CopyOnWriteArraySet A00 = new CopyOnWriteArraySet();
    public static volatile boolean A01;
    public static volatile boolean A02;
    public static volatile boolean A03;
    public static volatile boolean A04;
    public static volatile boolean A05;

    static {
        AnonymousClass17G r1 = new AnonymousClass17G(0);
        String[][] strArr = Systrace.A03;
        C10990hS.A02(r1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0010, code lost:
        if (r1 != false) goto L_0x0012;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized void A00() {
        /*
            java.lang.Class<com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger> r5 = com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger.class
            monitor-enter(r5)
            boolean r1 = A03     // Catch:{ all -> 0x005d }
            boolean r0 = A02     // Catch:{ all -> 0x005d }
            r4 = 0
            r3 = 1
            if (r0 != 0) goto L_0x0012
            boolean r0 = A04     // Catch:{ all -> 0x005d }
            if (r0 != 0) goto L_0x0012
            r0 = 0
            if (r1 == 0) goto L_0x0032
        L_0x0012:
            A05 = r3     // Catch:{ all -> 0x005d }
            r0 = r1 ^ 1
            boolean r2 = A02     // Catch:{ all -> 0x005d }
            boolean r1 = A04     // Catch:{ all -> 0x005d }
            if (r0 == 0) goto L_0x002e
            java.lang.String r0 = "classtracing"
            X.C18440x7.loadLibrary(r0)     // Catch:{ UnsatisfiedLinkError -> 0x0024 }
            com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerNativeHolder.sIsInitialized = r3     // Catch:{ UnsatisfiedLinkError -> 0x0024 }
            goto L_0x002e
        L_0x0024:
            r2 = move-exception
            java.lang.String r1 = "ClassTracingLoggerNH"
            java.lang.String r0 = "Failed to load native library"
            android.util.Log.w(r1, r0, r2)     // Catch:{ all -> 0x005d }
            r0 = 0
            goto L_0x0032
        L_0x002e:
            com.facebook.common.dextricks.classtracing.logger.ClassTracingLoggerNativeHolder.configureTracing(r2, r1)     // Catch:{ all -> 0x005d }
            r0 = 1
        L_0x0032:
            A03 = r0     // Catch:{ all -> 0x005d }
            boolean r0 = A03     // Catch:{ all -> 0x005d }
            if (r0 == 0) goto L_0x003d
            boolean r0 = com.facebook.common.dextricks.classid.ClassId.sInitialized     // Catch:{ all -> 0x005d }
            if (r0 == 0) goto L_0x003d
            r4 = 1
        L_0x003d:
            A01 = r4     // Catch:{ all -> 0x005d }
            boolean r0 = A01     // Catch:{ all -> 0x005d }
            X.C12760mF.A00 = r0     // Catch:{ all -> 0x005d }
            X.C12760mF.A01 = r3     // Catch:{ all -> 0x005d }
            java.util.concurrent.CopyOnWriteArraySet r0 = A00     // Catch:{ all -> 0x005d }
            java.util.Iterator r1 = r0.iterator()     // Catch:{ all -> 0x005d }
        L_0x004b:
            boolean r0 = r1.hasNext()     // Catch:{ all -> 0x005d }
            if (r0 == 0) goto L_0x005b
            java.lang.Object r0 = r1.next()     // Catch:{ all -> 0x005d }
            com.facebook.common.dextricks.ClassLoadsTracer$$ExternalSyntheticLambda0 r0 = (com.facebook.common.dextricks.ClassLoadsTracer$$ExternalSyntheticLambda0) r0     // Catch:{ all -> 0x005d }
            r0.onInitializationFinished(r3)     // Catch:{ all -> 0x005d }
            goto L_0x004b
        L_0x005b:
            monitor-exit(r5)
            return
        L_0x005d:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x005d }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.classtracing.logger.ClassTracingLogger.A00():void");
    }

    public static void A01(int i) {
        if (A03) {
            ClassTracingLoggerNativeHolder.classLoadStarted((String) null);
            ClassTracingLoggerNativeHolder.classLoaded((((long) i) << 32) | 2425405050L);
        }
    }

    public static long[] A03() {
        if (!A05) {
            return new long[0];
        }
        long[] loadedClassIds = ClassTracingLoggerNativeHolder.loadedClassIds();
        HashMap A0w = AnonymousClass001.A0w();
        int i = 0;
        boolean z = false;
        for (long j : loadedClassIds) {
            if (j != -1) {
                int i2 = (int) (j & 4294967295L);
                if (i2 != 1505373456 && i2 != 1215735889) {
                    z = true;
                } else if (!A0w.containsKey(Long.valueOf(j)) || z) {
                    z = false;
                }
                int i3 = i + 1;
                loadedClassIds[i] = j;
                if (i2 == 1505373456 || i2 == 1215735889) {
                    A0w.put(Long.valueOf(j), true);
                }
                i = i3;
            }
        }
        return Arrays.copyOf(loadedClassIds, i);
    }

    public static void beginClassLoad(String str) {
        if (A01 && ClassTracingLoggerNativeHolder.sIsInitialized) {
            ClassTracingLoggerNativeHolder.classLoadStarted(str);
        }
    }

    public static void classLoaded(Class cls) {
        long classId;
        if (A01 && ClassTracingLoggerNativeHolder.sIsInitialized) {
            if (!ClassId.sInitialized) {
                classId = -1;
            } else {
                classId = ClassId.getClassId(cls);
                if ((-281474976710656L & classId) == 0) {
                    Thread currentThread = Thread.currentThread();
                    if (currentThread != null) {
                        classId |= (currentThread.getId() & QplEventsProvider.ACTION_ID_MASK) << 48;
                    }
                } else {
                    throw AnonymousClass001.A0q();
                }
            }
            ClassTracingLoggerNativeHolder.classLoaded(classId);
        }
    }

    public static void classNotFound() {
        if (A01 && ClassTracingLoggerNativeHolder.sIsInitialized) {
            ClassTracingLoggerNativeHolder.classLoadCancelled();
        }
    }

    public static boolean A02() {
        return A01;
    }

    public static void updateEnabledState(Context context, boolean z, Set set) {
        Iterator it = set.iterator();
        while (it.hasNext()) {
            C18550xJ.A01(context, AnonymousClass0WY.A0i("classtracinglogger_enable_", (String) it.next()), z ? 1 : 0);
        }
    }
}
