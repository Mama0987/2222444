package com.facebook.common.dextricks;

public interface ClassLoadsLoggingProvider {
    void addListener(ClassLoadsListener classLoadsListener);
}
