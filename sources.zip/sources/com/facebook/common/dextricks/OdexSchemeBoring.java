package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import android.os.Build;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.DexStore;
import com.facebook.common.dextricks.OdexScheme;
import dalvik.system.DexFile;
import java.io.File;
import java.util.Iterator;
import java.util.Map;

public final class OdexSchemeBoring extends OdexScheme {

    public final class BoringCompiler extends OdexScheme.Compiler {
        public final DexStore mDexStore;
        public final int mFlags;
        public boolean mLowDiskSpace;
        public final Map mRenameTempToFinalOdexMap = AnonymousClass001.A0w();
        public final DexStore.TmpDir mTmpDir;

        private void onLowDiskSpaceLikelyDetected() {
            this.mLowDiskSpace = true;
            for (File file : this.mRenameTempToFinalOdexMap.keySet()) {
                file.delete();
                file.getAbsolutePath();
            }
            this.mRenameTempToFinalOdexMap.clear();
        }

        public void close() {
            this.mTmpDir.close();
        }

        public void compile(InputDex inputDex) {
            File file;
            String makeDexName = OdexSchemeBoring.makeDexName(inputDex.dex);
            String makeOdexName = OdexSchemeBoring.makeOdexName(makeDexName);
            File A0D = AnonymousClass001.A0D(this.mDexStore.root, makeDexName);
            File A0D2 = AnonymousClass001.A0D(this.mDexStore.root, makeOdexName);
            if ((this.mFlags & 1) == 0 || !A0D.exists() || !A0D2.exists()) {
                File A0D3 = AnonymousClass001.A0D(this.mTmpDir.directory, makeDexName);
                String str = null;
                if (!this.mLowDiskSpace) {
                    file = AnonymousClass001.A0D(this.mTmpDir.directory, makeOdexName);
                } else {
                    file = null;
                }
                inputDex.extract(A0D3);
                if (Build.VERSION.SDK_INT > 33) {
                    A0D3.setWritable(false);
                }
                String absolutePath = A0D3.getAbsolutePath();
                if (file != null) {
                    str = file.getAbsolutePath();
                }
                DexFile.loadDex(absolutePath, str, 0);
                Fs.renameOrThrow(A0D3, A0D);
                if (file == null) {
                    return;
                }
                if (file.exists()) {
                    this.mRenameTempToFinalOdexMap.put(file, A0D2);
                    return;
                }
                Mlog.w("Odex file does not exist (likely because dex2oat failed due to low disk space).\n Failing back to using dex file: %s\n Odex file: %s", A0D, file.getAbsolutePath());
                onLowDiskSpaceLikelyDetected();
            }
        }

        public void performFinishActions() {
            Iterator A12 = AnonymousClass001.A12(this.mRenameTempToFinalOdexMap);
            while (A12.hasNext()) {
                Map.Entry A13 = AnonymousClass001.A13(A12);
                ((File) A13.getKey()).getAbsolutePath();
                ((File) A13.getValue()).getAbsolutePath();
                Fs.renameOrThrow((File) A13.getKey(), (File) A13.getValue());
            }
        }

        public BoringCompiler(DexStore dexStore, int i) {
            this.mDexStore = dexStore;
            this.mFlags = i;
            this.mTmpDir = dexStore.makeTemporaryDirectory("boring-compiler");
            this.mLowDiskSpace = AnonymousClass001.A1R(i & 32);
        }
    }

    public static ExpectedFileInfo[] makeExpectedFileList(DexManifest.Dex[] dexArr) {
        int length = dexArr.length;
        ExpectedFileInfo[] expectedFileInfoArr = new ExpectedFileInfo[(length * 2)];
        for (int i = 0; i < length; i++) {
            DexManifest.Dex dex = dexArr[i];
            String makeDexName = makeDexName(dex);
            int i2 = i * 2;
            expectedFileInfoArr[i2] = new ExpectedFileInfo(dex, makeDexName);
            int i3 = i2 + 1;
            ExpectedFileInfo expectedFileInfo = new ExpectedFileInfo(makeOdexName(makeDexName));
            expectedFileInfo.mIsOptional = true;
            expectedFileInfoArr[i3] = expectedFileInfo;
        }
        return expectedFileInfoArr;
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
        int i = 0;
        while (true) {
            String[] strArr = this.expectedFiles;
            if (i < strArr.length) {
                File A0D = AnonymousClass001.A0D(file, strArr[i + 1]);
                File file2 = null;
                if (A0D.exists()) {
                    file2 = A0D;
                }
                classLoaderConfiguration.addDex(AnonymousClass001.A0D(file, this.expectedFiles[i]), file2);
                i += 2;
            } else {
                return;
            }
        }
    }

    public OdexSchemeBoring(DexManifest.Dex[] dexArr) {
        super(8, makeExpectedFileList(dexArr));
    }

    public static String makeDexName(DexManifest.Dex dex) {
        String str = dex.assetName;
        boolean endsWith = str.endsWith(".dex.xz");
        String str2 = DexManifest.DEX_EXT;
        if (!endsWith && !str.endsWith(str2)) {
            str2 = ".dex.jar";
        }
        return AnonymousClass0WY.A0w("prog-", dex.hash, str2);
    }

    public OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        return new BoringCompiler(dexStore, i);
    }

    public static String makeOdexName(String str) {
        return AnonymousClass0WY.A0i(Fs.stripLastExtension(str), DexManifest.ODEX_EXT);
    }

    public String getSchemeName() {
        return "OdexSchemeBoring";
    }
}
