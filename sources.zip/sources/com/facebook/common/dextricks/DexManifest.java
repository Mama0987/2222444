package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0N9;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public final class DexManifest {
    public static final String DEX_EXT = ".dex";
    public static final String ODEX_EXT = ".odex";
    public final Dex[] dexes;
    public final String id;
    public final boolean isArtMainStore;
    public final boolean isExoPackage;
    public final boolean locators;
    public final String[] requires;
    public final boolean rootRelative;
    public final AnonymousClass0N9 superpackExtension;
    public final int superpackFiles;

    public final class Dex {
        public final String assetName;
        public final String canaryClass;
        public final String hash;

        public String makeDexName() {
            return DexManifest.makeCompileUnitNameFromHashAndExtension(this.hash, DexManifest.DEX_EXT);
        }

        public String makeOdexName() {
            return DexManifest.makeCompileUnitNameFromHashAndExtension(this.hash, DexManifest.ODEX_EXT);
        }

        public String toString() {
            return String.format("<Dex assetName:[%s]>", new Object[]{this.assetName});
        }

        public Dex(String str, String str2, String str3) {
            this.assetName = str;
            this.hash = str2;
            this.canaryClass = str3;
        }
    }

    private boolean isUncompressedDex() {
        Dex[] dexArr = this.dexes;
        if (dexArr.length != 0) {
            return dexArr[0].assetName.endsWith(DEX_EXT);
        }
        return false;
    }

    public static String makeCompileUnitNameFromHashAndExtension(String str, String str2) {
        if (!str2.startsWith(".")) {
            str2 = AnonymousClass0WY.A0i(".", str2);
        }
        return AnonymousClass0WY.A0w("prog-", str, str2);
    }

    public static String makeDexNameFromHash(String str) {
        return makeCompileUnitNameFromHashAndExtension(str, DEX_EXT);
    }

    public static String makeOdexNameFromHash(String str) {
        return makeCompileUnitNameFromHashAndExtension(str, ODEX_EXT);
    }

    private void preloadDexClass() {
        Mlog.w("Preloading class %s", Dex.class.getName());
    }

    public boolean canLoadCanaryClass() {
        if (this.isArtMainStore) {
            AnonymousClass001.A1I("Art main store, not checking canary class");
            return true;
        }
        Dex[] dexArr = this.dexes;
        if (dexArr.length == 0) {
            return false;
        }
        try {
            Class.forName(dexArr[0].canaryClass);
            return true;
        } catch (ClassNotFoundException | NoClassDefFoundError unused) {
            return false;
        }
    }

    public boolean isUncompressedExo() {
        if (!this.isExoPackage || !isUncompressedDex()) {
            return false;
        }
        return true;
    }

    public void verifyCanaryClasses() {
        int i = 0;
        if (this.isArtMainStore) {
            AnonymousClass001.A1I("Art main store, not verifying canary class");
            return;
        }
        while (true) {
            Dex[] dexArr = this.dexes;
            if (i < dexArr.length) {
                Class.forName(dexArr[i].canaryClass);
                i++;
            } else {
                return;
            }
        }
    }

    public DexManifest(InputStream inputStream, boolean z) {
        preloadDexClass();
        this.isExoPackage = z;
        ArrayList A0t = AnonymousClass001.A0t();
        AnonymousClass0N9 r4 = AnonymousClass0N9.NONE;
        AnonymousClass0N9 r14 = r4;
        String str = DexStoreUtils.MAIN_DEX_STORE_ID;
        ArrayList A0t2 = AnonymousClass001.A0t();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
        boolean z2 = false;
        boolean z3 = false;
        int i = 0;
        while (true) {
            try {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    bufferedReader.close();
                    this.rootRelative = z2;
                    this.locators = z3;
                    this.superpackFiles = i;
                    this.superpackExtension = r4;
                    this.id = str;
                    this.requires = AnonymousClass002.A0t(A0t2);
                    this.dexes = (Dex[]) A0t.toArray(new Dex[A0t.size()]);
                    this.isArtMainStore = false;
                    return;
                } else if (readLine.length() != 0) {
                    if (readLine.equals(".root_relative")) {
                        z2 = true;
                    } else if (readLine.equals(".locators")) {
                        z3 = true;
                    } else if (readLine.startsWith(".superpack_files")) {
                        i = Integer.parseInt(readLine.split(" ")[1]);
                    } else if (readLine.startsWith(".superpack_extension")) {
                        String str2 = readLine.split(" ")[1];
                        if (!str2.isEmpty()) {
                            if (str2.equalsIgnoreCase("xz")) {
                                r4 = AnonymousClass0N9.XZ;
                            } else if (str2.equalsIgnoreCase("zst") || str2.equalsIgnoreCase("zstd")) {
                                r4 = AnonymousClass0N9.ZST;
                            } else if (str2.equalsIgnoreCase("spo")) {
                                r4 = AnonymousClass0N9.OB;
                            }
                        }
                        r4 = r14;
                    } else if (readLine.startsWith(".id")) {
                        str = readLine.split(" ")[1];
                    } else if (readLine.startsWith(".requires")) {
                        A0t2.add(readLine.split(" ")[1]);
                    } else if (readLine.startsWith(".")) {
                        Mlog.w("ignoring dex metadata pragma [%s]", readLine);
                    } else {
                        String[] split = readLine.split(" ");
                        A0t.add(new Dex(split[0], split[1], split[2]));
                    }
                }
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
                throw th;
            }
        }
    }

    public static DexManifest loadManifestFrom(ResProvider resProvider, String str, boolean z) {
        InputStream open = resProvider.open(str);
        try {
            DexManifest dexManifest = new DexManifest(open, resProvider.isExoResProvider());
            if (open != null) {
                open.close();
            }
            if (z && dexManifest.rootRelative) {
                resProvider.markRootRelative();
            }
            return dexManifest;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public boolean isArtMainStore() {
        return this.isArtMainStore;
    }

    public DexManifest(boolean z) {
        this.dexes = new Dex[0];
        this.rootRelative = false;
        this.locators = false;
        this.superpackFiles = 0;
        this.superpackExtension = AnonymousClass0N9.NONE;
        this.id = DexStoreUtils.MAIN_DEX_STORE_ID;
        this.requires = new String[0];
        this.isArtMainStore = true;
        this.isExoPackage = z;
    }
}
