package com.facebook.common.dextricks;

import X.AnonymousClass001;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import java.io.Closeable;
import java.io.IOException;
import java.util.Iterator;

public abstract class InputDexIterator implements Iterator, Closeable {
    public int mDexPos = 0;
    public final DexManifest.Dex[] mDexes;
    public LightweightQuickPerformanceLogger mQplCollector;

    public abstract InputDex nextImpl(DexManifest.Dex dex);

    public final int getLength() {
        return this.mDexes.length;
    }

    public final boolean hasNext() {
        if (this.mDexPos < this.mDexes.length) {
            return true;
        }
        return false;
    }

    public final InputDex next() {
        try {
            DexManifest.Dex[] dexArr = this.mDexes;
            int i = this.mDexPos;
            this.mDexPos = i + 1;
            return nextImpl(dexArr[i]);
        } catch (IOException e) {
            throw AnonymousClass001.A0X(e);
        }
    }

    public InputDexIterator(DexManifest dexManifest, LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger) {
        this.mDexes = dexManifest.dexes;
        this.mQplCollector = lightweightQuickPerformanceLogger;
    }

    public void close() {
    }

    public final int getIdx() {
        return this.mDexPos;
    }

    public final void remove() {
        throw AnonymousClass001.A0q();
    }
}
