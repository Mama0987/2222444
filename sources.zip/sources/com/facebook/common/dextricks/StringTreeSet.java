package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import android.os.Build;

public class StringTreeSet {
    public static final int BITS_PER_PAYLOAD_UNIT = 6;
    public static final int CHILDREN_SIZE = 4;
    public static final int FLAG_NONTERMINAL = 16;
    public static final int FLAG_NO_PAYLOAD = 8;
    public static final int FLAG_PAYLOAD_UNIT = 64;
    public static final boolean IS_OS_VERSION_CHAOTIC;
    public static final int OFFSET_BASE_ENCODING = 127;
    public static final int PAYLOAD_MASK = 63;
    public static final int PAYLOAD_UNITS_MASK = 7;
    public static final int SINGLE_SYMBOL_MIN_VALUE = 32;
    public static final String TAG = "StringTreeSet";
    public static volatile Logger sLogger;

    public interface Logger {
        void onStringTreeLookup(String str);
    }

    public static boolean search(String str, String str2) {
        return searchMapAtPos(str, str2, 0, 1) != 1;
    }

    public static int searchMap(String str, String str2, int i) {
        return searchMapAtPos(str, str2, 0, i);
    }

    public static int searchMapAtPos(String str, String str2, int i, int i2) {
        int i3 = 0;
        int i4 = i;
        int i5 = 0;
        while (true) {
            int i6 = 3;
            if (i5 < str.length()) {
                char charAt = str.charAt(i5);
                int i7 = i4 + 1;
                char charAt2 = str2.charAt(i4);
                if (charAt2 < ' ') {
                    int i8 = i7 + (charAt2 & 7);
                    int i9 = i8 + 1;
                    int charAt3 = str2.charAt(i8) - 1;
                    if (charAt3 < 1) {
                        break;
                    }
                    int i10 = i9 + 1;
                    int i11 = charAt3 - 1;
                    if (str2.charAt(i9) != charAt) {
                        int binarySearch = binarySearch(charAt, str2, i10, i11);
                        if (binarySearch == -1) {
                            break;
                        }
                        int i12 = i10 + (binarySearch * 4);
                        int i13 = 0;
                        do {
                            i13 = ((i13 * 127) + str2.charAt(i12 + i6)) - 1;
                            i6--;
                        } while (i6 > 0);
                        i7 = i13 + i;
                    } else {
                        i7 = i10 + (i11 * 4);
                    }
                } else if (charAt2 != charAt) {
                    return i2;
                }
                i4 = i7;
                i5++;
            } else {
                int i14 = i4 + 1;
                char charAt4 = str2.charAt(i4);
                if (charAt4 < ' ' && (charAt4 & 16) != 16) {
                    if ((charAt4 & 8) == 8) {
                        return 0;
                    }
                    char c = charAt4 & 7;
                    i2 = 0;
                    while (i3 < c) {
                        int i15 = i14 + 1;
                        char charAt5 = str2.charAt(i14);
                        if ((charAt5 & '@') == '@') {
                            char c2 = charAt5 & '?';
                            if (i3 == 5) {
                                if (c2 > 3) {
                                    throw new ArithmeticException("overflow");
                                }
                            } else if (i3 == 6 && c2 != 0) {
                                throw new ArithmeticException("overflow");
                            }
                            i2 |= c2 << (i3 * 6);
                            i3++;
                            i14 = i15;
                        } else {
                            throw AnonymousClass001.A0P(AnonymousClass0WY.A0d("Bad data at ", i15 - 1));
                        }
                    }
                }
            }
        }
        return i2;
    }

    static {
        boolean z = false;
        if (Build.VERSION.SDK_INT <= 30) {
            z = true;
        }
        IS_OS_VERSION_CHAOTIC = z;
    }

    public static int binarySearch(char c, String str, int i, int i2) {
        int i3 = i2 - 1;
        int i4 = 0;
        while (i4 <= i3) {
            int i5 = (i4 + i3) >> 1;
            char charAt = str.charAt((i5 * 4) + i);
            if (charAt == c) {
                return i5;
            }
            if (charAt > c) {
                i3 = i5 - 1;
            } else {
                i4 = i5 + 1;
            }
        }
        return -1;
    }

    public static int searchMapStringify(Object obj, String str, int i) {
        String obj2;
        String str2;
        int searchMapAtPos;
        Logger logger = sLogger;
        if (obj == null) {
            if (logger != null) {
                logger.onStringTreeLookup((String) null);
            }
            return i;
        } else if (IS_OS_VERSION_CHAOTIC) {
            synchronized (StringTreeSet.class) {
                if (obj instanceof Class) {
                    str2 = ((Class) obj).getName();
                } else {
                    str2 = obj.toString();
                }
                if (logger != null) {
                    logger.onStringTreeLookup(str2);
                }
                searchMapAtPos = searchMapAtPos(str2, str, 0, i);
            }
            return searchMapAtPos;
        } else {
            if (obj instanceof Class) {
                obj2 = ((Class) obj).getName();
            } else {
                obj2 = obj.toString();
            }
            if (logger != null) {
                logger.onStringTreeLookup(obj2);
            }
            return searchMapAtPos(obj2, str, 0, i);
        }
    }

    public static int decodeBase127Int(String str, int i) {
        return (str.charAt(i) - 1) + ((str.charAt(i + 1) - 1) * 127) + ((str.charAt(i + 2) - 1) * 127 * 127);
    }

    public static Logger getLogger() {
        return sLogger;
    }

    public static String searchStringToStringMap(String str, String str2, String str3) {
        int length = str2.length();
        if (length >= 6) {
            int decodeBase127Int = decodeBase127Int(str2, 0);
            if (decodeBase127Int >= 6) {
                int decodeBase127Int2 = decodeBase127Int(str2, 3);
                if (decodeBase127Int2 >= 6) {
                    int searchMapAtPos = searchMapAtPos(str, str2, decodeBase127Int, Integer.MAX_VALUE);
                    if (searchMapAtPos == Integer.MAX_VALUE) {
                        return str3;
                    }
                    if (searchMapAtPos >= 0) {
                        int i = searchMapAtPos + decodeBase127Int2;
                        int decodeBase127Int3 = decodeBase127Int(str2, i);
                        int i2 = i + 3;
                        return str2.substring(i2, decodeBase127Int3 + i2);
                    }
                    throw AnonymousClass001.A0P(String.valueOf(searchMapAtPos));
                }
                throw AnonymousClass001.A0N();
            }
            throw AnonymousClass001.A0N();
        }
        throw AnonymousClass001.A0L(String.valueOf(length));
    }

    public static void setLogger(Logger logger) {
        sLogger = logger;
    }
}
