package com.facebook.common.dextricks.halfnosis;

public class Halfnosis {
    public static final String LONGTAIL_MODULE_NAME = "longtail";

    public static String getLongtailModuleName() {
        return LONGTAIL_MODULE_NAME;
    }
}
