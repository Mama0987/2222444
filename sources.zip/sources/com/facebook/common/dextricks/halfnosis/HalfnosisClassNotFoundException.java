package com.facebook.common.dextricks.halfnosis;

public class HalfnosisClassNotFoundException extends ClassNotFoundException {
    public HalfnosisClassNotFoundException(String str) {
        super(str);
    }
}
