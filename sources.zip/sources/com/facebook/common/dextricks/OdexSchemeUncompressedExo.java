package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import com.facebook.common.dextricks.DexManifest;
import com.facebook.common.dextricks.OdexScheme;
import java.io.File;

public class OdexSchemeUncompressedExo extends OdexScheme {
    public final DexManifest dexManifest;
    public final ResProvider resProvider;

    public OdexSchemeUncompressedExo(DexManifest dexManifest2, ResProvider resProvider2) {
        super(0, new String[0]);
        this.dexManifest = dexManifest2;
        this.resProvider = resProvider2;
    }

    public void configureClassLoader(File file, ClassLoaderConfiguration classLoaderConfiguration) {
        DexManifest.Dex[] dexArr = this.dexManifest.dexes;
        int length = dexArr.length;
        int i = 0;
        while (i < length) {
            DexManifest.Dex dex = dexArr[i];
            String filePath = this.resProvider.getFilePath(dex.assetName);
            if (filePath != null) {
                classLoaderConfiguration.addDex(AnonymousClass001.A0E(filePath));
                i++;
            } else {
                throw AnonymousClass001.A0G(AnonymousClass0WY.A0i("Could not find dex file ", dex.assetName));
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.facebook.common.dextricks.OdexScheme$Compiler] */
    public OdexScheme.Compiler makeCompiler(DexStore dexStore, int i) {
        return new Object();
    }

    public String getSchemeName() {
        return "OdexSchemeUncompressedExo";
    }
}
