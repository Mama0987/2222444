package com.facebook.common.dextricks.coverage.logger;

import X.C10960hP;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ClassCoverageLogger {
    public static final Queue A00 = new ConcurrentLinkedQueue();
    public static volatile String A01 = C10960hP.A02("fb.throw_on_class_load");
    public static volatile boolean A02 = "true".equals(C10960hP.A02("fb.enable_class_coverage"));
}
