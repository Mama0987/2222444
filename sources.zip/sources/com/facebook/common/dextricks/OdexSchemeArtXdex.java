package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.C13060mv;
import com.facebook.common.dextricks.DexManifest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public final class OdexSchemeArtXdex extends OdexSchemeArtTurbo {
    public static final long MIN_DISK_FREE_FOR_MIXED_MODE = 419430400;
    public static final String REGENERATE_SOFT_ERROR_CATEGORY = "OdexSchemeArtXdex_REGEN";
    public static final long STATE_DEX2OAT_CLASSPATH_SET = 2048;
    public static final long STATE_DEX2OAT_QUICKENING_NEEDED = 64;
    public static final long STATE_DEX2OAT_QUICK_ATTEMPTED = 512;
    public static final long STATE_DO_PERIODIC_PGO_COMP_ATTEMPTED = 32768;
    public static final long STATE_DO_PERIODIC_PGO_COMP_FINISHED = 65536;
    public static final long STATE_DO_PERIODIC_PGO_COMP_NEEDED = 16384;
    public static final long STATE_MASK = 20720;
    public static final long STATE_MIXED_ATTEMPTED = 1024;
    public static final long STATE_MIXED_NEEDED = 128;
    public static final long STATE_OATMEAL_QUICKENING_NEEDED = 32;
    public static final long STATE_OATMEAL_QUICK_ATTEMPTED = 256;
    public static final long STATE_OPT_COMPLETED = 16;
    public static final long STATE_PGO_ATTEMPTED = 8192;
    public static final long STATE_PGO_NEEDED = 4096;
    public final DexManifest.Dex[] mDexes;
    public final boolean mIsLoadable;

    public static boolean anyOptimizationDone(long j) {
        if ((j & STATE_MASK) != 0) {
            return true;
        }
        return false;
    }

    public static File getCannotTruncateDexFlagFile(File file) {
        return AnonymousClass0WY.A01(DexStoreUtils.IGNORE_DIRTY_CHECK_PREFIX, "cannot_trunc_dex.flg", file);
    }

    public static boolean getCannotTruncateDexesFlag(File file) {
        return AnonymousClass0WY.A01(DexStoreUtils.IGNORE_DIRTY_CHECK_PREFIX, "cannot_trunc_dex.flg", file).exists();
    }

    private boolean needsTruncation(File file, int i) {
        if (i < 0 || dexAppearsTruncated(file, i)) {
            return false;
        }
        return true;
    }

    public static String oatNameFromDexName(String str) {
        if (str.contains(".")) {
            str = AnonymousClass001.A0f(str, str.lastIndexOf(46));
        }
        return AnonymousClass0WY.A0i(str, DexManifest.ODEX_EXT);
    }

    public static boolean optimizationCompleted(long j) {
        if ((j & 16) != 0) {
            return true;
        }
        return false;
    }

    private void truncateWithBackup(File file, File file2, int i) {
        FileInputStream A0F;
        if (i >= 0) {
            Fs.renameOrThrow(file, file2);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            try {
                A0F = AnonymousClass001.A0F(file2);
                C13060mv.A04(A0F, fileOutputStream, i);
                A0F.close();
                fileOutputStream.close();
                return;
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                    throw th;
                } catch (Throwable th2) {
                    AnonymousClass0ZM.A00(th, th2);
                    throw th;
                }
            }
        } else {
            return;
        }
        throw th;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x00d0 A[Catch:{ IOException -> 0x00f7 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void configureClassLoader(java.io.File r23, com.facebook.common.dextricks.ClassLoaderConfiguration r24) {
        /*
            r22 = this;
            r14 = r22
            boolean r0 = r14.mIsLoadable
            r4 = 0
            r13 = r23
            r12 = r24
            if (r0 != 0) goto L_0x000f
            super.configureClassLoader(r13, r12)
        L_0x000e:
            return
        L_0x000f:
            java.lang.String[] r0 = r14.expectedFiles
            java.util.List r1 = java.util.Arrays.asList(r0)
            java.lang.String r0 = "oat"
            boolean r2 = r1.contains(r0)
            java.lang.String r1 = "expect oat dir"
            java.lang.Object[] r0 = new java.lang.Object[r4]
            com.facebook.common.dextricks.Mlog.assertThat(r2, r1, r0)
            com.facebook.common.dextricks.DexStore r8 = com.facebook.common.dextricks.DexStore.findOpened((java.io.File) r13)
            long r2 = r8.reportStatus()
            com.facebook.common.dextricks.DexStore$Config r0 = r8.readConfig()
            int r11 = r0.artTruncatedDexSize
            java.lang.String r10 = com.facebook.common.dextricks.OdexSchemeArtTurbo.getOreoOdexOutputDirectory(r13, r4)
            java.lang.String[] r0 = r14.expectedFiles
            java.util.Arrays.toString(r0)
            r9 = 0
        L_0x003a:
            java.lang.String[] r4 = r14.expectedFiles
            int r0 = r4.length
            java.lang.String r7 = "OdexSchemeArtXdex_REGEN"
            if (r9 >= r0) goto L_0x00ed
            r1 = r4[r9]
            java.lang.String r0 = ".dex"
            boolean r0 = r1.endsWith(r0)
            if (r0 == 0) goto L_0x00e9
            r0 = r4[r9]
            java.lang.String r0 = oatNameFromDexName(r0)
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r10, r0)
            java.io.File r6 = X.AnonymousClass001.A0E(r0)
            r6.lastModified()
            r6.length()
            java.lang.String[] r0 = r14.expectedFiles
            r0 = r0[r9]
            java.io.File r5 = X.AnonymousClass001.A0D(r13, r0)
            java.lang.String[] r0 = r14.expectedFiles
            r1 = r0[r9]
            java.lang.String r0 = ".backup"
            java.io.File r15 = X.AnonymousClass0WY.A01(r1, r0, r13)
            java.lang.String r1 = "odexSchemeArtXDex.configureClassLoader() status="
            long r16 = r8.reportStatus()
            java.lang.String r0 = java.lang.Long.toHexString(r16)
            java.lang.String r4 = X.AnonymousClass0WY.A0i(r1, r0)
            boolean r0 = r5.exists()
            if (r0 != 0) goto L_0x009b
            java.lang.StringBuilder r1 = X.AnonymousClass001.A0o(r4)
            java.lang.String r0 = " expected dex file "
            r1.append(r0)
            r1.append(r5)
            java.lang.String r0 = " not found"
            r1.append(r0)
        L_0x0096:
            java.lang.String r4 = r1.toString()
            goto L_0x00c0
        L_0x009b:
            long r18 = r5.length()
            r16 = 0
            int r0 = (r18 > r16 ? 1 : (r18 == r16 ? 0 : -1))
            if (r0 != 0) goto L_0x00c0
            boolean r0 = r6.exists()
            if (r0 == 0) goto L_0x00c0
            java.lang.StringBuilder r1 = X.AnonymousClass001.A0o(r4)
            java.lang.String r0 = " attempting to load 0 length dex file "
            r1.append(r0)
            r1.append(r5)
            java.lang.String r0 = " when we seemed to have already compiled to "
            r1.append(r0)
            r1.append(r6)
            goto L_0x0096
        L_0x00c0:
            r19 = r2
            r21 = r11
            r16 = r14
            r17 = r13
            r18 = r5
            boolean r0 = r16.shouldTruncateDexesNow(r17, r18, r19, r21)     // Catch:{ IOException -> 0x00f7 }
            if (r0 == 0) goto L_0x00e6
            r14.truncateWithBackup(r5, r15, r11)     // Catch:{ IOException -> 0x00f7 }
            r12.addDex((java.io.File) r5, (java.io.File) r6)     // Catch:{ IOException -> 0x00da }
            com.facebook.common.dextricks.Fs.deleteRecursive(r15)     // Catch:{ IOException -> 0x00da }
            goto L_0x00e9
        L_0x00da:
            r1 = move-exception
            com.facebook.common.dextricks.Fs.renameOrThrow(r15, r5)     // Catch:{ IOException -> 0x00f7 }
            java.lang.String r0 = "failed to load truncated dex"
            X.AnonymousClass0TR.A01(r7, r0, r1)     // Catch:{ IOException -> 0x00f7 }
            r8.forceRegenerateOnNextLoad()     // Catch:{ IOException -> 0x00f7 }
        L_0x00e6:
            r12.addDex((java.io.File) r5, (java.io.File) r6)     // Catch:{ IOException -> 0x00f7 }
        L_0x00e9:
            int r9 = r9 + 1
            goto L_0x003a
        L_0x00ed:
            boolean r0 = optimizationCompleted(r2)
            if (r0 == 0) goto L_0x000e
            r8.writeStatusLocked(r2)
            return
        L_0x00f7:
            r2 = move-exception
            java.lang.StringBuilder r1 = X.AnonymousClass001.A0m()
            java.lang.String r0 = "IOException adding dex "
            r1.append(r0)
            r1.append(r5)
            java.lang.String r0 = " will rethrow and attempt recovery"
            java.lang.String r0 = X.AnonymousClass001.A0g(r0, r1)
            X.AnonymousClass0TR.A01(r7, r0, r2)
            r8.forceRegenerateOnNextLoad()
            java.io.IOException r1 = new java.io.IOException
            r1.<init>(r4, r2)
            com.facebook.common.dextricks.DexStore$RecoverableDexException r0 = new com.facebook.common.dextricks.DexStore$RecoverableDexException
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.OdexSchemeArtXdex.configureClassLoader(java.io.File, com.facebook.common.dextricks.ClassLoaderConfiguration):void");
    }

    public int loadInformationalStatus(File file, long j) {
        ByteArrayOutputStream byteArrayOutputStream;
        String[] makeExpectedFileListFrom = OdexSchemeArtTurbo.makeExpectedFileListFrom(makeExpectedFileInfoList(this.mDexes, 0));
        int i = 0;
        String oreoOdexOutputDirectory = OdexSchemeArtTurbo.getOreoOdexOutputDirectory(file, false);
        int i2 = 0;
        while (true) {
            if (i2 >= makeExpectedFileListFrom.length) {
                break;
            }
            File A0E = AnonymousClass001.A0E(AnonymousClass0WY.A0i(oreoOdexOutputDirectory, oatNameFromDexName(makeExpectedFileListFrom[i2])));
            if (!A0E.exists()) {
                A0E.getAbsolutePath();
                break;
            }
            A0E.getAbsolutePath();
            try {
                FileInputStream A0F = AnonymousClass001.A0F(A0E);
                try {
                    byteArrayOutputStream = new ByteArrayOutputStream(1024);
                    if (Fs.discardFromInputStream(A0F, STATE_PGO_NEEDED) != STATE_PGO_NEEDED) {
                        AnonymousClass001.A1I(AnonymousClass0WY.A0i("loadInformationalStatus couldn't read more than 4k of the beginning of ", A0E.getAbsolutePath()));
                    } else {
                        C13060mv.A05(A0F, byteArrayOutputStream, 4096);
                        byteArrayOutputStream.flush();
                    }
                    byteArrayOutputStream.close();
                    A0F.close();
                } catch (Throwable th) {
                    A0F.close();
                    throw th;
                }
            } catch (IOException unused) {
                AnonymousClass001.A1I(AnonymousClass0WY.A0i("loadInformationalStatus couldn't open ", A0E.getAbsolutePath()));
            } catch (Throwable th2) {
                AnonymousClass0ZM.A00(th, th2);
                break;
            }
            i2++;
        }
        if ((j & 128) == 0 && (j & STATE_MIXED_ATTEMPTED) != 0) {
            i = 1024;
        }
        if ((j & STATE_PGO_NEEDED) == 0 && (j & STATE_PGO_ATTEMPTED) != 0) {
            i |= Constants.LOAD_RESULT_PGO;
        }
        if ((j & STATE_MIXED_ATTEMPTED) != 0) {
            i |= Constants.LOAD_RESULT_MIXED_MODE_ATTEMPTED;
        }
        if ((j & STATE_PGO_ATTEMPTED) != 0) {
            i |= Constants.LOAD_RESULT_PGO_ATTEMPTED;
        }
        if ((j & STATE_DEX2OAT_CLASSPATH_SET) != 0) {
            i |= Constants.LOAD_RESULT_DEX2OAT_CLASSPATH_SET;
        }
        if ((j & STATE_DO_PERIODIC_PGO_COMP_NEEDED) == 0) {
            return i;
        }
        if (!((j & STATE_DO_PERIODIC_PGO_COMP_FINISHED) == 0 || (j & STATE_DO_PERIODIC_PGO_COMP_ATTEMPTED) == 0)) {
            i = 131072 | i;
        }
        if ((j & STATE_DO_PERIODIC_PGO_COMP_ATTEMPTED) != 0) {
            return i | Constants.LOAD_RESULT_DEX2OAT_TRY_PERIODIC_PGO_COMP_ATTEMPTED;
        }
        return i;
        throw th;
    }

    public OdexSchemeArtXdex(DexManifest.Dex[] dexArr, long j) {
        super(1, OdexSchemeArtTurbo.makeExpectedFileListFrom(makeExpectedFileInfoList(dexArr, j)));
        this.mDexes = dexArr;
        this.mIsLoadable = AnonymousClass001.A1R(((j & STATE_MASK) > 0 ? 1 : ((j & STATE_MASK) == 0 ? 0 : -1)));
    }

    public static boolean dexAppearsTruncated(File file, int i) {
        if (file.length() <= ((long) i)) {
            return true;
        }
        return false;
    }

    public static int getOdexFlags() {
        return 1;
    }

    private int getTruncatedSize(DexStore dexStore) {
        return dexStore.readConfig().artTruncatedDexSize;
    }

    public static List makeExpectedFileInfoList(DexManifest.Dex[] dexArr, long j) {
        boolean anyOptimizationDone = anyOptimizationDone(j);
        List makeExpectedFileInfoList = OdexSchemeArtTurbo.makeExpectedFileInfoList(dexArr, (String) null);
        if (anyOptimizationDone) {
            makeExpectedFileInfoList.add(new ExpectedFileInfo(OdexSchemeArtTurbo.OREO_ODEX_DIR));
        }
        return makeExpectedFileInfoList;
    }

    public static String[] makeExpectedFileList(DexManifest.Dex[] dexArr, long j) {
        return OdexSchemeArtTurbo.makeExpectedFileListFrom(makeExpectedFileInfoList(dexArr, j));
    }

    private boolean shouldTruncateDexesNow(File file, File file2, long j, int i) {
        if (!needsTruncation(file2, i) || !optimizationCompleted(j)) {
            return false;
        }
        return !getCannotTruncateDexesFlag(file);
    }

    public String getSchemeName() {
        return "OdexSchemeArtXdex";
    }

    public static boolean isOatFileStillValid(File file, long j, long j2) {
        return true;
    }
}
