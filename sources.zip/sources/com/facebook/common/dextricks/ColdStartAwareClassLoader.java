package com.facebook.common.dextricks;

public interface ColdStartAwareClassLoader {
    void onColdstartDone();
}
