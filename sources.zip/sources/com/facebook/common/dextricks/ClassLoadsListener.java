package com.facebook.common.dextricks;

public interface ClassLoadsListener {
    void onClassLoadBegin(String str);

    void onClassLoaded(Class cls);

    void onClassNotFound(String str);
}
