package com.facebook.common.dextricks;

import X.AnonymousClass001;
import X.C06300Vs;
import java.io.Closeable;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public final class ReentrantLockFile implements Closeable {
    public static final int ACQUIRE_SHARED = 1;
    public static final boolean LOCK_DEBUG = false;
    public static final ReentrantLockFile sListHead = new ReentrantLockFile();
    public final File lockFileName;
    public FileChannel mChannel;
    public int mLockFlags;
    public final Lock mLockHandle;
    public boolean mLockInProgress;
    public Thread mLockOwner;
    public int mLockShareCount;
    public ReentrantLockFile mNext;
    public ReentrantLockFile mPrev;
    public int mReferenceCount;
    public FileLock mTheLock;

    public final class Lock implements Closeable {
        public Lock() {
        }

        public void close() {
            ReentrantLockFile.this.release();
        }

        public ReentrantLockFile getReentrantLockFile() {
            return ReentrantLockFile.this;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0021, code lost:
        if (r1 == false) goto L_0x0023;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0029, code lost:
        if (r10.mLockOwner == java.lang.Thread.currentThread()) goto L_0x002b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0048, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized com.facebook.common.dextricks.ReentrantLockFile.Lock tryAcquire(int r11) {
        /*
            r10 = this;
            monitor-enter(r10)
            java.nio.channels.FileChannel r4 = r10.mChannel     // Catch:{ all -> 0x006f }
            if (r4 == 0) goto L_0x0068
            r0 = r11 & 1
            r1 = 0
            boolean r9 = X.AnonymousClass001.A1R(r0)
            boolean r0 = r10.mLockInProgress     // Catch:{ all -> 0x006f }
            r3 = 0
            if (r0 != 0) goto L_0x0066
            int r2 = r10.mLockShareCount     // Catch:{ all -> 0x006f }
            if (r2 <= 0) goto L_0x0032
            int r0 = r10.mLockFlags     // Catch:{ all -> 0x006f }
            r0 = r0 & 1
            if (r0 == 0) goto L_0x001c
            r1 = 1
        L_0x001c:
            if (r9 == 0) goto L_0x0021
            if (r1 != 0) goto L_0x002b
            goto L_0x0023
        L_0x0021:
            if (r1 != 0) goto L_0x0066
        L_0x0023:
            java.lang.Thread r1 = r10.mLockOwner     // Catch:{ all -> 0x006f }
            java.lang.Thread r0 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x006f }
            if (r1 != r0) goto L_0x0066
        L_0x002b:
            int r0 = r2 + 1
            r10.mLockShareCount = r0     // Catch:{ all -> 0x006f }
            com.facebook.common.dextricks.ReentrantLockFile$Lock r0 = r10.mLockHandle     // Catch:{ all -> 0x006f }
            goto L_0x0047
        L_0x0032:
            r5 = 0
            r7 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            java.nio.channels.FileLock r0 = r4.tryLock(r5, r7, r9)     // Catch:{ IOException -> 0x0049 }
            if (r0 == 0) goto L_0x0066
            r10.addrefLocked()     // Catch:{ all -> 0x006f }
            r10.claimLock(r11, r0)     // Catch:{ all -> 0x006f }
            com.facebook.common.dextricks.ReentrantLockFile$Lock r0 = r10.mLockHandle     // Catch:{ all -> 0x006f }
        L_0x0047:
            monitor-exit(r10)
            return r0
        L_0x0049:
            r2 = move-exception
            java.lang.String r1 = r2.getMessage()     // Catch:{ all -> 0x006f }
            if (r1 == 0) goto L_0x0061
            java.lang.String r0 = ": EAGAIN ("
            boolean r0 = r1.contains(r0)     // Catch:{ all -> 0x006f }
            if (r0 != 0) goto L_0x0066
            java.lang.String r0 = ": errno 11 ("
            boolean r0 = r1.contains(r0)     // Catch:{ all -> 0x006f }
            if (r0 == 0) goto L_0x0061
            goto L_0x0066
        L_0x0061:
            java.lang.RuntimeException r0 = X.AnonymousClass001.A0X(r2)     // Catch:{ all -> 0x006f }
            goto L_0x006e
        L_0x0066:
            monitor-exit(r10)
            return r3
        L_0x0068:
            java.lang.String r0 = "cannot acquire closed lock"
            java.lang.IllegalStateException r0 = X.AnonymousClass001.A0P(r0)     // Catch:{ all -> 0x006f }
        L_0x006e:
            throw r0     // Catch:{ all -> 0x006f }
        L_0x006f:
            r0 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x006f }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ReentrantLockFile.tryAcquire(int):com.facebook.common.dextricks.ReentrantLockFile$Lock");
    }

    private void addrefLocked() {
        if (this.mChannel != null) {
            this.mReferenceCount++;
            return;
        }
        throw AnonymousClass001.A0P("cannot add reference to dead lock");
    }

    private void claimLock(int i, FileLock fileLock) {
        if ((i & 1) == 0) {
            this.mLockOwner = Thread.currentThread();
        }
        this.mTheLock = fileLock;
        this.mLockFlags = i;
        this.mLockShareCount = 1;
    }

    public static synchronized ReentrantLockFile open(File file) {
        ReentrantLockFile reentrantLockFile;
        FileChannel fileChannel;
        synchronized (ReentrantLockFile.class) {
            File absoluteFile = file.getAbsoluteFile();
            reentrantLockFile = sListHead;
            ReentrantLockFile reentrantLockFile2 = reentrantLockFile;
            do {
                reentrantLockFile = reentrantLockFile.mNext;
                if (reentrantLockFile == reentrantLockFile2) {
                    RandomAccessFile randomAccessFile = null;
                    try {
                        RandomAccessFile A0I = AnonymousClass001.A0I(absoluteFile);
                        try {
                            fileChannel = A0I.getChannel();
                        } catch (Throwable th) {
                            th = th;
                            fileChannel = null;
                            randomAccessFile = A0I;
                            Fs.safeClose((Closeable) randomAccessFile);
                            Fs.safeClose((Closeable) fileChannel);
                            throw th;
                        }
                        try {
                            reentrantLockFile = new ReentrantLockFile(absoluteFile, fileChannel);
                            reentrantLockFile.mPrev = reentrantLockFile2;
                            reentrantLockFile.mNext = reentrantLockFile2.mNext;
                            reentrantLockFile2.mNext = reentrantLockFile;
                            reentrantLockFile.mNext.mPrev = reentrantLockFile;
                            break;
                        } catch (Throwable th2) {
                            th = th2;
                            Fs.safeClose((Closeable) randomAccessFile);
                            Fs.safeClose((Closeable) fileChannel);
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        fileChannel = null;
                        Fs.safeClose((Closeable) randomAccessFile);
                        Fs.safeClose((Closeable) fileChannel);
                        throw th;
                    }
                }
            } while (!absoluteFile.equals(reentrantLockFile.lockFileName));
            synchronized (reentrantLockFile) {
                try {
                    reentrantLockFile.addrefLocked();
                } catch (Throwable th4) {
                    while (true) {
                        th = th4;
                        break;
                    }
                }
            }
        }
        return reentrantLockFile;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002a, code lost:
        if (r2 == false) goto L_0x002f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002c, code lost:
        close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x002f, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        r0 = r8.mChannel.lock(0, Long.MAX_VALUE, r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0046, code lost:
        if (r0 != null) goto L_0x0056;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
        monitor-enter(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
        r8.mLockInProgress = false;
        notifyAll();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x004e, code lost:
        monitor-exit(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0050, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
        close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0056, code lost:
        monitor-enter(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:?, code lost:
        claimLock(r9, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
        r8.mLockInProgress = false;
        notifyAll();
        r0 = r8.mLockHandle;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0061, code lost:
        monitor-exit(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0062, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0063, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0064, code lost:
        r1 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:?, code lost:
        monitor-exit(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0067, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x0069, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x006e, code lost:
        throw X.AnonymousClass001.A0X(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x006f, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:?, code lost:
        monitor-enter(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:?, code lost:
        r8.mLockInProgress = false;
        notifyAll();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x0078, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:?, code lost:
        close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x007e, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:?, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0087, code lost:
        if (r1 == false) goto L_0x008e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x008a, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x008b, code lost:
        close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x008e, code lost:
        throw r0;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [B:29:0x0048, B:61:0x0071] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.facebook.common.dextricks.ReentrantLockFile.Lock acquireInterruptubly(int r9) {
        /*
            r8 = this;
            r0 = r9 & 1
            r1 = 0
            r3 = 1
            boolean r7 = X.AnonymousClass001.A1R(r0)
            r8.assertMonitorLockNotHeld()
            monitor-enter(r8)     // Catch:{ all -> 0x0086 }
            r2 = 0
        L_0x000d:
            com.facebook.common.dextricks.ReentrantLockFile$Lock r0 = r8.tryAcquire(r9)     // Catch:{ all -> 0x007f }
            if (r0 == 0) goto L_0x0017
            com.facebook.common.dextricks.ReentrantLockFile$Lock r0 = r8.mLockHandle     // Catch:{ all -> 0x007f }
            monitor-exit(r8)     // Catch:{ all -> 0x007f }
            goto L_0x002a
        L_0x0017:
            boolean r0 = r8.mLockInProgress     // Catch:{ all -> 0x007f }
            if (r0 != 0) goto L_0x0020
            int r0 = r8.mLockShareCount     // Catch:{ all -> 0x007f }
            if (r0 != 0) goto L_0x0020
            goto L_0x0030
        L_0x0020:
            if (r2 != 0) goto L_0x0026
            r8.addrefLocked()     // Catch:{ all -> 0x007f }
            r2 = 1
        L_0x0026:
            r8.wait()     // Catch:{ all -> 0x007f }
            goto L_0x000d
        L_0x002a:
            if (r2 == 0) goto L_0x002f
            r8.close()
        L_0x002f:
            return r0
        L_0x0030:
            if (r2 != 0) goto L_0x0036
            r8.addrefLocked()     // Catch:{ all -> 0x007f }
            r2 = 1
        L_0x0036:
            r8.mLockInProgress = r3     // Catch:{ all -> 0x007f }
            monitor-exit(r8)     // Catch:{ all -> 0x007f }
            java.nio.channels.FileChannel r2 = r8.mChannel     // Catch:{ IOException -> 0x0069 }
            r3 = 0
            r5 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            java.nio.channels.FileLock r0 = r2.lock(r3, r5, r7)     // Catch:{ IOException -> 0x0069 }
            if (r0 != 0) goto L_0x0056
            monitor-enter(r8)     // Catch:{ all -> 0x008a }
            r8.mLockInProgress = r1     // Catch:{ all -> 0x0050 }
            r8.notifyAll()     // Catch:{ all -> 0x0050 }
            monitor-exit(r8)     // Catch:{ all -> 0x0050 }
            goto L_0x0053
        L_0x0050:
            r0 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x0050 }
            goto L_0x007e
        L_0x0053:
            r8.close()     // Catch:{ all -> 0x008a }
        L_0x0056:
            monitor-enter(r8)     // Catch:{ all -> 0x008a }
            r8.claimLock(r9, r0)     // Catch:{ all -> 0x0063 }
            r8.mLockInProgress = r1     // Catch:{ all -> 0x0067 }
            r8.notifyAll()     // Catch:{ all -> 0x0067 }
            com.facebook.common.dextricks.ReentrantLockFile$Lock r0 = r8.mLockHandle     // Catch:{ all -> 0x0067 }
            monitor-exit(r8)     // Catch:{ all -> 0x0067 }
            return r0
        L_0x0063:
            r0 = move-exception
            r1 = 1
        L_0x0065:
            monitor-exit(r8)     // Catch:{ all -> 0x0067 }
            goto L_0x0085
        L_0x0067:
            r0 = move-exception
            goto L_0x0065
        L_0x0069:
            r0 = move-exception
            java.lang.RuntimeException r0 = X.AnonymousClass001.A0X(r0)     // Catch:{ all -> 0x006f }
            throw r0     // Catch:{ all -> 0x006f }
        L_0x006f:
            r0 = move-exception
            monitor-enter(r8)     // Catch:{ all -> 0x008a }
            r8.mLockInProgress = r1     // Catch:{ all -> 0x0078 }
            r8.notifyAll()     // Catch:{ all -> 0x0078 }
            monitor-exit(r8)     // Catch:{ all -> 0x0078 }
            goto L_0x007b
        L_0x0078:
            r0 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x0078 }
            goto L_0x007e
        L_0x007b:
            r8.close()     // Catch:{ all -> 0x008a }
        L_0x007e:
            throw r0     // Catch:{ all -> 0x008a }
        L_0x007f:
            r0 = move-exception
            r1 = r2
        L_0x0081:
            monitor-exit(r8)     // Catch:{ all -> 0x0083 }
            goto L_0x0085
        L_0x0083:
            r0 = move-exception
            goto L_0x0081
        L_0x0085:
            throw r0     // Catch:{ all -> 0x0086 }
        L_0x0086:
            r0 = move-exception
            if (r1 == 0) goto L_0x008e
            goto L_0x008b
        L_0x008a:
            r0 = move-exception
        L_0x008b:
            r8.close()
        L_0x008e:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ReentrantLockFile.acquireInterruptubly(int):com.facebook.common.dextricks.ReentrantLockFile$Lock");
    }

    public void donateLock(Thread thread) {
        boolean z = false;
        if (this.mLockOwner == Thread.currentThread()) {
            z = true;
        }
        Mlog.assertThat(z, "caller must own lock exclusively", new Object[0]);
        this.mLockOwner = thread;
    }

    public void stealLock() {
        Mlog.assertThat(AnonymousClass001.A1U(this.mLockOwner), "cannot steal unowned lock", new Object[0]);
        this.mLockOwner = Thread.currentThread();
    }

    public ReentrantLockFile(File file, FileChannel fileChannel) {
        this.lockFileName = file;
        this.mChannel = fileChannel;
        this.mReferenceCount = 1;
        this.mLockHandle = new Lock();
    }

    private void assertMonitorLockNotHeld() {
        boolean z = !Thread.holdsLock(this);
        Object[] objArr = new Object[0];
        if (!z) {
            Mlog.assertThat(z, "lock order violation", objArr);
            throw C06300Vs.createAndThrow();
        }
    }

    public Lock acquire(int i) {
        try {
            return acquireInterruptubly(i);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0013, code lost:
        r2 = com.facebook.common.dextricks.ReentrantLockFile.class;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0015, code lost:
        monitor-enter(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:?, code lost:
        monitor-enter(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        r0 = r3.mReferenceCount - 1;
        r3.mReferenceCount = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x001c, code lost:
        if (r0 != 0) goto L_0x0034;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x001e, code lost:
        r1 = r3.mPrev;
        r1.mNext = r3.mNext;
        r3.mNext.mPrev = r1;
        r3.mPrev = null;
        r3.mNext = null;
        com.facebook.common.dextricks.Fs.safeClose((java.io.Closeable) r3.mChannel);
        r3.mChannel = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0034, code lost:
        monitor-exit(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
        monitor-exit(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0036, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0011, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void close() {
        /*
            r3 = this;
            r3.assertMonitorLockNotHeld()
            monitor-enter(r3)
            java.nio.channels.FileChannel r0 = r3.mChannel     // Catch:{ all -> 0x003d }
            if (r0 == 0) goto L_0x0010
            int r0 = r3.mReferenceCount     // Catch:{ all -> 0x003d }
            r1 = 1
            if (r0 <= r1) goto L_0x0012
            int r0 = r0 - r1
            r3.mReferenceCount = r0     // Catch:{ all -> 0x003d }
        L_0x0010:
            monitor-exit(r3)     // Catch:{ all -> 0x003d }
            return
        L_0x0012:
            monitor-exit(r3)     // Catch:{ all -> 0x003d }
            java.lang.Class<com.facebook.common.dextricks.ReentrantLockFile> r2 = com.facebook.common.dextricks.ReentrantLockFile.class
            monitor-enter(r2)
            monitor-enter(r3)     // Catch:{ all -> 0x003a }
            int r0 = r3.mReferenceCount     // Catch:{ all -> 0x0037 }
            int r0 = r0 - r1
            r3.mReferenceCount = r0     // Catch:{ all -> 0x0037 }
            if (r0 != 0) goto L_0x0034
            com.facebook.common.dextricks.ReentrantLockFile r1 = r3.mPrev     // Catch:{ all -> 0x0037 }
            com.facebook.common.dextricks.ReentrantLockFile r0 = r3.mNext     // Catch:{ all -> 0x0037 }
            r1.mNext = r0     // Catch:{ all -> 0x0037 }
            com.facebook.common.dextricks.ReentrantLockFile r0 = r3.mNext     // Catch:{ all -> 0x0037 }
            r0.mPrev = r1     // Catch:{ all -> 0x0037 }
            r1 = 0
            r3.mPrev = r1     // Catch:{ all -> 0x0037 }
            r3.mNext = r1     // Catch:{ all -> 0x0037 }
            java.nio.channels.FileChannel r0 = r3.mChannel     // Catch:{ all -> 0x0037 }
            com.facebook.common.dextricks.Fs.safeClose((java.io.Closeable) r0)     // Catch:{ all -> 0x0037 }
            r3.mChannel = r1     // Catch:{ all -> 0x0037 }
        L_0x0034:
            monitor-exit(r3)     // Catch:{ all -> 0x0037 }
            monitor-exit(r2)     // Catch:{ all -> 0x003a }
            return
        L_0x0037:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0037 }
            throw r0     // Catch:{ all -> 0x003a }
        L_0x003a:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x003a }
            throw r0
        L_0x003d:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x003d }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ReentrantLockFile.close():void");
    }

    public Thread getExclusiveOwner() {
        return this.mLockOwner;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001f, code lost:
        if (r6.mLockOwner == java.lang.Thread.currentThread()) goto L_0x0021;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void release() {
        /*
            r6 = this;
            r6.assertMonitorLockNotHeld()
            monitor-enter(r6)
            int r5 = r6.mLockShareCount     // Catch:{ all -> 0x0054 }
            r4 = 1
            r3 = 0
            r2 = 0
            if (r5 <= 0) goto L_0x000c
            r2 = 1
        L_0x000c:
            java.lang.String r1 = "lock release balance"
            java.lang.Object[] r0 = new java.lang.Object[r3]     // Catch:{ all -> 0x0054 }
            if (r2 == 0) goto L_0x0046
            int r0 = r6.mLockFlags     // Catch:{ all -> 0x0054 }
            r0 = r0 & 1
            if (r0 != 0) goto L_0x0021
            java.lang.Thread r1 = r6.mLockOwner     // Catch:{ all -> 0x0054 }
            java.lang.Thread r0 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0054 }
            r2 = 0
            if (r1 != r0) goto L_0x0022
        L_0x0021:
            r2 = 1
        L_0x0022:
            java.lang.String r1 = "lock thread affinity"
            java.lang.Object[] r0 = new java.lang.Object[r3]     // Catch:{ all -> 0x0054 }
            if (r2 == 0) goto L_0x0046
            int r5 = r5 - r4
            r6.mLockShareCount = r5     // Catch:{ all -> 0x0054 }
            if (r5 != 0) goto L_0x0034
            java.nio.channels.FileLock r0 = r6.mTheLock     // Catch:{ IOException -> 0x004e }
            r0.release()     // Catch:{ IOException -> 0x004e }
            r0 = 0
            goto L_0x0036
        L_0x0034:
            r4 = 0
            goto L_0x003f
        L_0x0036:
            r6.mLockOwner = r0     // Catch:{ all -> 0x0054 }
            r6.mTheLock = r0     // Catch:{ all -> 0x0054 }
            r6.mLockFlags = r3     // Catch:{ all -> 0x0054 }
            r6.notifyAll()     // Catch:{ all -> 0x0054 }
        L_0x003f:
            monitor-exit(r6)     // Catch:{ all -> 0x0054 }
            if (r4 == 0) goto L_0x0045
            r6.close()
        L_0x0045:
            return
        L_0x0046:
            com.facebook.common.dextricks.Mlog.assertThat(r2, r1, r0)     // Catch:{ all -> 0x0054 }
            X.0Vs r0 = X.C06300Vs.createAndThrow()
            goto L_0x0053
        L_0x004e:
            r0 = move-exception
            java.lang.RuntimeException r0 = X.AnonymousClass001.A0X(r0)     // Catch:{ all -> 0x0054 }
        L_0x0053:
            throw r0     // Catch:{ all -> 0x0054 }
        L_0x0054:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x0054 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.dextricks.ReentrantLockFile.release():void");
    }

    public ReentrantLockFile() {
        this.lockFileName = null;
        this.mLockHandle = null;
        this.mNext = this;
        this.mPrev = this;
    }
}
