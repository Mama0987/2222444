package com.facebook.common.activitythreadhook;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import android.app.ActivityOptions;
import android.app.IApplicationThread;
import android.app.IInstrumentationWatcher;
import android.app.IUiAutomationConnection;
import android.app.ProfilerInfo;
import android.app.servertransaction.ClientTransaction;
import android.content.ComponentName;
import android.content.IIntentReceiver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ParceledListSlice;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.res.CompatibilityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.Debug;
import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.PersistableBundle;
import com.android.internal.app.IVoiceInteractor;
import com.facebook.common.binderhooker.BinderHook;
import com.facebook.common.binderhooker.IWrappedBinderHook;
import java.io.FileDescriptor;
import java.util.List;
import java.util.Map;

public class IApplicationThreadBinderHookWrapper extends BinderHook implements IApplicationThread, IWrappedBinderHook {
    public final BinderHook mWrappedBinderHook;
    public final IApplicationThread mWrappedIAppThread;

    public IApplicationThreadBinderHookWrapper(BinderHook binderHook, Binder binder) {
        super(binderHook);
        IllegalArgumentException illegalArgumentException;
        int i;
        int A03 = AnonymousClass0BS.A03(-801277796);
        if (binder == null) {
            illegalArgumentException = AnonymousClass001.A0L("Cannot give a null IApplicationThread");
            i = 664868420;
        } else if (!(binder instanceof IApplicationThread)) {
            illegalArgumentException = AnonymousClass001.A0L(String.format("Binder Hook given to wrap (cls: %s) must hook an instance of IApplicationThread (found: %s).", new Object[]{AnonymousClass001.A0c(binderHook), AnonymousClass001.A0c(binder)}));
            i = 507513518;
        } else if (!(binderHook instanceof IApplicationThread)) {
            this.mWrappedBinderHook = binderHook;
            this.mWrappedIAppThread = (IApplicationThread) binder;
            AnonymousClass0BS.A09(1234479574, A03);
            return;
        } else {
            illegalArgumentException = AnonymousClass001.A0L(String.format("Binder Hook given to wrap (cls: %s) is already an instance of IApplicationThread.", new Object[]{AnonymousClass001.A0c(binderHook)}));
            i = -2132816084;
        }
        AnonymousClass0BS.A09(i, A03);
        throw illegalArgumentException;
    }

    public void attachAgent(String str) {
        int A03 = AnonymousClass0BS.A03(296635812);
        this.mWrappedIAppThread.attachAgent(str);
        AnonymousClass0BS.A09(-1909946925, A03);
    }

    public void clearDnsCache() {
        int A03 = AnonymousClass0BS.A03(-1136113881);
        this.mWrappedIAppThread.clearDnsCache();
        AnonymousClass0BS.A09(77370534, A03);
    }

    public void dispatchPackageBroadcast(int i, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(888452824);
        this.mWrappedIAppThread.dispatchPackageBroadcast(i, strArr);
        AnonymousClass0BS.A09(1352448995, A03);
    }

    public void dumpActivity(ParcelFileDescriptor parcelFileDescriptor, IBinder iBinder, String str, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-1175048992);
        this.mWrappedIAppThread.dumpActivity(parcelFileDescriptor, iBinder, str, strArr);
        AnonymousClass0BS.A09(1703009410, A03);
    }

    public void dumpDbInfo(ParcelFileDescriptor parcelFileDescriptor, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-2085582709);
        this.mWrappedIAppThread.dumpDbInfo(parcelFileDescriptor, strArr);
        AnonymousClass0BS.A09(1087934476, A03);
    }

    public void dumpGfxInfo(ParcelFileDescriptor parcelFileDescriptor, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(1208693433);
        this.mWrappedIAppThread.dumpGfxInfo(parcelFileDescriptor, strArr);
        AnonymousClass0BS.A09(-178633319, A03);
    }

    public void dumpHeap(boolean z, String str, ParcelFileDescriptor parcelFileDescriptor) {
        int A03 = AnonymousClass0BS.A03(-2131906959);
        this.mWrappedIAppThread.dumpHeap(z, str, parcelFileDescriptor);
        AnonymousClass0BS.A09(873260210, A03);
    }

    public void dumpMemInfo(FileDescriptor fileDescriptor, Debug.MemoryInfo memoryInfo, boolean z, boolean z2, boolean z3, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(1599007650);
        this.mWrappedIAppThread.dumpMemInfo(fileDescriptor, memoryInfo, z, z2, z3, strArr);
        AnonymousClass0BS.A09(493586227, A03);
    }

    public void dumpMemInfoProto(ParcelFileDescriptor parcelFileDescriptor, Debug.MemoryInfo memoryInfo, boolean z, boolean z2, boolean z3, boolean z4, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-2059853731);
        this.mWrappedIAppThread.dumpMemInfoProto(parcelFileDescriptor, memoryInfo, z, z2, z3, z4, strArr);
        AnonymousClass0BS.A09(1347024886, A03);
    }

    public void dumpProvider(ParcelFileDescriptor parcelFileDescriptor, IBinder iBinder, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(893057689);
        this.mWrappedIAppThread.dumpProvider(parcelFileDescriptor, iBinder, strArr);
        AnonymousClass0BS.A09(346510927, A03);
    }

    public void dumpService(FileDescriptor fileDescriptor, IBinder iBinder, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-978221324);
        this.mWrappedIAppThread.dumpService(fileDescriptor, iBinder, strArr);
        AnonymousClass0BS.A09(-1094871334, A03);
    }

    public BinderHook getWrappedBinderHook() {
        int A03 = AnonymousClass0BS.A03(-1110698793);
        BinderHook binderHook = this.mWrappedBinderHook;
        AnonymousClass0BS.A09(1305332004, A03);
        return binderHook;
    }

    public void handleTrustStorageUpdate() {
        int A03 = AnonymousClass0BS.A03(-892555323);
        this.mWrappedIAppThread.handleTrustStorageUpdate();
        AnonymousClass0BS.A09(-353097109, A03);
    }

    public boolean interceptOnTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int A03 = AnonymousClass0BS.A03(933458470);
        IllegalStateException A0P = AnonymousClass001.A0P("Wrapper should never handle onTransact");
        AnonymousClass0BS.A09(-1666681551, A03);
        throw A0P;
    }

    public void notifyCleartextNetwork(byte[] bArr) {
        int A03 = AnonymousClass0BS.A03(1664242699);
        this.mWrappedIAppThread.notifyCleartextNetwork(bArr);
        AnonymousClass0BS.A09(-1889411970, A03);
    }

    public void processInBackground() {
        int A03 = AnonymousClass0BS.A03(-1418846366);
        this.mWrappedIAppThread.processInBackground();
        AnonymousClass0BS.A09(1905282480, A03);
    }

    public void profilerControl(boolean z, ProfilerInfo profilerInfo, int i) {
        int A03 = AnonymousClass0BS.A03(-752831655);
        this.mWrappedIAppThread.profilerControl(z, profilerInfo, i);
        AnonymousClass0BS.A09(-59052519, A03);
    }

    public void requestAssistContextExtras(IBinder iBinder, IBinder iBinder2, int i) {
        int A03 = AnonymousClass0BS.A03(-1055967542);
        this.mWrappedIAppThread.requestAssistContextExtras(iBinder, iBinder2, i);
        AnonymousClass0BS.A09(-436931845, A03);
    }

    public void runIsolatedEntryPoint(String str, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-642391328);
        this.mWrappedIAppThread.runIsolatedEntryPoint(str, strArr);
        AnonymousClass0BS.A09(39110060, A03);
    }

    public void scheduleActivityConfigurationChanged(IBinder iBinder, Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(-1487177860);
        this.mWrappedIAppThread.scheduleActivityConfigurationChanged(iBinder, configuration);
        AnonymousClass0BS.A09(-1824489983, A03);
    }

    public void scheduleActivityMovedToDisplay(IBinder iBinder, int i, Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(-152423885);
        this.mWrappedIAppThread.scheduleActivityMovedToDisplay(iBinder, i, configuration);
        AnonymousClass0BS.A09(-1535918329, A03);
    }

    public void scheduleApplicationInfoChanged(ApplicationInfo applicationInfo) {
        int A03 = AnonymousClass0BS.A03(-1776741848);
        this.mWrappedIAppThread.scheduleApplicationInfoChanged(applicationInfo);
        AnonymousClass0BS.A09(1657553875, A03);
    }

    public void scheduleBackgroundVisibleBehindChanged(IBinder iBinder, boolean z) {
        int A03 = AnonymousClass0BS.A03(-635019393);
        this.mWrappedIAppThread.scheduleBackgroundVisibleBehindChanged(iBinder, z);
        AnonymousClass0BS.A09(24307920, A03);
    }

    public void scheduleBindService(IBinder iBinder, Intent intent, boolean z, int i) {
        int A03 = AnonymousClass0BS.A03(-1754991660);
        this.mWrappedIAppThread.scheduleBindService(iBinder, intent, z, i);
        AnonymousClass0BS.A09(-1144949784, A03);
    }

    public void scheduleCancelVisibleBehind(IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(-855744230);
        this.mWrappedIAppThread.scheduleCancelVisibleBehind(iBinder);
        AnonymousClass0BS.A09(890553248, A03);
    }

    public void scheduleConfigurationChanged(Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(1506914370);
        this.mWrappedIAppThread.scheduleConfigurationChanged(configuration);
        AnonymousClass0BS.A09(265428818, A03);
    }

    public void scheduleCrash(String str) {
        int A03 = AnonymousClass0BS.A03(394776915);
        this.mWrappedIAppThread.scheduleCrash(str);
        AnonymousClass0BS.A09(1734982531, A03);
    }

    public void scheduleCreateBackupAgent(ApplicationInfo applicationInfo, CompatibilityInfo compatibilityInfo, int i) {
        int A03 = AnonymousClass0BS.A03(2031566656);
        this.mWrappedIAppThread.scheduleCreateBackupAgent(applicationInfo, compatibilityInfo, i);
        AnonymousClass0BS.A09(175962302, A03);
    }

    public void scheduleCreateService(IBinder iBinder, ServiceInfo serviceInfo, CompatibilityInfo compatibilityInfo, int i) {
        int A03 = AnonymousClass0BS.A03(1668698005);
        this.mWrappedIAppThread.scheduleCreateService(iBinder, serviceInfo, compatibilityInfo, i);
        AnonymousClass0BS.A09(-1641150292, A03);
    }

    public void scheduleDestroyActivity(IBinder iBinder, boolean z, int i) {
        int A03 = AnonymousClass0BS.A03(1739869066);
        this.mWrappedIAppThread.scheduleDestroyActivity(iBinder, z, i);
        AnonymousClass0BS.A09(1207226364, A03);
    }

    public void scheduleDestroyBackupAgent(ApplicationInfo applicationInfo, CompatibilityInfo compatibilityInfo) {
        int A03 = AnonymousClass0BS.A03(-2025261509);
        this.mWrappedIAppThread.scheduleDestroyBackupAgent(applicationInfo, compatibilityInfo);
        AnonymousClass0BS.A09(-978727261, A03);
    }

    public void scheduleEnterAnimationComplete(IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(-1625368224);
        this.mWrappedIAppThread.scheduleEnterAnimationComplete(iBinder);
        AnonymousClass0BS.A09(-1216617785, A03);
    }

    public void scheduleExit() {
        int A03 = AnonymousClass0BS.A03(1834327564);
        this.mWrappedIAppThread.scheduleExit();
        AnonymousClass0BS.A09(-1638104090, A03);
    }

    public void scheduleInstallProvider(ProviderInfo providerInfo) {
        int A03 = AnonymousClass0BS.A03(-1426020122);
        this.mWrappedIAppThread.scheduleInstallProvider(providerInfo);
        AnonymousClass0BS.A09(843403524, A03);
    }

    public void scheduleLocalVoiceInteractionStarted(IBinder iBinder, IVoiceInteractor iVoiceInteractor) {
        int A03 = AnonymousClass0BS.A03(323591866);
        this.mWrappedIAppThread.scheduleLocalVoiceInteractionStarted(iBinder, iVoiceInteractor);
        AnonymousClass0BS.A09(1947371853, A03);
    }

    public void scheduleLowMemory() {
        int A03 = AnonymousClass0BS.A03(-1817017779);
        this.mWrappedIAppThread.scheduleLowMemory();
        AnonymousClass0BS.A09(1768717242, A03);
    }

    public void scheduleMultiWindowModeChanged(IBinder iBinder, boolean z, Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(2117272858);
        this.mWrappedIAppThread.scheduleMultiWindowModeChanged(iBinder, z, configuration);
        AnonymousClass0BS.A09(-1361537003, A03);
    }

    public void scheduleNewIntent(List list, IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(261604509);
        this.mWrappedIAppThread.scheduleNewIntent(list, iBinder);
        AnonymousClass0BS.A09(-757269386, A03);
    }

    public void scheduleOnNewActivityOptions(IBinder iBinder, ActivityOptions activityOptions) {
        int A03 = AnonymousClass0BS.A03(-986337588);
        this.mWrappedIAppThread.scheduleOnNewActivityOptions(iBinder, activityOptions);
        AnonymousClass0BS.A09(511143902, A03);
    }

    public void schedulePauseActivity(IBinder iBinder, boolean z, boolean z2, int i, boolean z3) {
        int A03 = AnonymousClass0BS.A03(-648221060);
        this.mWrappedIAppThread.schedulePauseActivity(iBinder, z, z2, i, z3);
        AnonymousClass0BS.A09(-375311536, A03);
    }

    public void schedulePictureInPictureModeChanged(IBinder iBinder, boolean z, Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(635477070);
        this.mWrappedIAppThread.schedulePictureInPictureModeChanged(iBinder, z, configuration);
        AnonymousClass0BS.A09(-1283226634, A03);
    }

    public void scheduleReceiver(Intent intent, ActivityInfo activityInfo, CompatibilityInfo compatibilityInfo, int i, String str, Bundle bundle, boolean z, int i2, int i3) {
        int A03 = AnonymousClass0BS.A03(2133371749);
        this.mWrappedIAppThread.scheduleReceiver(intent, activityInfo, compatibilityInfo, i, str, bundle, z, i2, i3);
        AnonymousClass0BS.A09(1942440801, A03);
    }

    public void scheduleRegisteredReceiver(IIntentReceiver iIntentReceiver, Intent intent, int i, String str, Bundle bundle, boolean z, boolean z2, int i2, int i3) {
        int A03 = AnonymousClass0BS.A03(-142336460);
        this.mWrappedIAppThread.scheduleRegisteredReceiver(iIntentReceiver, intent, i, str, bundle, z, z2, i2, i3);
        AnonymousClass0BS.A09(-1710931060, A03);
    }

    public void scheduleRelaunchActivity(IBinder iBinder, List list, List list2, int i, boolean z, Configuration configuration) {
        int A03 = AnonymousClass0BS.A03(-56480443);
        this.mWrappedIAppThread.scheduleRelaunchActivity(iBinder, list, list2, i, z, configuration);
        AnonymousClass0BS.A09(1565157612, A03);
    }

    public void scheduleResumeActivity(IBinder iBinder, int i, boolean z, Bundle bundle) {
        int A03 = AnonymousClass0BS.A03(-90651416);
        this.mWrappedIAppThread.scheduleResumeActivity(iBinder, i, z, bundle);
        AnonymousClass0BS.A09(1354716657, A03);
    }

    public void scheduleSendResult(IBinder iBinder, List list) {
        int A03 = AnonymousClass0BS.A03(-498782564);
        this.mWrappedIAppThread.scheduleSendResult(iBinder, list);
        AnonymousClass0BS.A09(715738159, A03);
    }

    public void scheduleServiceArgs(IBinder iBinder, ParceledListSlice parceledListSlice) {
        int A03 = AnonymousClass0BS.A03(-2028964379);
        this.mWrappedIAppThread.scheduleServiceArgs(iBinder, parceledListSlice);
        AnonymousClass0BS.A09(-1920445562, A03);
    }

    public void scheduleSleeping(IBinder iBinder, boolean z) {
        int A03 = AnonymousClass0BS.A03(-2072219897);
        this.mWrappedIAppThread.scheduleSleeping(iBinder, z);
        AnonymousClass0BS.A09(1382553218, A03);
    }

    public void scheduleStopActivity(IBinder iBinder, boolean z, int i) {
        int A03 = AnonymousClass0BS.A03(834027185);
        this.mWrappedIAppThread.scheduleStopActivity(iBinder, z, i);
        AnonymousClass0BS.A09(-881314147, A03);
    }

    public void scheduleStopService(IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(1504854386);
        this.mWrappedIAppThread.scheduleStopService(iBinder);
        AnonymousClass0BS.A09(-1390199261, A03);
    }

    public void scheduleSuicide() {
        int A03 = AnonymousClass0BS.A03(144436806);
        this.mWrappedIAppThread.scheduleSuicide();
        AnonymousClass0BS.A09(997627314, A03);
    }

    public void scheduleTransaction(ClientTransaction clientTransaction) {
        int A03 = AnonymousClass0BS.A03(-1966728792);
        this.mWrappedIAppThread.scheduleTransaction(clientTransaction);
        AnonymousClass0BS.A09(1810370755, A03);
    }

    public void scheduleTranslucentConversionComplete(IBinder iBinder, boolean z) {
        int A03 = AnonymousClass0BS.A03(184965808);
        this.mWrappedIAppThread.scheduleTranslucentConversionComplete(iBinder, z);
        AnonymousClass0BS.A09(-749056546, A03);
    }

    public void scheduleTrimMemory(int i) {
        int A03 = AnonymousClass0BS.A03(1760860317);
        this.mWrappedIAppThread.scheduleTrimMemory(i);
        AnonymousClass0BS.A09(-95732814, A03);
    }

    public void scheduleUnbindService(IBinder iBinder, Intent intent) {
        int A03 = AnonymousClass0BS.A03(-1130246688);
        this.mWrappedIAppThread.scheduleUnbindService(iBinder, intent);
        AnonymousClass0BS.A09(1763031441, A03);
    }

    public void scheduleWindowVisibility(IBinder iBinder, boolean z) {
        int A03 = AnonymousClass0BS.A03(486001037);
        this.mWrappedIAppThread.scheduleWindowVisibility(iBinder, z);
        AnonymousClass0BS.A09(1056183233, A03);
    }

    public void setCoreSettings(Bundle bundle) {
        int A03 = AnonymousClass0BS.A03(-1443181394);
        this.mWrappedIAppThread.setCoreSettings(bundle);
        AnonymousClass0BS.A09(47747864, A03);
    }

    public void setHttpProxy(String str, String str2, String str3, Uri uri) {
        int A03 = AnonymousClass0BS.A03(1826694038);
        this.mWrappedIAppThread.setHttpProxy(str, str2, str3, uri);
        AnonymousClass0BS.A09(-250216023, A03);
    }

    public void setNetworkBlockSeq(long j) {
        int A03 = AnonymousClass0BS.A03(-948656192);
        this.mWrappedIAppThread.setNetworkBlockSeq(j);
        AnonymousClass0BS.A09(1664457742, A03);
    }

    public void setProcessState(int i) {
        int A03 = AnonymousClass0BS.A03(-276526673);
        this.mWrappedIAppThread.setProcessState(i);
        AnonymousClass0BS.A09(57126691, A03);
    }

    public void setSchedulingGroup(int i) {
        int A03 = AnonymousClass0BS.A03(-435015245);
        this.mWrappedIAppThread.setSchedulingGroup(i);
        AnonymousClass0BS.A09(-1694020572, A03);
    }

    public void startBinderTracking() {
        int A03 = AnonymousClass0BS.A03(1013481922);
        this.mWrappedIAppThread.startBinderTracking();
        AnonymousClass0BS.A09(855229968, A03);
    }

    public void stopBinderTrackingAndDump(ParcelFileDescriptor parcelFileDescriptor) {
        int A03 = AnonymousClass0BS.A03(-922522390);
        this.mWrappedIAppThread.stopBinderTrackingAndDump(parcelFileDescriptor);
        AnonymousClass0BS.A09(453200530, A03);
    }

    public void unstableProviderDied(IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(-1204326346);
        this.mWrappedIAppThread.unstableProviderDied(iBinder);
        AnonymousClass0BS.A09(993482273, A03);
    }

    public void updatePackageCompatibilityInfo(String str, CompatibilityInfo compatibilityInfo) {
        int A03 = AnonymousClass0BS.A03(-1313092375);
        this.mWrappedIAppThread.updatePackageCompatibilityInfo(str, compatibilityInfo);
        AnonymousClass0BS.A09(94116087, A03);
    }

    public void updateTimePrefs(int i) {
        int A03 = AnonymousClass0BS.A03(-932410500);
        this.mWrappedIAppThread.updateTimePrefs(i);
        AnonymousClass0BS.A09(-1882154779, A03);
    }

    public void updateTimeZone() {
        int A03 = AnonymousClass0BS.A03(1145157466);
        this.mWrappedIAppThread.updateTimeZone();
        AnonymousClass0BS.A09(-396377174, A03);
    }

    public void bindApplication(String str, ApplicationInfo applicationInfo, List list, ComponentName componentName, ProfilerInfo profilerInfo, Bundle bundle, IInstrumentationWatcher iInstrumentationWatcher, IUiAutomationConnection iUiAutomationConnection, int i, boolean z, boolean z2, boolean z3, boolean z4, Configuration configuration, CompatibilityInfo compatibilityInfo, Map map, Bundle bundle2, String str2, boolean z5) {
        int A03 = AnonymousClass0BS.A03(1562295330);
        boolean z6 = z;
        int i2 = i;
        IUiAutomationConnection iUiAutomationConnection2 = iUiAutomationConnection;
        IInstrumentationWatcher iInstrumentationWatcher2 = iInstrumentationWatcher;
        Bundle bundle3 = bundle;
        ProfilerInfo profilerInfo2 = profilerInfo;
        Bundle bundle4 = bundle2;
        ComponentName componentName2 = componentName;
        Map map2 = map;
        List list2 = list;
        CompatibilityInfo compatibilityInfo2 = compatibilityInfo;
        ApplicationInfo applicationInfo2 = applicationInfo;
        Configuration configuration2 = configuration;
        String str3 = str;
        boolean z7 = z4;
        this.mWrappedIAppThread.bindApplication(str3, applicationInfo2, list2, componentName2, profilerInfo2, bundle3, iInstrumentationWatcher2, iUiAutomationConnection2, i2, z6, z2, z3, z7, configuration2, compatibilityInfo2, map2, bundle4, str2, z5);
        AnonymousClass0BS.A09(-1424588274, A03);
    }

    public void scheduleLaunchActivity(Intent intent, IBinder iBinder, int i, ActivityInfo activityInfo, Configuration configuration, Configuration configuration2, CompatibilityInfo compatibilityInfo, String str, IVoiceInteractor iVoiceInteractor, int i2, Bundle bundle, PersistableBundle persistableBundle, List list, List list2, boolean z, boolean z2, ProfilerInfo profilerInfo) {
        int A03 = AnonymousClass0BS.A03(-295866304);
        int i3 = i2;
        IVoiceInteractor iVoiceInteractor2 = iVoiceInteractor;
        String str2 = str;
        ActivityInfo activityInfo2 = activityInfo;
        int i4 = i;
        boolean z3 = z;
        IBinder iBinder2 = iBinder;
        List list3 = list2;
        Intent intent2 = intent;
        List list4 = list;
        Configuration configuration3 = configuration;
        Configuration configuration4 = configuration2;
        CompatibilityInfo compatibilityInfo2 = compatibilityInfo;
        this.mWrappedIAppThread.scheduleLaunchActivity(intent2, iBinder2, i4, activityInfo2, configuration3, configuration4, compatibilityInfo2, str2, iVoiceInteractor2, i3, bundle, persistableBundle, list4, list3, z3, z2, profilerInfo);
        AnonymousClass0BS.A09(357809616, A03);
    }

    public void dumpActivity(FileDescriptor fileDescriptor, IBinder iBinder, String str, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-905400261);
        this.mWrappedIAppThread.dumpActivity(fileDescriptor, iBinder, str, strArr);
        AnonymousClass0BS.A09(-2074778321, A03);
    }

    public void dumpDbInfo(FileDescriptor fileDescriptor, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(2130588134);
        this.mWrappedIAppThread.dumpDbInfo(fileDescriptor, strArr);
        AnonymousClass0BS.A09(-173120592, A03);
    }

    public void dumpGfxInfo(FileDescriptor fileDescriptor, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(-1478717448);
        this.mWrappedIAppThread.dumpGfxInfo(fileDescriptor, strArr);
        AnonymousClass0BS.A09(-1518901947, A03);
    }

    public void dumpHeap(boolean z, boolean z2, boolean z3, String str, ParcelFileDescriptor parcelFileDescriptor) {
        int A03 = AnonymousClass0BS.A03(713178312);
        this.mWrappedIAppThread.dumpHeap(z, z2, z3, str, parcelFileDescriptor);
        AnonymousClass0BS.A09(-2025548934, A03);
    }

    public void dumpMemInfo(ParcelFileDescriptor parcelFileDescriptor, Debug.MemoryInfo memoryInfo, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(1909028993);
        this.mWrappedIAppThread.dumpMemInfo(parcelFileDescriptor, memoryInfo, z, z2, z3, z4, z5, strArr);
        AnonymousClass0BS.A09(1155548505, A03);
    }

    public void dumpProvider(FileDescriptor fileDescriptor, IBinder iBinder, String[] strArr) {
        int A03 = AnonymousClass0BS.A03(583659281);
        this.mWrappedIAppThread.dumpProvider(fileDescriptor, iBinder, strArr);
        AnonymousClass0BS.A09(-290824975, A03);
    }

    public void requestAssistContextExtras(IBinder iBinder, IBinder iBinder2, int i, int i2, int i3) {
        int A03 = AnonymousClass0BS.A03(1609605923);
        this.mWrappedIAppThread.requestAssistContextExtras(iBinder, iBinder2, i, i2, i3);
        AnonymousClass0BS.A09(899932089, A03);
    }

    public void scheduleActivityConfigurationChanged(IBinder iBinder) {
        int A03 = AnonymousClass0BS.A03(2065873218);
        this.mWrappedIAppThread.scheduleActivityConfigurationChanged(iBinder);
        AnonymousClass0BS.A09(-1281989915, A03);
    }

    public void scheduleNewIntent(List list, IBinder iBinder, boolean z) {
        int A03 = AnonymousClass0BS.A03(1677790180);
        this.mWrappedIAppThread.scheduleNewIntent(list, iBinder, z);
        AnonymousClass0BS.A09(-1736083917, A03);
    }

    public void scheduleRelaunchActivity(IBinder iBinder, List list, List list2, int i, boolean z, Configuration configuration, Configuration configuration2, boolean z2) {
        int A03 = AnonymousClass0BS.A03(608509238);
        this.mWrappedIAppThread.scheduleRelaunchActivity(iBinder, list, list2, i, z, configuration, configuration2, z2);
        AnonymousClass0BS.A09(-868661110, A03);
    }

    public void scheduleServiceArgs(IBinder iBinder, boolean z, int i, int i2, Intent intent) {
        int A03 = AnonymousClass0BS.A03(392905631);
        this.mWrappedIAppThread.scheduleServiceArgs(iBinder, z, i, i2, intent);
        AnonymousClass0BS.A09(-597417985, A03);
    }

    public void updateTimePrefs(boolean z) {
        int A03 = AnonymousClass0BS.A03(157836850);
        this.mWrappedIAppThread.updateTimePrefs(z);
        AnonymousClass0BS.A09(-1527116831, A03);
    }

    public void bindApplication(String str, ApplicationInfo applicationInfo, List list, ComponentName componentName, ProfilerInfo profilerInfo, Bundle bundle, IInstrumentationWatcher iInstrumentationWatcher, IUiAutomationConnection iUiAutomationConnection, int i, boolean z, boolean z2, boolean z3, boolean z4, Configuration configuration, CompatibilityInfo compatibilityInfo, Map map, Bundle bundle2, String str2) {
        int A03 = AnonymousClass0BS.A03(1332861292);
        boolean z5 = z;
        int i2 = i;
        IUiAutomationConnection iUiAutomationConnection2 = iUiAutomationConnection;
        IInstrumentationWatcher iInstrumentationWatcher2 = iInstrumentationWatcher;
        ProfilerInfo profilerInfo2 = profilerInfo;
        ComponentName componentName2 = componentName;
        Map map2 = map;
        List list2 = list;
        CompatibilityInfo compatibilityInfo2 = compatibilityInfo;
        ApplicationInfo applicationInfo2 = applicationInfo;
        Configuration configuration2 = configuration;
        String str3 = str;
        boolean z6 = z4;
        Bundle bundle3 = bundle;
        this.mWrappedIAppThread.bindApplication(str3, applicationInfo2, list2, componentName2, profilerInfo2, bundle3, iInstrumentationWatcher2, iUiAutomationConnection2, i2, z5, z2, z3, z6, configuration2, compatibilityInfo2, map2, bundle2, str2);
        AnonymousClass0BS.A09(-476819406, A03);
    }

    public void scheduleLaunchActivity(Intent intent, IBinder iBinder, int i, ActivityInfo activityInfo, Configuration configuration, CompatibilityInfo compatibilityInfo, IVoiceInteractor iVoiceInteractor, int i2, Bundle bundle, PersistableBundle persistableBundle, List list, List list2, boolean z, boolean z2, ProfilerInfo profilerInfo) {
        int A03 = AnonymousClass0BS.A03(-2051087027);
        PersistableBundle persistableBundle2 = persistableBundle;
        IBinder iBinder2 = iBinder;
        Intent intent2 = intent;
        boolean z3 = z;
        int i3 = i;
        ActivityInfo activityInfo2 = activityInfo;
        Configuration configuration2 = configuration;
        CompatibilityInfo compatibilityInfo2 = compatibilityInfo;
        IVoiceInteractor iVoiceInteractor2 = iVoiceInteractor;
        int i4 = i2;
        Bundle bundle2 = bundle;
        this.mWrappedIAppThread.scheduleLaunchActivity(intent2, iBinder2, i3, activityInfo2, configuration2, compatibilityInfo2, iVoiceInteractor2, i4, bundle2, persistableBundle2, list, list2, z3, z2, profilerInfo);
        AnonymousClass0BS.A09(-566637918, A03);
    }

    public void bindApplication(String str, ApplicationInfo applicationInfo, List list, ComponentName componentName, ProfilerInfo profilerInfo, Bundle bundle, IInstrumentationWatcher iInstrumentationWatcher, IUiAutomationConnection iUiAutomationConnection, int i, boolean z, boolean z2, boolean z3, Configuration configuration, CompatibilityInfo compatibilityInfo, Map map, Bundle bundle2) {
        int A03 = AnonymousClass0BS.A03(640326742);
        boolean z4 = z;
        int i2 = i;
        List list2 = list;
        ApplicationInfo applicationInfo2 = applicationInfo;
        CompatibilityInfo compatibilityInfo2 = compatibilityInfo;
        String str2 = str;
        Configuration configuration2 = configuration;
        ComponentName componentName2 = componentName;
        ProfilerInfo profilerInfo2 = profilerInfo;
        Bundle bundle3 = bundle;
        IInstrumentationWatcher iInstrumentationWatcher2 = iInstrumentationWatcher;
        IUiAutomationConnection iUiAutomationConnection2 = iUiAutomationConnection;
        this.mWrappedIAppThread.bindApplication(str2, applicationInfo2, list2, componentName2, profilerInfo2, bundle3, iInstrumentationWatcher2, iUiAutomationConnection2, i2, z4, z2, z3, configuration2, compatibilityInfo2, map, bundle2);
        AnonymousClass0BS.A09(275641290, A03);
    }
}
