package com.facebook.common.activitythreadhook;

import X.AnonymousClass0BS;
import X.AnonymousClass0RJ;
import X.C11990jh;
import X.C12100ju;
import android.os.Parcel;
import com.facebook.common.binderhooker.BinderHook;

public class ActivityThreadBinderHooker$ApplicationThreadBinderHook extends BinderHook {
    public static final AnonymousClass0RJ A02 = new AnonymousClass0RJ("ApplicationThreadBinderHook");
    public final C11990jh A00 = new C11990jh(this);
    public final C12100ju A01;

    public ActivityThreadBinderHooker$ApplicationThreadBinderHook(C12100ju r3) {
        int A03 = AnonymousClass0BS.A03(678242368);
        this.A01 = r3;
        AnonymousClass0BS.A09(-239022467, A03);
    }

    public final boolean interceptOnTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int A03 = AnonymousClass0BS.A03(2126590221);
        this.A01.A01(this.A00, i, parcel);
        AnonymousClass0BS.A09(1764171646, A03);
        return true;
    }
}
