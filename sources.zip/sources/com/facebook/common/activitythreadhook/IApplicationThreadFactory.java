package com.facebook.common.activitythreadhook;

import X.AnonymousClass001;
import X.AnonymousClass0RJ;
import X.AnonymousClass0WY;
import X.AnonymousClass0n6;
import X.AnonymousClass0n8;
import X.C11960jd;
import X.C13130n9;
import X.C13140nB;
import X.C13580o6;
import X.C13720oN;
import X.C13760oR;
import android.os.Binder;
import com.facebook.common.binderhooker.BinderHook;

public class IApplicationThreadFactory {
    public static final String EXPECTED_IAPPLICATION_THREAD_PACKAGE_NAME_NO_DOT = "com.facebook.common.activitythreadhook";
    public static final String IAPPLICATION_THREAD_WRAPPER_SIMPLE_CLASS_NAME = "IApplicationThreadBinderHookWrapper";
    public static final Object LOCK = AnonymousClass001.A0U();
    public static final AnonymousClass0RJ ML = new AnonymousClass0RJ("IApplicationThreadFactory");
    public static boolean sIApplicationThreadWrapperClassLoadTried;
    public static Class sIApplicationThreadWrapperFullClassName;
    public static volatile IApplicationThreadFactory sInstance;
    public final C13140nB mHiddenApis;

    public static Class findWrappedIApplicationThreadCls(C13140nB r5) {
        AnonymousClass0n8 r4 = AnonymousClass0n8.LikelyHidden;
        Class A0J = r5.A0J(r4, "com.facebook.common.activitythreadhook.IApplicationThreadBinderHookWrapper");
        if (A0J == null) {
            String guessedPackedName = getGuessedPackedName();
            if (EXPECTED_IAPPLICATION_THREAD_PACKAGE_NAME_NO_DOT.equals(guessedPackedName) || (A0J = r5.A0J(r4, AnonymousClass0WY.A0w(guessedPackedName, ".", IAPPLICATION_THREAD_WRAPPER_SIMPLE_CLASS_NAME))) == null) {
                return null;
            }
        }
        return A0J;
    }

    public static String getGuessedPackedName() {
        String name = IApplicationThreadFactory.class.getName();
        int lastIndexOf = name.lastIndexOf(46);
        if (lastIndexOf >= 0) {
            return name.substring(0, lastIndexOf);
        }
        throw AnonymousClass001.A0V(String.format("Cannot deduce package name from name %s", new Object[]{name}));
    }

    public static IApplicationThreadFactory getInstance(C13140nB r2) {
        if (r2 != null) {
            IApplicationThreadFactory iApplicationThreadFactory = sInstance;
            if (iApplicationThreadFactory != null) {
                return iApplicationThreadFactory;
            }
            synchronized (LOCK) {
                if (sInstance != null) {
                    IApplicationThreadFactory iApplicationThreadFactory2 = sInstance;
                    return iApplicationThreadFactory2;
                }
                sInstance = new IApplicationThreadFactory(r2);
                IApplicationThreadFactory iApplicationThreadFactory3 = sInstance;
                return iApplicationThreadFactory3;
            }
        }
        throw AnonymousClass001.A0S();
    }

    public static Class getWrappedIApplicationThreadCls(C13140nB r2) {
        boolean z = sIApplicationThreadWrapperClassLoadTried;
        Class cls = sIApplicationThreadWrapperFullClassName;
        if (z) {
            return cls;
        }
        Class findWrappedIApplicationThreadCls = findWrappedIApplicationThreadCls(r2);
        sIApplicationThreadWrapperFullClassName = findWrappedIApplicationThreadCls;
        sIApplicationThreadWrapperClassLoadTried = true;
        return findWrappedIApplicationThreadCls;
    }

    public BinderHook constructApplicationThreadBinderHookWrapper(BinderHook binderHook, Binder binder) {
        Exception exc;
        String str;
        C11960jd A02;
        if (binderHook == null) {
            throw AnonymousClass001.A0S();
        } else if (binder != null) {
            AnonymousClass0RJ r4 = ML;
            binderHook.getInterfaceDescriptor();
            Class<?> cls = binderHook.getClass();
            Class wrappedIApplicationThreadCls = getWrappedIApplicationThreadCls(this.mHiddenApis);
            if (wrappedIApplicationThreadCls == null) {
                r4.A09("Failled to construct an AppThreadWrapper %s for binder hook %s.", IAPPLICATION_THREAD_WRAPPER_SIMPLE_CLASS_NAME, binderHook.getInterfaceDescriptor());
                return null;
            }
            Class<BinderHook> cls2 = BinderHook.class;
            try {
                Object A05 = C13140nB.A05(wrappedIApplicationThreadCls, new C13130n9(cls2, binderHook), new C13130n9(Binder.class, binder));
                if (A05 != null) {
                    String name = cls2.getName();
                    Class<?> cls3 = A05.getClass();
                    try {
                        if (cls2.isAssignableFrom(cls3)) {
                            BinderHook binderHook2 = (BinderHook) A05;
                            boolean A1U = AnonymousClass001.A1U(binderHook2);
                            if (binderHook2 == null) {
                                str = "<UNDEFINED CLASS>";
                            } else {
                                str = AnonymousClass001.A0c(binderHook2);
                            }
                            Object[] objArr = {str};
                            C13760oR r0 = C13580o6.A05;
                            C13760oR r1 = C13720oN.A02;
                            if (r1.A03 != null) {
                                A02 = C13760oR.A01(r1, "(cls: %s)", objArr, 0, 0);
                            } else {
                                A02 = C13760oR.A02(r1, "(cls: %s)", objArr);
                            }
                            C13760oR.A02(C13580o6.A05, 103, Boolean.valueOf(A1U), null, A02);
                            binderHook.getInterfaceDescriptor();
                            return binderHook2;
                        }
                        throw new ClassCastException(String.format("Class %s is not assignable from %s. Cls Id: %s", new Object[]{name, cls3.getName(), wrappedIApplicationThreadCls}));
                    } catch (ClassCastException e) {
                        exc = new Exception(String.format("Could not construct cls %s because %s is not a base class.", new Object[]{wrappedIApplicationThreadCls, name}), e);
                    }
                } else {
                    exc = new Exception(String.format("Could not construct cls %s because we got a null instance..", new Object[]{wrappedIApplicationThreadCls}));
                    throw exc;
                }
            } catch (AnonymousClass0n6 e2) {
                r4.A0A(e2, "Cannot construct AppThread wrapper %s for binder hook %s (cls: %s).", wrappedIApplicationThreadCls, binderHook.getInterfaceDescriptor(), cls);
                return null;
            }
        } else {
            throw AnonymousClass001.A0S();
        }
    }

    public IApplicationThreadFactory(C13140nB r1) {
        this.mHiddenApis = r1;
    }
}
