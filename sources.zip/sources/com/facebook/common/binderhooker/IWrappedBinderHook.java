package com.facebook.common.binderhooker;

public interface IWrappedBinderHook {
    BinderHook getWrappedBinderHook();
}
