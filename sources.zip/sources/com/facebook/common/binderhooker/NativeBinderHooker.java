package com.facebook.common.binderhooker;

import X.AnonymousClass001;
import X.AnonymousClass0RJ;
import X.C12590ko;
import X.C18440x7;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.Parcel;
import java.lang.reflect.Field;

public final class NativeBinderHooker {
    public static final Field FIELD_Parcel_mNativePtr;
    public static final AnonymousClass0RJ ML;
    public static final int NATIVE_RETURN_ERROR = -1;
    public static final boolean PLATFORM_SUPPORTED;

    public static long fromNativeWriteBinderToParcelAndReturnParcelPtr(Object obj) {
        String str;
        Object[] objArr = new Object[1];
        if (obj != null) {
            str = obj.toString();
        } else {
            str = "<null binder>";
        }
        objArr[0] = str;
        try {
            Parcel obtain = Parcel.obtain();
            obtain.setDataPosition(0);
            obtain.writeStrongBinder((IBinder) obj);
            obtain.setDataPosition(0);
            return getParcelNativePtr(obtain);
        } catch (ClassCastException | IllegalAccessException e) {
            ML.A0B(e, "Failed to write binder to parcel and return", new Object[0]);
            return -1;
        }
    }

    public static native int nativeCallOriginalBinderOnTransact(long j, int i, long j2, long j3, int i2);

    public static native long nativeHookBinder(Object obj, Object obj2);

    public static native boolean nativeSetupBinderHooker();

    public static native boolean nativeUnhookBinder(long j);

    static {
        boolean z;
        AnonymousClass0RJ r2 = new AnonymousClass0RJ("NativeBinderHooker");
        ML = r2;
        boolean z2 = true;
        if (C12590ko.A00) {
            try {
                C18440x7.loadLibrary("binderhookerjni");
                z = true;
            } catch (UnsatisfiedLinkError e) {
                ML.A0B(e, "Can't load Binder hooker lib", new Object[0]);
            }
        } else {
            r2.A09("Binder hooking is not currently supported on Android %d.", AnonymousClass001.A1a(Build.VERSION.SDK_INT));
            z = false;
        }
        Field field = null;
        if (z) {
            try {
                field = AnonymousClass001.A0s(Parcel.class, "mNativePtr");
            } catch (NoSuchFieldException e2) {
                ML.A0B(e2, "Can't find Parcel mNativePtr", new Object[0]);
                z2 = false;
            }
            z &= z2;
        }
        FIELD_Parcel_mNativePtr = field;
        PLATFORM_SUPPORTED = z;
    }

    public static long getParcelNativePtr(Parcel parcel) {
        Field field = FIELD_Parcel_mNativePtr;
        if (field == null) {
            throw new IllegalAccessException();
        } else if (parcel == null) {
            return 0;
        } else {
            return field.getLong(parcel);
        }
    }

    public static int callOriginalBinderOnTransact(long j, int i, Parcel parcel, Parcel parcel2, int i2) {
        if (!isSupported()) {
            return 523;
        }
        try {
            return nativeCallOriginalBinderOnTransact(j, i, getParcelNativePtr(parcel), getParcelNativePtr(parcel2), i2);
        } catch (IllegalAccessException e) {
            ML.A0B(e, "Call original binder on transact failed", new Object[0]);
            return 523;
        }
    }

    public static long hookBinder(Binder binder, BinderHook binderHook) {
        if (!isSupported()) {
            return 0;
        }
        return nativeHookBinder(binder, binderHook);
    }

    public static boolean isSupported() {
        return PLATFORM_SUPPORTED;
    }

    public static boolean setupBinderHooker() {
        if (!isSupported()) {
            return false;
        }
        return nativeSetupBinderHooker();
    }

    public static boolean unhookBinder(long j) {
        if (!isSupported()) {
            return false;
        }
        return nativeUnhookBinder(j);
    }
}
