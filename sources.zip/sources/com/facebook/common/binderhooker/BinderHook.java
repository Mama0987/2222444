package com.facebook.common.binderhooker;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0BS;
import X.AnonymousClass0RJ;
import X.AnonymousClass0WY;
import X.C12560kl;
import X.C12570km;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import java.io.FileDescriptor;

public abstract class BinderHook extends Binder implements IInterface {
    public static final AnonymousClass0RJ ML = new AnonymousClass0RJ("BinderHook");
    public static final String NO_NAME = null;
    public static final boolean ON_TRANSACT_PASS = true;
    public static final boolean ON_TRANSACT_STOP = false;
    public C12560kl mCurrentHookedData;
    public final Object mLock;
    public final String mName;
    public boolean mShouldTransparentlyConvert;
    public final BinderHook mWrapped;

    public abstract boolean interceptOnTransact(int i, Parcel parcel, Parcel parcel2, int i2);

    public static int callOriginalBinderOnTransactFromHookedData(C12560kl r4, int i, Parcel parcel, Parcel parcel2, int i2) {
        C12570km r1;
        if (r4 == null || (r1 = r4.A01) == null) {
            ML.A09("Do not have snapshot of current hooked data, so can't call original binder. This can have serious issues. HookData: %s", r4);
            return 523;
        }
        Parcel parcel3 = parcel;
        if (parcel != null) {
            parcel.setDataPosition(0);
        }
        Parcel parcel4 = parcel2;
        if (parcel2 != null) {
            parcel2.setDataPosition(0);
        }
        return NativeBinderHooker.callOriginalBinderOnTransact(r1.A00, i, parcel3, parcel4, i2);
    }

    public static C12570km getHookedBinderDataFrom(C12560kl r0) {
        if (r0 == null) {
            return null;
        }
        return r0.A01;
    }

    public static Binder getHookedBinderFrom(C12560kl r0) {
        if (r0 == null) {
            return null;
        }
        return r0.A00;
    }

    public static String hookBinderToString(Binder binder) {
        if (binder == null) {
            return "<Null Binder>";
        }
        String interfaceDescriptor = binder.getInterfaceDescriptor();
        if (interfaceDescriptor == null) {
            return "<No Interface Desc>";
        }
        return interfaceDescriptor;
    }

    public BinderHook(BinderHook binderHook) {
        int A03 = AnonymousClass0BS.A03(587170499);
        this.mLock = AnonymousClass001.A0U();
        this.mCurrentHookedData = null;
        this.mShouldTransparentlyConvert = false;
        if (binderHook != null) {
            this.mName = AnonymousClass0WY.A0w(AnonymousClass001.A0b(this), "_", AnonymousClass001.A0b(binderHook));
            this.mWrapped = binderHook;
            AnonymousClass0BS.A09(747212541, A03);
            return;
        }
        IllegalArgumentException A0L = AnonymousClass001.A0L("Can not wrap a null binder hook");
        AnonymousClass0BS.A09(1791664172, A03);
        throw A0L;
    }

    private Binder getHookedBinderIfShouldCall() {
        int A03 = AnonymousClass0BS.A03(931153262);
        Binder hookedBinder = getHookedBinder();
        AnonymousClass0BS.A09(-1067414401, A03);
        return hookedBinder;
    }

    private Binder getHookedBinder_native() {
        int A03 = AnonymousClass0BS.A03(2109027204);
        Binder hookedBinder = getHookedBinder();
        AnonymousClass0BS.A09(-443399799, A03);
        return hookedBinder;
    }

    public static long getHookedDataPtrFrom(C12560kl r1) {
        C12570km hookedBinderDataFrom = getHookedBinderDataFrom(r1);
        if (hookedBinderDataFrom == null) {
            return 0;
        }
        return hookedBinderDataFrom.A00;
    }

    private long getHookedDataPtr_native() {
        int A03 = AnonymousClass0BS.A03(579033870);
        long hookedDataPtr = getHookedDataPtr();
        AnonymousClass0BS.A09(-2094432216, A03);
        return hookedDataPtr;
    }

    private Binder getNotWrappedHookedBinder() {
        int A03 = AnonymousClass0BS.A03(-1066733307);
        Binder hookedBinderFrom = getHookedBinderFrom(this.mCurrentHookedData);
        AnonymousClass0BS.A09(1452682522, A03);
        return hookedBinderFrom;
    }

    private long getNotWrappedHookedDataPtr() {
        int A03 = AnonymousClass0BS.A03(-791329220);
        long hookedDataPtrFrom = getHookedDataPtrFrom(this.mCurrentHookedData);
        AnonymousClass0BS.A09(1118293812, A03);
        return hookedDataPtrFrom;
    }

    private BinderHook getWrappedObjToUse() {
        int A03 = AnonymousClass0BS.A03(2099686188);
        BinderHook binderHook = this.mWrapped;
        AnonymousClass0BS.A09(886191166, A03);
        return binderHook;
    }

    public IBinder asBinder() {
        int i;
        int A03 = AnonymousClass0BS.A03(239049395);
        IBinder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall == null || !(hookedBinderIfShouldCall instanceof IInterface)) {
            i = 1475318014;
        } else {
            hookedBinderIfShouldCall = ((IInterface) hookedBinderIfShouldCall).asBinder();
            i = -809780118;
        }
        AnonymousClass0BS.A09(i, A03);
        return hookedBinderIfShouldCall;
    }

    public final int callOriginalBinderOnTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int A03 = AnonymousClass0BS.A03(-1776446313);
        int callOriginalBinderOnTransactInternal = callOriginalBinderOnTransactInternal(i, parcel, parcel2, i2);
        AnonymousClass0BS.A09(1355266691, A03);
        return callOriginalBinderOnTransactInternal;
    }

    public int callOriginalBinderOnTransactInternal(int i, Parcel parcel, Parcel parcel2, int i2) {
        int callOriginalBinderOnTransactFromHookedData;
        int i3;
        int A03 = AnonymousClass0BS.A03(595621200);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            callOriginalBinderOnTransactFromHookedData = wrappedObjToUse.callOriginalBinderOnTransactInternal(i, parcel, parcel2, i2);
            i3 = 1340581244;
        } else {
            callOriginalBinderOnTransactFromHookedData = callOriginalBinderOnTransactFromHookedData(this.mCurrentHookedData, i, parcel, parcel2, i2);
            i3 = -538124395;
        }
        AnonymousClass0BS.A09(i3, A03);
        return callOriginalBinderOnTransactFromHookedData;
    }

    public void clearHookedBinderData() {
        int A03 = AnonymousClass0BS.A03(-1575160925);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            Object[] objArr = {this.mName, wrappedObjToUse.getName()};
            wrappedObjToUse.clearHookedBinderData();
            AnonymousClass0BS.A09(967941669, A03);
            return;
        }
        C12560kl r3 = this.mCurrentHookedData;
        Object[] objArr2 = {this.mName, hookBinderToString(getHookedBinderFrom(r3)), r3};
        synchronized (this.mLock) {
            try {
                this.mCurrentHookedData = null;
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(2104934050, A03);
                    throw th;
                }
            }
        }
        AnonymousClass0BS.A09(615164817, A03);
    }

    public void dump(FileDescriptor fileDescriptor, String[] strArr) {
        int i;
        int A03 = AnonymousClass0BS.A03(-829322259);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            hookedBinderIfShouldCall.dump(fileDescriptor, strArr);
            i = 612626007;
        } else {
            super.dump(fileDescriptor, strArr);
            i = -1741515878;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public void dumpAsync(FileDescriptor fileDescriptor, String[] strArr) {
        int i;
        int A03 = AnonymousClass0BS.A03(1585412868);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            hookedBinderIfShouldCall.dumpAsync(fileDescriptor, strArr);
            i = -211636046;
        } else {
            super.dumpAsync(fileDescriptor, strArr);
            i = 341877525;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public Binder getHookedBinder() {
        Binder notWrappedHookedBinder;
        int i;
        int A03 = AnonymousClass0BS.A03(-1116733962);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            notWrappedHookedBinder = wrappedObjToUse.getHookedBinder();
            i = 375020093;
        } else {
            notWrappedHookedBinder = getNotWrappedHookedBinder();
            i = -286122783;
        }
        AnonymousClass0BS.A09(i, A03);
        return notWrappedHookedBinder;
    }

    public long getHookedDataPtr() {
        long notWrappedHookedDataPtr;
        int i;
        int A03 = AnonymousClass0BS.A03(1102772852);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            notWrappedHookedDataPtr = wrappedObjToUse.getHookedDataPtr();
            i = -2068253736;
        } else {
            notWrappedHookedDataPtr = getNotWrappedHookedDataPtr();
            i = 726620739;
        }
        AnonymousClass0BS.A09(i, A03);
        return notWrappedHookedDataPtr;
    }

    public String getInterfaceDescriptor() {
        String interfaceDescriptor;
        int i;
        int A03 = AnonymousClass0BS.A03(-1236743041);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            interfaceDescriptor = hookedBinderIfShouldCall.getInterfaceDescriptor();
            i = 660187571;
        } else {
            interfaceDescriptor = super.getInterfaceDescriptor();
            i = -2079079549;
        }
        AnonymousClass0BS.A09(i, A03);
        return interfaceDescriptor;
    }

    public String getName() {
        int A03 = AnonymousClass0BS.A03(-697685446);
        String str = this.mName;
        AnonymousClass0BS.A09(190782397, A03);
        return str;
    }

    public boolean hasWrap() {
        int A03 = AnonymousClass0BS.A03(839204923);
        boolean A1U = AnonymousClass001.A1U(getWrappedObjToUse());
        AnonymousClass0BS.A09(644891022, A03);
        return A1U;
    }

    public boolean isBinderAlive() {
        boolean isBinderAlive;
        int i;
        int A03 = AnonymousClass0BS.A03(1770720429);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            isBinderAlive = hookedBinderIfShouldCall.isBinderAlive();
            i = 2127871636;
        } else {
            isBinderAlive = super.isBinderAlive();
            i = -1892620096;
        }
        AnonymousClass0BS.A09(i, A03);
        return isBinderAlive;
    }

    public boolean isHooked() {
        boolean A1U;
        int i;
        int A03 = AnonymousClass0BS.A03(1872862619);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            A1U = wrappedObjToUse.isHooked();
            i = 1688011406;
        } else {
            A1U = AnonymousClass001.A1U(this.mCurrentHookedData);
            i = 1366081844;
        }
        AnonymousClass0BS.A09(i, A03);
        return A1U;
    }

    public void linkToDeath(IBinder.DeathRecipient deathRecipient, int i) {
        int i2;
        int A03 = AnonymousClass0BS.A03(1929404028);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            hookedBinderIfShouldCall.linkToDeath(deathRecipient, i);
            i2 = 602389253;
        } else {
            super.linkToDeath(deathRecipient, i);
            i2 = -837496000;
        }
        AnonymousClass0BS.A09(i2, A03);
    }

    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        boolean z;
        int i3;
        int A03 = AnonymousClass0BS.A03(-40174759);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            z = wrappedObjToUse.onTransact(i, parcel, parcel2, i2);
            i3 = -1056663244;
        } else {
            C12560kl r1 = this.mCurrentHookedData;
            if (!interceptOnTransact(i, parcel, parcel2, i2)) {
                AnonymousClass0BS.A09(1561170019, A03);
                return true;
            }
            if (parcel != null) {
                parcel.setDataPosition(0);
            }
            if (parcel2 != null) {
                parcel2.setDataPosition(0);
            }
            int callOriginalBinderOnTransactFromHookedData = callOriginalBinderOnTransactFromHookedData(r1, i, parcel, parcel2, i2);
            if (callOriginalBinderOnTransactFromHookedData == 523) {
                z = super.onTransact(i, parcel, parcel2, i2);
                i3 = 807025287;
            } else {
                z = false;
                if (callOriginalBinderOnTransactFromHookedData == 213) {
                    z = true;
                }
                i3 = 90620012;
            }
        }
        AnonymousClass0BS.A09(i3, A03);
        return z;
    }

    public boolean pingBinder() {
        boolean pingBinder;
        int i;
        int A03 = AnonymousClass0BS.A03(-678205118);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            pingBinder = hookedBinderIfShouldCall.pingBinder();
            i = 508227447;
        } else {
            pingBinder = super.pingBinder();
            i = -983658150;
        }
        AnonymousClass0BS.A09(i, A03);
        return pingBinder;
    }

    public IInterface queryLocalInterface(String str) {
        IInterface queryLocalInterface;
        int i;
        int A03 = AnonymousClass0BS.A03(1370005925);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            queryLocalInterface = hookedBinderIfShouldCall.queryLocalInterface(str);
            i = -1504908781;
        } else {
            queryLocalInterface = super.queryLocalInterface(str);
            i = 336920254;
        }
        AnonymousClass0BS.A09(i, A03);
        return queryLocalInterface;
    }

    public void setHookedBinderData(Binder binder, long j) {
        int A03 = AnonymousClass0BS.A03(1207019107);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            Object[] objArr = {this.mName, wrappedObjToUse.getName()};
            wrappedObjToUse.setHookedBinderData(binder, j);
            AnonymousClass0BS.A09(-2048462348, A03);
            return;
        }
        Object[] objArr2 = {this.mName, hookBinderToString(binder), Long.valueOf(j)};
        synchronized (this.mLock) {
            try {
                this.mCurrentHookedData = new C12560kl(binder, j);
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(597954832, A03);
                    throw th;
                }
            }
        }
        AnonymousClass0BS.A09(-43519876, A03);
    }

    public void setShouldTransparentlyConvert(boolean z) {
        int A03 = AnonymousClass0BS.A03(1589894280);
        this.mShouldTransparentlyConvert = z;
        AnonymousClass0BS.A09(-944215316, A03);
    }

    public String toString() {
        String str;
        int A03 = AnonymousClass0BS.A03(-2021918421);
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("[BinderHook ");
        A0m.append(this.mName);
        A0m.append('(');
        A0m.append(AnonymousClass001.A0c(this));
        A0m.append(')');
        A0m.append(" Hooked Data: ");
        C12560kl r0 = this.mCurrentHookedData;
        if (r0 != null) {
            str = r0.toString();
        } else {
            str = "Not Hooked";
        }
        A0m.append(str);
        BinderHook wrappedObjToUse = getWrappedObjToUse();
        if (wrappedObjToUse != null) {
            A0m.append(" wrap: ");
            AnonymousClass001.A1L(A0m, wrappedObjToUse);
        }
        String A0O = AnonymousClass002.A0O(A0m);
        AnonymousClass0BS.A09(2065824159, A03);
        return A0O;
    }

    public boolean unlinkToDeath(IBinder.DeathRecipient deathRecipient, int i) {
        boolean unlinkToDeath;
        int i2;
        int A03 = AnonymousClass0BS.A03(1080247057);
        Binder hookedBinderIfShouldCall = getHookedBinderIfShouldCall();
        if (hookedBinderIfShouldCall != null) {
            unlinkToDeath = hookedBinderIfShouldCall.unlinkToDeath(deathRecipient, i);
            i2 = -2145363977;
        } else {
            unlinkToDeath = super.unlinkToDeath(deathRecipient, i);
            i2 = -799434936;
        }
        AnonymousClass0BS.A09(i2, A03);
        return unlinkToDeath;
    }

    public BinderHook(String str) {
        int A03 = AnonymousClass0BS.A03(389790626);
        this.mLock = AnonymousClass001.A0U();
        this.mCurrentHookedData = null;
        this.mShouldTransparentlyConvert = false;
        this.mName = str == null ? AnonymousClass001.A0b(this) : str;
        this.mWrapped = null;
        AnonymousClass0BS.A09(-1655867106, A03);
    }

    public BinderHook() {
        this(NO_NAME);
        AnonymousClass0BS.A09(-1194310546, AnonymousClass0BS.A03(-376421738));
    }
}
