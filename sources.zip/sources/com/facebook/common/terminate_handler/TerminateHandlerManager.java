package com.facebook.common.terminate_handler;

import X.C18440x7;

public final class TerminateHandlerManager {
    public static final TerminateHandlerManager INSTANCE = new Object();

    public static final native void nativeInstallTerminateHandler();

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.facebook.common.terminate_handler.TerminateHandlerManager] */
    static {
        C18440x7.loadLibrary("terminate_handler_manager");
    }
}
