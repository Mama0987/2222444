package com.facebook.common.earlystartupperf;

import X.C18440x7;

public final class Odex {
    public static final Odex INSTANCE = new Odex();

    public static final native int getOdexSize(boolean z);

    static {
        C18440x7.loadLibrary("earlystartupperf-jni");
    }
}
