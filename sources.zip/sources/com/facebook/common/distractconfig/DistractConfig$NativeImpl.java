package com.facebook.common.distractconfig;

import X.C18440x7;

public final class DistractConfig$NativeImpl {
    public static final DistractConfig$NativeImpl INSTANCE = new Object();

    public static final native void configureDistractBlockingNative(String str, String str2);

    /* JADX WARNING: type inference failed for: r0v0, types: [com.facebook.common.distractconfig.DistractConfig$NativeImpl, java.lang.Object] */
    static {
        C18440x7.loadLibrary("distract-config");
    }
}
