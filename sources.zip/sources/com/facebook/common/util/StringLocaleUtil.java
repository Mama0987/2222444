package com.facebook.common.util;

import X.C15800sA;
import java.util.Arrays;
import java.util.Locale;

public abstract class StringLocaleUtil {
    public static final String A00(String str, Object... objArr) {
        C15800sA.A0D(str, 0);
        Locale locale = Locale.getDefault();
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
        String format = String.format(locale, str, Arrays.copyOf(copyOf, copyOf.length));
        C15800sA.A09(format);
        return format;
    }

    public static final String toLowerCaseLocaleSafe(String str) {
        if (str == null) {
            return null;
        }
        String lowerCase = str.toLowerCase(Locale.ROOT);
        C15800sA.A0H(lowerCase, "toLowerCase(...)");
        return lowerCase;
    }

    public static final String toUpperCaseLocaleSafe(String str) {
        if (str == null) {
            return null;
        }
        Locale locale = Locale.US;
        C15800sA.A0H(locale, "US");
        String upperCase = str.toUpperCase(locale);
        C15800sA.A0H(upperCase, "toUpperCase(...)");
        return upperCase;
    }
}
