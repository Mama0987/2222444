package com.facebook.common.lyra;

import X.AnonymousClass001;
import X.C14270pR;
import X.C18440x7;
import X.C18590xN;
import android.content.Context;
import java.util.concurrent.atomic.AtomicBoolean;

public final class LyraManager {
    public static final LyraManager INSTANCE = new Object();
    public static final AtomicBoolean initialized = AnonymousClass001.A17();

    public static final native void installLibraryIdentifierFunction();

    public static final native boolean nativeInstallLyraHook(boolean z);

    /* JADX WARNING: type inference failed for: r0v0, types: [com.facebook.common.lyra.LyraManager, java.lang.Object] */
    static {
        C18440x7.loadLibrary("lyramanager");
    }

    /* JADX WARNING: type inference failed for: r0v5, types: [X.0xK, X.0xM, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v7, types: [X.0xK, X.0xM, java.lang.Object] */
    public static final void init(Context context, boolean z) {
        int i = 0;
        if (initialized.compareAndSet(false, true)) {
            if ("true".equals(System.getProperty("fb.running_e2e"))) {
                i = 1;
            }
            ? obj = new Object();
            obj.A00 = context;
            boolean z2 = true;
            if (C18590xN.A00(obj, "android_crash_lyra_hook_cxa_throw", i) != 1) {
                z2 = false;
            }
            ? obj2 = new Object();
            obj2.A00 = context;
            int A00 = C18590xN.A00(obj2, "android_crash_lyra_enable_backtraces", i);
            boolean z3 = true;
            if (A00 != 1) {
                z3 = false;
            }
            if (z2) {
                try {
                    if (!nativeInstallLyraHook(z3)) {
                        C14270pR.A0F("LyraManager", "Installing lyra hook failed.");
                    }
                } catch (Exception e) {
                    C14270pR.A0I("LyraManager", "Exception thrown during installing Lyra hook", e);
                }
            }
        }
    }
}
