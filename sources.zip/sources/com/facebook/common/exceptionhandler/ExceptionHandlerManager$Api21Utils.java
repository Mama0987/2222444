package com.facebook.common.exceptionhandler;

import X.AnonymousClass030;
import X.C004902x;
import android.system.ErrnoException;
import android.system.Os;
import java.io.File;
import java.io.FileDescriptor;
import java.io.InterruptedIOException;

public class ExceptionHandlerManager$Api21Utils {
    public static volatile C004902x sLogger;

    public static boolean canLog() {
        if (sLogger != null) {
            return true;
        }
        return false;
    }

    public static void onHandlerFinished(int i, int i2, String str) {
        if (sLogger != null) {
            C004902x r1 = sLogger;
            if (i > 126) {
                i = 127;
            }
            AnonymousClass030 r6 = r1.A00;
            byte b = (byte) i;
            if (r6.A00 != null) {
                byte[] bArr = r6.A02;
                bArr[0] = 5;
                bArr[1] = b;
                try {
                    Os.write(r6.A00, bArr, 0, AnonymousClass030.A00(r6, AnonymousClass030.A02(str, bArr, AnonymousClass030.A05(bArr, i2, 2), AnonymousClass030.A01(r6, 6, 1))));
                } catch (ErrnoException | InterruptedIOException unused) {
                }
            }
        }
    }

    public static void onHandlerStarted(int i, int i2) {
        if (sLogger != null) {
            C004902x r1 = sLogger;
            if (i > 126) {
                i = 127;
            }
            AnonymousClass030 r5 = r1.A00;
            byte b = (byte) i;
            FileDescriptor fileDescriptor = r5.A00;
            if (fileDescriptor != null) {
                byte[] bArr = r5.A02;
                bArr[0] = 7;
                bArr[1] = b;
                try {
                    Os.write(fileDescriptor, bArr, 0, AnonymousClass030.A00(r5, AnonymousClass030.A05(bArr, i2, 2)));
                } catch (ErrnoException | InterruptedIOException unused) {
                }
            }
        }
    }

    public static void onUncaughtException(String str, boolean z) {
        if (sLogger != null) {
            C004902x r1 = sLogger;
            if (z) {
                Runtime runtime = Runtime.getRuntime();
                AnonymousClass030 r9 = r1.A00;
                long freeMemory = runtime.freeMemory();
                long j = runtime.totalMemory();
                long maxMemory = runtime.maxMemory();
                if (r9.A00 != null) {
                    byte[] bArr = r9.A02;
                    bArr[0] = 6;
                    try {
                        Os.write(r9.A00, bArr, 0, AnonymousClass030.A00(r9, AnonymousClass030.A06(bArr, AnonymousClass030.A06(bArr, AnonymousClass030.A06(bArr, AnonymousClass030.A02(str, bArr, 1, AnonymousClass030.A01(r9, 25, 1)), freeMemory), j), maxMemory)));
                    } catch (ErrnoException | InterruptedIOException unused) {
                    }
                }
            } else {
                AnonymousClass030 r4 = r1.A00;
                if (r4.A00 != null) {
                    byte[] bArr2 = r4.A02;
                    bArr2[0] = 1;
                    Os.write(r4.A00, bArr2, 0, AnonymousClass030.A00(r4, AnonymousClass030.A02(str, bArr2, 1, AnonymousClass030.A01(r4, 1, 1))));
                }
            }
        }
    }

    public static void stopLogging() {
        if (sLogger != null) {
            AnonymousClass030 r4 = sLogger.A00;
            FileDescriptor fileDescriptor = r4.A00;
            if (fileDescriptor != null) {
                byte[] bArr = r4.A02;
                bArr[0] = 4;
                try {
                    Os.write(fileDescriptor, bArr, 0, AnonymousClass030.A00(r4, 1));
                } catch (ErrnoException | InterruptedIOException unused) {
                }
            }
            FileDescriptor fileDescriptor2 = r4.A00;
            if (fileDescriptor2 != null) {
                try {
                    Os.close(fileDescriptor2);
                } catch (ErrnoException unused2) {
                }
                r4.A00 = null;
            }
        }
    }

    public static void initLogging(File file) {
        sLogger = new C004902x(file.getAbsolutePath());
    }
}
