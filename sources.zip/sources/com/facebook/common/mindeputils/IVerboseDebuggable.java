package com.facebook.common.mindeputils;

public interface IVerboseDebuggable {
}
