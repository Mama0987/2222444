package com.facebook.common.mindeputils;

import java.util.concurrent.Callable;

public interface ILogPart extends Callable {
}
