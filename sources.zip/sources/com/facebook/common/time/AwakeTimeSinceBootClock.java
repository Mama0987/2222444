package com.facebook.common.time;

import X.C13980op;
import X.C14000os;

public class AwakeTimeSinceBootClock implements C13980op {
    public static final AwakeTimeSinceBootClock INSTANCE = new Object();

    public static AwakeTimeSinceBootClock get() {
        return INSTANCE;
    }

    public /* synthetic */ long now() {
        return C14000os.$default$now(this);
    }

    public long nowNanos() {
        return System.nanoTime();
    }
}
