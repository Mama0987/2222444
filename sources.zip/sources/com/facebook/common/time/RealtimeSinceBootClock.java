package com.facebook.common.time;

import X.C13970oo;
import android.os.SystemClock;
import java.util.concurrent.TimeUnit;

public class RealtimeSinceBootClock implements C13970oo {
    public static final RealtimeSinceBootClock A00 = new Object();

    public final long nowNanos() {
        return TimeUnit.MILLISECONDS.toNanos(now());
    }

    public static RealtimeSinceBootClock get() {
        return A00;
    }

    public final long now() {
        return SystemClock.elapsedRealtime();
    }
}
