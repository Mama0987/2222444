package com.facebook.common.callercontext;

public interface CallerContextable {
}
