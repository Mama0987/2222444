package com.facebook.common.perfcounter;

import X.AnonymousClass001;
import com.facebook.endtoend.EndToEnd;

public final class PerfCounter {
    public static volatile int A00 = -1;
    public static int A01;
    public static final Object A02 = AnonymousClass001.A0U();
    public static volatile boolean A03;

    public static final native boolean nativeBegin();

    public static final native void nativeEnd();

    public static final native void nativeReport(Object obj);

    public static final void A00() {
        synchronized (A02) {
            int i = A01;
            if (i != 0) {
                if (i == 1) {
                    nativeEnd();
                }
                A01--;
            }
        }
    }

    public static final boolean A01() {
        int i;
        if (A00 == -1) {
            if (!AnonymousClass001.A1X("/proc/sys/kernel/perf_event_paranoid") || (!EndToEnd.A04() && !AnonymousClass001.A1X("/data/local/tmp/ctscan_perfcounter_collect"))) {
                i = 0;
            } else {
                i = 1;
            }
            A00 = i;
        }
        if (A00 == 1) {
            return true;
        }
        return false;
    }
}
