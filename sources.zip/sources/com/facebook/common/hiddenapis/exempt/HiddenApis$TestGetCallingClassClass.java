package com.facebook.common.hiddenapis.exempt;

import X.AnonymousClass0RJ;
import X.C13140nB;
import android.os.Build;
import dalvik.system.VMStack;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import sun.reflect.Reflection;

public class HiddenApis$TestGetCallingClassClass {
    public static boolean testSunReflectGetCallingClass() {
        if (33 <= Build.VERSION.SDK_INT) {
            return false;
        }
        AnonymousClass0RJ unused = C13140nB.A0D;
        try {
            Class callerClass = Reflection.getCallerClass();
            Class<HiddenApis$TestGetCallingClassClass> cls = HiddenApis$TestGetCallingClassClass.class;
            if (!cls.equals(callerClass)) {
                C13140nB.A0D.A09("Cannot call sun.reflect.Reflection.getCallerClass on this platform. Got result: %s but expected: %s", callerClass, cls);
                return false;
            }
            AnonymousClass0RJ unused2 = C13140nB.A0D;
            return true;
        } catch (NoClassDefFoundError | NoSuchMethodError e) {
            C13140nB.A0D.A08("Cannot call sun.reflect.Reflection.getCallerClass on this platform", e);
            return false;
        }
    }

    public static boolean callAndCheckVMStackGetStackClass2(Method method) {
        AnonymousClass0RJ unused = C13140nB.A0D;
        Object[] objArr = {method.getDeclaringClass(), method.getName()};
        try {
            Class cls = (Class) method.invoke((Object) null, (Object[]) null);
            Class<HiddenApis$TestGetCallingClassClass> cls2 = HiddenApis$TestGetCallingClassClass.class;
            if (!cls2.equals(cls)) {
                C13140nB.A0D.A09("Cannot call %s.%s on this platform. Got result: %s but expected: %s", method.getDeclaringClass(), method.getName(), cls, cls2);
                return false;
            }
            AnonymousClass0RJ unused2 = C13140nB.A0D;
            Object[] objArr2 = {method.getDeclaringClass(), method.getName()};
            return true;
        } catch (ClassCastException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            C13140nB.A0D.A0C(e, "Cannot call %s.%s on this platform", method.getDeclaringClass(), method.getName());
            return false;
        }
    }

    public static boolean testJdkInternalReflectGetCallingClass() {
        AnonymousClass0RJ unused = C13140nB.A0D;
        try {
            Class callerClass = jdk.internal.reflect.Reflection.getCallerClass();
            Class<HiddenApis$TestGetCallingClassClass> cls = HiddenApis$TestGetCallingClassClass.class;
            if (!cls.equals(callerClass)) {
                C13140nB.A0D.A09("Cannot call jdk.internal.reflect.Reflection.getCallerClass on this platform. Got result: %s but expected: %s", callerClass, cls);
                return false;
            }
            AnonymousClass0RJ unused2 = C13140nB.A0D;
            return true;
        } catch (Throwable th) {
            C13140nB.A0D.A08("Cannot call jdk.internal.reflect.Reflection.getCallerClass on this platform", th);
            return false;
        }
    }

    public static boolean testVMStackGetCallingClassLoader() {
        AnonymousClass0RJ unused = C13140nB.A0D;
        try {
            ClassLoader callingClassLoader = VMStack.getCallingClassLoader();
            ClassLoader classLoader = HiddenApis$TestGetCallingClassClass.class.getClassLoader();
            if (classLoader == null || !classLoader.equals(callingClassLoader)) {
                C13140nB.A0D.A09("Cannot call VMStack.getCallingClassLoader on this platform. Got result: %s but expected: %s", callingClassLoader, classLoader);
                return false;
            }
            AnonymousClass0RJ unused2 = C13140nB.A0D;
            return false;
        } catch (NoClassDefFoundError | NoSuchMethodError e) {
            C13140nB.A0D.A08("Cannot call VMStack.getCallingClassLoader on this platform", e);
            return false;
        }
    }
}
