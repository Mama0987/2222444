package com.facebook.common.jit.common;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MethodInfo {
    public static final Map PRIMITIVE_TO_SIGNATURE;
    public static final Map SIGNATURE_TO_PRIMITIVE;
    public final Class cls;
    public final Constructor constructor;
    public final Method method;
    public final String name;
    public final String signature;

    /* JADX WARNING: CFG modification limit reached, blocks count: 164 */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0069, code lost:
        if (r4 != 'L') goto L_0x002a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x006b, code lost:
        r5 = r14.indexOf(59, r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0071, code lost:
        if (r5 < 0) goto L_0x002a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0073, code lost:
        r0 = r2 + 1;
        r4 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0076, code lost:
        if (r5 <= r0) goto L_0x002a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
        r4 = java.lang.Class.forName(r14.substring(r0, r5).replace('/', '.'));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00ad, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:?, code lost:
        android.util.Log.w("JitMethodInfo", java.lang.String.format("Cannot find class: %s for method: %s sig: %s", new java.lang.Object[]{r12, r13, r14}), r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00bb, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00bc, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00bd, code lost:
        android.util.Log.w("JitMethodInfo", java.lang.String.format("Programming Error: class: %s for method: %s sig: %s", new java.lang.Object[]{r12, r13, r14}), r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00ca, code lost:
        return null;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00ad A[ExcHandler: ClassNotFoundException | NoClassDefFoundError (r2v0 'e' java.lang.Throwable A[CUSTOM_DECLARE]), Splitter:B:4:0x000a] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00bc A[ExcHandler: Error | RuntimeException (r2v1 'e' java.lang.Throwable A[CUSTOM_DECLARE]), Splitter:B:52:0x00b0] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.facebook.common.jit.common.MethodInfo getMethod(java.lang.String r12, java.lang.String r13, java.lang.String r14) {
        /*
            r11 = 0
            r0 = 0
            java.lang.String r3 = "JitMethodInfo"
            if (r12 == 0) goto L_0x00cb
            if (r13 == 0) goto L_0x00cb
            if (r14 == 0) goto L_0x00cb
            java.lang.Class r6 = java.lang.Class.forName(r12)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            char r1 = r14.charAt(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            r0 = 40
            if (r1 != r0) goto L_0x002a
            r0 = 41
            int r8 = r14.indexOf(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r8 < 0) goto L_0x002a
            java.util.ArrayList r7 = X.AnonymousClass001.A0t()     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            r2 = 1
            goto L_0x003a
        L_0x0024:
            boolean r0 = addArrayType(r7, r0, r9)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r0 != 0) goto L_0x0038
        L_0x002a:
            java.lang.String r1 = "Cannot find class: %s for method: %s sig: %s. Cannot parse sig"
            java.lang.Object[] r0 = new java.lang.Object[]{r12, r13, r14}     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.String r0 = java.lang.String.format(r1, r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            android.util.Log.w(r3, r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            goto L_0x00ac
        L_0x0038:
            int r2 = r2 + 1
        L_0x003a:
            if (r2 >= r8) goto L_0x0099
            char r4 = r14.charAt(r2)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            r9 = 0
        L_0x0041:
            r0 = 91
            if (r4 != r0) goto L_0x004e
            int r9 = r9 + 1
            int r2 = r2 + 1
            char r4 = r14.charAt(r2)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            goto L_0x0041
        L_0x004e:
            r10 = 0
            if (r9 <= 0) goto L_0x0052
            r10 = 1
        L_0x0052:
            java.util.Map r1 = SIGNATURE_TO_PRIMITIVE     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Character r0 = java.lang.Character.valueOf(r4)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Object r0 = r1.get(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Class r0 = (java.lang.Class) r0     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r0 == 0) goto L_0x0067
            if (r10 == 0) goto L_0x0063
            goto L_0x0024
        L_0x0063:
            r7.add(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            goto L_0x0038
        L_0x0067:
            r0 = 76
            if (r4 != r0) goto L_0x002a
            r0 = 59
            int r5 = r14.indexOf(r0, r2)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r5 < 0) goto L_0x002a
            int r0 = r2 + 1
            r4 = 0
            if (r5 <= r0) goto L_0x002a
            java.lang.String r2 = r14.substring(r0, r5)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            r1 = 47
            r0 = 46
            java.lang.String r0 = r2.replace(r1, r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Class r4 = java.lang.Class.forName(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x0088, ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
        L_0x0088:
            if (r4 == 0) goto L_0x002a
            if (r10 == 0) goto L_0x0093
            boolean r0 = addArrayType(r7, r4, r9)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r0 != 0) goto L_0x0096
            goto L_0x002a
        L_0x0093:
            r7.add(r4)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
        L_0x0096:
            int r2 = r5 + 1
            goto L_0x003a
        L_0x0099:
            int r0 = r7.size()     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Class[] r0 = new java.lang.Class[r0]     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Object[] r0 = r7.toArray(r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            java.lang.Class[] r0 = (java.lang.Class[]) r0     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            if (r0 == 0) goto L_0x002a
            com.facebook.common.jit.common.MethodInfo r11 = getMethod((java.lang.Class) r6, (java.lang.String) r13, (java.lang.Class[]) r0)     // Catch:{ ClassNotFoundException | NoClassDefFoundError -> 0x00ad }
            return r11
        L_0x00ac:
            return r11
        L_0x00ad:
            r2 = move-exception
            java.lang.String r1 = "Cannot find class: %s for method: %s sig: %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r12, r13, r14}     // Catch:{ Error | RuntimeException -> 0x00bc, Error | RuntimeException -> 0x00bc }
            java.lang.String r0 = java.lang.String.format(r1, r0)     // Catch:{ Error | RuntimeException -> 0x00bc, Error | RuntimeException -> 0x00bc }
            android.util.Log.w(r3, r0, r2)     // Catch:{ Error | RuntimeException -> 0x00bc, Error | RuntimeException -> 0x00bc }
            return r11
        L_0x00bc:
            r2 = move-exception
            java.lang.Object[] r1 = new java.lang.Object[]{r12, r13, r14}
            java.lang.String r0 = "Programming Error: class: %s for method: %s sig: %s"
            java.lang.String r0 = java.lang.String.format(r0, r1)
            android.util.Log.w(r3, r0, r2)
            return r11
        L_0x00cb:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.jit.common.MethodInfo.getMethod(java.lang.String, java.lang.String, java.lang.String):com.facebook.common.jit.common.MethodInfo");
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0031 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r4) {
        /*
            r3 = this;
            r2 = 0
            if (r4 == 0) goto L_0x0032
            boolean r0 = r4 instanceof com.facebook.common.jit.common.MethodInfo
            if (r0 == 0) goto L_0x0032
            com.facebook.common.jit.common.MethodInfo r4 = (com.facebook.common.jit.common.MethodInfo) r4
            java.lang.Class r1 = r3.cls
            java.lang.Class r0 = r4.cls
            if (r1 != 0) goto L_0x004f
            if (r0 != 0) goto L_0x0032
        L_0x0011:
            java.lang.reflect.Method r1 = r3.method
            java.lang.reflect.Method r0 = r4.method
            if (r1 != 0) goto L_0x0048
            if (r0 != 0) goto L_0x0032
        L_0x0019:
            java.lang.reflect.Constructor r1 = r3.constructor
            java.lang.reflect.Constructor r0 = r4.constructor
            if (r1 != 0) goto L_0x0041
            if (r0 != 0) goto L_0x0032
        L_0x0021:
            java.lang.String r1 = r3.name
            java.lang.String r0 = r4.name
            if (r1 != 0) goto L_0x003a
            if (r0 != 0) goto L_0x0032
        L_0x0029:
            java.lang.String r1 = r3.signature
            java.lang.String r0 = r4.signature
            if (r1 != 0) goto L_0x0033
            if (r0 != 0) goto L_0x0032
        L_0x0031:
            r2 = 1
        L_0x0032:
            return r2
        L_0x0033:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x0032
            goto L_0x0031
        L_0x003a:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x0032
            goto L_0x0029
        L_0x0041:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x0032
            goto L_0x0021
        L_0x0048:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x0032
            goto L_0x0019
        L_0x004f:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x0032
            goto L_0x0011
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.jit.common.MethodInfo.equals(java.lang.Object):boolean");
    }

    static {
        HashMap hashMap = new HashMap(9);
        PRIMITIVE_TO_SIGNATURE = hashMap;
        AnonymousClass002.A0m(hashMap);
        hashMap.put(Void.TYPE, "V");
        hashMap.put(Boolean.TYPE, "Z");
        HashMap hashMap2 = new HashMap(9);
        SIGNATURE_TO_PRIMITIVE = hashMap2;
        hashMap2.put('B', Byte.TYPE);
        hashMap2.put('C', Character.TYPE);
        hashMap2.put('S', Short.TYPE);
        hashMap2.put('I', Integer.TYPE);
        hashMap2.put('J', Long.TYPE);
        hashMap2.put('F', Float.TYPE);
        hashMap2.put('D', Double.TYPE);
        hashMap2.put('V', Void.TYPE);
        hashMap2.put('Z', Boolean.TYPE);
    }

    public static boolean addArrayType(List list, Class cls2, int i) {
        if (i > 0) {
            StringBuilder A0m = AnonymousClass001.A0m();
            int i2 = 0;
            do {
                A0m.append('[');
                i2++;
            } while (i2 < i);
            String obj = A0m.toString();
            String A0e = AnonymousClass001.A0e(cls2, PRIMITIVE_TO_SIGNATURE);
            StringBuilder A0m2 = AnonymousClass001.A0m();
            if (A0e != null) {
                A0m2.append(obj);
            } else {
                A0m2.append(obj);
                A0m2.append("L");
                A0m2.append(cls2.getName());
                A0e = ";";
            }
            A0m2.append(A0e);
            String obj2 = A0m2.toString();
            try {
                Class<?> cls3 = Class.forName(obj2);
                if (cls3 == null) {
                    return false;
                }
                list.add(cls3);
                return true;
            } catch (ClassNotFoundException | NoClassDefFoundError e) {
                Log.w("JitMethodInfo", String.format("Cannot find array class: %s", new Object[]{obj2}), e);
                return false;
            }
        } else {
            throw AnonymousClass0WY.A05("Array count ", " is not valid", i);
        }
    }

    public static String getSignatureFromType(Class cls2) {
        String str;
        String A0e = AnonymousClass001.A0e(cls2, PRIMITIVE_TO_SIGNATURE);
        if (A0e != null) {
            return A0e;
        }
        boolean isArray = cls2.isArray();
        StringBuilder A0m = AnonymousClass001.A0m();
        if (isArray) {
            A0m.append("[");
            str = getSignatureFromType(cls2.getComponentType());
        } else {
            A0m.append("L");
            A0m.append(cls2.getName().replace('.', '/'));
            str = ";";
        }
        return AnonymousClass001.A0g(str, A0m);
    }

    public int hashCode() {
        int i;
        int i2 = 0;
        int hashCode = ((((this.cls.hashCode() * 31) + AnonymousClass002.A04(this.method)) * 31) + AnonymousClass002.A04(this.constructor)) * 31;
        String str = this.name;
        if (str != null) {
            i = str.hashCode();
        } else {
            i = 0;
        }
        int i3 = (hashCode + i) * 31;
        String str2 = this.signature;
        if (str2 != null) {
            i2 = str2.hashCode();
        }
        return i3 + i2;
    }

    public String toString() {
        String str;
        StringBuilder A0p = AnonymousClass001.A0p("[ MethodInfo ");
        A0p.append("cls: ");
        Class cls2 = this.cls;
        String str2 = "<null>";
        if (cls2 != null) {
            str2 = cls2.getName();
        }
        A0p.append(str2);
        A0p.append(", ");
        Executable executable = this.method;
        if (executable != null) {
            str = "method: ";
        } else {
            executable = this.constructor;
            if (executable != null) {
                str = "constructor: ";
            }
            A0p.append("name: ");
            A0p.append(this.name);
            A0p.append(", ");
            A0p.append("signature: ");
            A0p.append(this.signature);
            return AnonymousClass002.A0O(A0p);
        }
        A0p.append(str);
        A0p.append(executable.getName());
        A0p.append(", ");
        A0p.append("name: ");
        A0p.append(this.name);
        A0p.append(", ");
        A0p.append("signature: ");
        A0p.append(this.signature);
        return AnonymousClass002.A0O(A0p);
    }

    public MethodInfo(Class cls2, Constructor constructor2, String str, String str2) {
        this.cls = cls2;
        this.method = null;
        this.constructor = constructor2;
        this.name = str;
        this.signature = str2;
    }

    public static String getSignature(Class[] clsArr, Class cls2) {
        StringBuilder A0S = AnonymousClass002.A0S();
        for (Class signatureFromType : clsArr) {
            A0S.append(getSignatureFromType(signatureFromType));
        }
        A0S.append(')');
        return AnonymousClass001.A0g(getSignatureFromType(cls2), A0S);
    }

    public MethodInfo(Class cls2, String str, String str2) {
        this.cls = cls2;
        this.method = null;
        this.constructor = null;
        this.name = str;
        this.signature = str2;
    }

    public static MethodInfo getMethod(Class cls2, String str, Class... clsArr) {
        Constructor constructor2;
        Class superclass;
        Class cls3;
        if (cls2 != null) {
            if ("<clinit>".equals(str)) {
                return new MethodInfo(cls2, str, getSignature(clsArr, Void.TYPE));
            }
            if (!"<init>".equals(str)) {
                Class cls4 = cls2;
                do {
                    try {
                        Method declaredMethod = cls2.getDeclaredMethod(str, clsArr);
                        if (declaredMethod != null) {
                            return new MethodInfo(cls2, declaredMethod, str, getSignature(declaredMethod.getParameterTypes(), declaredMethod.getReturnType()));
                        }
                    } catch (NoSuchMethodException unused) {
                    }
                    superclass = cls4.getSuperclass();
                    cls3 = cls4;
                    cls4 = superclass;
                    if (superclass == null) {
                        break;
                    }
                } while (superclass != cls3);
                Arrays.toString(clsArr);
                Arrays.toString(clsArr);
            } else {
                try {
                    constructor2 = cls2.getDeclaredConstructor(clsArr);
                    if (constructor2 != null) {
                        return new MethodInfo(cls2, constructor2, str, getSignature(constructor2.getParameterTypes(), Void.TYPE));
                    }
                } catch (NoSuchMethodException unused2) {
                }
                if (cls2.getEnclosingClass() != null) {
                    int length = clsArr.length;
                    int i = length + 1;
                    if (i < i) {
                        throw AnonymousClass001.A0L("Dest array is not big enough");
                    } else if (length >= length) {
                        for (int i2 = 0; i2 < length; i2++) {
                        }
                        try {
                            constructor2 = cls2.getDeclaredConstructor(clsArr);
                            if (constructor2 == null) {
                                Arrays.toString(clsArr);
                                return null;
                            }
                            return new MethodInfo(cls2, constructor2, str, getSignature(constructor2.getParameterTypes(), Void.TYPE));
                        } catch (NoSuchMethodException unused3) {
                        }
                    } else {
                        throw AnonymousClass001.A0L("Src array lacks the num of needed elements");
                    }
                }
            }
        }
        return null;
    }

    public MethodInfo(Class cls2, Method method2, String str, String str2) {
        this.cls = cls2;
        this.method = method2;
        this.constructor = null;
        this.name = str;
        this.signature = str2;
    }

    public MethodInfo() {
        this.cls = null;
        this.method = null;
        this.constructor = null;
        this.name = null;
        this.signature = null;
    }
}
