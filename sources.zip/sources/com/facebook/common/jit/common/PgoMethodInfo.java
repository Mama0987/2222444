package com.facebook.common.jit.common;

import X.AnonymousClass001;
import X.AnonymousClass002;

public class PgoMethodInfo {
    public final int count;
    public final boolean hasExtraInfo;
    public final MethodInfo methodInfo;
    public final int methodSize;
    public final double topKUsedPercentage;
    public final double usedPercent;

    public String toString() {
        StringBuilder A0p = AnonymousClass001.A0p("[ PgoMethodInfo ");
        A0p.append("methodInfo: ");
        A0p.append(this.methodInfo);
        A0p.append(", ");
        A0p.append("hasExtraInfo: ");
        boolean z = this.hasExtraInfo;
        A0p.append(z);
        A0p.append(" ");
        if (z) {
            A0p.append("[ ");
            A0p.append("count: ");
            A0p.append(this.count);
            A0p.append(", ");
            A0p.append("methodSize: ");
            A0p.append(this.methodSize);
            A0p.append(", ");
            A0p.append("usedPercent: ");
            A0p.append(this.usedPercent);
            A0p.append(", ");
            A0p.append("topKUsedPercentage: ");
            A0p.append(this.topKUsedPercentage);
            A0p.append(" ]");
        }
        return AnonymousClass002.A0O(A0p);
    }

    public PgoMethodInfo(MethodInfo methodInfo2) {
        this.methodInfo = methodInfo2;
        this.hasExtraInfo = false;
        this.count = 0;
        this.methodSize = 0;
        this.usedPercent = 0.0d;
        this.topKUsedPercentage = 0.0d;
    }

    public PgoMethodInfo(MethodInfo methodInfo2, int i, int i2, double d, double d2) {
        this.methodInfo = methodInfo2;
        this.hasExtraInfo = true;
        this.count = i;
        this.methodSize = i2;
        this.usedPercent = d;
        this.topKUsedPercentage = d2;
    }
}
