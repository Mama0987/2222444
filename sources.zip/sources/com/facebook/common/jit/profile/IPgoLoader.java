package com.facebook.common.jit.profile;

public interface IPgoLoader {
    boolean load();
}
