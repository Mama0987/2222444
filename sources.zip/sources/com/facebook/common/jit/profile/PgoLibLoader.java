package com.facebook.common.jit.profile;

import X.C13290nb;
import X.C18440x7;

public final class PgoLibLoader implements IPgoLoader {
    public static final C13290nb Companion = new Object();
    public static final String TAG = "PgoLibLoader";

    public boolean load() {
        try {
            C18440x7.loadLibrary("fbpgojni");
            return true;
        } catch (UnsatisfiedLinkError unused) {
            return false;
        }
    }
}
