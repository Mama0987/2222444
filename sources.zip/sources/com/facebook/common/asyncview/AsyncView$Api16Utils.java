package com.facebook.common.asyncview;

import X.AnonymousClass0J0;
import X.AnonymousClass0QF;
import android.view.Choreographer;

public final class AsyncView$Api16Utils {
    public static Choreographer.FrameCallback makeFrameCallback(AnonymousClass0QF r1) {
        r1.getClass();
        return new AnonymousClass0J0(r1);
    }

    public static void postFrameCallback(Choreographer.FrameCallback frameCallback) {
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    public static void removeFrameCallback(Choreographer.FrameCallback frameCallback) {
        Choreographer.getInstance().removeFrameCallback(frameCallback);
    }
}
