package com.facebook.common.errorreporting.extranslators;

import libcore.io.ErrnoException;
import libcore.io.OsConstants;

public final class ErrnoUtil {

    public final class Api11Utils {
        public static int errnoFromException(Throwable th) {
            if (th instanceof ErrnoException) {
                return ((ErrnoException) th).errno;
            }
            return -1;
        }

        public static String errnoName(int i) {
            return OsConstants.errnoName(i);
        }
    }

    public final class Api21Utils {
        public static int errnoFromException(Throwable th) {
            if (th instanceof android.system.ErrnoException) {
                return ((android.system.ErrnoException) th).errno;
            }
            return -1;
        }

        public static String errnoName(int i) {
            return android.system.OsConstants.errnoName(i);
        }
    }

    public static int errnoFromException(Throwable th) {
        return Api21Utils.errnoFromException(th);
    }

    public static String errnoName(int i) {
        return Api21Utils.errnoName(i);
    }
}
