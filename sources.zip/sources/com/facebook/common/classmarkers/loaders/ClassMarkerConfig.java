package com.facebook.common.classmarkers.loaders;

public interface ClassMarkerConfig {
    boolean androidGenerateClassMarkers();
}
