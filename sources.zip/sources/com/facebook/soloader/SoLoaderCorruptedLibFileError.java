package com.facebook.soloader;

public class SoLoaderCorruptedLibFileError extends SoLoaderULError {
    public SoLoaderCorruptedLibFileError(String str, String str2) {
        super(str, str2);
    }

    public SoLoaderCorruptedLibFileError(String str) {
        super(str);
    }
}
