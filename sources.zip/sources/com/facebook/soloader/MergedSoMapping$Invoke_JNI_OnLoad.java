package com.facebook.soloader;

public class MergedSoMapping$Invoke_JNI_OnLoad {
    public static native int libAttachmentPathPluginjni_so();

    public static native int libChannelHealthAppHttpProberPluginjni_so();

    public static native int libConnectionContextProviderPluginjni_so();

    public static native int libContiguousFramesTracker_so();

    public static native int libFB4AMediaReceiverFetchPluginjni_so();

    public static native int libFBAdvancedCryptoTransportReinstallDataProviderPluginjni_so();

    public static native int libFBMessagingDasmConfigCreator_jni_so();

    public static native int libFBMessagingDatabaseRedactor_jni_so();

    public static native int libFBMessagingDatabaseSchemaDeployer_acg_so();

    public static native int libFBMessagingDatabaseSchemaDeployer_jni_so();

    public static native int libFBMessagingDatabaseSchemaDeployer_jninovt_so();

    public static native int libFBMessagingDatabaseSchemaDeployer_so();

    public static native int libFBMessagingDatabaseSchemaDeployernovt_so();

    public static native int libFBMessagingTableToCqlProcRegistration_jni_so();

    public static native int libLoadGeneratorPluginjni_so();

    public static native int libMCIAppExperimentsPluginjni_so();

    public static native int libMDCoreSchemaDeployer_acg_so();

    public static native int libMDCoreSchemaDeployer_so();

    public static native int libMDCoreSchemaDeployernovt_so();

    public static native int libMEMMobileConfigPlatformMibAndroidPluginjni_so();

    public static native int libMemEncryptedBackupsDatabaseSchemaDeployer_acg_so();

    public static native int libMemEncryptedBackupsDatabaseSchemaDeployer_so();

    public static native int libMemEncryptedBackupsDatabaseSchemaDeployernovt_so();

    public static native int libMessengerEchoQueriesCQLTestHelpers_so();

    public static native int libMessengerEncryptedMessagingCryptoDatabaseSchemaDeployer_acg_so();

    public static native int libMessengerEncryptedMessagingCryptoDatabaseSchemaDeployer_so();

    public static native int libMessengerEncryptedMessagingCryptoDatabaseSchemaDeployernovt_so();

    public static native int libMessengerEncryptedMessagingIncomingDatabaseSchemaDeployer_acg_so();

    public static native int libMessengerEncryptedMessagingIncomingDatabaseSchemaDeployer_so();

    public static native int libMessengerEncryptedMessagingIncomingDatabaseSchemaDeployernovt_so();

    public static native int libMessengerEncryptedMessagingReverbDatabaseSchemaDeployer_acg_so();

    public static native int libMessengerEncryptedMessagingReverbDatabaseSchemaDeployer_so();

    public static native int libMessengerEncryptedMessagingReverbDatabaseSchemaDeployernovt_so();

    public static native int libMessengerMediaPlatformHelpersPluginjni_so();

    public static native int libMessengerShimCQLTestHelpers_so();

    public static native int libMessengerTamCQLTestHelpers_so();

    public static native int libMsysAdvancedMediaTranscoderPluginjni_so();

    public static native int libMsysAnalyticsPluginjni_so();

    public static native int libMsysAuthDataStoragePluginjni_so();

    public static native int libMsysCoreLocalUserSettingsCQLGeneratedTestHelpers_so();

    public static native int libMsysCryptoPluginjni_so();

    public static native int libMsysDeviceBackupPluginjni_so();

    public static native int libMsysExperimentCachePluginjni_so();

    public static native int libMsysExperimentPluginjni_so();

    public static native int libMsysFileManagerPluginjni_so();

    public static native int libMsysInstacrashRemedyPluginjni_so();

    public static native int libMsysLocalizationPluginjni_so();

    public static native int libMsysMobileConfigAdminIdPluginjni_so();

    public static native int libMsysMobileConfigSessionedPluginjni_so();

    public static native int libMsysSettingsPluginjni_so();

    public static native int libMsysTamStorageDirectoryPluginjni_so();

    public static native int libS2SComponentLoggerPluginjni_so();

    public static native int libSearchDatabaseSchemaDeployer_acg_so();

    public static native int libSearchDatabaseSchemaDeployer_so();

    public static native int libSearchDatabaseSchemaDeployernovt_so();

    public static native int libVideoJni_so();

    public static native int libaborthooks_so();

    public static native int libaddressspace_so();

    public static native int libadvancedcryptotransport_jni_so();

    public static native int libanalyticsutil_jni_so();

    public static native int libandroid_aware_dlopen_so();

    public static native int libandroid_reachability_announcer_so();

    public static native int libandroid_video_protocol_eventlog_so();

    public static native int libappmodules_so();

    public static native int libappnetsessionid_so();

    public static native int libappnetsessionidinterceptor_so();

    public static native int libappstatelogger2_so();

    public static native int libappstatesyncer_jni_so();

    public static native int libarclassBenchmark_so();

    public static native int libarclass_so();

    public static native int libard_android_async_asset_fetcher_listener_so();

    public static native int libard_android_async_asset_fetcher_so();

    public static native int libard_android_effect_manager_so();

    public static native int libard_android_listener_so();

    public static native int libard_android_model_metadata_manager_so();

    public static native int libard_android_network_consent_manager_impl_so();

    public static native int libard_android_network_consent_manager_interf_so();

    public static native int libard_async_downloader_so();

    public static native int libard_cacheprovider_so();

    public static native int libard_connection_info_so();

    public static native int libard_models_so();

    public static native int libard_remote_model_fetch_callback_so();

    public static native int libard_scripting_downloader_so();

    public static native int libard_spark_vision_downloader_so();

    public static native int libardcache_jni_so();

    public static native int libardcache_stash_so();

    public static native int libarengineservicesutils_so();

    public static native int libarfx_engine_plugin_avatars_so();

    public static native int libarfx_engine_plugin_touch_gestures_so();

    public static native int libarlogridjni_so();

    public static native int libarpersistenceservice_so();

    public static native int libartsmartgc_so();

    public static native int libarvr_libraries_avatar_stable_branches_v35_staging_Libraries_avatar_live_editing_avatar_live_editing_min_size_so();

    public static native int libasyncexecutor_so();

    public static native int libasyncgraphstoreservice_so();

    public static native int libaten_vulkan_so();

    public static native int libaudiograph_native_so();

    public static native int libaudiographservice_so();

    public static native int libavatarsdataprovider_so();

    public static native int libbackground_so();

    public static native int libbase64_so();

    public static native int libbatch_box_cox_ops_xplat_so();

    public static native int libbinderhookerjni_so();

    public static native int libbodytrackingdataprovider_so();

    public static native int libbreakpad_so();

    public static native int libbundled_input_image_decoder_ops_xplat_so();

    public static native int libbwemanager_so();

    public static native int libcancalljavautils_so();

    public static native int libcatalyst_mobileconfigmodule_so();

    public static native int libcatalystcomponents_so();

    public static native int libchatddgw_jni_so();

    public static native int libchipset_so();

    public static native int libclassid1000_so();

    public static native int libclassid1100_so();

    public static native int libclassid800_so();

    public static native int libclassid810_so();

    public static native int libclassid900_so();

    public static native int libclassid_so();

    public static native int libclasstracing_so();

    public static native int libclickid_so();

    public static native int libcomponents_loggerMCFBridgejni_so();

    public static native int libconcealcpp_so();

    public static native int libconcealjni_so();

    public static native int libcongestionmanager_so();

    public static native int libconnectiontypeinterceptor_jni_so();

    public static native int libcrosscorrelationAndroid_so();

    public static native int libcryptojni_so();

    public static native int libcryptopub_jni_so();

    public static native int libcryptopub_so();

    public static native int libcryptox_so();

    public static native int libctaudioprocessor_native_so();

    public static native int libctaudiosync_native_so();

    public static native int libctautoenhance_native_so();

    public static native int libctvoiceeffectprocessor_native_so();

    public static native int libdalviksmartgc_so();

    public static native int libdatabaseMCFBridgejni_so();

    public static native int libdevice_store_provider_so();

    public static native int libdextricks_reflection_so();

    public static native int libdextricks_so();

    public static native int libdistract_common_funcs_so();

    public static native int libdistract_common_museum_funcs_800_so();

    public static native int libdistract_common_museum_funcs_810_so();

    public static native int libdistract_so();

    public static native int libdistractutil_so();

    public static native int libdistribgw_jni_so();

    public static native int libdistribgw_mns_jni_so();

    public static native int libdistribgw_tigon_jni_so();

    public static native int libdouble_conversion_so();

    public static native int libdsrinterceptor_so();

    public static native int libdynamic_pytorch_impl_so();

    public static native int libdynamicblendedvipinterceptor_so();

    public static native int libelf_so();

    public static native int libelflookuphelper_so();

    public static native int libenigma_so();

    public static native int libexpressionfittingdataprovider_so();

    public static native int libexpressiontracking_so();

    public static native int libfabricjni_so();

    public static native int libfb_ffmpeg_2_8_20_so();

    public static native int libfb_ffmpeg_jni_2_8_20_so();

    public static native int libfb_graphqlrt_subscription_jni_so();

    public static native int libfb_so();

    public static native int libfb_sqlite_3470000_so();

    public static native int libfb_xzdecoder_so();

    public static native int libfbacore_jni_so();

    public static native int libfbacoreimpl_so();

    public static native int libfbandroid_java_com_facebook_cameracore_ardelivery_xplat_assetmanager_jni_jni_so();

    public static native int libfbandroid_java_com_facebook_cameracore_mediapipeline_arclass_benchmark_interfaces_jni_jni_so();

    public static native int libfbandroid_java_com_facebook_cameracore_mediapipeline_dataproviders_javascriptmodules_implementation_jni_jni_so();

    public static native int libfbandroid_java_com_facebook_cameracore_mediapipeline_engine_assets_texture_fbfresco_jni_jni_so();

    public static native int libfbandroid_java_com_facebook_cameracore_mediapipeline_services_touch_implementation_jni_jni_so();

    public static native int libfbandroid_java_com_facebook_cameracore_mediapipeline_services_touch_interfaces_jni_jni_so();

    public static native int libfbandroid_libraries_profilo_cpp_providers_so();

    public static native int libfbbacktrace_so();

    public static native int libfbbindingsjni_so();

    public static native int libfbcalculator_so();

    public static native int libfbcalculatorprovider_so();

    public static native int libfbgloginit_so();

    public static native int libfbhttpprioritycontext_so();

    public static native int libfbimageblur_so();

    public static native int libfbjitjni_so();

    public static native int libfbjitoptionsjni_so();

    public static native int libfbjitshared_so();

    public static native int libfbjni_kt_so();

    public static native int libfbjni_so();

    public static native int libfbmapscache_so();

    public static native int libfbmapsttrc_so();

    public static native int libfbmessagingmessagelistchildresultsetutils_so();

    public static native int libfbmessagingthreadlistchildresultsetutils_so();

    public static native int libfbmobileproberjob_so();

    public static native int libfbpayptt_android_so();

    public static native int libfbpgojni_so();

    public static native int libfbreact_i18nassetsmodule_so();

    public static native int libfbsofterror_so();

    public static native int libfbsphericalprocessing_so();

    public static native int libfbsystrace_so();

    public static native int libfbwolfservice_so();

    public static native int libfdidinterceptor_so();

    public static native int libfeatureconfig_so();

    public static native int libfeed_imageloader_jni_so();

    public static native int libffqplbridge_so();

    public static native int libfgbg_provider_so();

    public static native int libfilters_native_android_so();

    public static native int libfittedexpressiontracking_so();

    public static native int libflatbuffers_so();

    public static native int libflatbuffersflatc_so();

    public static native int libflexlayout_so();

    public static native int libflipper_live_data_provider_impl_jni_so();

    public static native int libflipper_live_plugin_jni_so();

    public static native int libfmt_so();

    public static native int libforce_dlopen_so();

    public static native int libforker_so();

    public static native int libframeratelimiter_jni_so();

    public static native int libfssync_so();

    public static native int libfury_so();

    public static native int libgifimage_so();

    public static native int libgktogglelist_so();

    public static native int libglog_so();

    public static native int libgltfholdernew_so();

    public static native int libgputimer_jni_so();

    public static native int libgraphbase_so();

    public static native int libgraphicsengine_arengineservices_fb4aeffectservicehost_native_so();

    public static native int libgraphicsengine_fb4a_native_so();

    public static native int libgraphql_post_processor_so();

    public static native int libgraphqllivequeriessdk_so();

    public static native int libgraphqlrealtimeservice_jni_so();

    public static native int libgraphqlrt_subscription_jni_so();

    public static native int libgraphqlservice_so();

    public static native int libgraphqlsubscriptionssdk_so();

    public static native int libgraphservice_jni_asset_so();

    public static native int libgraphservice_jni_facebook_so();

    public static native int libgraphservice_jni_factory_so();

    public static native int libgraphservice_jni_mutations_so();

    public static native int libgraphservice_jni_nativeconfig_so();

    public static native int libgraphservice_jni_nativeconfigloader_so();

    public static native int libgraphservice_jni_serialization_so();

    public static native int libgraphservice_jni_so();

    public static native int libgraphservice_jni_tree_so();

    public static native int libgraphstore_so();

    public static native int libgraphstorecache_so();

    public static native int libgraphstorecereal_so();

    public static native int libgraphstorecerealutil_so();

    public static native int libgraphutil_so();

    public static native int libhairsegmentationdataprovider_so();

    public static native int libhandtrackingdataprovider_so();

    public static native int libheader_injector_so();

    public static native int libhermes_crashmanager_experimental_sh_staging_so();

    public static native int libhermes_crashmanager_so();

    public static native int libhermes_executor_so();

    public static native int libhermesinstancejni_experimental_sh_staging_so();

    public static native int libhermesinstancejni_so();

    public static native int libhiddenapis2_so();

    public static native int libhprofsanitizer_so();

    public static native int libhprofsanitizercommon_so();

    public static native int libhttp_provider_so();

    public static native int libhybridlogsinkjni_so();

    public static native int libimagepipeline_so();

    public static native int libimageprocutils_so();

    public static native int libiopri_jni_so();

    public static native int libjava2js_slow_so();

    public static native int libjava2js_so();

    public static native int libjavamemmetrics_so();

    public static native int libjavamemtracking800_so();

    public static native int libjavamemtracking810_so();

    public static native int libjavamemtracking900_so();

    public static native int libjni_mcpintegration_mcp_integration_fban634998794PluginRegistry_so();

    public static native int libjniexecutors_so();

    public static native int libjnilwqpl_so();

    public static native int libjniperflogger_so();

    public static native int libjniuserflow_so();

    public static native int libjsijniprofiler_so();

    public static native int libjsimodulejni_so();

    public static native int liblacrimamobileconfig_jni_so();

    public static native int libliger_multiconnector_so();

    public static native int libliger_native_so();

    public static native int libliger_so();

    public static native int liblimitstack_so();

    public static native int liblinkerutils_so();

    public static native int liblive_query_impl_common_jni_so();

    public static native int liblive_query_jni_so();

    public static native int liblive_query_rs_impl_jni_so();

    public static native int liblivequery_auxiliary_jni_so();

    public static native int liblocationdataprovider_so();

    public static native int liblockfreecounter_so();

    public static native int liblogger_provider_so();

    public static native int liblooper_jni_so();

    public static native int liblyramanager_so();

    public static native int libmachineidhttpheader_so();

    public static native int libmagi_jni_so();

    public static native int libmailboxaccountinformationjni_so();

    public static native int libmailboxactattachmentsjni_so();

    public static native int libmailboxadvancedcryptostagingjni_so();

    public static native int libmailboxadvancedcryptotransportdiskmanagerjni_so();

    public static native int libmailboxadvancedcryptotransporte2etestutilsjni_so();

    public static native int libmailboxadvancedcryptotransportjni_so();

    public static native int libmailboxadvancedcryptotransportmediajni_so();

    public static native int libmailboxaibotsjni_so();

    public static native int libmailboxanalyticsloggingjni_so();

    public static native int libmailboxattachmentsjni_so();

    public static native int libmailboxavatarartifactojni_so();

    public static native int libmailboxavatarpowerupsjni_so();

    public static native int libmailboxavatarquickreactionsjni_so();

    public static native int libmailboxavatarsinfojni_so();

    public static native int libmailboxbadgecountjni_so();

    public static native int libmailboxbloksxmajni_so();

    public static native int libmailboxbmopbuyerviewfeaturecapabilitiesjni_so();

    public static native int libmailboxbotsjni_so();

    public static native int libmailboxbotthreadcontactsyncjni_so();

    public static native int libmailboxbroadcastflowjni_so();

    public static native int libmailboxbusinessinboxjni_so();

    public static native int libmailboxcallhistoryjni_so();

    public static native int libmailboxcatchupjni_so();

    public static native int libmailboxchannelhealthjni_so();

    public static native int libmailboxclientnotificationsjni_so();

    public static native int libmailboxclientnotificationssilentpushjni_so();

    public static native int libmailboxcommunitychatsuggestedactionsjni_so();

    public static native int libmailboxcommunityjni_so();

    public static native int libmailboxcommunitymessagingpresencejni_so();

    public static native int libmailboxcommunitymessagingsearchjni_so();

    public static native int libmailboxcommunitymessagingtrendingjni_so();

    public static native int libmailboxcomposerjni_so();

    public static native int libmailboxcomposerreplacementjni_so();

    public static native int libmailboxcontactsharesettingsjni_so();

    public static native int libmailboxcontactuploadjni_so();

    public static native int libmailboxcopresencejni_so();

    public static native int libmailboxcorejni_so();

    public static native int libmailboxcutoverinternaljni_so();

    public static native int libmailboxcutoverjni_so();

    public static native int libmailboxe2eexmareceiverfetchjni_so();

    public static native int libmailboxencryptedbackupsjni_so();

    public static native int libmailboxencryptedbackupsminosjni_so();

    public static native int libmailboxencryptedbackupsonmaindb_for_internal_use_onlyjni_so();

    public static native int libmailboxeventsjni_so();

    public static native int libmailboxfacebookcontactsearchjni_so();

    public static native int libmailboxfacebookcontentsharethreadlistjni_so();

    public static native int libmailboxfacebookmediaviewerjni_so();

    public static native int libmailboxfacebookmessagingnotificationjni_so();

    public static native int libmailboxfacebooktamjni_so();

    public static native int libmailboxfbmessagingbadgecountjni_so();

    public static native int libmailboxfbmessagingcontactlistjni_so();

    public static native int libmailboxfbmessaginginboxjni_so();

    public static native int libmailboxfbmessagingjni_so();

    public static native int libmailboxfbmessagingmessagelistjni_so();

    public static native int libmailboxfbmessagingpresencejni_so();

    public static native int libmailboxfbmessagingsecureparticipantjni_so();

    public static native int libmailboxfbmessagingsharewithyoujni_so();

    public static native int libmailboxfbmessagingthreadjni_so();

    public static native int libmailboxfbmthreadsettingsjni_so();

    public static native int libmailboxfbprivatereplymessagelistjni_so();

    public static native int libmailboxfbsharingjni_so();

    public static native int libmailboxfbtransportjni_so();

    public static native int libmailboxfeaturelimitsjni_so();

    public static native int libmailboxfilteredthreadsrangesjni_so();

    public static native int libmailboxforwardingjni_so();

    public static native int libmailboxfriendstabjni_so();

    public static native int libmailboxfrxjni_so();

    public static native int libmailboxftsjni_so();

    public static native int libmailboxfxcaljni_so();

    public static native int libmailboxgamesbotthreadjni_so();

    public static native int libmailboxgenaisearchwarmupjni_so();

    public static native int libmailboxgifjni_so();

    public static native int libmailboxglobaldeletejni_so();

    public static native int libmailboxglobaldeletesettingsjni_so();

    public static native int libmailboxgraphjni_so();

    public static native int libmailboxgrouplinksjni_so();

    public static native int libmailboxhighlightstabjni_so();

    public static native int libmailboxhotreloadjni_so();

    public static native int libmailboxignoremessagesjni_so();

    public static native int libmailboxinboxfoldersjni_so();

    public static native int libmailboxinboxjni_so();

    public static native int libmailboxinjectgenaicontextjni_so();

    public static native int libmailboxintegrityblockjni_so();

    public static native int libmailboxinthreadadcontextbannerjni_so();

    public static native int libmailboxinthreadbannerjni_so();

    public static native int libmailboxjewelnotificationjni_so();

    public static native int libmailboxloadgeneratorjni_so();

    public static native int libmailboxloadgeneratorproxyjni_so();

    public static native int libmailboxlocalstoragemanagementjni_so();

    public static native int libmailboxlocationsharingjni_so();

    public static native int libmailboxmagicalmessengerjni_so();

    public static native int libmailboxmagicwordsjni_so();

    public static native int libmailboxmarketplacectajni_so();

    public static native int libmailboxmarketplacemakeofferjni_so();

    public static native int libmailboxmarkinboxfolderseenjni_so();

    public static native int libmailboxmarkinboxseenjni_so();

    public static native int libmailboxmediareceiverfetchjni_so();

    public static native int libmailboxmemberrequestsjni_so();

    public static native int libmailboxmemmediautilsjni_so();

    public static native int libmailboxmemoriesjni_so();

    public static native int libmailboxmessagecountsjni_so();

    public static native int libmailboxmessagelistjni_so();

    public static native int libmailboxmessagerequestcqlproceduresjni_so();

    public static native int libmailboxmessagerequestjni_so();

    public static native int libmailboxmessagerequestssdkjni_so();

    public static native int libmailboxmessagingadsattributionv2jni_so();

    public static native int libmailboxmessagingprivacysettingsjni_so();

    public static native int libmailboxmessengerencryptedbackupsjni_so();

    public static native int libmailboxmessengerrankingextensionjni_so();

    public static native int libmailboxmessengersafetyinterventionplatformjni_so();

    public static native int libmailboxmessengershoppingcartstatusjni_so();

    public static native int libmailboxmplwaisyncmonitorjni_so();

    public static native int libmailboxmsgorcapinnedmessagesjni_so();

    public static native int libmailboxmsgpinnedmessagesjni_so();

    public static native int libmailboxnotesjni_so();

    public static native int libmailboxnotificationengineintegratorjni_so();

    public static native int libmailboxnotificationsettingsjni_so();

    public static native int libmailboxnulltransportjni_so();

    public static native int libmailboxorcacontactlistjni_so();

    public static native int libmailboxorcajni_so();

    public static native int libmailboxorcaphoneconnectionjni_so();

    public static native int libmailboxorcaslimjni_so();

    public static native int libmailboxorcathreadsettingsjni_so();

    public static native int libmailboxpinnedthreadsjni_so();

    public static native int libmailboxpollsjni_so();

    public static native int libmailboxpresencejni_so();

    public static native int libmailboxproactivewarningsjni_so();

    public static native int libmailboxproactivewarningsnoncorejni_so();

    public static native int libmailboxprofilesheetjni_so();

    public static native int libmailboxpublicchatsjni_so();

    public static native int libmailboxpushnotificationsjni_so();

    public static native int libmailboxqpdebuggerjni_so();

    public static native int libmailboxqpjni_so();

    public static native int libmailboxquickreplyjni_so();

    public static native int libmailboxrankingjni_so();

    public static native int libmailboxreachabilitysettingsjni_so();

    public static native int libmailboxreactionjni_so();

    public static native int libmailboxreactionv2jni_so();

    public static native int libmailboxremediationsdkjni_so();

    public static native int libmailboxreplyreminderdigestjni_so();

    public static native int libmailboxreplyreminderjni_so();

    public static native int libmailboxreportingsdkjni_so();

    public static native int libmailboxrollcalljni_so();

    public static native int libmailboxroomschatjni_so();

    public static native int libmailboxroomsjni_so();

    public static native int libmailboxrtccalleventsjni_so();

    public static native int libmailboxrtcjni_so();

    public static native int libmailboxsafetyinterventionsjni_so();

    public static native int libmailboxsdkjni_so();

    public static native int libmailboxsdktransportjni_so();

    public static native int libmailboxsearchaibotsjni_so();

    public static native int libmailboxsearchjni_so();

    public static native int libmailboxsearchqueryjni_so();

    public static native int libmailboxsecuremessagejni_so();

    public static native int libmailboxsharingjni_so();

    public static native int libmailboxshimjni_so();

    public static native int libmailboxstatusjni_so();

    public static native int libmailboxstickerjni_so();

    public static native int libmailboxstickerpickerjni_so();

    public static native int libmailboxstoriesjni_so();

    public static native int libmailboxsyncstatesjni_so();

    public static native int libmailboxtamattachmentuploadjni_so();

    public static native int libmailboxtamjni_so();

    public static native int libmailboxtammessagedebugjni_so();

    public static native int libmailboxtamreportingjni_so();

    public static native int libmailboxthreadactionsystemjni_so();

    public static native int libmailboxthreadactionsystemlistjni_so();

    public static native int libmailboxthreadbansjni_so();

    public static native int libmailboxthreadbusinessjni_so();

    public static native int libmailboxthreaddetailsjni_so();

    public static native int libmailboxthreademojijni_so();

    public static native int libmailboxthreadjni_so();

    public static native int libmailboxthreadlimitsjni_so();

    public static native int libmailboxthreadlistjni_so();

    public static native int libmailboxthreadmembersjni_so();

    public static native int libmailboxthreadparticipantsjni_so();

    public static native int libmailboxthreadsubscriptionsjni_so();

    public static native int libmailboxthreadthemejni_so();

    public static native int libmailboxtopbannersjni_so();

    public static native int libmailboxtracehandlerjni_so();

    public static native int libmailboxtranslationjni_so();

    public static native int libmailboxtransportjni_so();

    public static native int libmailboxtypingindicatorjni_so();

    public static native int libmailboxunifiedbadgecountjni_so();

    public static native int libmailboxusercontrolsjni_so();

    public static native int libmailboxuserrestrictjni_so();

    public static native int libmailboxuservisibleerrorjni_so();

    public static native int libmailboxvoicemessagesjni_so();

    public static native int libmalloc_hooks_so();

    public static native int libmantle_common_mantleDataValue_so();

    public static native int libmantle_fb_so();

    public static native int libmantle_nodes_value_model_lightweight_vm_so();

    public static native int libmantle_so();

    public static native int libmapbox_gl_so();

    public static native int libmapbufferjni_so();

    public static native int libmaskrcnn_ops_xplat_so();

    public static native int libmat_multAndroid_so();

    public static native int libmcftypeholder_so();

    public static native int libmcicomponentattributionlogger_jni_so();

    public static native int libmciqpl_jni_so();

    public static native int libmclconfig_jni_so();

    public static native int libmcpdynamic_mcpdynamic_so();

    public static native int libmediacodechooks_jni_so();

    public static native int libmediapipeline_igl_context_so();

    public static native int libmediapipeline_iglufilter_holder_so();

    public static native int libmediapipeline_iglufilter_insights_so();

    public static native int libmediastreaming_bundledservices_so();

    public static native int libmediastreaming_config_so();

    public static native int libmediastreaming_dvr_so();

    public static native int libmediastreaming_livetrace_so();

    public static native int libmediastreaming_mediastreamingtimer_so();

    public static native int libmediastreaming_riskrewardabr_so();

    public static native int libmediastreaming_sessionlog_so();

    public static native int libmediastreaming_so();

    public static native int libmediastreaming_stalldetector_so();

    public static native int libmediastreaming_timestampchecker_so();

    public static native int libmediastreaming_transport_so();

    public static native int libmediastreaming_tslog_so();

    public static native int libmediastreaming_videoqualityquery_so();

    public static native int libmediastreaming_xanalytics_so();

    public static native int libmem_alloc_marker_so();

    public static native int libmessagechannel_so();

    public static native int libmessengermcppluginregistryintegrationjni_so();

    public static native int libmessengerorcachildresultsetutils_so();

    public static native int libmessengerpinnedmessageschildresultsetutils_so();

    public static native int libmessengerplatformloggerjni_so();

    public static native int libmessengerplatformloggermplsyncmonitorjni_so();

    public static native int libmessengerplatformloggerttrclistenerjni_so();

    public static native int libmessengerqpfilterdispatcherjni_so();

    public static native int libmessengersdkthreadlistchildresultsetutils_so();

    public static native int libminscompiler_jni_so();

    public static native int libmnscertificateverifier_so();

    public static native int libmobile_purpose_policy_so();

    public static native int libmobileconfig_jni_so();

    public static native int libmobileconfigtroubleshooting_jni_so();

    public static native int libmodels_common_so();

    public static native int libmodels_core_so();

    public static native int libmodels_evaluator_so();

    public static native int libmodels_gbdt_so();

    public static native int libmodels_so();

    public static native int libmqttbypass_interface_jni_so();

    public static native int libmqttbypass_jni_so();

    public static native int libmqttchannel_so();

    public static native int libmqttlib_so();

    public static native int libmqttprotocol_jni_so();

    public static native int libmqtttransport_jni_so();

    public static native int libmsg_notif_journey_so();

    public static native int libmsgnotificationenginejni_so();

    public static native int libmsgr_om_sync_so();

    public static native int libmsysdgw_jni_so();

    public static native int libmsysjni_so();

    public static native int libmsysjnidasm_so();

    public static native int libmsysjniinfra_so();

    public static native int libmsysjniinframinimal_so();

    public static native int libmsysjniinfranosqlite_so();

    public static native int libmsysjniutils_so();

    public static native int libmsysohai_jni_so();

    public static native int libmsystracemetadataproviderjni_so();

    public static native int libmsystransportbootstrapjni_so();

    public static native int libmuseumutils_so();

    public static native int libmusiceffect_native_so();

    public static native int libnative_allocation_hooks_installer_jni_so();

    public static native int libnative_bridge_so();

    public static native int libnative_filters_so();

    public static native int libnative_imagetranscoder_so();

    public static native int libnative_mem_tracing_so();

    public static native int libnative_memdump_so();

    public static native int libnative_oomscorereader_so();

    public static native int libnative_random_so();

    public static native int libnativeheapstats_so();

    public static native int libnativeutil_jni_so();

    public static native int libnetworkMCFBridgejni_so();

    public static native int libnetworkpropertiesinterceptor_jni_so();

    public static native int libntbinary_util_so();

    public static native int libntgraphql_util_so();

    public static native int libomnigridjni_so();

    public static native int libomnistore_so();

    public static native int libomnistorecollections_so();

    public static native int libomnistoreexceptions_so();

    public static native int libomnistoreindexquery_so();

    public static native int libomnistoreopener_so();

    public static native int libomnistoresqliteandroid_so();

    public static native int liboom_interceptor_so();

    public static native int liboptminsolver_so();

    public static native int libopus_mlow_so();

    public static native int liboreofileutils_jni_so();

    public static native int libourprocsinfo_so();

    public static native int libpando_active_fields_so();

    public static native int libpando_adaptive_service_so();

    public static native int libpando_async_so();

    public static native int libpando_bloks_embedded_parse_utils_so();

    public static native int libpando_client_adaptive_jni_so();

    public static native int libpando_client_analytics_jni_so();

    public static native int libpando_client_async_jni_so();

    public static native int libpando_client_cache_jni_so();

    public static native int libpando_client_cancelledcallbacks_jni_so();

    public static native int libpando_client_livequery_jni_so();

    public static native int libpando_client_networksequencing_jni_so();

    public static native int libpando_client_runtimedefaults_jni_so();

    public static native int libpando_client_tigon_jni_so();

    public static native int libpando_client_tigongraphstore_jni_so();

    public static native int libpando_connection_jni_so();

    public static native int libpando_connection_so();

    public static native int libpando_consistency_analytics_so();

    public static native int libpando_constants_so();

    public static native int libpando_core_so();

    public static native int libpando_data_service_so();

    public static native int libpando_disk_cache_so();

    public static native int libpando_engine_so();

    public static native int libpando_flatbuffer_jni_so();

    public static native int libpando_flipper_jni_so();

    public static native int libpando_graphql_analytics_so();

    public static native int libpando_graphql_ast_flatbuffers_runtime_so();

    public static native int libpando_graphql_ast_so();

    public static native int libpando_graphql_jni_so();

    public static native int libpando_graphql_network_sequencing_service_so();

    public static native int libpando_graphql_network_so();

    public static native int libpando_graphql_pagination_service_so();

    public static native int libpando_graphql_params_so();

    public static native int libpando_graphql_serialize_so();

    public static native int libpando_graphql_service_so();

    public static native int libpando_graphql_so();

    public static native int libpando_graphstore_jni_so();

    public static native int libpando_graphstore_pagination_so();

    public static native int libpando_graphstore_parsing_so();

    public static native int libpando_graphstore_serialization_so();

    public static native int libpando_graphstore_so();

    public static native int libpando_graphstore_tigon_so();

    public static native int libpando_jni_so();

    public static native int libpando_json_string_callbacks_so();

    public static native int libpando_livequery_service_so();

    public static native int libpando_pagination_jni_so();

    public static native int libpando_persist_so();

    public static native int libpando_response_cache_so();

    public static native int libpando_serialize_so();

    public static native int libpando_serialize_utils_so();

    public static native int libpando_tigon_data_service_so();

    public static native int libpando_tigon_request_so();

    public static native int libpando_tree_updater_utils_so();

    public static native int libpapaya_engine_so();

    public static native int libpapaya_fb_engine_voltron_so();

    public static native int libpapaya_fb_executor_voltron_so();

    public static native int libpapaya_fb_fa_generic_executor_dataloading_so();

    public static native int libpapaya_fb_fa_mldw_falco_executor_so();

    public static native int libpapaya_fb_heavyhitters_executor_so();

    public static native int libpapaya_fb_histogram_executor_so();

    public static native int libpapaya_fb_percentile_executor_so();

    public static native int libpapaya_fb_transport_so();

    public static native int libpapaya_hash_so();

    public static native int libpapaya_log_so();

    public static native int libpapaya_mldw_file_transport_so();

    public static native int libpapaya_mldw_network_transport_so();

    public static native int libpapaya_mldw_so();

    public static native int libpapaya_mldw_udf_regex_so();

    public static native int libpapaya_model_loader_so();

    public static native int libpapaya_so();

    public static native int libpapaya_store_encryptor_otp_so();

    public static native int libpapaya_store_interface_so();

    public static native int libpapaya_store_so();

    public static native int libperfloggerxplat_init_so();

    public static native int libpersonsegmentation_so();

    public static native int libpgo_native_800_so();

    public static native int libpgo_native_810_so();

    public static native int libpgo_native_900_so();

    public static native int libphaser_so();

    public static native int libplthooks_so();

    public static native int libpolicyawareencryption_so();

    public static native int libpostmlp_so();

    public static native int libprefetch_jni_so();

    public static native int libprofilo_apiimpl_so();

    public static native int libprofilo_atrace_so();

    public static native int libprofilo_block_logger_so();

    public static native int libprofilo_breakpad_so();

    public static native int libprofilo_config_so();

    public static native int libprofilo_configjni_so();

    public static native int libprofilo_counters_so();

    public static native int libprofilo_disk_so();

    public static native int libprofilo_jmulti_buffer_logger_so();

    public static native int libprofilo_jni_helpers_so();

    public static native int libprofilo_libcio_so();

    public static native int libprofilo_local_symbols_so();

    public static native int libprofilo_logger_so();

    public static native int libprofilo_mapping_logger_so();

    public static native int libprofilo_mappings_so();

    public static native int libprofilo_mmap_file_writer_so();

    public static native int libprofilo_mmapbuf_buffer_jni_so();

    public static native int libprofilo_mmapbuf_buffer_so();

    public static native int libprofilo_mmapbuf_rdr_so();

    public static native int libprofilo_mmapbuf_so();

    public static native int libprofilo_multi_buffer_logger_so();

    public static native int libprofilo_perfevents_so();

    public static native int libprofilo_qplprovider_so();

    public static native int libprofilo_signal_handler_so();

    public static native int libprofilo_so();

    public static native int libprofilo_stack_unwinder_so();

    public static native int libprofilo_stacktrace_artcompat_so();

    public static native int libprofilo_stacktrace_so();

    public static native int libprofilo_systemcounters_so();

    public static native int libprofilo_threadmetadata_so();

    public static native int libprofilo_util_so();

    public static native int libprofiloextapi_so();

    public static native int libprofiloprofilerunwindc800_so();

    public static native int libprofiloprofilerunwindc810_so();

    public static native int libprofiloprofilerunwindc900_so();

    public static native int libproviders_applayer_so();

    public static native int libproxygen_http_so();

    public static native int libproxygen_lib_utils_compression_so();

    public static native int libproxygen_lib_utils_conn_quality_so();

    public static native int libproxygen_lib_utils_crypt_so();

    public static native int libproxygen_lib_utils_logging_so();

    public static native int libproxygen_structured_headers_so();

    public static native int libpthread_interceptor_so();

    public static native int libpublickeycrypto_so();

    public static native int libpulsar_jni_so();

    public static native int libpytorch_bi_bytedoc_nnc_v1_so();

    public static native int libqpl_gks_jni_so();

    public static native int libqpljsibindingsjni_so();

    public static native int libqplreliabilityhttpheader_so();

    public static native int libreachability_provider_so();

    public static native int libreact_devsupportjni_so();

    public static native int libreact_featureflagsjni_so();

    public static native int libreact_newarchdefaults_so();

    public static native int libreactnativeblob_so();

    public static native int libreactnativejni_common_so();

    public static native int libreactnativejni_so();

    public static native int librealtimeconfig_so();

    public static native int libregionhint_android_jni_so();

    public static native int librelenginterceptor_so();

    public static native int libreliability_so();

    public static native int libreliablemediamonitor_so();

    public static native int librequeststream_jni_so();

    public static native int librestricks_so();

    public static native int librevproxyqeinterceptor_so();

    public static native int librewritenativeinterceptor_so();

    public static native int librewritenativeinterceptorutils_so();

    public static native int librninstance_so();

    public static native int libroi_align_ops_xplat_so();

    public static native int librs_api_jni_so();

    public static native int librs_builder_jni_so();

    public static native int librs_client_jni_so();

    public static native int librs_dgw_builder_jni_so();

    public static native int librs_streameventhandler_jni_so();

    public static native int librs_streamref_jni_so();

    public static native int librtgqlsdk_so();

    public static native int librtgqlsdkproviderbase_so();

    public static native int librtinetwork_jni_so();

    public static native int libsampling_so();

    public static native int libsdkthreadidentifierjni_so();

    public static native int libsegmentationdataprovider_so();

    public static native int libshepherd_libcoldstart_so();

    public static native int libshepherd_libdexload_so();

    public static native int libshepherd_libscrollmerged_so();

    public static native int libsigmux_so();

    public static native int libsigquit_so();

    public static native int libsimplejni_so();

    public static native int libsingle_model_cache_native_android_so();

    public static native int libsodium_so();

    public static native int libspark_ocarxlogger_native_so();

    public static native int libspark_ocxlogger_native_so();

    public static native int libspatialaudio_so();

    public static native int libspectrum_so();

    public static native int libspectrumpluginjpeg_so();

    public static native int libspectrumpluginpng_so();

    public static native int libspectrumpluginwebp_so();

    public static native int libsqlitevec_so();

    public static native int libsslx_so();

    public static native int libstartup_signals_provider_so();

    public static native int libstash_jni_so();

    public static native int libstorer_jni_so();

    public static native int libstreamid_jni_so();

    public static native int libstringregex_jni_so();

    public static native int libsymmkeycrypto_so();

    public static native int libtar_brotli_archive_native_so();

    public static native int libterminate_handler_manager_so();

    public static native int libthird_party_png__pngAndroid_so();

    public static native int libtigonfilebodyproviderjni_so();

    public static native int libtigonhuc_so();

    public static native int libtigoninterceptors_so();

    public static native int libtigonjni_so();

    public static native int libtigonkeyattestationresponseinterceptor_so();

    public static native int libtigonliger_so();

    public static native int libtigonnativeauthedservice_so();

    public static native int libtigonnativeservice_so();

    public static native int libtigonobserver_so();

    public static native int libtigonohaiserviceholder_jni_so();

    public static native int libtigonxplatobserversholder_so();

    public static native int libtigonzerocodeattestationrequestinterceptor_so();

    public static native int libtimeinapp_jni_so();

    public static native int libtntstigonrequestint_so();

    public static native int libtorch_code_gen_so();

    public static native int libtorchvision_ops_so();

    public static native int libtraceroute_jni_so();

    public static native int libtrafficntsmanager_so();

    public static native int libtrafficntsmanagerpost_so();

    public static native int libtrafficntstigonprovider_so();

    public static native int libturbomodulejsijni_so();

    public static native int libuimanagerjni_so();

    public static native int libunet_106_ops_xplat_so();

    public static native int libunifiedtargettrackingdataprovider_so();

    public static native int libunwindstack_stream_so();

    public static native int libusdidinterceptor_so();

    public static native int libusercrypto_so();

    public static native int libvalue_model_holder_jni_so();

    public static native int libverifier800_so();

    public static native int libverifier810_so();

    public static native int libverifier_so();

    public static native int libversioned_model_cache_native_android_so();

    public static native int libvoprf_ristretto_so();

    public static native int libwhistle_so();

    public static native int libworldtrackerdataprovider_so();

    public static native int libworldtrackerv2dataprovider_so();

    public static native int libxanalyticsadapter_jni_so();

    public static native int libxanalyticsnative_jni_so();

    public static native int libxplat_arfx_logging_bug_report_bug_reportAndroid_so();

    public static native int libxplat_arfx_services_impl_avatars_avatarsAndroid_so();

    public static native int libxplat_arfx_services_interfaces_interfacesAndroid_so();

    public static native int libxplat_ecos_ecos_base_baseAndroid_so();

    public static native int libxplat_js_react_native_github_packages_react_native_ReactAndroid_src_main_jni_react_turbomodule_callinvokerholderAndroid_so();

    public static native int libxplat_js_react_native_github_packages_react_native_ReactCommon_react_nativemodule_core_coreAndroid_so();

    public static native int libxplat_mediastreaming_AudioEnhancementAndroid_so();

    public static native int libxplat_papaya_client_platform_android_androidAndroid_so();

    public static native int libxplat_papaya_fb_client_engine_voltron_voltronAndroid_so();

    public static native int libxplat_perflogger_jni_java_metadata_provider_java_network_stats_metadata_providerAndroid_so();

    public static native int libxplat_shermes_stable_HermesAPIAndroid_so();

    public static native int libxplat_shermes_staging_HermesAPIAndroid_so();

    public static native int libxplatmqttclient_jni_so();

    public static native int libxxhash_so();

    public static native int libyoga_internal_so();

    public static native int libyoga_so();

    public static native int libyogacore_so();

    public static native int libzopt_jni_so();

    public static native int libzopt_so();
}
