package com.facebook.soloader;

import X.AnonymousClass0WY;
import android.util.Log;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SoLoaderULErrorFactory {
    public static boolean corruptedLibName(String str) {
        Matcher matcher = Pattern.compile("\\P{ASCII}+").matcher(str);
        if (!matcher.find()) {
            return false;
        }
        Log.w("SoLoader", AnonymousClass0WY.A0i("Library name is corrupted, contains non-ASCII characters ", matcher.group()));
        return true;
    }

    public static SoLoaderULError create(String str, UnsatisfiedLinkError unsatisfiedLinkError) {
        SoLoaderULError soLoaderULError;
        String A0w = AnonymousClass0WY.A0w(" (soName: ", str, ")");
        if (unsatisfiedLinkError.getMessage() != null && unsatisfiedLinkError.getMessage().contains("ELF")) {
            soLoaderULError = new SoLoaderULError(str, AnonymousClass0WY.A0i(unsatisfiedLinkError.toString(), A0w));
        } else if (corruptedLibName(str)) {
            soLoaderULError = new SoLoaderULError(str, AnonymousClass0WY.A0w("corrupted lib name: ", unsatisfiedLinkError.toString(), A0w));
        } else {
            soLoaderULError = new SoLoaderULError(str, AnonymousClass0WY.A0i(unsatisfiedLinkError.toString(), A0w));
        }
        soLoaderULError.initCause(unsatisfiedLinkError);
        return soLoaderULError;
    }
}
