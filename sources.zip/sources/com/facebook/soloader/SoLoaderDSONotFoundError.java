package com.facebook.soloader;

import X.AnonymousClass001;
import X.C209015n;
import android.content.Context;

public class SoLoaderDSONotFoundError extends SoLoaderULError {
    /* JADX WARNING: type inference failed for: r0v3, types: [com.facebook.soloader.SoLoaderULError, com.facebook.soloader.SoLoaderDSONotFoundError] */
    public static SoLoaderDSONotFoundError create(String str, Context context, C209015n[] r5) {
        StringBuilder A0p = AnonymousClass001.A0p("couldn't find DSO to load: ");
        A0p.append(str);
        A0p.append("\n\texisting SO sources: ");
        for (int i = 0; i < r5.length; i++) {
            A0p.append("\n\t\tSoSource ");
            A0p.append(i);
            A0p.append(": ");
            AnonymousClass001.A1L(A0p, r5[i]);
        }
        if (context != null) {
            A0p.append("\n\tNative lib dir: ");
            AnonymousClass001.A1M(A0p, context.getApplicationInfo().nativeLibraryDir);
        }
        return new SoLoaderULError(str, A0p.toString());
    }

    public SoLoaderDSONotFoundError(String str, String str2) {
        super(str, str2);
    }

    public SoLoaderDSONotFoundError(String str) {
        super(str);
    }
}
