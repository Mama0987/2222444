package com.facebook.soloader;

public class SoLoaderCorruptedLibNameError extends SoLoaderULError {
    public SoLoaderCorruptedLibNameError(String str, String str2) {
        super(str, str2);
    }

    public SoLoaderCorruptedLibNameError(String str) {
        super(str);
    }
}
