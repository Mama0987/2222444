package com.facebook.soloader;

public class MinElf$ElfError extends UnsatisfiedLinkError {
    public MinElf$ElfError(String str) {
        super(str);
    }
}
