package com.facebook.quicksilver.shortcut;

import X.AnonymousClass0BS;
import X.C15800sA;
import X.C195810b;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public final class QuicksilverShortcutExternalActivity extends Activity {
    public final void onCreate(Bundle bundle) {
        int A00 = AnonymousClass0BS.A00(279661201);
        super.onCreate(bundle);
        Object newInstance = Class.forName("com.facebook.quicksilver.shortcut.QuicksilverShortcutExternalAction").getConstructor(new Class[]{Context.class}).newInstance(new Object[]{this});
        C15800sA.A0G(newInstance, "null cannot be cast to non-null type com.facebook.quicksilver.shortcut.QuicksilverShortcutExternalActivity.IntentAction");
        Intent intent = getIntent();
        C15800sA.A09(intent);
        ((C195810b) newInstance).handle(intent);
        finish();
        AnonymousClass0BS.A07(211219378, A00);
    }
}
