package com.facebook.tools.dextr.runtime.detour;

import X.C017409c;
import android.animation.Animator;

public class AnimatorDetour$Api19Utils {
    public static final Animator.AnimatorPauseListener sAnimatorPauseListener = new C017409c();
}
