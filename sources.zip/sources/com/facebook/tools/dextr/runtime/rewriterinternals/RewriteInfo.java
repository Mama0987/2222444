package com.facebook.tools.dextr.runtime.rewriterinternals;

public class RewriteInfo {
    public static String CALLMAP_UUID = "<unset>";
}
