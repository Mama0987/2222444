package com.facebook.errorreporting.lacrima.detector.broadcast;

import X.AnonymousClass001;
import X.AnonymousClass0HG;
import X.AnonymousClass0RZ;
import X.C003002b;
import X.C05970Uc;
import X.C15160r0;
import X.C17840vs;
import android.content.Context;
import android.content.Intent;

public class PublicLockScreenBroadcastReceiver extends C05970Uc {
    public final void doReceive(Context context, Intent intent, AnonymousClass0HG r5) {
        C15160r0 r0;
        C17840vs A0B;
        C15160r0 r02;
        C17840vs A0B2;
        String action = intent.getAction();
        C003002b.A00(action);
        if (!(!action.equals("com.instagram.android.intent.action.ACTION_SCREEN_OFF") || (r02 = AnonymousClass0RZ.A00) == null || (A0B2 = AnonymousClass001.A0B(r02)) == null)) {
            A0B2.A04(false);
        }
        if (intent.getAction().equals("com.instagram.android.intent.action.ACTION_SCREEN_ON") && (r0 = AnonymousClass0RZ.A00) != null && (A0B = AnonymousClass001.A0B(r0)) != null) {
            A0B.A04(true);
        }
    }
}
