package com.facebook.errorreporting.lacrima.detector.broadcast;

import X.AnonymousClass002;
import X.AnonymousClass0M7;
import X.C14270pR;
import X.C16130so;
import X.C17950w5;
import X.C18230wa;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import java.io.File;
import java.util.Iterator;
import java.util.Map;

public class SecureShutdownBootBroadcastReceiver extends AnonymousClass0M7 {
    public static File A00;

    /* JADX WARNING: type inference failed for: r1v0, types: [X.0Gj, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v0, types: [X.0Gj, java.lang.Object] */
    public SecureShutdownBootBroadcastReceiver() {
        super(new Object(), new Object());
    }

    public final void A01(Context context, C18230wa r7) {
        try {
            C16130so.A01(C16130so.A00(context), "last_device_shutdown_s", 0);
            A00 = AnonymousClass002.A0B(r7);
            Iterator it = this.A00.iterator();
            while (it.hasNext()) {
                IntentFilter intentFilter = (IntentFilter) it.next();
                if (Build.VERSION.SDK_INT < 34 || context.getApplicationInfo().targetSdkVersion < 34) {
                    context.registerReceiver(this, intentFilter);
                } else {
                    context.registerReceiver(this, intentFilter, 2);
                }
            }
        } catch (Throwable th) {
            C17950w5.A00().CnD("SecureShutdownBootBroadcastReceiverStart", th, (Map) null);
            C14270pR.A0K("lacrima", "SecureShutdownBootBroadcastReceiver failed", th);
        }
    }
}
