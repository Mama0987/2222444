package com.facebook.errorreporting.lacrima.detector.broadcast;

import X.AnonymousClass001;
import X.AnonymousClass0AR;
import X.AnonymousClass0HG;
import X.AnonymousClass0RZ;
import X.C15160r0;
import X.C17620vQ;
import X.C17840vs;
import android.content.Context;
import android.content.Intent;

public class ProtectedLockScreenBroadcastReceiver extends C17620vQ {
    public final void doReceive(Context context, Intent intent, AnonymousClass0HG r5) {
        C15160r0 r0;
        C17840vs A0B;
        C15160r0 r02;
        C17840vs A0B2;
        if (!(!AnonymousClass0AR.A00(intent.getAction(), "android.intent.action.SCREEN_OFF") || (r02 = AnonymousClass0RZ.A00) == null || (A0B2 = AnonymousClass001.A0B(r02)) == null)) {
            A0B2.A04(false);
        }
        if (AnonymousClass0AR.A00(intent.getAction(), "android.intent.action.SCREEN_ON") && (r0 = AnonymousClass0RZ.A00) != null && (A0B = AnonymousClass001.A0B(r0)) != null) {
            A0B.A04(true);
        }
    }
}
