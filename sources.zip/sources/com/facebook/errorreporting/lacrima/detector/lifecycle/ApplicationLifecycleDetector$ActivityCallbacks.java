package com.facebook.errorreporting.lacrima.detector.lifecycle;

import X.AnonymousClass0X6;
import X.AnonymousClass0sS;
import X.C10650gm;
import X.C10690gr;
import X.C14710qF;
import X.C17750vf;
import X.C17840vs;
import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class ApplicationLifecycleDetector$ActivityCallbacks implements Application.ActivityLifecycleCallbacks {
    public final /* synthetic */ C17840vs this$0;

    public void handleCreated(Activity activity, Bundle bundle, C10650gm r8) {
        boolean z;
        String obj;
        AnonymousClass0sS r1;
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r8.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01(activity, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A0Y, activity);
                z = true;
            } else {
                z = false;
            }
            Intent intent = activity.getIntent();
            C17840vs r2 = this.this$0;
            boolean isFinishing = activity.isFinishing();
            if (intent == null) {
                obj = "Null intent";
            } else {
                obj = intent.toString();
            }
            r2.updateAppState(activity, r8, isFinishing, obj);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A0Y, activity);
            }
        }
        C17840vs.A03(this.this$0);
    }

    public void handleDestroyed(Activity activity, C10650gm r5) {
        boolean z;
        AnonymousClass0sS r1;
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r5.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01((Activity) null, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A15, activity);
                z = true;
            } else {
                z = false;
            }
            C17840vs.A00(activity, r5, this.this$0);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A15, activity);
            }
        }
        C14710qF r0 = this.this$0.A0C;
        if (r0 != null && !r0.E87(activity)) {
            C17840vs.A03(this.this$0);
        }
    }

    public void handlePaused(Activity activity, C10650gm r5) {
        boolean z;
        AnonymousClass0sS r1;
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r5.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01((Activity) null, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A0j, activity);
                z = true;
            } else {
                z = false;
            }
            C17840vs.A00(activity, r5, this.this$0);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A0j, activity);
            }
        }
    }

    public void handleResumed(Activity activity, C10650gm r5) {
        boolean z;
        AnonymousClass0sS r1;
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r5.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01((Activity) null, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A00, activity);
                z = true;
            } else {
                z = false;
            }
            C17840vs.A00(activity, r5, this.this$0);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A00, activity);
            }
        }
    }

    public void handleStarted(Activity activity, C10650gm r5) {
        boolean z;
        AnonymousClass0sS r1;
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r5.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01((Activity) null, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A0C, activity);
                z = true;
            } else {
                z = false;
            }
            C17840vs.A00(activity, r5, this.this$0);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A0C, activity);
            }
        }
    }

    public void handleStopped(Activity activity, C10650gm r5) {
        boolean z;
        AnonymousClass0sS r1;
        C14710qF r0;
        C17840vs r12 = this.this$0;
        if (r12.A0P && (r0 = r12.A0C) != null) {
            boolean E87 = r0.E87(activity);
            C17840vs r2 = this.this$0;
            if (E87) {
                Object obj = C17840vs.A0f;
                synchronized (obj) {
                    if (!r2.A06) {
                        C10690gr.A00(obj);
                        r2.A06 = true;
                    }
                }
            } else {
                C17840vs.A03(r2);
            }
        }
        synchronized (this.this$0.A0M) {
            if (Build.VERSION.SDK_INT < 29 || r5.equals(C10650gm.PRE_CALLBACK)) {
                C17840vs.A01((Activity) null, this.this$0);
                this.this$0.A0B.A04(AnonymousClass0X6.A0u, activity);
                z = true;
            } else {
                z = false;
            }
            C17840vs.A00(activity, r5, this.this$0);
            if (z && (r1 = this.this$0.A0G) != null) {
                r1.A05(AnonymousClass0X6.A0u, activity);
            }
        }
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        if (!shouldIgnore(activity)) {
            handleCreated(activity, bundle, C10650gm.IN_CALLBACK);
        }
    }

    public void onActivityDestroyed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleDestroyed(activity, C10650gm.IN_CALLBACK);
        }
    }

    public void onActivityPaused(Activity activity) {
        if (!shouldIgnore(activity)) {
            handlePaused(activity, C10650gm.IN_CALLBACK);
        }
    }

    public void onActivityResumed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleResumed(activity, C10650gm.IN_CALLBACK);
        }
    }

    public void onActivityStarted(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStarted(activity, C10650gm.IN_CALLBACK);
        }
    }

    public void onActivityStopped(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStopped(activity, C10650gm.IN_CALLBACK);
        }
    }

    public boolean shouldIgnore(Activity activity) {
        return activity.getClass().getName().equals(this.this$0.A03);
    }

    public /* synthetic */ ApplicationLifecycleDetector$ActivityCallbacks(C17840vs r1, C17750vf r2) {
        this(r1);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public ApplicationLifecycleDetector$ActivityCallbacks(C17840vs r1) {
        this.this$0 = r1;
    }
}
