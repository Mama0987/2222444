package com.facebook.errorreporting.lacrima.detector.lifecycle;

import X.C10650gm;
import X.C17750vf;
import X.C17840vs;
import android.app.Activity;
import android.os.Bundle;

public class ApplicationLifecycleDetector$ActivityCallbacksApi29 extends ApplicationLifecycleDetector$ActivityCallbacks {
    public final /* synthetic */ C17840vs this$0;

    public void onActivityPostCreated(Activity activity, Bundle bundle) {
        if (!shouldIgnore(activity)) {
            handleCreated(activity, bundle, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPostDestroyed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleDestroyed(activity, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPostPaused(Activity activity) {
        if (!shouldIgnore(activity)) {
            handlePaused(activity, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPostResumed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleResumed(activity, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPostStarted(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStarted(activity, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPostStopped(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStopped(activity, C10650gm.POST_CALLBACK);
        }
    }

    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        if (!shouldIgnore(activity)) {
            handleCreated(activity, bundle, C10650gm.PRE_CALLBACK);
        }
    }

    public void onActivityPreDestroyed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleDestroyed(activity, C10650gm.PRE_CALLBACK);
        }
    }

    public void onActivityPrePaused(Activity activity) {
        if (!shouldIgnore(activity)) {
            handlePaused(activity, C10650gm.PRE_CALLBACK);
        }
    }

    public void onActivityPreResumed(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleResumed(activity, C10650gm.PRE_CALLBACK);
        }
    }

    public void onActivityPreStarted(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStarted(activity, C10650gm.PRE_CALLBACK);
        }
    }

    public void onActivityPreStopped(Activity activity) {
        if (!shouldIgnore(activity)) {
            handleStopped(activity, C10650gm.PRE_CALLBACK);
        }
    }

    public /* synthetic */ ApplicationLifecycleDetector$ActivityCallbacksApi29(C17840vs r1, C17750vf r2) {
        this(r1);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ApplicationLifecycleDetector$ActivityCallbacksApi29(C17840vs r1) {
        super(r1);
        this.this$0 = r1;
    }
}
