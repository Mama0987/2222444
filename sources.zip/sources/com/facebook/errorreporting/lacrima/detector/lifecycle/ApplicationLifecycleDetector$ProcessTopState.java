package com.facebook.errorreporting.lacrima.detector.lifecycle;

public final class ApplicationLifecycleDetector$ProcessTopState {
    public final String toString() {
        return "ProcessTopState";
    }
}
