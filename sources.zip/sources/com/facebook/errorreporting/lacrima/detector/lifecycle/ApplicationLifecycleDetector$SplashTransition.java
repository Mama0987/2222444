package com.facebook.errorreporting.lacrima.detector.lifecycle;

public final class ApplicationLifecycleDetector$SplashTransition {
    public final String toString() {
        return "SplashTransition";
    }
}
