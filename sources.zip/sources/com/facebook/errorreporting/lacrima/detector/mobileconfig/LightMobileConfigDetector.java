package com.facebook.errorreporting.lacrima.detector.mobileconfig;

import X.C15160r0;
import X.C16470tW;
import X.C17490vD;
import X.C17500vE;
import com.facebook.jni.HybridData;
import com.facebook.mobileconfig.MobileConfigCanaryChangeListener;

public final class LightMobileConfigDetector implements C16470tW {
    public final String TAG = "MobileConfigDetector";
    public final C15160r0 collectorManager;
    public String lastValue = "[]";
    public HybridData mHybridData;

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004e, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x004f, code lost:
        X.C17950w5.A01("MobileConfigDetector", "Light Mobile Config canary retrieval failed.", r2).CnD("LightMCCanaryFetch", r2, (java.util.Map) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x005c, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final /* synthetic */ void access$onUpdate(com.facebook.errorreporting.lacrima.detector.mobileconfig.LightMobileConfigDetector r4) {
        /*
            r3 = 0
            java.lang.String r1 = r4.getAllCanaryData()     // Catch:{ all -> 0x004e }
            if (r1 != 0) goto L_0x0018
            X.0vz r1 = X.C17950w5.A00()     // Catch:{ all -> 0x004e }
            java.lang.String r0 = "LightMCDetectorOnUpdate"
            r1.CnD(r0, r3, r3)     // Catch:{ all -> 0x004e }
            java.lang.String r1 = "MobileConfigDetector"
            java.lang.String r0 = "Unable to fetch data from getAllCanaryData()."
            X.C14270pR.A0G(r1, r0)     // Catch:{ all -> 0x004e }
            return
        L_0x0018:
            monitor-enter(r4)     // Catch:{ all -> 0x004e }
            int r0 = r1.length()     // Catch:{ all -> 0x004b }
            if (r0 == 0) goto L_0x0049
            java.lang.String r0 = "[]"
            boolean r0 = r1.equals(r0)     // Catch:{ all -> 0x004b }
            if (r0 != 0) goto L_0x0049
            java.lang.String r0 = r4.lastValue     // Catch:{ all -> 0x004b }
            boolean r0 = r1.equals(r0)     // Catch:{ all -> 0x004b }
            if (r0 != 0) goto L_0x0049
            r4.lastValue = r1     // Catch:{ all -> 0x004b }
            X.0qw r2 = new X.0qw     // Catch:{ all -> 0x004b }
            r2.<init>(r3)     // Catch:{ all -> 0x004b }
            com.facebook.errorreporting.field.ReportFieldString r0 = X.C14990qj.A7W     // Catch:{ all -> 0x004b }
            r2.De9(r0, r1)     // Catch:{ all -> 0x004b }
            X.0r0 r1 = r4.collectorManager     // Catch:{ all -> 0x004b }
            X.0rs r0 = X.C15660rs.CRITICAL_REPORT     // Catch:{ all -> 0x004b }
            r1.A09(r2, r0, r4)     // Catch:{ all -> 0x004b }
            X.0r0 r1 = r4.collectorManager     // Catch:{ all -> 0x004b }
            X.0rs r0 = X.C15660rs.LARGE_REPORT     // Catch:{ all -> 0x004b }
            r1.A09(r2, r0, r4)     // Catch:{ all -> 0x004b }
        L_0x0049:
            monitor-exit(r4)     // Catch:{ all -> 0x004e }
            return
        L_0x004b:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x004e }
            throw r0     // Catch:{ all -> 0x004e }
        L_0x004e:
            r2 = move-exception
            java.lang.String r1 = "MobileConfigDetector"
            java.lang.String r0 = "Light Mobile Config canary retrieval failed."
            X.0vz r1 = X.C17950w5.A01(r1, r0, r2)
            java.lang.String r0 = "LightMCCanaryFetch"
            r1.CnD(r0, r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.errorreporting.lacrima.detector.mobileconfig.LightMobileConfigDetector.access$onUpdate(com.facebook.errorreporting.lacrima.detector.mobileconfig.LightMobileConfigDetector):void");
    }

    private final native String getAllCanaryData();

    private final native HybridData initHybrid();

    private final native String setUpdateListener(MobileConfigCanaryChangeListener mobileConfigCanaryChangeListener);

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0056, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0057, code lost:
        X.C17950w5.A00().CnD("MobileConfigDetectorLoader", r2, (java.util.Map) null);
        X.C14270pR.A0S("MobileConfigDetector", r2, "Unable to load liblacrimamobileconfig-jni.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0067, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void start() {
        /*
            r4 = this;
            r3 = 0
            java.lang.String r0 = "lacrimamobileconfig-jni"
            X.C18440x7.loadLibrary(r0)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            com.facebook.jni.HybridData r0 = r4.initHybrid()     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            r4.mHybridData = r0     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            X.06Y r0 = new X.06Y     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            r0.<init>(r4)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            java.lang.String r1 = r4.setUpdateListener(r0)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            if (r1 != 0) goto L_0x0028
            X.0vz r1 = X.C17950w5.A00()     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            java.lang.String r0 = "LightMCDetectorInstallListener"
            r1.CnD(r0, r3, r3)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            java.lang.String r1 = "MobileConfigDetector"
            java.lang.String r0 = "Unable to fetch data from setUpdateListener()."
            X.C14270pR.A0G(r1, r0)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            return
        L_0x0028:
            monitor-enter(r4)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            int r0 = r1.length()     // Catch:{ all -> 0x0053 }
            if (r0 == 0) goto L_0x0051
            java.lang.String r0 = "[]"
            boolean r0 = r1.equals(r0)     // Catch:{ all -> 0x0053 }
            if (r0 != 0) goto L_0x0051
            r4.lastValue = r1     // Catch:{ all -> 0x0053 }
            X.0qw r2 = new X.0qw     // Catch:{ all -> 0x0053 }
            r2.<init>(r3)     // Catch:{ all -> 0x0053 }
            com.facebook.errorreporting.field.ReportFieldString r0 = X.C14990qj.A7W     // Catch:{ all -> 0x0053 }
            r2.De9(r0, r1)     // Catch:{ all -> 0x0053 }
            X.0r0 r1 = r4.collectorManager     // Catch:{ all -> 0x0053 }
            X.0rs r0 = X.C15660rs.CRITICAL_REPORT     // Catch:{ all -> 0x0053 }
            r1.A09(r2, r0, r4)     // Catch:{ all -> 0x0053 }
            X.0r0 r1 = r4.collectorManager     // Catch:{ all -> 0x0053 }
            X.0rs r0 = X.C15660rs.LARGE_REPORT     // Catch:{ all -> 0x0053 }
            r1.A09(r2, r0, r4)     // Catch:{ all -> 0x0053 }
        L_0x0051:
            monitor-exit(r4)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            return
        L_0x0053:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
            throw r0     // Catch:{ UnsatisfiedLinkError -> 0x0056 }
        L_0x0056:
            r2 = move-exception
            X.0vz r1 = X.C17950w5.A00()
            java.lang.String r0 = "MobileConfigDetectorLoader"
            r1.CnD(r0, r2, r3)
            java.lang.String r1 = "MobileConfigDetector"
            java.lang.String r0 = "Unable to load liblacrimamobileconfig-jni."
            X.C14270pR.A0S(r1, r2, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.errorreporting.lacrima.detector.mobileconfig.LightMobileConfigDetector.start():void");
    }

    public LightMobileConfigDetector(C15160r0 r2) {
        this.collectorManager = r2;
    }

    public /* synthetic */ int getHealthEventSamplingRate() {
        return 100000;
    }

    public /* synthetic */ C17500vE getLimiter() {
        return null;
    }

    public C17490vD getName() {
        return C17490vD.A0I;
    }
}
