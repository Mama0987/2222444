package com.facebook.errorreporting.lacrima.collector.large;

import X.C14270pR;
import X.C17950w5;
import android.content.Context;
import android.os.health.HealthStats;
import android.os.health.SystemHealthManager;
import android.util.Pair;
import java.util.Map;

public final class SystemHealthStatsCollector$Api24Utils {
    public static Pair sCachedStats;

    public static Pair collectHealthStats(Context context, String str, boolean z) {
        HealthStats healthStats;
        long j;
        if (!z) {
            Pair pair = sCachedStats;
            if (pair != null) {
                return pair;
            }
            SystemHealthManager systemHealthManager = (SystemHealthManager) context.getSystemService(SystemHealthManager.class);
            if (systemHealthManager != null) {
                try {
                    HealthStats takeMyUidSnapshot = systemHealthManager.takeMyUidSnapshot();
                    if (!(takeMyUidSnapshot == null || !takeMyUidSnapshot.hasStats(10014) || (healthStats = takeMyUidSnapshot.getStats(10014).get(str)) == null)) {
                        long j2 = 0;
                        if (healthStats.hasMeasurement(30005)) {
                            j = healthStats.getMeasurement(30005);
                        } else {
                            j = 0;
                        }
                        if (healthStats.hasMeasurement(30004)) {
                            j2 = healthStats.getMeasurement(30004);
                        }
                        Pair pair2 = new Pair(Long.valueOf(j), Long.valueOf(j2));
                        sCachedStats = pair2;
                        return pair2;
                    }
                } catch (SecurityException e) {
                    C17950w5.A00().CnD("OSSysHealthCollect", e, (Map) null);
                    C14270pR.A0I("lacrima", "Unable to retrieve health stats", e);
                    return null;
                }
            }
        }
        return null;
    }
}
