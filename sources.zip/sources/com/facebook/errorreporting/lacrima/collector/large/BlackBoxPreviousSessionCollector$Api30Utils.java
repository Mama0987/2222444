package com.facebook.errorreporting.lacrima.collector.large;

public final class BlackBoxPreviousSessionCollector$Api30Utils {
    public static String getKey(int i, String str) {
        if (i == 3) {
            return "lmk";
        }
        return str;
    }
}
