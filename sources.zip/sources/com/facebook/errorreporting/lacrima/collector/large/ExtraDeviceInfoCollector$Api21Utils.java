package com.facebook.errorreporting.lacrima.collector.large;

import android.os.Build;

public class ExtraDeviceInfoCollector$Api21Utils {
    public static String[] getCpuAbis() {
        return Build.SUPPORTED_ABIS;
    }
}
