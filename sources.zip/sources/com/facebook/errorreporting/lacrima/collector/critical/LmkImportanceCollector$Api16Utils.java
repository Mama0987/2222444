package com.facebook.errorreporting.lacrima.collector.critical;

import android.app.ActivityManager;

public class LmkImportanceCollector$Api16Utils {
    public static int getLastTrimLevel(ActivityManager.RunningAppProcessInfo runningAppProcessInfo) {
        return runningAppProcessInfo.lastTrimLevel;
    }
}
