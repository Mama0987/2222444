package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14910qa;
import X.C14990qj;
import X.C15110qv;
import android.content.pm.PackageManager;

public class AppInfoCollector$Api29Utils {
    public static boolean isTest() {
        return false;
    }

    public static void setUpgradeInfo(PackageManager packageManager, C15110qv r3) {
        boolean isDeviceUpgrading;
        boolean isTest = isTest();
        C14910qa r1 = C14990qj.A0G;
        if (isTest) {
            isDeviceUpgrading = false;
        } else {
            isDeviceUpgrading = packageManager.isDeviceUpgrading();
        }
        r3.De6(r1, isDeviceUpgrading);
    }
}
