package com.facebook.errorreporting.lacrima.collector.critical;

import X.AnonymousClass001;
import X.C14990qj;
import X.C15110qv;
import android.content.Context;
import android.content.pm.ModuleInfo;
import android.content.pm.PackageManager;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceInfoCollector$Api29Utils {
    public static void addModuleVersions(Context context, C15110qv r6) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager != null) {
            List<ModuleInfo> installedModules = packageManager.getInstalledModules(0);
            JSONObject A19 = AnonymousClass001.A19();
            for (ModuleInfo packageName : installedModules) {
                String packageName2 = packageName.getPackageName();
                if (packageName2 != null) {
                    try {
                        A19.put(packageName2, packageManager.getPackageInfo(packageName2, 1073741824).getLongVersionCode());
                    } catch (PackageManager.NameNotFoundException | JSONException unused) {
                    }
                }
            }
            r6.De9(C14990qj.A7a, A19.toString());
        }
    }
}
