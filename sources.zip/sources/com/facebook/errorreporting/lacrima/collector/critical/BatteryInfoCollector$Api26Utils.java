package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14990qj;
import X.C15110qv;
import android.os.BatteryManager;

public class BatteryInfoCollector$Api26Utils {
    public static void setApi26Properties(BatteryManager batteryManager, C15110qv r3) {
        r3.De7(C14990qj.A1Y, batteryManager.getIntProperty(6));
    }
}
