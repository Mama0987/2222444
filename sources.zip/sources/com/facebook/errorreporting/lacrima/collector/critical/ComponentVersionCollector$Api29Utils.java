package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14960qf;
import X.C14990qj;
import X.C15110qv;
import X.C15250rA;
import X.C17950w5;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.facebook.errorreporting.field.ReportFieldString;
import java.util.Map;

public class ComponentVersionCollector$Api29Utils {
    public static void setArtVersionInfo(PackageManager packageManager, C15110qv r4, C15250rA r5) {
        PackageInfo packageInfo;
        ReportFieldString reportFieldString;
        C14960qf r2;
        PackageManager packageManager2;
        try {
            packageManager2 = packageManager;
            PackageInfo packageInfo2 = packageManager.getPackageInfo("com.google.android.art", 1073741824);
            packageManager2 = packageInfo2;
            packageInfo = packageInfo2;
        } catch (PackageManager.NameNotFoundException unused) {
            try {
                packageInfo = packageManager2.getPackageInfo("com.android.art", 1073741824);
            } catch (PackageManager.NameNotFoundException e) {
                C17950w5.A00().CnD("ArtVer", e, (Map) null);
                return;
            }
        }
        if (packageInfo != null) {
            C15250rA r22 = C15250rA.CURRENT;
            if (r5 == r22) {
                reportFieldString = C14990qj.A4W;
            } else {
                reportFieldString = C14990qj.A4X;
            }
            r4.De9(reportFieldString, packageInfo.versionName);
            if (r5 == r22) {
                r2 = C14990qj.A1I;
            } else {
                r2 = C14990qj.A1J;
            }
            C15110qv.A00(r2, r4, packageInfo.getLongVersionCode());
        }
    }
}
