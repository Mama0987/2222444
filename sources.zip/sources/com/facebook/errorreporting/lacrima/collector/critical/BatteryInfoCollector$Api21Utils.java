package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14990qj;
import X.C15110qv;
import android.content.Context;
import android.os.BatteryManager;

public class BatteryInfoCollector$Api21Utils {
    public static BatteryManager getBatteryManager(Context context) {
        return (BatteryManager) context.getSystemService("batterymanager");
    }

    public static void setApi21Properties(BatteryManager batteryManager, C15110qv r4) {
        r4.De7(C14990qj.A1T, batteryManager.getIntProperty(4));
        r4.De7(C14990qj.A1U, batteryManager.getIntProperty(1));
        r4.De7(C14990qj.A1V, batteryManager.getIntProperty(3));
        r4.De7(C14990qj.A1W, batteryManager.getIntProperty(2));
        r4.De8(C14990qj.A1X, Long.valueOf(batteryManager.getLongProperty(5)));
    }
}
