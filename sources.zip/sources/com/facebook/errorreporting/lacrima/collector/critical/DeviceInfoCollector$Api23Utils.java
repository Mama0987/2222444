package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14990qj;
import X.C15110qv;
import android.os.Build;

public class DeviceInfoCollector$Api23Utils {
    public static void addSecurityPatchInfo(C15110qv r2) {
        r2.De9(C14990qj.A9h, Build.VERSION.SECURITY_PATCH);
    }
}
