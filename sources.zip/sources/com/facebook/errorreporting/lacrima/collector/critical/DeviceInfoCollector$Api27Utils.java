package com.facebook.errorreporting.lacrima.collector.critical;

import X.C14990qj;
import X.C15110qv;
import android.content.Context;
import android.content.pm.PackageManager;

public class DeviceInfoCollector$Api27Utils {
    public static void addLowRamFeature(Context context, C15110qv r3) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager != null) {
            r3.De6(C14990qj.A07, packageManager.hasSystemFeature("android.hardware.ram.low"));
        }
    }
}
