package com.facebook.errorreporting.lacrima.common.lifecycle;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public final class ApplicationLifecycleEventHistory$Api21Utils {
    public static void setRemoveOnCancelPolicy(ScheduledExecutorService scheduledExecutorService) {
        if (scheduledExecutorService instanceof ScheduledThreadPoolExecutor) {
            ((ScheduledThreadPoolExecutor) scheduledExecutorService).setRemoveOnCancelPolicy(true);
        }
    }
}
