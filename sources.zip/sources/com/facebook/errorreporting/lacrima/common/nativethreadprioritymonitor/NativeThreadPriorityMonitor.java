package com.facebook.errorreporting.lacrima.common.nativethreadprioritymonitor;

import X.C18440x7;

public final class NativeThreadPriorityMonitor {
    public static final NativeThreadPriorityMonitor INSTANCE = new Object();

    public static final native void registerMonitor();

    /* JADX WARNING: type inference failed for: r0v0, types: [com.facebook.errorreporting.lacrima.common.nativethreadprioritymonitor.NativeThreadPriorityMonitor, java.lang.Object] */
    static {
        C18440x7.loadLibrary("native_threadprioritymonitor");
    }
}
