package com.facebook.errorreporting.lacrima.common;

import android.os.ext.SdkExtensions;
import java.util.Map;

public class SdkExtensionsUtil$Api31Utils {
    public static Map getSdkExtensionsVersionsMap() {
        return SdkExtensions.getAllExtensionVersions();
    }
}
