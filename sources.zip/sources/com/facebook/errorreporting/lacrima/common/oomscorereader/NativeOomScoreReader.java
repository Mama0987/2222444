package com.facebook.errorreporting.lacrima.common.oomscorereader;

import X.AnonymousClass05N;
import X.C10740gw;
import X.C18440x7;

public class NativeOomScoreReader implements C10740gw {
    public final boolean mSetDumpable;

    private native void readValues(int i, Object obj, boolean z);

    static {
        C18440x7.loadLibrary("native_oomscorereader");
    }

    public AnonymousClass05N readOomScoreInfo(int i) {
        AnonymousClass05N r1 = new AnonymousClass05N();
        readValues(i, r1, this.mSetDumpable);
        return r1;
    }

    public NativeOomScoreReader(boolean z) {
        this.mSetDumpable = z;
    }
}
