package com.facebook.errorreporting.lacrima.common.asl;

import android.os.Build;

public final class AppStateSessionSummary$Api33Utils {
    public static String exitInfoReasonAsString(int i) {
        if (i == 14) {
            return "freezer";
        }
        if (Build.VERSION.SDK_INT >= 34) {
            return AppStateSessionSummary$Api34Utils.exitInfoReasonAsString(i);
        }
        return "unexplained";
    }
}
