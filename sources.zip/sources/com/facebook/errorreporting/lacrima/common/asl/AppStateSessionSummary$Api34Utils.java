package com.facebook.errorreporting.lacrima.common.asl;

public final class AppStateSessionSummary$Api34Utils {
    public static String exitInfoReasonAsString(int i) {
        if (i == 15 || i == 16) {
            return "upgrade";
        }
        return "unexplained";
    }
}
