package com.facebook.errorreporting.lacrima.common.exception;

import X.C15830sD;

public class LacrimaJavascriptException extends RuntimeException implements C15830sD {
    public String mExtraDataAsJson;
}
