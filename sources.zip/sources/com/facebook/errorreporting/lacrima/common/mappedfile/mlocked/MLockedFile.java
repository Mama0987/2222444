package com.facebook.errorreporting.lacrima.common.mappedfile.mlocked;

import X.C15960sV;
import java.nio.ByteBuffer;

public class MLockedFile extends C15960sV {
    public static volatile boolean sLibraryLoaded;

    public static native void mlockBuffer(ByteBuffer byteBuffer);

    public static native void munlockBuffer(ByteBuffer byteBuffer);

    public void mlockBuffer() {
        if (sLibraryLoaded) {
            mlockBuffer(this.A00);
        }
    }
}
