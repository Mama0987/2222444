package com.facebook.errorreporting.field;

import X.AnonymousClass001;
import X.C14900qZ;
import X.C15800sA;
import java.util.Set;
import kotlin.jvm.internal.DefaultConstructorMarker;

public class ReportFieldBase {
    public static final C14900qZ Companion = new Object();
    public static int autoId = 1;
    public static final Set sNoConsentNeeded = AnonymousClass001.A0x();
    public int id;
    public final String name;
    public final boolean requiresConsent;

    public ReportFieldBase(int i, String str, boolean z) {
        C15800sA.A0D(str, 2);
        this.id = i;
        this.name = str;
        this.requiresConsent = z;
        int i2 = autoId;
        if (i == 0) {
            autoId = i2 + 1;
            this.id = i2;
        } else {
            autoId = Math.max(i2, i + 1);
        }
        if (!z) {
            sNoConsentNeeded.add(str);
        }
    }

    public static final String getUnmarkedKey(String str) {
        C15800sA.A0D(str, 0);
        return str;
    }

    public static final boolean requiresConsent(String str) {
        C15800sA.A0D(str, 0);
        return !sNoConsentNeeded.contains(str);
    }

    public final int getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final boolean getRequiresConsent() {
        return this.requiresConsent;
    }

    public final boolean isRequiresConsent() {
        return this.requiresConsent;
    }

    public final void setId(int i) {
        this.id = i;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ReportFieldBase(int i, String str, boolean z, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(i, str, (i2 & 4) != 0 ? true : z);
    }
}
