package com.facebook.errorreporting.field;

import X.C14890qY;
import X.C14970qg;
import X.C15800sA;
import kotlin.jvm.internal.DefaultConstructorMarker;

public class ReportFieldString extends C14890qY {
    public static final C14970qg Companion = new Object();
    public static final int DEFAULT_STRING_FIELD_LENGTH = 48;
    public static final int FIX_ME_DISK_ID = -1;
    public static final int FIX_ME_MEM_ID = -2;
    public final boolean overflowToDisk;
    public final boolean useLeadByte;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ReportFieldString(int r8, java.lang.String r9, boolean r10, boolean r11) {
        /*
            r7 = this;
            r0 = 2
            r2 = r9
            X.C15800sA.A0D(r9, r0)
            r4 = r11 ^ 1
            r5 = 48
            if (r11 == 0) goto L_0x000c
            r5 = 1
        L_0x000c:
            r0 = r7
            r1 = r8
            r3 = r10
            r6 = r4
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.errorreporting.field.ReportFieldString.<init>(int, java.lang.String, boolean, boolean):void");
    }

    public static final ReportFieldString createFixMe(String str) {
        C15800sA.A0D(str, 0);
        return new ReportFieldString(-2, str, true);
    }

    public static final ReportFieldString createForTesting(String str) {
        C15800sA.A0D(str, 0);
        return new ReportFieldString(0, str, false);
    }

    public static final ReportFieldString createFixMePersist(String str) {
        return C14970qg.A00(str);
    }

    public final boolean getOverflowToDisk() {
        return this.overflowToDisk;
    }

    public final boolean getUseLeadByte() {
        return this.useLeadByte;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ReportFieldString(int i, String str, boolean z) {
        this(i, str, z, true, 48, true);
        C15800sA.A0D(str, 2);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ReportFieldString(int i, String str, boolean z, int i2, boolean z2, int i3, DefaultConstructorMarker defaultConstructorMarker) {
        this(i, str, z, i2, (i3 & 16) != 0 ? false : z2);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ReportFieldString(int i, String str, boolean z, int i2, boolean z2) {
        this(i, str, z, true, i2, z2);
        C15800sA.A0D(str, 2);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ReportFieldString(int i, String str, boolean z, boolean z2, int i2, boolean z3) {
        super(i, str, z, Math.min(126, i2));
        C15800sA.A0D(str, 2);
        this.useLeadByte = z2;
        this.overflowToDisk = z3;
    }
}
