package com.facebook.errorreporting.processimportance;

import X.C14270pR;
import X.C18240wb;
import android.app.ActivityManager;

public final class ProcessImportanceProvider$Api16Utils {
    public static boolean getMyMemoryState(ActivityManager.RunningAppProcessInfo runningAppProcessInfo) {
        synchronized (runningAppProcessInfo) {
            try {
                ActivityManager.getMyMemoryState(runningAppProcessInfo);
            } catch (RuntimeException e) {
                C14270pR.A0I(C18240wb.__redex_internal_original_name, "Could not get current importance", e);
                return false;
            }
        }
        return true;
    }

    public static void copyLastTrimLevel(ActivityManager.RunningAppProcessInfo runningAppProcessInfo, ActivityManager.RunningAppProcessInfo runningAppProcessInfo2) {
        runningAppProcessInfo2.lastTrimLevel = runningAppProcessInfo.lastTrimLevel;
    }
}
