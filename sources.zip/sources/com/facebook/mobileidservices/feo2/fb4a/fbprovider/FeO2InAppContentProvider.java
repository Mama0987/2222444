package com.facebook.mobileidservices.feo2.fb4a.fbprovider;

import X.C10640fx;

public final class FeO2InAppContentProvider extends C10640fx {
}
