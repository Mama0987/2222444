package com.facebook.abtest.qe.db;

import X.C10640fx;

public class QuickExperimentContentProvider extends C10640fx {
}
