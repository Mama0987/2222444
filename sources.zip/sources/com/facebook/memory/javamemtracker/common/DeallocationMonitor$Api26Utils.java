package com.facebook.memory.javamemtracker.common;

public class DeallocationMonitor$Api26Utils {
    public static String getClassName(Class cls) {
        return cls.getTypeName();
    }
}
