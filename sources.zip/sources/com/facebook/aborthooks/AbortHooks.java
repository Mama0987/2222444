package com.facebook.aborthooks;

import X.C18440x7;

public final class AbortHooks {
    public static final AbortHooks INSTANCE = new Object();
    public static volatile boolean sInstalled;

    public static final native void hookAbort();

    public static final native void hookAndroidLogAssert();

    public static final native void hookAndroidSetAbortMessage();

    public static final native void install(int i);

    public static final native void setGlogFatalHandler();

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.facebook.aborthooks.AbortHooks] */
    static {
        C18440x7.loadLibrary("aborthooks");
    }
}
