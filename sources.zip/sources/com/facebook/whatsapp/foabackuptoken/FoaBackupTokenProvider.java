package com.facebook.whatsapp.foabackuptoken;

import X.C10640fx;

public final class FoaBackupTokenProvider extends C10640fx {
}
