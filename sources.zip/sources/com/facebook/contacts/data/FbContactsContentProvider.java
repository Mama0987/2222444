package com.facebook.contacts.data;

import X.C10640fx;

public class FbContactsContentProvider extends C10640fx {
}
