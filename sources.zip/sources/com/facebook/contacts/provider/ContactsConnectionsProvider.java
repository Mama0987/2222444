package com.facebook.contacts.provider;

import X.C10640fx;

@Deprecated
public class ContactsConnectionsProvider extends C10640fx {
}
