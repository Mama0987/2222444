package com.facebook.mobileboost.framework.os.jni;

import X.C14270pR;
import X.C18440x7;

public class MobileBoostNative {
    public static boolean sNativeLibLoaded;

    public static native void disableSmartFsync();

    public static native boolean enableLicmFix(boolean z);

    public static native boolean enableSmartFsync(boolean z);

    static {
        try {
            sNativeLibLoaded = C18440x7.loadLibrary("fb_mboost");
        } catch (UnsatisfiedLinkError e) {
            C14270pR.A0J("MobileBoostJNI", "Failed to load MobileBoostNative lib.", e);
            sNativeLibLoaded = false;
        }
    }
}
