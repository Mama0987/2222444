package com.facebook.base.lwperf.traceutil;

import X.C08060bQ;
import X.C10980hR;
import X.C15800sA;

public final class TraceUtil$Api18Utils {
    public static final TraceUtil$Api18Utils INSTANCE = new TraceUtil$Api18Utils();
    public static final int MAX_SECTION_NAME_LENGTH = 127;

    public static final void beginSection(String str) {
        C15800sA.A0D(str, 0);
        if (str.length() > 127) {
            str = str.substring(0, 127);
            C15800sA.A09(str);
        }
        C08060bQ.A01(str, 2105111227);
    }

    static {
        C10980hR.A00();
    }

    public static final void endSection() {
        C08060bQ.A00(2033863689);
    }
}
