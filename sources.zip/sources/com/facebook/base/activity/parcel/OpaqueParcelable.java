package com.facebook.base.activity.parcel;

import X.AnonymousClass16Q;
import X.C15800sA;
import android.os.Parcel;
import android.os.Parcelable;

public final class OpaqueParcelable implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16Q(1);
    public final byte[] A00;

    public final void writeToParcel(Parcel parcel, int i) {
        C15800sA.A0D(parcel, 0);
        byte[] bArr = this.A00;
        parcel.writeInt(bArr.length);
        parcel.writeByteArray(bArr);
    }

    public OpaqueParcelable(Parcelable parcelable) {
        Parcel obtain = Parcel.obtain();
        C15800sA.A09(obtain);
        try {
            parcelable.writeToParcel(obtain, 0);
            this.A00 = obtain.marshall();
        } finally {
            obtain.recycle();
        }
    }

    public final int describeContents() {
        return 0;
    }

    public OpaqueParcelable(Parcel parcel) {
        byte[] bArr = new byte[parcel.readInt()];
        this.A00 = bArr;
        parcel.readByteArray(bArr);
    }
}
