package com.facebook.base.app;

import X.AnonymousClass0HQ;
import X.AnonymousClass0i5;
import X.C15800sA;
import android.app.Activity;
import android.view.ViewTreeObserver;

public abstract class SplashScreenActivity extends Activity implements AnonymousClass0HQ {

    public final class Api16Utils {
        public static final Api16Utils INSTANCE = new Api16Utils();

        public static final void arrangeDrawNotification(ViewTreeObserver viewTreeObserver, SplashScreenActivity splashScreenActivity) {
            C15800sA.A0F(viewTreeObserver, splashScreenActivity);
            viewTreeObserver.addOnDrawListener(new AnonymousClass0i5(viewTreeObserver, splashScreenActivity));
        }
    }
}
