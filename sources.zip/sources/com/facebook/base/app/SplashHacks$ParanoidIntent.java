package com.facebook.base.app;

import X.C15800sA;
import android.content.Intent;

public final class SplashHacks$ParanoidIntent extends Intent {
    public final boolean hasExtra(String str) {
        C15800sA.A0D(str, 0);
        if ("android.view.autofill.extra.RESTORE_SESSION_TOKEN".equals(str) || "android.view.autofill.extra.RESTORE_CROSS_ACTIVITY".equals(str) || "huawei_preload".equals(str)) {
            return false;
        }
        return super.hasExtra(str);
    }
}
