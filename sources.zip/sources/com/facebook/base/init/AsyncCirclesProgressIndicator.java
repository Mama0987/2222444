package com.facebook.base.init;

import X.AnonymousClass0BS;
import X.AnonymousClass0QF;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.view.SurfaceHolder;

public final class AsyncCirclesProgressIndicator extends AnonymousClass0QF {
    public int A00;
    public float A01;
    public float A02;
    public float A03;
    public float A04;
    public final Paint A05;
    public final Paint A06;

    public final void A04(SurfaceHolder surfaceHolder) {
        Canvas lockCanvas;
        Paint paint;
        if (surfaceHolder != null && (lockCanvas = surfaceHolder.lockCanvas()) != null) {
            lockCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
            for (int i = 0; i < 5; i++) {
                float f = this.A02;
                float f2 = ((((float) i) * (this.A04 - (2.0f * f))) / 4.0f) + f;
                float f3 = this.A03 + f;
                if (this.A00 % 5 == i) {
                    paint = this.A06;
                } else {
                    paint = this.A05;
                }
                lockCanvas.drawCircle(f2, f3, f, paint);
            }
            if (surfaceHolder.getSurface() != null && surfaceHolder.getSurface().isValid()) {
                try {
                    surfaceHolder.unlockCanvasAndPost(lockCanvas);
                } catch (IllegalArgumentException unused) {
                }
            }
        }
    }

    public AsyncCirclesProgressIndicator(Context context, float f, float f2, float f3, int i, int i2) {
        super(context);
        this.A02 = 0;
        setZOrderOnTop(true);
        SurfaceHolder holder = getHolder();
        holder.setFormat(-3);
        holder.addCallback(this);
        Paint paint = new Paint(1);
        this.A06 = paint;
        Paint paint2 = new Paint(1);
        this.A05 = paint2;
        this.A04 = f;
        this.A01 = f2;
        this.A03 = f3;
        this.A02 = f2 / 2.0f;
        paint2.setColor(i);
        paint.setColor(i2);
        setBackgroundColor(0);
        getHolder().setFixedSize((int) this.A04, (int) (this.A01 + this.A03));
        A03();
    }

    public final void finalize() {
        int A032 = AnonymousClass0BS.A03(1933660493);
        try {
            A02();
        } finally {
            AnonymousClass0BS.A09(566026877, A032);
        }
    }
}
