package com.facebook.base.receiver;

import X.AnonymousClass0BS;
import X.AnonymousClass0WY;
import X.C11490iW;
import X.C14270pR;
import X.C14840qS;
import X.C14990qj;
import X.C15800sA;
import X.C211116i;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.LinkedList;
import java.util.stream.Collectors;
import kotlin.jvm.functions.Function1;

public final class AppInitReplayBroadcastReceiver extends BroadcastReceiver {
    public static final LinkedList A00 = new LinkedList();
    public static final LinkedList A01 = new LinkedList();

    public final void onReceive(Context context, Intent intent) {
        int A012 = AnonymousClass0BS.A01(1142214918);
        C15800sA.A0F(context, intent);
        C14270pR.A0G("AppInitBroadcast", AnonymousClass0WY.A0i("Received broadcast during app init: ", intent.getAction()));
        LinkedList linkedList = A01;
        synchronized (linkedList) {
            try {
                linkedList.push(intent);
                C14840qS.A08(C14990qj.A4w, String.valueOf(linkedList.size()));
                C14840qS.A08(C14990qj.A4u, (String) linkedList.stream().map(new C211116i((Function1) C11490iW.A00)).collect(Collectors.joining(", ")));
            } finally {
                AnonymousClass0BS.A0D(1410107245, A012, intent);
            }
        }
    }
}
