package com.facebook.analytics2.logger.legacy.uploader;

import X.C10940hL;

public class Analytics2UploadService extends C10940hL {
}
