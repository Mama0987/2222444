package com.facebook.voltron.metadata;

import X.AnonymousClass001;
import X.C14270pR;
import X.C15800sA;
import X.C198111f;

public final class VoltronModuleMetadataHelper {
    public static final int getBase62ClassName(String str) {
        int i;
        int i2 = 0;
        C15800sA.A0D(str, 0);
        int length = str.length();
        for (int A05 = C198111f.A05(str, '.', length - 1) + 1; A05 < length; A05++) {
            i2 *= 62;
            char charAt = str.charAt(A05);
            if (C15800sA.A00(charAt, 48) >= 0 && C15800sA.A00(charAt, 57) <= 0) {
                i = charAt - '0';
            } else if (C15800sA.A00(charAt, 65) < 0 || C15800sA.A00(charAt, 90) > 0) {
                if (C15800sA.A00(charAt, 97) >= 0 && C15800sA.A00(charAt, 122) <= 0) {
                    i = (charAt - 'a') + 10 + 26;
                }
            } else {
                i = (charAt - 'A') + 10;
            }
            i2 += i;
        }
        return i2;
    }

    public static final String getPackageNameForClass(String str) {
        C15800sA.A0D(str, 0);
        int length = str.length();
        if (length == 0) {
            throw AnonymousClass001.A0L("Class name is empty");
        } else if (str.startsWith("X.")) {
            return "X";
        } else {
            if (!Character.isLowerCase(str.codePointAt(0))) {
                return "";
            }
            int i = length - 1;
            int A04 = C198111f.A04(str, '.', 0);
            while (A04 > 0 && A04 < i) {
                if (!Character.isLowerCase(str.codePointAt(A04 + 1))) {
                    String substring = str.substring(0, A04);
                    C15800sA.A09(substring);
                    return substring;
                }
                A04 = C198111f.A04(str, '.', A04 + 1);
            }
            return "";
        }
    }

    public static final String getShortNameForClass(String str, String str2) {
        C15800sA.A0D(str, 0);
        C15800sA.A0D(str2, 1);
        int length = str2.length();
        if (length == 0) {
            return str;
        }
        String substring = str.substring(length + 1);
        C15800sA.A09(substring);
        return substring;
    }

    public static final int getModuleRangeIndexForRedexClassName(String str, int[] iArr) {
        boolean A0Q = C15800sA.A0Q(str, iArr);
        return getModuleRangeIndexForRedexClassName(getBase62ClassName(str), iArr, A0Q ? 1 : 0, (iArr.length / 2) - 1);
    }

    public static final int getModuleRangeIndexForRedexClassName(int i, int[] iArr, int i2, int i3) {
        int i4;
        if (i2 > i3) {
            return -1;
        }
        int i5 = (i2 + i3) / 2;
        int i6 = i5 * 2;
        int i7 = i6 + 1;
        int i8 = iArr[i6];
        if (i8 == -1 || (i4 = iArr[i7]) == -1) {
            C14270pR.A0G("VoltronModuleMetadataHelper", "Invalid range in module range index");
            return -1;
        } else if (i > i4) {
            return getModuleRangeIndexForRedexClassName(i, iArr, i5 + 1, i3);
        } else {
            if (i < i8) {
                return getModuleRangeIndexForRedexClassName(i, iArr, i2, i5 - 1);
            }
            return i5;
        }
    }
}
