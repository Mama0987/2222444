package com.facebook.voltron.runtime.osutil;

import X.AnonymousClass001;
import X.C15800sA;
import android.os.Build;

public final class AndroidOsBuildAbi$OsBuildAbiHelper {
    public static final AndroidOsBuildAbi$OsBuildAbiHelper INSTANCE = new AndroidOsBuildAbi$OsBuildAbiHelper();

    public final String getDeviceOsBuildAbi() {
        String str;
        String[] strArr = Build.SUPPORTED_ABIS;
        C15800sA.A0A(strArr);
        if (strArr.length != 0 && (str = strArr[0]) != null) {
            return str;
        }
        throw AnonymousClass001.A0V("Could not obtain device cpu abi: null");
    }
}
