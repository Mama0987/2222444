package com.facebook.voltron.runtime;

import X.AnonymousClass0WY;
import android.content.Context;

public class ModuleApkUtil$ModuleResolver {
    public static String getSplitApkLocation(String str, Context context) {
        String[] strArr = context.getApplicationInfo().splitSourceDirs;
        if (strArr != null) {
            String A0w = AnonymousClass0WY.A0w("split_", str, ".apk");
            for (String str2 : strArr) {
                if (str2.endsWith(A0w)) {
                    return str2;
                }
            }
        }
        return null;
    }
}
