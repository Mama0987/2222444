package com.facebook.oxygen.preloads.integration.dogfooding;

import X.C10640fx;

public class AppManagerSsoProvider extends C10640fx {
}
