package com.facebook.nobreak;

import android.app.Notification;

public final class CrashLoopRemedy$Api16Utils {
    public static void applyBigTextStyle(Notification.Builder builder, String str) {
        builder.setStyle(new Notification.BigTextStyle().bigText(str));
    }
}
