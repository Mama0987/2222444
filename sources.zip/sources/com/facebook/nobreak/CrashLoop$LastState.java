package com.facebook.nobreak;

import X.AnonymousClass0BS;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CrashLoop$LastState extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
        AnonymousClass0BS.A0D(1429700000, AnonymousClass0BS.A01(1170860296), intent);
    }
}
