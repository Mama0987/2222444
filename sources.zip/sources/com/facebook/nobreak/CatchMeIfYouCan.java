package com.facebook.nobreak;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0V1;
import X.AnonymousClass0WY;
import X.AnonymousClass0ZM;
import X.AnonymousClass11T;
import X.C06300Vs;
import X.C12920mh;
import X.C12930mi;
import X.C12960ml;
import X.C12970mm;
import X.C13010mq;
import X.C13910oh;
import X.C18960yc;
import X.C18970yd;
import X.C18980yf;
import X.C19000yj;
import X.C19010yk;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.os.Process;
import android.util.Log;
import com.facebook.endtoend.EndToEnd;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class CatchMeIfYouCan implements C13010mq {
    public static final String ATTRIBUTE_LONG_NUMBER_OF_CRASHES = "number_of_crashes";
    public static final String CRASH_LOCK_FILE_NAME = "crash_lock";
    public static final int CRASH_LOG_ANALYSIS_SECONDS = 14400;
    public static final String CRASH_LOG_FILE_NAME = "crash_log";
    public static final String DISABLED_SIGNAL_FILE_NAME = "app_was_disabled";
    public static final int FLAG_COUNT_CRASHES_IN_THIS_PROCESS = 2;
    public static final int FLAG_SILENT_EXIT = 1;
    public static int INSTACRASH_INTERVAL_MS = 45000;
    public static final long INSTACRASH_REMEDY_TIMEOUT_MS = 3600000;
    public static final String INSTA_CRASH_LOG_FILE_NAME = "insta_crash_log";
    public static int LEVEL_1_INSTACRASH_THRESHOLD = 2;
    public static int LEVEL_1_THRESHOLD = 5;
    public static int LEVEL_2_INSTACRASH_THRESHOLD = 5;
    public static int LEVEL_2_THRESHOLD = 30;
    public static int LEVEL_3_INSTACRASH_THRESHOLD = 10;
    public static int LEVEL_3_THRESHOLD = 40;
    public static final long NOT_CRASHED_TIMESTAMP = 1;
    public static final int NR_CRASH_LOG_RECORDS = 40;
    public static final long REMEDY_TIMEOUT_MS = 86400000;
    public static final String TAG = "CatchMeIfYouCan";
    public static boolean VERBOSE = false;
    public static int sAppliedCrashRemedyThisStartup = 0;
    public static int sAppliedInstaCrashRemedyThisStartup = 0;
    public static C12920mh sCrashLog = null;
    public static int sFlags = 0;
    public static C12920mh sInstaCrashLog = null;
    public static int sInstaCrashRemedyLevelNeeded = 0;
    public static CatchMeIfYouCan sInstance = null;
    public static C19000yj sSavedInstaCrashRemedyLog = null;
    public static long sSavedNowAtStartup = 0;
    public static int sSavedNrRecentCrashes = -1;
    public static int sSavedNrRecentInstaCrashes = -1;
    public static C19000yj sSavedRemedyLog;
    public static boolean shouldLogInstacrashAsCrash;
    public static boolean shouldUseOptimizedCmiyc;

    public static void analyzeRecentCrashes(Context context, String str, long j) {
        int i;
        int i2;
        Context context2 = context;
        AnonymousClass11T r6 = new AnonymousClass11T(new File(AnonymousClass001.A0a(context2), CRASH_LOCK_FILE_NAME));
        try {
            C12920mh r0 = sCrashLog;
            MappedByteBuffer mappedByteBuffer = r0.A03;
            int i3 = r0.A01;
            long now = r0.A00.now();
            long j2 = now - 14400000;
            int i4 = 0;
            for (int i5 = 0; i5 < i3; i5++) {
                long j3 = mappedByteBuffer.getLong(i5 * 8);
                if (j3 >= j2 && j3 <= now) {
                    i4++;
                }
            }
            sSavedNrRecentCrashes = i4;
            int i6 = 1;
            if (i4 >= LEVEL_3_THRESHOLD) {
                i = 3;
            } else if (i4 >= LEVEL_2_THRESHOLD) {
                i = 2;
            } else {
                i = 0;
                if (i4 >= LEVEL_1_THRESHOLD) {
                    i = 1;
                }
            }
            C12920mh r02 = sInstaCrashLog;
            MappedByteBuffer mappedByteBuffer2 = r02.A03;
            int i7 = r02.A01;
            long now2 = r02.A00.now();
            long j4 = now2 - 14400000;
            int i8 = 0;
            for (int i9 = 0; i9 < i7; i9++) {
                long j5 = mappedByteBuffer2.getLong(i9 * 8);
                if (j5 >= j4 && j5 <= now2) {
                    i8++;
                }
            }
            sSavedNrRecentInstaCrashes = i8;
            if (i8 >= LEVEL_3_INSTACRASH_THRESHOLD) {
                i2 = 3;
            } else if (i8 >= LEVEL_2_INSTACRASH_THRESHOLD) {
                i2 = 2;
            } else {
                i2 = 0;
                if (i8 >= LEVEL_1_INSTACRASH_THRESHOLD) {
                    i2 = 1;
                }
            }
            if (j < REMEDY_TIMEOUT_MS && i > 1) {
                i = 1;
            }
            if (j >= INSTACRASH_REMEDY_TIMEOUT_MS || i2 <= 1) {
                i6 = i2;
            }
            sInstaCrashRemedyLevelNeeded = i6;
            handleRemedyLocked(i, i6, context2, str);
            r6.close();
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public static boolean getDidApplyCrashOrInstaCrashRemedyAboveLevel1ThisStartup() {
        if (sAppliedInstaCrashRemedyThisStartup <= 1) {
            return false;
        }
        return true;
    }

    public static long getRecentCrashes() {
        return (long) sSavedNrRecentCrashes;
    }

    public static long getRecentInstaCrashes() {
        return (long) sSavedNrRecentInstaCrashes;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [X.0V1, java.lang.Object] */
    public static AnonymousClass0V1 getRemedyClass(String str) {
        if (str != null) {
            try {
                AnonymousClass0V1 r0 = (AnonymousClass0V1) Class.forName(str).newInstance();
                if (r0 != null) {
                    return r0;
                }
            } catch (Throwable th) {
                Log.e(TAG, "instantiating custom remedy class failed; continuing", th);
            }
        }
        return new Object();
    }

    public static void handleRemedyLocked(int i, int i2, Context context, String str) {
        int i3;
        int i4;
        Context context2 = context;
        String A0a = AnonymousClass001.A0a(context2);
        long currentTimeMillis = System.currentTimeMillis();
        loadPreviousRemedies(context2, currentTimeMillis, false);
        loadPreviousRemedies(context2, currentTimeMillis, true);
        File file = new File(A0a, DISABLED_SIGNAL_FILE_NAME);
        if (file.exists()) {
            try {
                PackageManager packageManager = context2.getPackageManager();
                ComponentName componentName = new ComponentName(context2, CrashLoop$LastState.class);
                ArrayList A0t = AnonymousClass001.A0t();
                C18980yf.A00(context2, packageManager, A0t);
                ArrayList A0t2 = AnonymousClass001.A0t();
                Iterator it = A0t.iterator();
                while (it.hasNext()) {
                    PackageItemInfo packageItemInfo = (PackageItemInfo) it.next();
                    A0t2.add(new ComponentName(packageItemInfo.packageName, packageItemInfo.name));
                }
                Iterator it2 = A0t2.iterator();
                while (it2.hasNext()) {
                    ComponentName componentName2 = (ComponentName) it2.next();
                    componentName2.getClassName();
                    packageManager.setComponentEnabledSetting(componentName2, 0, 1);
                }
                packageManager.setComponentEnabledSetting(componentName, 0, 1);
            } catch (PackageManager.NameNotFoundException e) {
                throw AnonymousClass001.A0X(e);
            } catch (RuntimeException e2) {
                Log.e(TAG, "unable to reset crash loop", e2);
            }
            file.delete();
        }
        C19000yj r0 = sSavedRemedyLog;
        if (r0 == null) {
            i3 = 0;
        } else {
            i3 = r0.A00;
        }
        C19000yj r1 = sSavedInstaCrashRemedyLog;
        if (r1 == null) {
            i4 = 0;
        } else {
            i4 = r1.A00;
        }
        int i5 = i2;
        String str2 = str;
        if (i5 > i4) {
            applyRemedyAndRecord(context2, i5, i4, true, currentTimeMillis, str2);
            return;
        }
        int i6 = i;
        if (i6 > i3) {
            applyRemedyAndRecord(context2, i6, i3, false, currentTimeMillis, str2);
        } else if (i2 > 0) {
            applyRemedyAndRecord(context2, i5, i4, true, currentTimeMillis, str2);
        } else if (i > 0) {
            applyRemedyAndRecord(context2, i6, i3, false, currentTimeMillis, str2);
        }
    }

    public static void init(Context context, int i, String str, C18970yd r20) {
        long j;
        Context context2 = context;
        VERBOSE = isDebug(context2);
        CatchMeIfYouCan catchMeIfYouCan = new CatchMeIfYouCan();
        sInstance = catchMeIfYouCan;
        C12960ml.A02(catchMeIfYouCan, -100000);
        sFlags = i;
        if (r20 != null) {
            throw AnonymousClass001.A0T("getInstacrashLevel1Threshold");
        }
        boolean z = false;
        if (EndToEnd.A04()) {
            LEVEL_1_THRESHOLD = 3;
            LEVEL_2_THRESHOLD = 5;
            LEVEL_3_THRESHOLD = 7;
        }
        File crashLogFile = getCrashLogFile(context2);
        String str2 = context2.getApplicationInfo().sourceDir;
        sSavedNowAtStartup = System.currentTimeMillis();
        long lastModified = AnonymousClass001.A0E(str2).lastModified();
        long j2 = sSavedNowAtStartup - lastModified;
        if (crashLogFile.exists()) {
            j = crashLogFile.lastModified();
            if (j < lastModified && j != 1) {
                C19000yj.A00(context2, false);
                if (!crashLogFile.delete()) {
                    Log.e(TAG, AnonymousClass002.A0M(crashLogFile, "unable to delete stale crash log file: ", AnonymousClass001.A0m()));
                }
                z = true;
            }
        } else {
            j = -1;
        }
        File instaCrashLogFile = getInstaCrashLogFile(context2);
        if (j != 1 && instaCrashLogFile.exists() && instaCrashLogFile.lastModified() < lastModified) {
            C19000yj.A00(context2, true);
            if (!instaCrashLogFile.delete()) {
                Log.e(TAG, AnonymousClass002.A0M(instaCrashLogFile, "could not delete insta crash log file: ", AnonymousClass001.A0m()));
            }
        }
        int i2 = NR_CRASH_LOG_RECORDS;
        sCrashLog = new C12920mh(context2, crashLogFile, i2, shouldUseOptimizedCmiyc);
        sInstaCrashLog = new C12920mh(context2, instaCrashLogFile, i2, shouldUseOptimizedCmiyc);
        if (shouldUseOptimizedCmiyc) {
            if (z) {
                try {
                    crashLogFile.setLastModified(1);
                    return;
                } catch (Exception unused) {
                }
            } else if (sSavedNowAtStartup - j > REMEDY_TIMEOUT_MS) {
                return;
            }
        }
        if ((i & 2) != 0) {
            String str3 = str;
            Executors.newScheduledThreadPool(1).schedule(new C18960yc(context2, str3), (long) INSTACRASH_INTERVAL_MS, TimeUnit.MILLISECONDS);
            analyzeRecentCrashes(context2, str3, j2);
        }
    }

    public static boolean isInitialized() {
        if (sInstance != null) {
            return true;
        }
        return false;
    }

    public static void killSiblingProcesses(Context context, boolean z) {
        int i;
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        int myPid = Process.myPid();
        int myUid = Process.myUid();
        if (activityManager.getRunningAppProcesses() != null) {
            for (ActivityManager.RunningAppProcessInfo next : activityManager.getRunningAppProcesses()) {
                if (next.uid == myUid && (i = next.pid) != myPid) {
                    Process.killProcess(i);
                }
            }
        }
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: SSATransform
        java.lang.ArrayIndexOutOfBoundsException
        */
    public static void killThisProcess() {
        /*
            java.lang.String r1 = "CatchMeIfYouCan"
            java.lang.String r0 = "CatchMeIfYouCan is killing this process"
            android.util.Log.e(r1, r0)
            int r0 = android.os.Process.myPid()
            android.os.Process.killProcess(r0)
            r0 = 10
            java.lang.System.exit(r0)
        L_0x0013:
            goto L_0x0013
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.nobreak.CatchMeIfYouCan.killThisProcess():void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:38:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x0079  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void loadPreviousRemedies(android.content.Context r8, long r9, boolean r11) {
        /*
            java.lang.String r3 = "CatchMeIfYouCan"
            if (r11 == 0) goto L_0x0009
            r6 = 3600000(0x36ee80, double:1.7786363E-317)
        L_0x0007:
            r5 = 0
            goto L_0x000d
        L_0x0009:
            r6 = 86400000(0x5265c00, double:4.2687272E-316)
            goto L_0x0007
        L_0x000d:
            java.lang.String r2 = X.AnonymousClass001.A0a(r8)     // Catch:{ all -> 0x0053 }
            if (r11 == 0) goto L_0x001f
            java.lang.String r0 = "insta_crash_remedy_log"
        L_0x0015:
            java.io.File r1 = new java.io.File     // Catch:{ all -> 0x0053 }
            r1.<init>(r2, r0)     // Catch:{ all -> 0x0053 }
            java.io.RandomAccessFile r0 = X.AnonymousClass001.A0H(r1)     // Catch:{ all -> 0x0053 }
            goto L_0x0022
        L_0x001f:
            java.lang.String r0 = "remedy_log"
            goto L_0x0015
        L_0x0022:
            int r2 = r0.readInt()     // Catch:{ all -> 0x0049 }
            r0.close()     // Catch:{ all -> 0x0053 }
            long r0 = r1.lastModified()     // Catch:{ all -> 0x0053 }
            X.0yj r4 = new X.0yj     // Catch:{ all -> 0x0053 }
            r4.<init>(r0, r2)     // Catch:{ all -> 0x0053 }
            long r0 = r4.A01
            long r9 = r9 - r0
            r1 = 0
            int r0 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0041
            java.lang.String r0 = "remedy is from the future!"
            android.util.Log.w(r3, r0)
            goto L_0x0070
        L_0x0041:
            int r0 = (r9 > r6 ? 1 : (r9 == r6 ? 0 : -1))
            if (r0 < 0) goto L_0x0070
            X.C19000yj.A00(r8, r11)
            goto L_0x0071
        L_0x0049:
            r1 = move-exception
            r0.close()     // Catch:{ all -> 0x004e }
            goto L_0x0052
        L_0x004e:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ all -> 0x0053 }
        L_0x0052:
            throw r1     // Catch:{ all -> 0x0053 }
        L_0x0053:
            r4 = move-exception
            java.lang.String r2 = X.AnonymousClass001.A0a(r8)
            if (r11 == 0) goto L_0x0076
            java.lang.String r1 = "insta_crash_remedy_log"
        L_0x005c:
            java.io.File r0 = new java.io.File
            r0.<init>(r2, r1)
            boolean r0 = r0.exists()
            if (r0 == 0) goto L_0x006c
            java.lang.String r0 = "unable to read remedy log file"
            android.util.Log.w(r3, r0, r4)
        L_0x006c:
            X.C19000yj.A00(r8, r11)
            r4 = r5
        L_0x0070:
            r5 = r4
        L_0x0071:
            if (r11 == 0) goto L_0x0079
            sSavedInstaCrashRemedyLog = r5
            return
        L_0x0076:
            java.lang.String r1 = "remedy_log"
            goto L_0x005c
        L_0x0079:
            sSavedRemedyLog = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.nobreak.CatchMeIfYouCan.loadPreviousRemedies(android.content.Context, long, boolean):void");
    }

    public static void maybeRecordCrash() {
        if ((sFlags & 2) != 0) {
            long currentTimeMillis = System.currentTimeMillis() - sSavedNowAtStartup;
            try {
                if (shouldLogInstacrashAsCrash) {
                    sCrashLog.A00();
                    if (currentTimeMillis <= ((long) INSTACRASH_INTERVAL_MS)) {
                        sInstaCrashLog.A00();
                    }
                } else if (currentTimeMillis > ((long) INSTACRASH_INTERVAL_MS)) {
                    sCrashLog.A00();
                } else {
                    sInstaCrashLog.A00();
                }
            } catch (Throwable unused) {
            }
        }
    }

    public static void reportExceptionToLogCat(Throwable th) {
        if (VERBOSE) {
            Log.e(TAG, AnonymousClass0WY.A0w("Uncaught exception in '", C13910oh.A00().A04(), "':"));
            for (String e : Log.getStackTraceString(th).split("\n")) {
                Log.e(TAG, e);
            }
        }
    }

    public int handleUncaughtException(Thread thread, Throwable th, C12930mi r6) {
        if (!(th instanceof C12970mm)) {
            maybeRecordCrash();
            try {
                reportExceptionToLogCat(th);
            } catch (Throwable unused) {
            }
            if ((sFlags & 1) != 0) {
                killThisProcess();
                throw C06300Vs.createAndThrow();
            }
            Log.e(TAG, "Not killing process because SILENT_EXIT flag is not set.");
        }
        return 0;
    }

    public static C19010yk applyRemedy(Context context, int i, int i2, boolean z, String str) {
        return getRemedyClass(str).A01(context, i, i2);
    }

    public static void applyRemedyAndRecord(Context context, int i, int i2, boolean z, long j, String str) {
        String str2;
        RandomAccessFile A0I;
        C19010yk applyRemedy = applyRemedy(context, i, i2, z, str);
        if (applyRemedy.A01) {
            if (!z) {
                sAppliedCrashRemedyThisStartup = i;
            } else {
                sAppliedInstaCrashRemedyThisStartup = i;
            }
            try {
                C19000yj r4 = new C19000yj(j, i);
                String A0a = AnonymousClass001.A0a(context);
                if (z) {
                    str2 = "insta_crash_remedy_log";
                } else {
                    str2 = "remedy_log";
                }
                File file = new File(A0a, str2);
                A0I = AnonymousClass001.A0I(file);
                A0I.writeInt(r4.A00);
                A0I.setLength(A0I.getFilePointer());
                A0I.close();
                if (!file.setLastModified(r4.A01)) {
                    Log.w("CrashLoopRemedyLog", "unable to set remedy log last modified timestamp");
                }
                if (z) {
                    sSavedInstaCrashRemedyLog = r4;
                } else {
                    sSavedRemedyLog = r4;
                }
            } catch (IOException e) {
                Log.w(TAG, "error recording remedy log", e);
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
            }
        }
        if (applyRemedy.A00) {
            try {
                killSiblingProcesses(context, true);
            } catch (Throwable th2) {
                Log.w(TAG, "error killing sibling processes", th2);
            }
            killThisProcess();
            throw C06300Vs.createAndThrow();
        }
        return;
        throw th;
    }

    public static File getCrashLogFile(Context context) {
        File file = new File(AnonymousClass001.A0a(context), CRASH_LOG_FILE_NAME);
        try {
            file.createNewFile();
            file.setReadable(true);
            file.setWritable(true);
        } catch (IOException unused) {
        }
        return file;
    }

    public static String getCrashLogFilePath(Context context) {
        return getCrashLogFile(context).getPath();
    }

    public static int getCrashRemedyAppliedThisStartup() {
        return sAppliedCrashRemedyThisStartup;
    }

    public static File getInstaCrashLogFile(Context context) {
        File file = new File(AnonymousClass001.A0a(context), INSTA_CRASH_LOG_FILE_NAME);
        try {
            file.createNewFile();
            file.setReadable(true);
            file.setWritable(true);
        } catch (IOException unused) {
        }
        return file;
    }

    public static String getInstaCrashLogFilePath(Context context) {
        return getInstaCrashLogFile(context).getPath();
    }

    public static int getInstaCrashRemedyAppliedThisStartup() {
        return sAppliedInstaCrashRemedyThisStartup;
    }

    public static int getInstaCrashRemedyLevelNeeded() {
        return sInstaCrashRemedyLevelNeeded;
    }

    public static C19000yj getLastInstaCrashRemedyApplication() {
        return sSavedInstaCrashRemedyLog;
    }

    public static C19000yj getLastRemedyApplication() {
        return sSavedRemedyLog;
    }

    public static long getTimeAtStartup() {
        return sSavedNowAtStartup;
    }

    public static boolean isDebug(Context context) {
        if ((context.getApplicationInfo().flags & 2) != 0) {
            return true;
        }
        return false;
    }

    public /* synthetic */ int getFlags() {
        return 0;
    }

    public int getId() {
        return 16;
    }

    public static void init(Context context, int i, String str) {
        init(context, i, str, (C18970yd) null);
    }
}
