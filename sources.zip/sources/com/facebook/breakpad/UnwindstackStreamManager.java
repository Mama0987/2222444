package com.facebook.breakpad;

import X.AnonymousClass001;
import X.C14270pR;
import X.C18440x7;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class UnwindstackStreamManager {
    public static volatile boolean isRegistered;
    public static boolean isUnwindstackJniLoaded = true;

    public static native void nativeRegister(String str, String str2);

    public static native void nativeUnregister();

    static {
        try {
            C18440x7.loadLibrary("unwindstack_stream");
        } catch (UnsatisfiedLinkError e) {
            C14270pR.A0I("unwindstack", "Failed to load unwindstack jni library: ", e);
        }
    }

    public static boolean register() {
        boolean z;
        ReentrantReadWriteLock reentrantReadWriteLock;
        synchronized (UnwindstackStreamManager.class) {
            if (!isRegistered) {
                if (!isUnwindstackJniLoaded) {
                    C14270pR.A0F("unwindstack", "Loading unwindstack jni native library failed. Cannot register unwindstack stream to breakpad");
                } else {
                    try {
                        String A01 = C18440x7.A01("libunwindstack_binary.so");
                        if (A01 == null) {
                            C14270pR.A0F("unwindstack", "Unable to find libunwindstack_binary.so");
                        } else {
                            ArrayList A0t = AnonymousClass001.A0t();
                            A0t.add("libunwindstack_binary.so");
                            ArrayList A0t2 = AnonymousClass001.A0t();
                            File parentFile = AnonymousClass001.A0E(A01).getParentFile();
                            if (parentFile != null) {
                                A0t2.add(parentFile.getCanonicalPath());
                            }
                            for (int i = 0; i < A0t.size(); i++) {
                                String str = (String) A0t.get(i);
                                reentrantReadWriteLock = C18440x7.A09;
                                reentrantReadWriteLock.readLock().lock();
                                String[] strArr = null;
                                if (C18440x7.A0D != null) {
                                    int i2 = 0;
                                    while (i2 < C18440x7.A0D.length) {
                                        strArr = C18440x7.A0D[i2].A02(str);
                                        i2++;
                                        if (strArr == null) {
                                        }
                                    }
                                }
                                reentrantReadWriteLock.readLock().unlock();
                                if (strArr == null) {
                                    C14270pR.A0P("unwindstack", "unable to find dependencies for %s, but it's okay for SystemLoadWrapperSoSource", A0t.get(i));
                                } else {
                                    for (String str2 : strArr) {
                                        String A012 = C18440x7.A01(str2);
                                        if (A012 == null) {
                                            C14270pR.A0P("unwindstack", "unable to find path for %s", str2);
                                        } else if (!A0t.contains(str2) && !A012.startsWith("/system") && !A012.startsWith("/vendor") && !A012.startsWith("/apex") && !A012.startsWith("/odm")) {
                                            A0t.add(str2);
                                            File parentFile2 = new File(A012).getParentFile();
                                            if (parentFile2 != null) {
                                                String canonicalPath = parentFile2.getCanonicalPath();
                                                if (!A0t2.contains(canonicalPath)) {
                                                    A0t2.add(canonicalPath);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            StringBuilder A0p = AnonymousClass001.A0p((String) A0t2.get(0));
                            for (int i3 = 1; i3 < A0t2.size(); i3++) {
                                A0p.append(":");
                                A0p.append((String) A0t2.get(i3));
                            }
                            nativeRegister(A01, A0p.toString());
                            z = true;
                            isRegistered = z;
                        }
                    } catch (IOException e) {
                        C14270pR.A0I("unwindstack", "Error registering unwindstack stream", e);
                    } catch (Throwable th) {
                        AnonymousClass001.A1Q(reentrantReadWriteLock);
                        throw th;
                    }
                }
                z = false;
                isRegistered = z;
            }
        }
        return isRegistered;
    }
}
