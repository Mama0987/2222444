package com.facebook.breakpad;

import X.C14270pR;
import X.C18440x7;

public class BreakpadExtraManager {
    public static volatile boolean sInstalled;

    public static native boolean appendSessionIdInTombstone(String str);

    static {
        try {
            C18440x7.loadLibrary("breakpad_extra");
        } catch (UnsatisfiedLinkError e) {
            C14270pR.A0I("BreakpadExtra", "Failed to load breakpad extra jni library: ", e);
        }
    }
}
