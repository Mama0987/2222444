package com.facebook.redex;

import X.AnonymousClass0WY;
import X.C15800sA;

public final class ConstantPropagationAssertHandler {
    public static final void fieldValueError(String str) {
        C15800sA.A0D(str, 0);
        throw new Error(AnonymousClass0WY.A0i("Assertion failed for field ", str));
    }

    public static final void returnValueError(String str) {
        C15800sA.A0D(str, 0);
        throw new Error(AnonymousClass0WY.A0i("Assertion failed for method ", str));
    }

    public static final void paramValueError(int i) {
        throw new Error(AnonymousClass0WY.A0d("Assertion failed for parameter ", i));
    }
}
