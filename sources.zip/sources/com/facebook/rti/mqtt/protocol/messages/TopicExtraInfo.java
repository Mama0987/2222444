package com.facebook.rti.mqtt.protocol.messages;

import android.os.Parcelable;

public interface TopicExtraInfo extends Parcelable {
}
