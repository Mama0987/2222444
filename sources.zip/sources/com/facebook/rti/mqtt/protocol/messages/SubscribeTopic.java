package com.facebook.rti.mqtt.protocol.messages;

import X.AnonymousClass001;
import X.AnonymousClass16O;
import X.C04550Me;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

public final class SubscribeTopic implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16O(5);
    public final int A00;
    public final String A01;

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null && getClass() == obj.getClass()) {
                SubscribeTopic subscribeTopic = (SubscribeTopic) obj;
                if (!C04550Me.A00(this.A01, subscribeTopic.A01) || this.A00 != subscribeTopic.A00) {
                    return false;
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.A01, Integer.valueOf(this.A00)});
    }

    public final String toString() {
        return String.format("{ name='%s', qos='%s', extra='%s' }", new Object[]{this.A01, Integer.valueOf(this.A00), null});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.A01);
        parcel.writeInt(this.A00);
        parcel.writeParcelable((Parcelable) null, i);
    }

    public SubscribeTopic(String str, int i) {
        if (str != null) {
            this.A01 = str;
            Integer valueOf = Integer.valueOf(i);
            if (valueOf != null) {
                this.A00 = valueOf.intValue();
                return;
            }
            throw AnonymousClass001.A0S();
        }
        throw AnonymousClass001.A0S();
    }

    public final int describeContents() {
        return 0;
    }

    public SubscribeTopic(Parcel parcel) {
        this.A01 = parcel.readString();
        this.A00 = parcel.readInt();
        parcel.readParcelable(TopicExtraInfo.class.getClassLoader());
    }
}
