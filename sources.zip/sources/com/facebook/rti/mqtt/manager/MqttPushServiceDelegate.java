package com.facebook.rti.mqtt.manager;

import X.AnonymousClass001;
import X.AnonymousClass0AT;
import X.AnonymousClass0G5;
import X.AnonymousClass0MB;
import X.AnonymousClass0MM;
import X.AnonymousClass0QM;
import X.AnonymousClass0T5;
import X.AnonymousClass0W2;
import X.AnonymousClass0WY;
import X.AnonymousClass127;
import X.AnonymousClass12C;
import X.AnonymousClass12H;
import X.AnonymousClass12J;
import X.AnonymousClass12M;
import X.AnonymousClass12N;
import X.AnonymousClass12O;
import X.AnonymousClass12Q;
import X.AnonymousClass12W;
import X.AnonymousClass12Y;
import X.AnonymousClass131;
import X.AnonymousClass139;
import X.AnonymousClass13D;
import X.AnonymousClass13F;
import X.AnonymousClass13O;
import X.AnonymousClass13P;
import X.AnonymousClass13U;
import X.AnonymousClass13W;
import X.AnonymousClass141;
import X.AnonymousClass14B;
import X.AnonymousClass14M;
import X.C04300Lc;
import X.C05160Pw;
import X.C14270pR;
import X.C15800sA;
import X.C198011e;
import X.C200012a;
import X.C200212c;
import X.C200512f;
import X.C200612g;
import X.C200812i;
import X.C204413s;
import X.C204613u;
import X.C206514n;
import X.C207614y;
import X.C207714z;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import com.facebook.acra.util.JavaProcFileReader;
import com.facebook.rti.common.time.RealtimeSinceBootClock;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import org.json.JSONException;

public abstract class MqttPushServiceDelegate extends MqttBackgroundServiceDelegate {
    public long A00;
    public AnonymousClass0G5 A01;
    public AnonymousClass0MM A02;
    public RealtimeSinceBootClock A03;
    public AnonymousClass12J A04;
    public AnonymousClass12O A05;
    public AnonymousClass13D A06;
    public AnonymousClass13F A07;
    public AnonymousClass13O A08;
    public C204613u A09;
    public AtomicBoolean A0A = AnonymousClass001.A17();
    public AnonymousClass0AT A0B = AnonymousClass0AT.DISCONNECTED;
    public AnonymousClass141 A0C;
    public final C204413s A0D = new AnonymousClass14B(this);
    public volatile AnonymousClass12H A0E;

    public abstract AnonymousClass141 A0R();

    public abstract Integer A0T();

    public abstract String A0U();

    public abstract void A0a();

    public abstract void A0b();

    public abstract void A0c();

    public abstract void A0g(AnonymousClass127 r1, Long l, String str, byte[] bArr, int i, long j);

    public abstract void A0i(AnonymousClass0AT r1);

    public abstract void A0j(C207614y r1);

    public static String A02(MqttPushServiceDelegate mqttPushServiceDelegate) {
        long j;
        C206514n r2 = mqttPushServiceDelegate.A09.A13;
        if (r2 == null || r2.A0d != AnonymousClass0AT.CONNECTED) {
            j = 0;
        } else {
            j = SystemClock.elapsedRealtime() - r2.A0a;
        }
        AnonymousClass12O r1 = mqttPushServiceDelegate.A05;
        C200012a A002 = AnonymousClass12O.A00(r1);
        C200512f A012 = AnonymousClass12O.A01(r1, j);
        AnonymousClass12W r3 = (AnonymousClass12W) r1.A04(AnonymousClass12W.class);
        try {
            return AnonymousClass12M.A00(r1.A00.A00(false), r3, (AnonymousClass12Y) r1.A04(AnonymousClass12Y.class), A002, (C200212c) null, A012, (C200612g) r1.A04(C200612g.class), (C200812i) r1.A04(C200812i.class), true, false).toString(2);
        } catch (JSONException unused) {
            return "";
        }
    }

    public static final void A03(MqttPushServiceDelegate mqttPushServiceDelegate) {
        AnonymousClass0AT r4;
        C206514n r0 = mqttPushServiceDelegate.A09.A13;
        if (r0 == null) {
            r4 = AnonymousClass0AT.DISCONNECTED;
        } else {
            r4 = r0.A0d;
            if (r4 == null) {
                return;
            }
        }
        AnonymousClass0AT r02 = mqttPushServiceDelegate.A0B;
        if (r4 != r02) {
            mqttPushServiceDelegate.A01.CIO(AnonymousClass0WY.A18("[state_machine] ", r02.toString(), JavaProcFileReader.LS_SYMLINK_ARROW, r4.toString()));
            mqttPushServiceDelegate.A0B = r4;
            mqttPushServiceDelegate.A04.A01(r4.name());
            mqttPushServiceDelegate.A0i(r4);
        }
    }

    public final void A0G() {
        if (this.A0E != null) {
            AnonymousClass12H r2 = this.A0E;
            String A0i = AnonymousClass0WY.A0i(AnonymousClass14M.A00(A0T()), ".SERVICE_ON_DESTROY");
            String A0U = A0U();
            AnonymousClass0MB r4 = AnonymousClass0MB.A00;
            r2.A01((NetworkInfo) null, r4, r4, A0i, A0U, (String) null, 0, this.A0A.get());
        }
        super.A0G();
    }

    public void A0N() {
        AnonymousClass12H r2 = this.A0E;
        String A0i = AnonymousClass0WY.A0i(AnonymousClass14M.A00(A0T()), ".SERVICE_DESTROY");
        String A0U = A0U();
        AnonymousClass0MB r4 = AnonymousClass0MB.A00;
        boolean z = this.A0A.get();
        r2.A01(this.A06.A02(), r4, r4, A0i, A0U, (String) null, this.A06.A06.get(), z);
        HashMap A0w = AnonymousClass001.A0w();
        A0w.put("event", "doDestroy");
        A0w.put("pid", String.valueOf(Process.myPid()));
        this.A01.CIR("life_cycle", A0w);
        this.A01.E3q((C04300Lc) null);
        A0Z();
    }

    public void A0O() {
        if (this.A0C == null) {
            this.A0C = A0R();
            A0Y();
            A0X();
            this.A01.E3q(new C04300Lc(this));
            HashMap A0w = AnonymousClass001.A0w();
            A0w.put("event", "doCreate");
            A0w.put("pid", String.valueOf(Process.myPid()));
            this.A01.CIR("life_cycle", A0w);
            AnonymousClass12H r2 = this.A0E;
            String A0i = AnonymousClass0WY.A0i(AnonymousClass14M.A00(A0T()), ".SERVICE_CREATE");
            String A0U = A0U();
            AnonymousClass0MB r4 = AnonymousClass0MB.A00;
            boolean z = this.A0A.get();
            r2.A01(this.A06.A02(), r4, r4, A0i, A0U, (String) null, this.A06.A06.get(), z);
            return;
        }
        throw AnonymousClass001.A0N();
    }

    public void A0Q(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String valueOf;
        try {
            printWriter.println("[ MqttPushService ]");
            AnonymousClass0WY.A1T(printWriter, "persistence=", A0U());
            long j = this.A09.A04;
            if (j > 0) {
                valueOf = new Date(j).toString();
            } else {
                valueOf = String.valueOf(j);
            }
            AnonymousClass0WY.A1T(printWriter, "networkChangedTime=", valueOf);
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append("subscribedTopics=");
            printWriter.println(AnonymousClass001.A0d(this.A09.A0B(), A0m));
            if (!(!this.A0C.A06.A02)) {
                this.A09.A0K(printWriter);
                printWriter.println("[ MqttHealthStats ]");
                printWriter.println(A02(this));
            }
        } catch (Exception unused) {
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [X.14E, java.lang.Object] */
    public AnonymousClass0T5 A0S(Intent intent, int i, int i2) {
        String str;
        ? obj = new Object();
        AnonymousClass0QM r7 = this.A01;
        Context applicationContext = r7.getApplicationContext();
        C15800sA.A09(applicationContext);
        AnonymousClass0T5 A002 = obj.A00(applicationContext, this.A02);
        Intent intent2 = intent;
        if (intent != null) {
            if (intent2.hasExtra("caller")) {
                A002.A03 = intent2.getStringExtra("caller");
            }
            if (intent2.hasExtra("EXPIRED_SESSION")) {
                A002.A00 = intent2.getLongExtra("EXPIRED_SESSION", 0);
            }
            if (intent2.hasExtra("DELIVERY_RETRY_INTERVAL")) {
                Integer valueOf = Integer.valueOf(intent2.getIntExtra("DELIVERY_RETRY_INTERVAL", 300));
                if (!valueOf.equals(A002.A02)) {
                    A002.A02 = valueOf;
                    Context applicationContext2 = r7.getApplicationContext();
                    C15800sA.A09(applicationContext2);
                    AnonymousClass0W2 Ab9 = AnonymousClass0WY.A00(applicationContext2, this.A02, "runtime_params").Ab9();
                    Integer num = A002.A02;
                    if (num != null) {
                        Ab9.DeZ("DELIVERY_RETRY_INTERVAL", num.intValue());
                        Ab9.ANs();
                    }
                }
            }
            str = intent2.getAction();
        } else {
            str = "NULL";
        }
        Integer valueOf2 = Integer.valueOf(i);
        Integer valueOf3 = Integer.valueOf(i2);
        AnonymousClass12H r72 = this.A0E;
        String A0l = AnonymousClass0WY.A0l(AnonymousClass14M.A00(A0T()), str, '.');
        String A0U = A0U();
        String str2 = A002.A03;
        C198011e A003 = C05160Pw.A00(valueOf2);
        C198011e A004 = C05160Pw.A00(valueOf3);
        boolean z = this.A0A.get();
        r72.A01(this.A06.A02(), A003, A004, A0l, A0U, str2, this.A06.A06.get(), z);
        return A002;
    }

    public Future A0V(C207714z r5) {
        AnonymousClass131 r2 = AnonymousClass131.A01;
        if (!this.A0A.getAndSet(false)) {
            C14270pR.A0G("MqttPushService", "service/stop/inactive_connection");
            return r2;
        }
        A0c();
        this.A09.A0H();
        Future A0E2 = this.A09.A0E(r5);
        A03(this);
        return A0E2;
    }

    public void A0X() {
        AtomicLong atomicLong;
        AnonymousClass12O r5 = this.A05;
        AnonymousClass12N r4 = AnonymousClass12N.A01;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        synchronized (r5) {
            HashMap hashMap = r5.A02;
            if (!hashMap.containsKey(r4)) {
                hashMap.put(r4, new AtomicLong());
            }
            atomicLong = (AtomicLong) hashMap.get(r4);
        }
        atomicLong.set(elapsedRealtime);
    }

    public void A0Y() {
        AnonymousClass141 r0 = this.A0C;
        C204613u r9 = r0.A0O;
        AnonymousClass13D r8 = r0.A0I;
        AnonymousClass13P r7 = r0.A0K;
        RealtimeSinceBootClock realtimeSinceBootClock = r0.A04;
        AnonymousClass12H r5 = r0.A0B;
        AnonymousClass12O r4 = r0.A0D;
        AnonymousClass13F r3 = r0.A0J;
        AnonymousClass12J r2 = r0.A0C;
        AnonymousClass0G5 r1 = r0.A02;
        AnonymousClass0MM r02 = r0.A03;
        this.A09 = r9;
        this.A06 = r8;
        this.A08 = r7;
        this.A03 = realtimeSinceBootClock;
        this.A0E = r5;
        this.A05 = r4;
        this.A07 = r3;
        this.A04 = r2;
        this.A01 = r1;
        this.A02 = r02;
    }

    public final void A0Z() {
        if (this.A0A.get()) {
            A0V(C207714z.SERVICE_DESTROY);
        }
        C204613u r1 = this.A09;
        if (r1 != null) {
            r1.A0E(C207714z.SERVICE_DESTROY);
        }
        AnonymousClass141 r4 = this.A0C;
        if (r4 != null && !r4.A0W) {
            r4.A0W = true;
            AnonymousClass13W r3 = r4.A0M;
            if (r3 != null) {
                synchronized (r3) {
                    r3.A00();
                    if (r3.A01) {
                        r3.A01 = !r3.A07.A07(r3.A04, r3.A05);
                    }
                }
            }
            AnonymousClass13D r32 = r4.A0I;
            if (r32 != null) {
                synchronized (r32) {
                    try {
                        r32.A01.unregisterReceiver(r32.A00);
                    } catch (IllegalArgumentException e) {
                        C14270pR.A0S("MqttNetworkManager", e, "Failed to unregister broadcast receiver");
                    }
                }
            }
            AnonymousClass139 r0 = r4.A0G;
            if (r0 != null) {
                r0.shutdown();
            }
            AnonymousClass13U r02 = r4.A0L;
            if (r02 != null) {
                r02.A05();
            }
            AnonymousClass13F r33 = r4.A0J;
            if (r33 != null) {
                synchronized (r33) {
                    try {
                        r33.A02.unregisterReceiver(r33.A01);
                    } catch (IllegalArgumentException e2) {
                        C14270pR.A0S("ScreenPowerState", e2, "Failed to unregister broadcast receiver");
                    }
                    r33.A05.set((Object) null);
                }
            }
        }
    }

    public void A0h(AnonymousClass0T5 r5, Integer num) {
        if (!this.A0A.getAndSet(true)) {
            Integer num2 = r5.A02;
            if (num2 != null) {
                A0d(num2.intValue());
            }
            AnonymousClass12O r0 = this.A05;
            String A002 = AnonymousClass12C.A00(num);
            AnonymousClass12Q r3 = r0.A00;
            if (r3.A07 == null) {
                r3.A07 = A002;
                r3.A04.set(SystemClock.elapsedRealtime());
                r3.A02.set(SystemClock.elapsedRealtime());
            }
            A0b();
            this.A09.A0G();
        }
        String str = r5.A03;
        C204613u r02 = this.A09;
        if (str == null) {
            str = "MqttPushService";
        }
        r02.A0Q(num, str);
    }

    public boolean A0l() {
        if (!this.A0A.get()) {
            this.A01.CIO("MqttPushService/not_started");
            return false;
        }
        HashMap A0w = AnonymousClass001.A0w();
        if (this.A08.E6X(A0w)) {
            return true;
        }
        this.A01.CIR("MqttPushService/should_not_connect", A0w);
        return false;
    }

    public MqttPushServiceDelegate(AnonymousClass0QM r2) {
        super(r2);
    }

    public Looper A0L() {
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:63:0x00e1, code lost:
        if (r0 != null) goto L_0x0009;
     */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x007b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A0P(int r9, int r10, android.content.Intent r11) {
        /*
            r8 = this;
            java.util.HashMap r2 = X.AnonymousClass001.A0w()
            if (r11 != 0) goto L_0x00d2
            java.lang.String r1 = "intent"
            r0 = 0
        L_0x0009:
            r2.put(r1, r0)
        L_0x000c:
            X.0G5 r1 = r8.A01
            java.lang.String r0 = "start_command"
            r1.CIR(r0, r2)
            boolean r0 = r8.A0m(r11)
            if (r0 != 0) goto L_0x001a
            r11 = 0
        L_0x001a:
            X.0T5 r3 = r8.A0S(r11, r9, r10)
            if (r11 == 0) goto L_0x005a
            java.lang.String r0 = "Orca.PERSISTENT_KICK"
            boolean r0 = X.AnonymousClass001.A1Y(r0, r11)
            if (r0 != 0) goto L_0x005c
            java.lang.String r0 = "Orca.FORCE_KICK"
            boolean r0 = X.AnonymousClass001.A1Y(r0, r11)
            if (r0 != 0) goto L_0x005c
            java.lang.String r0 = "Orca.PERSISTENT_KICK_SKIP_PING"
            boolean r0 = X.AnonymousClass001.A1Y(r0, r11)
            if (r0 != 0) goto L_0x005c
            java.lang.String r1 = r11.getAction()
            java.lang.String r0 = "Orca.STOP"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x004f
            X.14z r0 = X.C207714z.SERVICE_STOP
            r8.A0V(r0)
            X.0QM r0 = r8.A01
            r0.A05()
        L_0x004e:
            return
        L_0x004f:
            java.lang.String r0 = "Orca.START"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x00e5
            java.lang.Integer r0 = X.AnonymousClass0X6.A00
            goto L_0x0074
        L_0x005a:
            r1 = 0
            goto L_0x0068
        L_0x005c:
            java.lang.String r0 = r11.getAction()
            if (r0 == 0) goto L_0x005a
            java.lang.String r0 = "Orca.FORCE_KICK"
            boolean r1 = X.AnonymousClass001.A1Y(r0, r11)
        L_0x0068:
            java.util.concurrent.atomic.AtomicBoolean r0 = r8.A0A
            boolean r0 = r0.get()
            if (r0 != 0) goto L_0x007b
            if (r11 != 0) goto L_0x0078
            java.lang.Integer r0 = X.AnonymousClass0X6.A01
        L_0x0074:
            r8.A0h(r3, r0)
            return
        L_0x0078:
            java.lang.Integer r0 = X.AnonymousClass0X6.A0C
            goto L_0x0074
        L_0x007b:
            if (r1 == 0) goto L_0x008b
            java.lang.Integer r2 = X.AnonymousClass0X6.A08
        L_0x007f:
            java.lang.String r1 = r3.A03
            X.13u r0 = r8.A09
            if (r1 != 0) goto L_0x0087
            java.lang.String r1 = "MqttPushService"
        L_0x0087:
            r0.A0Q(r2, r1)
            return
        L_0x008b:
            boolean r0 = r8.A0l()
            if (r0 == 0) goto L_0x00bf
            X.13u r0 = r8.A09
            X.14n r0 = r0.A13
            if (r0 == 0) goto L_0x00bf
            X.0AT r1 = r0.A0d
            X.0AT r0 = X.AnonymousClass0AT.CONNECTED
            if (r1 != r0) goto L_0x00bf
            if (r11 == 0) goto L_0x004e
            java.lang.String r0 = "Orca.PERSISTENT_KICK"
            boolean r0 = X.AnonymousClass001.A1Y(r0, r11)
            if (r0 == 0) goto L_0x004e
            X.13u r7 = r8.A09
            java.lang.String r6 = r3.A03
            X.0QO r0 = r7.A0F
            X.0M8 r0 = r0.A03()
            int r3 = r0.A0G
            if (r3 < 0) goto L_0x004e
            X.14n r2 = r7.A13
            if (r2 == 0) goto L_0x004e
            long r4 = android.os.SystemClock.elapsedRealtime()
            monitor-enter(r2)
            goto L_0x00c2
        L_0x00bf:
            java.lang.Integer r2 = X.AnonymousClass0X6.A0C
            goto L_0x007f
        L_0x00c2:
            long r0 = r2.A0W     // Catch:{ all -> 0x0114 }
            monitor-exit(r2)
            long r4 = r4 - r0
            long r2 = (long) r3
            r0 = 1000(0x3e8, double:4.94E-321)
            long r2 = r2 * r0
            int r0 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r0 <= 0) goto L_0x004e
            r7.A0R(r6)
            return
        L_0x00d2:
            java.lang.String r1 = "action"
            java.lang.String r0 = r11.getAction()
            r2.put(r1, r0)
            java.lang.String r1 = "caller"
            java.lang.String r0 = r11.getStringExtra(r1)
            if (r0 == 0) goto L_0x000c
            goto L_0x0009
        L_0x00e5:
            java.lang.String r0 = "Orca.EXPIRE_CONNECTION"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x0110
            X.13u r7 = r8.A09
            long r4 = r3.A00
            X.14n r6 = r7.A13
            X.12O r0 = r7.A0E
            java.lang.Integer r3 = X.AnonymousClass0X6.A0j
            r0.A0F = r3
            if (r6 == 0) goto L_0x010c
            long r1 = r6.A0a
            int r0 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r0 != 0) goto L_0x010c
            java.lang.Integer r1 = X.AnonymousClass0X6.A0Y
            X.14z r0 = X.C207714z.EXPIRE_CONNECTION
            r7.A0D(r6, r0, r1)
            X.C204613u.A05(r7)
            return
        L_0x010c:
            r7.A0P(r3)
            return
        L_0x0110:
            r8.A0f(r11, r3)
            return
        L_0x0114:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x0114 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.rti.mqtt.manager.MqttPushServiceDelegate.A0P(int, int, android.content.Intent):void");
    }

    public void A0W() {
    }

    public void A0d(int i) {
    }

    public boolean A0m(Intent intent) {
        return true;
    }

    public void A0f(Intent intent, AnonymousClass0T5 r2) {
    }

    public void A0e(long j, String str, boolean z) {
    }

    public void A0k(String str, String str2, Throwable th) {
    }
}
