package com.facebook.rti.mqtt.manager;

import X.AnonymousClass001;
import X.AnonymousClass0CZ;
import X.AnonymousClass0QM;
import X.AnonymousClass0QN;
import X.C204813w;
import X.C204913x;
import android.content.Intent;
import android.os.Looper;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class MqttBackgroundServiceDelegate extends AnonymousClass0QN {
    public boolean A00;
    public final Object A01 = AnonymousClass001.A0U();
    public volatile C204813w A02;

    public final void A0D(Intent intent, int i) {
        A0F(intent, -1, i);
    }

    public abstract Looper A0L();

    public abstract void A0N();

    public abstract void A0O();

    public abstract void A0P(int i, int i2, Intent intent);

    public abstract void A0Q(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public int A0F(Intent intent, int i, int i2) {
        this.A02.A02(i, i2, intent);
        return 1;
    }

    public void A0G() {
        this.A02.A00();
        super.A0G();
    }

    public final void A0M() {
        AnonymousClass0CZ.A04("MqttBackgroundServiceDelegate.ensureInitialized", -1398809912);
        try {
            synchronized (this.A01) {
                if (!this.A00) {
                    A0O();
                    this.A00 = true;
                }
            }
            AnonymousClass0CZ.A01(282297691);
        } catch (Throwable th) {
            AnonymousClass0CZ.A01(1268921199);
            throw th;
        }
    }

    public MqttBackgroundServiceDelegate(AnonymousClass0QM r2) {
        super(r2);
    }

    public final void A0E(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        A0M();
        A0Q(fileDescriptor, printWriter, strArr);
    }

    public void A0I() {
        C204813w r1;
        super.A0I();
        Looper A0L = A0L();
        if (A0L == null || A0L == Looper.getMainLooper()) {
            r1 = new C204913x(Looper.getMainLooper(), this);
        } else {
            r1 = new C204813w(A0L, this);
        }
        this.A02 = r1;
        this.A02.A01();
    }
}
