package com.facebook.rti.push.service;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0BS;
import X.AnonymousClass0TE;
import X.C14270pR;
import X.C15800sA;
import X.C18950yb;
import X.C201512p;
import android.content.Context;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.facebook.push.fbns.ipc.FbnsAIDLRequest;
import com.facebook.push.fbns.ipc.FbnsAIDLResult;
import com.facebook.push.fbns.ipc.IFbnsAIDLService;
import java.util.HashMap;
import java.util.Map;

public final class FbnsAIDLService extends Binder implements IFbnsAIDLService {
    public final Context A00;
    public final Map A01;

    public /* synthetic */ FbnsAIDLService(Context context, C18950yb r6, C18950yb r7) {
        this();
        int A03 = AnonymousClass0BS.A03(426944757);
        HashMap A0w = AnonymousClass001.A0w();
        this.A01 = A0w;
        AnonymousClass0TE r0 = AnonymousClass0TE.GET_PREF_BASED_CONFIG;
        C18950yb r1 = C201512p.A02;
        A0w.put(r0, r1);
        A0w.put(AnonymousClass0TE.SET_PREF_BASED_CONFIG, r1);
        AnonymousClass0TE r02 = AnonymousClass0TE.GET_ANALYTICS_CONFIG;
        C18950yb r12 = C201512p.A01;
        A0w.put(r02, r12);
        A0w.put(AnonymousClass0TE.SET_ANALYTICS_CONFIG, r12);
        AnonymousClass0TE r03 = AnonymousClass0TE.GET_PREF_IDS;
        C18950yb r13 = C201512p.A03;
        A0w.put(r03, r13);
        A0w.put(AnonymousClass0TE.SET_PREF_IDS, r13);
        this.A00 = context;
        A0w.put(AnonymousClass0TE.GET_APPS_STATISTICS, r6);
        A0w.put(AnonymousClass0TE.GET_FLYTRAP_REPORT, r7);
        AnonymousClass0BS.A09(-393220584, A03);
        AnonymousClass0BS.A09(181612027, AnonymousClass0BS.A03(-450747708));
    }

    private C18950yb A00(FbnsAIDLRequest fbnsAIDLRequest, boolean z) {
        IllegalArgumentException illegalArgumentException;
        int i;
        int i2;
        int A03 = AnonymousClass0BS.A03(1757836597);
        if (fbnsAIDLRequest == null || (i2 = fbnsAIDLRequest.A00) < 0) {
            C14270pR.A0F("FbnsAIDLService", "Invalid FbnsAIDLRequest");
            illegalArgumentException = AnonymousClass001.A0L("FbnsService received invalid FbnsAIDLRequest");
            i = 47240374;
        } else {
            AnonymousClass0TE r3 = (AnonymousClass0TE) AnonymousClass0TE.A00.get(Integer.valueOf(i2));
            if (r3 == null) {
                r3 = AnonymousClass0TE.NOT_EXIST;
            }
            if (r3 == AnonymousClass0TE.NOT_EXIST) {
                illegalArgumentException = AnonymousClass001.A0L("FbnsService operation not found");
                i = -783403537;
            } else if (r3.mHasReturn == z) {
                C18950yb r1 = (C18950yb) this.A01.get(r3);
                if (r1 != null) {
                    AnonymousClass0BS.A09(143105443, A03);
                    return r1;
                }
                illegalArgumentException = AnonymousClass002.A0E(r3, "FbnsService does not implement operation ", AnonymousClass001.A0m());
                i = 1761423386;
            } else {
                C14270pR.A0F("FbnsAIDLService", "FbnsAIDLOperation incorrect return type");
                illegalArgumentException = AnonymousClass001.A0L("FbnsService operation incorrect return type");
                i = -2746196;
            }
        }
        AnonymousClass0BS.A09(i, A03);
        throw illegalArgumentException;
    }

    public final FbnsAIDLResult Dei(FbnsAIDLRequest fbnsAIDLRequest) {
        int A03 = AnonymousClass0BS.A03(91810972);
        C18950yb A002 = A00(fbnsAIDLRequest, true);
        Context context = this.A00;
        Bundle bundle = fbnsAIDLRequest.A00;
        if (bundle == null) {
            bundle = Bundle.EMPTY;
            C15800sA.A0A(bundle);
        }
        FbnsAIDLResult fbnsAIDLResult = new FbnsAIDLResult(A002.AZn(context, bundle));
        AnonymousClass0BS.A09(576271924, A03);
        return fbnsAIDLResult;
    }

    public final void ELb(FbnsAIDLRequest fbnsAIDLRequest) {
        int A03 = AnonymousClass0BS.A03(812821291);
        C18950yb A002 = A00(fbnsAIDLRequest, false);
        Context context = this.A00;
        Bundle bundle = fbnsAIDLRequest.A00;
        if (bundle == null) {
            bundle = Bundle.EMPTY;
            C15800sA.A0A(bundle);
        }
        A002.AZy(context, bundle);
        AnonymousClass0BS.A09(283333045, A03);
    }

    public final IBinder asBinder() {
        AnonymousClass0BS.A09(920453875, AnonymousClass0BS.A03(1307666724));
        return this;
    }

    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int i3;
        int A03 = AnonymousClass0BS.A03(-761289823);
        boolean z = true;
        if (i >= 1) {
            if (i <= 16777215) {
                parcel.enforceInterface("com.facebook.push.fbns.ipc.IFbnsAIDLService");
                if (i == 1) {
                    FbnsAIDLResult Dei = Dei((FbnsAIDLRequest) AnonymousClass002.A0J(parcel, FbnsAIDLRequest.CREATOR));
                    parcel2.writeNoException();
                    parcel2.writeInt(1);
                    Dei.writeToParcel(parcel2, 1);
                } else if (i == 2) {
                    ELb((FbnsAIDLRequest) AnonymousClass002.A0J(parcel, FbnsAIDLRequest.CREATOR));
                }
                i3 = 987443338;
                AnonymousClass0BS.A09(i3, A03);
                return z;
            } else if (i == 1598968902) {
                parcel2.writeString("com.facebook.push.fbns.ipc.IFbnsAIDLService");
                i3 = -1081379517;
                AnonymousClass0BS.A09(i3, A03);
                return z;
            }
        }
        z = super.onTransact(i, parcel, parcel2, i2);
        i3 = -925902130;
        AnonymousClass0BS.A09(i3, A03);
        return z;
    }

    public FbnsAIDLService() {
        int A03 = AnonymousClass0BS.A03(-986241021);
        attachInterface(this, "com.facebook.push.fbns.ipc.IFbnsAIDLService");
        AnonymousClass0BS.A09(-1802141584, A03);
    }
}
