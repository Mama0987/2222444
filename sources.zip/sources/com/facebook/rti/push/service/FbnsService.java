package com.facebook.rti.push.service;

import X.AnonymousClass0QM;

public class FbnsService extends AnonymousClass0QM {
    public final String A0A() {
        return "com.facebook.rti.push.service.FbnsServiceDelegate";
    }
}
