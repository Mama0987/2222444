package com.facebook.rti.push.service;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass02Z;
import X.AnonymousClass0AT;
import X.AnonymousClass0Ev;
import X.AnonymousClass0M9;
import X.AnonymousClass0MB;
import X.AnonymousClass0MC;
import X.AnonymousClass0MD;
import X.AnonymousClass0ME;
import X.AnonymousClass0MF;
import X.AnonymousClass0MJ;
import X.AnonymousClass0MM;
import X.AnonymousClass0MO;
import X.AnonymousClass0MR;
import X.AnonymousClass0MS;
import X.AnonymousClass0MZ;
import X.AnonymousClass0QM;
import X.AnonymousClass0QN;
import X.AnonymousClass0QP;
import X.AnonymousClass0QS;
import X.AnonymousClass0T5;
import X.AnonymousClass0TA;
import X.AnonymousClass0W2;
import X.AnonymousClass0WY;
import X.AnonymousClass0X6;
import X.AnonymousClass0Y9;
import X.AnonymousClass0YV;
import X.AnonymousClass10J;
import X.AnonymousClass10W;
import X.AnonymousClass10Y;
import X.AnonymousClass113;
import X.AnonymousClass117;
import X.AnonymousClass118;
import X.AnonymousClass119;
import X.AnonymousClass11E;
import X.AnonymousClass11L;
import X.AnonymousClass11R;
import X.AnonymousClass11U;
import X.AnonymousClass11Z;
import X.AnonymousClass12A;
import X.AnonymousClass12C;
import X.AnonymousClass12O;
import X.AnonymousClass12V;
import X.AnonymousClass13D;
import X.AnonymousClass13K;
import X.AnonymousClass13V;
import X.AnonymousClass141;
import X.AnonymousClass14A;
import X.AnonymousClass14G;
import X.AnonymousClass14M;
import X.AnonymousClass14Q;
import X.AnonymousClass153;
import X.AnonymousClass17H;
import X.C04540Mc;
import X.C04640Mn;
import X.C05160Pw;
import X.C06620Xd;
import X.C07040Zd;
import X.C07060Zf;
import X.C07380aG;
import X.C09500dv;
import X.C12630kx;
import X.C12860mX;
import X.C14190pG;
import X.C14240pO;
import X.C14270pR;
import X.C14320pW;
import X.C14620q4;
import X.C14830qR;
import X.C15800sA;
import X.C18790y3;
import X.C196610p;
import X.C197811c;
import X.C198011e;
import X.C199111q;
import X.C200412e;
import X.C200512f;
import X.C201912t;
import X.C204413s;
import X.C204613u;
import X.C206614o;
import X.C207614y;
import X.C207714z;
import X.C208415g;
import X.C209515s;
import X.C211416l;
import X.C211516m;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.text.TextUtils;
import com.facebook.nobreak.CatchMeIfYouCan;
import com.facebook.rti.common.time.RealtimeSinceBootClock;
import com.facebook.rti.mqtt.manager.MqttPushServiceDelegate;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONException;
import org.json.JSONObject;

public class FbnsServiceDelegate extends MqttPushServiceDelegate {
    public static FbnsServiceDelegate A0E;
    public static final List A0F = new AnonymousClass17H(0);
    public static final List A0G = new AnonymousClass17H(1);
    public static final Map A0H;
    public AnonymousClass0MC A00;
    public FbnsAIDLService A01;
    public C14830qR A02;
    public C12860mX A03;
    public C12630kx A04;
    public C09500dv A05;
    public C201912t A06;
    public AnonymousClass117 A07;
    public AnonymousClass10W A08;
    public String A09;
    public Map A0A = AnonymousClass001.A0w();
    public final AnonymousClass13V A0B;
    public final C14240pO A0C;
    public final Object A0D = AnonymousClass001.A0U();

    /* JADX WARNING: type inference failed for: r3v0, types: [X.14E, java.lang.Object] */
    public final void A0W() {
        LinkedList<C199111q> A022 = this.A07.A02();
        this.A07.A03();
        A0A(this, "credentials_updated", "", "", (String) null, Collections.singletonMap("package_size", String.valueOf(A022.size())));
        ? obj = new Object();
        AnonymousClass0QM r0 = this.A01;
        Context applicationContext = r0.getApplicationContext();
        C15800sA.A09(applicationContext);
        C15800sA.A09(r0.getApplicationContext());
        A0h(obj.A00(applicationContext, ((AnonymousClass0MO) AnonymousClass0M9.A00).A02()), AnonymousClass0X6.A05);
        for (C199111q r3 : A022) {
            Intent A072 = AnonymousClass001.A07("com.facebook.rti.fbns.intent.REGISTER");
            A072.putExtra("pkg_name", r3.A02);
            A072.putExtra("appid", r3.A01);
            A072.setClassName(AnonymousClass0QN.A00(this), AnonymousClass001.A0c(this));
            A07(A072, this);
        }
    }

    public final void A0j(C207614y r14) {
        AnonymousClass117 r0 = this.A07;
        boolean z = false;
        if (System.currentTimeMillis() - ((AnonymousClass0MS) AnonymousClass0WY.A00(r0.A00, r0.A01, "fbns_state")).getLong("auto_reg_retry", 0) > CatchMeIfYouCan.REMEDY_TIMEOUT_MS) {
            z = true;
        }
        if (C207614y.FAILED_CONNECTION_REFUSED_BAD_USER_NAME_OR_PASSWORD.equals(r14) && z) {
            AnonymousClass117 r02 = this.A07;
            AnonymousClass0W2 Ab9 = AnonymousClass0WY.A00(r02.A00, r02.A01, "fbns_state").Ab9();
            Ab9.Deb("auto_reg_retry", System.currentTimeMillis());
            Ab9.ANu();
            LinkedList<C199111q> A022 = this.A07.A02();
            this.A07.A03();
            A0A(this, "authfail_auto_register", "", "", (String) null, Collections.singletonMap("package_size", String.valueOf(A022.size())));
            for (C199111q r3 : A022) {
                Intent A072 = AnonymousClass001.A07("com.facebook.rti.fbns.intent.REGISTER");
                A072.putExtra("pkg_name", r3.A02);
                A072.putExtra("appid", r3.A01);
                A072.setClassName(AnonymousClass0QN.A00(this), AnonymousClass001.A0c(this));
                A07(A072, this);
            }
        }
    }

    public final boolean A0m(Intent intent) {
        if (intent == null) {
            return true;
        }
        String A002 = AnonymousClass0MC.A00(intent);
        if (AnonymousClass0QN.A00(this).equals(A002)) {
            return true;
        }
        this.A08.A00("verify_sender_failed", A002);
        return false;
    }

    public final synchronized void A0q(ArrayList arrayList) {
        for (C199111q r0 : this.A07.A02()) {
            arrayList.add(r0.A02);
        }
    }

    private final C208415g A04(String str) {
        C208415g r0;
        synchronized (this.A0D) {
            HashMap A0w = AnonymousClass001.A0w();
            if (TextUtils.isEmpty(str) || !A0w.containsKey(str)) {
                str = "default";
            }
            Map map = this.A0A;
            if (map.containsKey(str)) {
                r0 = (C208415g) map.get(str);
            } else {
                r0 = new C208415g();
                map.put(str, r0);
            }
        }
        return r0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:55:0x01b9, code lost:
        if (android.text.TextUtils.isEmpty(r1) == false) goto L_0x01bc;
     */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0187  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x01ca  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void A07(android.content.Intent r24, com.facebook.rti.push.service.FbnsServiceDelegate r25) {
        /*
            java.lang.String r0 = "pkg_name"
            r5 = r24
            java.lang.String r4 = r5.getStringExtra(r0)
            java.lang.String r0 = "appid"
            java.lang.String r3 = r5.getStringExtra(r0)
            java.lang.String r0 = "local_generation"
            r6 = 0
            boolean r18 = r5.getBooleanExtra(r0, r6)
            java.util.HashMap r24 = X.AnonymousClass001.A0w()
            java.lang.String r1 = "push_renew_trigger"
            boolean r0 = r5.hasExtra(r1)
            java.lang.String r2 = "unknown"
            if (r0 == 0) goto L_0x008f
            java.lang.String r17 = r5.getStringExtra(r1)
        L_0x0027:
            r5 = r25
            X.0dv r0 = r5.A05
            r0.A00(r4)
            java.util.concurrent.atomic.AtomicBoolean r0 = r5.A0A
            boolean r0 = r0.get()
            if (r0 != 0) goto L_0x004a
            java.lang.String r1 = "FbnsServiceDelegate"
            java.lang.String r0 = "service/register/not_started"
            X.C14270pR.A0F(r1, r0)
            java.lang.String r20 = "reg_fail"
            java.lang.String r23 = "service not started"
            r21 = r4
            r22 = r3
            r19 = r5
            A0A(r19, r20, r21, r22, r23, r24)
        L_0x004a:
            java.lang.String r20 = "reg_called"
            r7 = 0
            r21 = r4
            r22 = r3
            r23 = r7
            r19 = r5
            A0A(r19, r20, r21, r22, r23, r24)
            X.117 r12 = r5.A07
            java.lang.String r10 = "RegistrationState"
            boolean r0 = android.text.TextUtils.isEmpty(r4)
            r1 = 1
            r0 = r0 ^ 1
            X.C197911d.A01(r0)
            java.util.concurrent.CountDownLatch r8 = new java.util.concurrent.CountDownLatch
            r8.<init>(r1)
            java.util.concurrent.atomic.AtomicReference r9 = new java.util.concurrent.atomic.AtomicReference
            r9.<init>(r7)
            X.0MM r11 = r12.A01
            android.content.Context r1 = r12.A00
            java.lang.String r0 = "registrations"
            X.0QS r1 = X.AnonymousClass0WY.A00(r1, r11, r0)
            java.lang.String r0 = ""
            X.0MS r1 = (X.AnonymousClass0MS) r1
            X.C15800sA.A0D(r4, r6)
            java.lang.String r1 = r1.getString(r4, r0)
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            if (r0 == 0) goto L_0x0092
            r8.countDown()
            goto L_0x00c6
        L_0x008f:
            r17 = r2
            goto L_0x0027
        L_0x0092:
            X.11q r1 = X.C199111q.A00(r1)     // Catch:{ JSONException -> 0x00bd }
            boolean r0 = r1.A04     // Catch:{ JSONException -> 0x00bd }
            if (r0 != 0) goto L_0x00b9
            long r15 = java.lang.System.currentTimeMillis()     // Catch:{ JSONException -> 0x00bd }
            java.lang.String r0 = r1.A03     // Catch:{ JSONException -> 0x00bd }
            r9.set(r0)     // Catch:{ JSONException -> 0x00bd }
            java.lang.Long r0 = r1.A00     // Catch:{ JSONException -> 0x00bd }
            long r13 = r0.longValue()     // Catch:{ JSONException -> 0x00bd }
            r0 = 86400000(0x5265c00, double:4.2687272E-316)
            long r11 = r13 + r0
            int r0 = (r11 > r15 ? 1 : (r11 == r15 ? 0 : -1))
            if (r0 < 0) goto L_0x00b6
            int r0 = (r13 > r15 ? 1 : (r13 == r15 ? 0 : -1))
            if (r0 <= 0) goto L_0x00b9
        L_0x00b6:
            r9.set(r7)     // Catch:{ JSONException -> 0x00bd }
        L_0x00b9:
            r8.countDown()     // Catch:{ JSONException -> 0x00bd }
            goto L_0x00c6
        L_0x00bd:
            r1 = move-exception
            java.lang.String r0 = "Parse failed"
            X.C14270pR.A0R(r10, r1, r0)
            r8.countDown()
        L_0x00c6:
            r8.await()     // Catch:{ InterruptedException -> 0x00ca }
            goto L_0x00d4
        L_0x00ca:
            r8 = move-exception
            java.lang.Object[] r1 = new java.lang.Object[]{r8}
            java.lang.String r0 = "Waiting for latch was interrupted"
            X.C14270pR.A0L(r10, r0, r8, r1)
        L_0x00d4:
            java.lang.Object r1 = r9.get()
            java.lang.String r1 = (java.lang.String) r1
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            if (r0 != 0) goto L_0x00ed
            if (r17 == 0) goto L_0x00e4
            r2 = r17
        L_0x00e4:
            A09(r5, r4, r1, r2)
            java.lang.String r20 = "cache_hit"
            A0A(r19, r20, r21, r22, r23, r24)
            return
        L_0x00ed:
            if (r18 == 0) goto L_0x01cc
            java.lang.String r0 = X.AnonymousClass0QN.A00(r5)
            boolean r0 = X.C04640Mn.A02(r0)
            if (r0 == 0) goto L_0x01cc
            java.lang.Object r0 = X.AnonymousClass0M9.A00
            X.0MO r0 = (X.AnonymousClass0MO) r0
            java.util.Set r0 = r0.A09
            boolean r0 = r0.contains(r4)
            if (r0 == 0) goto L_0x01bb
            X.13u r0 = r5.A09
            X.0QT r0 = r0.A0J
            X.0MY r0 = r0.BLZ()
            java.lang.Object r10 = r0.first
            java.lang.String r10 = (java.lang.String) r10
            boolean r0 = android.text.TextUtils.isEmpty(r10)
            if (r0 != 0) goto L_0x01bb
            java.lang.String r0 = r5.A09
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x01bb
            java.lang.String r11 = r5.A09
            boolean r0 = android.text.TextUtils.isEmpty(r11)
            if (r0 != 0) goto L_0x0182
            boolean r0 = android.text.TextUtils.isEmpty(r10)
            if (r0 != 0) goto L_0x0182
            boolean r0 = android.text.TextUtils.isEmpty(r4)
            if (r0 != 0) goto L_0x0182
            java.lang.String r0 = "{"
            java.lang.StringBuilder r9 = X.AnonymousClass001.A0p(r0)
            java.lang.String r0 = "\"pn\":"
            r9.append(r0)
            java.lang.String r8 = "\""
            java.lang.String r0 = X.AnonymousClass0WY.A0w(r8, r4, r8)
            r9.append(r0)
            java.lang.String r1 = ","
            r9.append(r1)
            java.lang.String r0 = "\"di\":"
            r9.append(r0)
            java.lang.String r0 = X.AnonymousClass0WY.A0w(r8, r11, r8)
            r9.append(r0)
            r9.append(r1)
            java.lang.String r0 = "\"ai\":"
            r9.append(r0)
            java.lang.String r0 = "567310203415052"
            r9.append(r0)
            r9.append(r1)
            java.lang.String r0 = "\"ck\":"
            r9.append(r0)
            java.lang.String r0 = X.AnonymousClass0WY.A0w(r8, r10, r8)
            r9.append(r0)
            java.lang.String r0 = X.AnonymousClass002.A0Q(r9)
            byte[] r1 = r0.getBytes()     // Catch:{ AssertionError -> 0x0182 }
            r0 = 2
            java.lang.String r0 = android.util.Base64.encodeToString(r1, r0)     // Catch:{ AssertionError -> 0x0182 }
            goto L_0x0183
        L_0x0182:
            r0 = r7
        L_0x0183:
            java.lang.String r10 = "fbns-b64"
            if (r0 == 0) goto L_0x01ca
            java.lang.String r1 = "{"
            java.lang.StringBuilder r9 = X.AnonymousClass001.A0p(r1)
            java.lang.String r1 = "\"k\":"
            r9.append(r1)
            java.lang.String r8 = "\""
            java.lang.String r0 = X.AnonymousClass0WY.A0w(r8, r0, r8)
            r9.append(r0)
            java.lang.String r1 = ","
            r9.append(r1)
            java.lang.String r0 = "\"v\":"
            X.AnonymousClass001.A1J(r0, r1, r9, r6)
            java.lang.String r0 = "\"t\":"
            r9.append(r0)
            java.lang.String r0 = X.AnonymousClass0WY.A0w(r8, r10, r8)
            r9.append(r0)
            java.lang.String r1 = X.AnonymousClass002.A0Q(r9)
        L_0x01b5:
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            if (r0 == 0) goto L_0x01bc
        L_0x01bb:
            r1 = r7
        L_0x01bc:
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            if (r0 != 0) goto L_0x01cc
            if (r17 == 0) goto L_0x01c6
            r2 = r17
        L_0x01c6:
            A09(r5, r4, r1, r2)
            return
        L_0x01ca:
            r1 = 0
            goto L_0x01b5
        L_0x01cc:
            A08(r5, r4, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.rti.push.service.FbnsServiceDelegate.A07(android.content.Intent, com.facebook.rti.push.service.FbnsServiceDelegate):void");
    }

    public static void A09(FbnsServiceDelegate fbnsServiceDelegate, String str, String str2, String str3) {
        fbnsServiceDelegate.A05.A00(str);
        Intent A072 = AnonymousClass001.A07("com.facebook.rti.fbns.intent.RECEIVE");
        A072.setPackage(str);
        A072.addCategory(str);
        A072.putExtra("receive_type", "registered");
        if (str2 != null) {
            A072.putExtra("data", str2);
        }
        A072.putExtra("push_renew_trigger", str3);
        fbnsServiceDelegate.A06(A072);
    }

    /* JADX WARNING: type inference failed for: r12v0, types: [X.10S, X.10p] */
    public static void A0A(FbnsServiceDelegate fbnsServiceDelegate, String str, String str2, String str3, String str4, Map map) {
        String str5 = str2;
        FbnsServiceDelegate fbnsServiceDelegate2 = fbnsServiceDelegate;
        String str6 = str;
        fbnsServiceDelegate2.A08.A01("registrations", new String[]{str6, str5}, 1);
        C14830qR r13 = fbnsServiceDelegate2.A02;
        long j = fbnsServiceDelegate2.A00;
        boolean A002 = fbnsServiceDelegate2.A07.A00();
        long j2 = fbnsServiceDelegate2.A07.A04.get();
        AnonymousClass0QS r4 = r13.A02;
        String str7 = AnonymousClass0TA.A02.mPrefKey;
        C15800sA.A0D(str7, 0);
        boolean z = ((AnonymousClass0MS) r4).getBoolean(str7, false);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j3 = elapsedRealtime - r13.A00;
        long j4 = elapsedRealtime - j;
        long j5 = elapsedRealtime - r13.A04.A06.get();
        long j6 = elapsedRealtime - j2;
        if (j2 < 0) {
            j6 = 0;
        }
        ? r12 = new C196610p("fbns_push_registration_lifecycle", Locale.getDefault().toString(), Build.MODEL, Build.MANUFACTURER);
        r12.A08 = str6;
        if (str5 == null) {
            str5 = "";
        }
        r12.A07 = str5;
        r12.A05 = str4;
        r12.A00 = elapsedRealtime;
        r12.A04 = j3;
        r12.A01 = j4;
        r12.A02 = j5;
        r12.A03 = j6;
        r12.A0A = A002;
        r12.A06 = str3;
        r12.A09 = z;
        r12.A04(map);
        r13.A01.DmU(r12);
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [X.10p, X.10V] */
    public static void A0B(FbnsServiceDelegate fbnsServiceDelegate, String str, String str2, String str3, String str4, Map map, long j) {
        FbnsServiceDelegate fbnsServiceDelegate2 = fbnsServiceDelegate;
        String str5 = str3;
        fbnsServiceDelegate2.A08.A01("notifications", new String[]{str, str5}, 1);
        C14830qR r12 = fbnsServiceDelegate2.A02;
        long j2 = fbnsServiceDelegate2.A00;
        boolean A002 = fbnsServiceDelegate2.A07.A00();
        long j3 = fbnsServiceDelegate2.A07.A04.get();
        AnonymousClass0QS r4 = r12.A02;
        String str6 = AnonymousClass0TA.A02.mPrefKey;
        C15800sA.A0D(str6, 0);
        boolean z = ((AnonymousClass0MS) r4).getBoolean(str6, false);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j4 = elapsedRealtime - r12.A00;
        long j5 = elapsedRealtime - j2;
        long j6 = elapsedRealtime - r12.A04.A06.get();
        long j7 = elapsedRealtime - j3;
        if (j3 < 0) {
            j7 = 0;
        }
        ? r11 = new C196610p("fbns_push_notification_lifecycle", Locale.getDefault().toString(), Build.MODEL, Build.MANUFACTURER);
        r11.A08 = str;
        r11.A07 = str5;
        r11.A09 = str2;
        r11.A01 = elapsedRealtime;
        r11.A05 = j4;
        r11.A02 = j5;
        r11.A03 = j6;
        r11.A04 = j7;
        r11.A0B = A002;
        r11.A06 = str4;
        r11.A00 = j;
        r11.A0A = z;
        r11.A04(map);
        r12.A01.DmU(r11);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x002c, code lost:
        if (r0.A00() == false) goto L_0x002e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void A0C(java.lang.String r16, java.lang.String r17, java.lang.String r18) {
        /*
            r15 = this;
            X.10W r4 = r15.A08
            r5 = r16
            r6 = r17
            if (r4 == 0) goto L_0x0017
            java.lang.String r0 = X.AnonymousClass0QN.A00(r15)
            java.lang.String[] r3 = new java.lang.String[]{r5, r0, r6}
            r1 = 1
            java.lang.String r0 = "services"
            r4.A01(r0, r3, r1)
        L_0x0017:
            X.0qR r4 = r15.A02
            if (r4 == 0) goto L_0x003f
            java.util.concurrent.atomic.AtomicBoolean r0 = r15.A0A
            boolean r13 = r0.get()
            long r9 = r15.A00
            X.13F r0 = r15.A07
            if (r0 == 0) goto L_0x002e
            boolean r0 = r0.A00()
            r14 = 1
            if (r0 != 0) goto L_0x002f
        L_0x002e:
            r14 = 0
        L_0x002f:
            X.13F r0 = r15.A07
            if (r0 == 0) goto L_0x0040
            java.util.concurrent.atomic.AtomicLong r0 = r0.A04
            long r11 = r0.get()
        L_0x0039:
            r8 = 0
            r7 = r18
            r4.A00(r5, r6, r7, r8, r9, r11, r13, r14)
        L_0x003f:
            return
        L_0x0040:
            r11 = 0
            goto L_0x0039
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.rti.push.service.FbnsServiceDelegate.A0C(java.lang.String, java.lang.String, java.lang.String):void");
    }

    public final IBinder A0H(Intent intent) {
        Intent intent2 = intent;
        A0C("bind", intent2.getAction(), intent2.getStringExtra("caller"));
        AnonymousClass11R r1 = new AnonymousClass11R(intent2, this.A00, "fbns_aidl_auth_domain");
        String A002 = AnonymousClass0MC.A00(intent2);
        if (!r1.CEx()) {
            C14270pR.A0O("FbnsServiceDelegate", "onBind invalid signature: %s", intent2.toString());
            HashMap A0w = AnonymousClass001.A0w();
            A0w.put("cntr", AnonymousClass0QN.A00(this));
            A0w.put("clr", A002);
            AnonymousClass0MC r12 = this.A00;
            int i = 0;
            if (A002 != null) {
                try {
                    PackageManager packageManager = r12.A00.getPackageManager();
                    if (packageManager != null) {
                        i = Integer.parseInt(packageManager.getPackageInfo(A002, 0).versionName.split("\\.", 2)[0]);
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    C14270pR.A0I("FbnsSecurityContextHelper", "requested package not found on the device", e);
                } catch (NumberFormatException e2) {
                    C14270pR.A0L("FbnsSecurityContextHelper", "Failed to parse major version for package: %s", e2, A002);
                }
            }
            A0w.put("ver", String.valueOf(i));
            C14830qR r9 = this.A02;
            boolean z = this.A0A.get();
            r9.A00("bind", "TRUSTED_APP_AUTH_INVALID", intent2.getAction(), A0w, this.A00, this.A07.A04.get(), z, this.A07.A00());
            this.A08.A01("fbns_ipc_auth", new String[]{"unauthorized", "secure", A002, intent2.getAction()}, 1);
            return null;
        }
        this.A08.A01("fbns_ipc_auth", new String[]{"authorised", "secure", A002, intent2.getAction()}, 1);
        return this.A01;
    }

    public final void A0Q(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        try {
            printWriter.println(AnonymousClass0WY.A0w("[ ", "FbnsServiceDelegate", " ]"));
            ArrayList A0t = AnonymousClass001.A0t();
            ArrayList A0t2 = AnonymousClass001.A0t();
            Context applicationContext = this.A01.getApplicationContext();
            C15800sA.A09(applicationContext);
            C04640Mn.A01(applicationContext, A0t, A0t2);
            ArrayList A0t3 = AnonymousClass001.A0t();
            A0q(A0t3);
            printWriter.println(AnonymousClass002.A0M(A0t, "validCompatibleApps=", AnonymousClass001.A0m()));
            printWriter.println(AnonymousClass002.A0M(A0t2, "enabledCompatibleApps=", AnonymousClass001.A0m()));
            printWriter.println(AnonymousClass002.A0M(A0t3, "registeredApps=", AnonymousClass001.A0m()));
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append("notificationCounter=");
            printWriter.println(AnonymousClass001.A0d(this.A05.A03, A0m));
        } catch (Exception unused) {
        }
        super.A0Q(fileDescriptor, printWriter, strArr);
    }

    /* JADX WARNING: type inference failed for: r2v37, types: [X.12t, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r10v1, types: [X.0cE, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r48v0, types: [java.lang.Object, X.14p] */
    /* JADX WARNING: type inference failed for: r49v0, types: [X.155, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r50v0, types: [java.lang.Object, X.15j] */
    /* JADX WARNING: type inference failed for: r31v1, types: [java.lang.Object, X.11W] */
    /* JADX WARNING: type inference failed for: r0v8, types: [X.0q4, X.141] */
    public final AnonymousClass141 A0R() {
        FbnsServiceDelegate fbnsServiceDelegate = A0E;
        if (fbnsServiceDelegate != null) {
            fbnsServiceDelegate.A0Z();
        }
        A0E = this;
        AnonymousClass0MO r24 = (AnonymousClass0MO) AnonymousClass0M9.A00;
        AnonymousClass0QM r41 = this.A01;
        C15800sA.A09(r41.getApplicationContext());
        AnonymousClass0MM A022 = r24.A02();
        Context applicationContext = r41.getApplicationContext();
        C15800sA.A09(applicationContext);
        this.A03 = new C12860mX(applicationContext, A022);
        C211416l r2 = new C211416l(this, 0);
        C211416l r22 = new C211416l(this, 1);
        C211416l r23 = new C211416l(this, 2);
        Context applicationContext2 = r41.getApplicationContext();
        C15800sA.A09(applicationContext2);
        AnonymousClass0MC r4 = new AnonymousClass0MC(applicationContext2, (AnonymousClass02Z) null, new C198011e(new C07060Zf(this)), (AnonymousClass0MD) null);
        boolean A023 = C04640Mn.A02(AnonymousClass0QN.A00(this));
        AnonymousClass0ME r3 = r24.A00;
        if (r3.A00 != null) {
            r3.A00();
            Context applicationContext3 = r41.getApplicationContext();
            C15800sA.A09(applicationContext3);
            AnonymousClass10Y r25 = new AnonymousClass10Y(applicationContext3, A022, A023);
            this.A09 = r25.B76();
            Context applicationContext4 = r41.getApplicationContext();
            C15800sA.A09(applicationContext4);
            C14320pW r15 = new C14320pW(applicationContext4);
            Context applicationContext5 = r41.getApplicationContext();
            C15800sA.A09(applicationContext5);
            Integer num = AnonymousClass0X6.A01;
            AnonymousClass0QS A002 = AnonymousClass0WY.A00(applicationContext5, A022, "analytics");
            Context applicationContext6 = r41.getApplicationContext();
            C15800sA.A09(applicationContext6);
            boolean z = true;
            int i = 1;
            if (!(!AnonymousClass0MZ.A00(applicationContext6).A02)) {
                i = 10000;
            }
            AnonymousClass0W2 Ab9 = A002.Ab9();
            if (new Random().nextInt(10000) >= i) {
                z = false;
            }
            AnonymousClass0TA r11 = AnonymousClass0TA.A0A;
            r11.A01(Ab9, Integer.valueOf(i));
            AnonymousClass0TA.A09.A01(Ab9, Boolean.valueOf(z));
            Iterator A12 = AnonymousClass001.A12(A0H);
            while (A12.hasNext()) {
                Map.Entry A13 = AnonymousClass001.A13(A12);
                String A0l = AnonymousClass001.A0l(A13);
                Object value = A13.getValue();
                if (value == null || r11.mWrapper.A00().isInstance(value)) {
                    r11.mWrapper.A03(Ab9, value, AnonymousClass0WY.A0w("LOG_SR", "/", A0l));
                } else {
                    StringBuilder A0m = AnonymousClass001.A0m();
                    AnonymousClass002.A0i(value, "Cannot cast", A0m);
                    throw new ClassCastException(A0m.toString());
                }
            }
            Ab9.ANu();
            AtomicInteger atomicInteger = new AtomicInteger(-1);
            int i2 = 1;
            CountDownLatch countDownLatch = new CountDownLatch(1);
            AnonymousClass0TA r12 = AnonymousClass0TA.A08;
            C07380aG r5 = new C07380aG(countDownLatch, atomicInteger);
            if (r12.mWrapper.A00().isInstance(-1)) {
                r12.mWrapper.A04(r5, A002, -1, r12.mPrefKey);
                try {
                    AnonymousClass002.A0o(countDownLatch);
                } catch (InterruptedException e) {
                    C14270pR.A0I("FbnsServiceDelegate", "Waiting for current health sample rate fetch in initHealthStatsAnalytics was interrupted", e);
                }
                int i3 = atomicInteger.get();
                if (i3 < 0 || i3 > 10000) {
                    Context applicationContext7 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext7);
                    if (!(!AnonymousClass0MZ.A00(applicationContext7).A02)) {
                        i2 = 10000;
                    }
                    Integer valueOf = Integer.valueOf(i2);
                    AnonymousClass0W2 Ab92 = A002.Ab9();
                    r12.A01(Ab92, valueOf);
                    Ab92.ANu();
                } else {
                    i2 = i3;
                }
                AtomicLong atomicLong = new AtomicLong(-1);
                CountDownLatch countDownLatch2 = new CountDownLatch(1);
                String str = AnonymousClass0TA.A01.mPrefKey;
                C15800sA.A0D(str, 0);
                try {
                    atomicLong.set(Long.parseLong(((AnonymousClass0MS) A002).getString(str, "")));
                } catch (NumberFormatException unused) {
                }
                countDownLatch2.countDown();
                try {
                    AnonymousClass002.A0o(countDownLatch2);
                } catch (InterruptedException e2) {
                    C14270pR.A0I("FbnsServiceDelegate", "Waiting for logger user id fetch was interrupted", e2);
                }
                Long valueOf2 = Long.valueOf(atomicLong.get());
                ? obj = new Object();
                obj.A00 = A002;
                this.A06 = obj;
                boolean z2 = false;
                if (new Random().nextInt(10000) < i2) {
                    z2 = true;
                }
                AnonymousClass0ME r42 = r24.A03;
                if (r42.A00 != null) {
                    AnonymousClass0MJ r26 = (AnonymousClass0MJ) r42.A00();
                    Context applicationContext8 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext8);
                    r26.A00 = z2;
                    Executor executor = AnonymousClass113.A04;
                    AnonymousClass113 r43 = new AnonymousClass113(applicationContext8, new C211516m(r15, this, 1));
                    C04540Mc r252 = new C04540Mc(applicationContext8, AnonymousClass0MZ.A00(applicationContext8), "MQTT", (String) null, (Map) null);
                    String B76 = r25.B76();
                    boolean z3 = false;
                    Context applicationContext9 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext9);
                    ? obj2 = new Object();
                    obj2.A00 = A002;
                    String A003 = AnonymousClass14M.A00(A0T());
                    C211516m r9 = new C211516m(r15, this, 0);
                    AnonymousClass11L r52 = AnonymousClass11E.A0E;
                    AnonymousClass0MZ A004 = AnonymousClass0MZ.A00(applicationContext9);
                    C04540Mc r253 = new C04540Mc(applicationContext9, A004, "MQTT", (String) null, (Map) null);
                    AnonymousClass11E r30 = new AnonymousClass11E(applicationContext9, r43, A002, r9, new AnonymousClass119(B76), obj2, A003, r253.A01(), A004.A01, A004.A00);
                    this.A08 = new AnonymousClass10W(r43);
                    Context applicationContext10 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext10);
                    AnonymousClass0QS A005 = AnonymousClass0WY.A00(applicationContext10, A022, "ids");
                    Context applicationContext11 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext11);
                    boolean z4 = A022.A00(applicationContext11, "zero_pre_init_qe").getBoolean("use_instagram_free_endpoint_fbns", false);
                    Context applicationContext12 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext12);
                    boolean z5 = A022.A00(applicationContext12, "com.instagram.lite").getBoolean("use_instagram_free_endpoint_fbns", false);
                    ? obj3 = new Object();
                    ? obj4 = new Object();
                    Context applicationContext13 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext13);
                    Context applicationContext14 = r41.getApplicationContext();
                    C15800sA.A09(applicationContext14);
                    C204613u r7 = new C204613u(AnonymousClass001.A1R(AnonymousClass11Z.A00(applicationContext14) ? 1 : 0));
                    C204413s r10 = this.A0D;
                    AnonymousClass14Q r53 = new AnonymousClass14Q(A005);
                    ? obj5 = new Object();
                    Handler A092 = AnonymousClass001.A09();
                    ? obj6 = new Object();
                    C12860mX r92 = this.A03;
                    C14240pO r32 = this.A0C;
                    if (r32.A02 == null) {
                        r32.A02 = r15;
                    }
                    AnonymousClass13V r8 = this.A0B;
                    C206614o r47 = new C206614o();
                    C198011e r44 = new C198011e(r26);
                    if (z4 || z5) {
                        z3 = true;
                    }
                    AnonymousClass10J r33 = new AnonymousClass10J(this);
                    ? r0 = new AnonymousClass141();
                    AnonymousClass14A r254 = new AnonymousClass14A(applicationContext13, A092, (AnonymousClass0Ev) null, (AnonymousClass02Z) null, r30, obj6, r44, r92, A022, (AnonymousClass118) null, r2, r23, r22, r23, (AnonymousClass118) null, r15, r53, r8, r10, r7, r25, r47, obj3, obj4, obj5, (C209515s) null, r33, num, valueOf2, (String) null, (String) null, (Map) null, (AtomicReference) null, 0, -1, -1, 0, -1, 0, 0, 0, 0, 0, false, false, false, false, false, false, false, false, false, false, false, false, z3, false, false, false, false, false, false, false);
                    C06620Xd r152 = new C06620Xd();
                    r0.A00 = r4;
                    Context context = r254.A0A;
                    AnonymousClass0MM A024 = r24.A02();
                    C197811c r45 = new C197811c(context, A024);
                    r0.A00(new C198011e(r45), r254, A0G);
                    AnonymousClass0QS A006 = AnonymousClass0WY.A00(context, A024, "analytics");
                    r0.A03 = new AnonymousClass117(context, A024, r0.A05, r0.A06);
                    AnonymousClass12A r54 = r0.A08;
                    RealtimeSinceBootClock realtimeSinceBootClock = r0.A04;
                    r0.A02 = new C09500dv(context, r0.A00, A024, realtimeSinceBootClock, r0.A07, r54);
                    AnonymousClass13D r14 = r0.A0I;
                    r0.A01 = new C14830qR(context, r0.A01, A006, r0.A04, r252, r14, r152);
                    return r0;
                }
                throw AnonymousClass001.A0V("IMqttStatsLogSwitcher not bound in FBNS Config Manager");
            }
            StringBuilder A0m2 = AnonymousClass001.A0m();
            AnonymousClass002.A0i(-1, "Cannot cast", A0m2);
            throw new ClassCastException(A0m2.toString());
        }
        throw AnonymousClass001.A0V("MqttIdManagerBuilder not bound in Fbns Config Manager");
    }

    public final void A0a() {
        ((AtomicLong) ((AnonymousClass12V) this.A05.A04(C200512f.class)).A01(C200412e.FbnsLiteNotificationDeliveryRetried)).addAndGet((long) this.A04.A01());
    }

    public final void A0b() {
        C12630kx r1 = this.A04;
        if (r1.A00 == null) {
            AnonymousClass14G r3 = new AnonymousClass14G(r1);
            r1.A00 = r3;
            AnonymousClass0MD.A02.A08(r3, r1.A04, new IntentFilter("com.facebook.rti.intent.ACTION_NOTIFICATION_ACK"), (Handler) null, AnonymousClass001.A0J());
        }
    }

    public final void A0c() {
        C12630kx r3 = this.A04;
        BroadcastReceiver broadcastReceiver = r3.A00;
        if (broadcastReceiver != null) {
            AnonymousClass0MD.A02.A07(broadcastReceiver, r3.A04);
            r3.A00 = null;
        }
    }

    public final void A0d(int i) {
        this.A04.A03(TimeUnit.SECONDS, i);
    }

    public final void A0f(Intent intent, AnonymousClass0T5 r18) {
        String str;
        String str2;
        StringBuilder A0p;
        Intent intent2 = intent;
        String action = intent2.getAction();
        String stringExtra = intent2.getStringExtra("appid");
        if (TextUtils.isEmpty(stringExtra)) {
            stringExtra = "";
        }
        if ("com.facebook.rti.fbns.intent.REGISTER".equals(action) || "com.facebook.rti.fbns.intent.REGISTER_RETRY".equals(action) || "com.facebook.rti.fbns.intent.UNREGISTER".equals(action)) {
            String stringExtra2 = intent2.getStringExtra("pkg_name");
            String A002 = AnonymousClass0MC.A00(intent2);
            if ("com.facebook.rti.fbns.intent.UNREGISTER".equals(action)) {
                str = "unreg_fail";
            } else {
                str = "reg_fail";
            }
            if (TextUtils.isEmpty(stringExtra2)) {
                A0p = AnonymousClass001.A0p("Empty package name for ");
                AnonymousClass002.A0j(action, " from ", A002, A0p);
            } else {
                if ("com.facebook.rti.fbns.intent.REGISTER_RETRY".equals(action)) {
                    str2 = AnonymousClass0QN.A00(this);
                } else {
                    str2 = stringExtra2;
                }
                if (!str2.equals(A002)) {
                    A0p = AnonymousClass001.A0p("Package mismatch for ");
                    AnonymousClass002.A0j(action, " from ", A002, A0p);
                    A0p.append(": packageName ");
                    A0p.append(str2);
                }
            }
            String obj = A0p.toString();
            C14270pR.A0G("FbnsServiceDelegate", obj);
            A0A(this, str, stringExtra2, stringExtra, obj, Collections.emptyMap());
            return;
        }
        String action2 = intent2.getAction();
        AnonymousClass0T5 r3 = r18;
        if ("com.facebook.rti.fbns.intent.REGISTER".equals(action2)) {
            A0h(r3, AnonymousClass0X6.A02);
            A07(intent2, this);
        } else if ("com.facebook.rti.fbns.intent.REGISTER_RETRY".equals(action2)) {
            A0h(r3, AnonymousClass0X6.A03);
            String stringExtra3 = intent2.getStringExtra("pkg_name");
            String stringExtra4 = intent2.getStringExtra("appid");
            A08(this, stringExtra3, stringExtra4);
            A0A(this, "reg_retry_legacy", stringExtra3, stringExtra4, (String) null, AnonymousClass001.A0w());
        } else if ("com.facebook.rti.fbns.intent.UNREGISTER".equals(action2)) {
            A0h(r3, AnonymousClass0X6.A04);
            String stringExtra5 = intent2.getStringExtra("pkg_name");
            AnonymousClass117 r0 = this.A07;
            AnonymousClass0QN.A01(stringExtra5);
            AnonymousClass0QS A003 = AnonymousClass0WY.A00(r0.A00, r0.A01, "registrations");
            C15800sA.A0D(stringExtra5, 0);
            String string = ((AnonymousClass0MS) A003).getString(stringExtra5, "");
            if (!TextUtils.isEmpty(string)) {
                try {
                    C199111q A004 = C199111q.A00(string);
                    if (!A004.A04) {
                        A004.A04 = true;
                        AnonymousClass117.A01(A003, A004, stringExtra5);
                    }
                } catch (JSONException e) {
                    C14270pR.A0R("RegistrationState", e, "Parse failed");
                }
            }
            Intent A072 = AnonymousClass001.A07("com.facebook.rti.fbns.intent.RECEIVE");
            A072.setPackage(stringExtra5);
            A072.addCategory(stringExtra5);
            A072.putExtra("receive_type", "unregistered");
            A06(A072);
            AnonymousClass117 r02 = this.A07;
            AnonymousClass0YV r4 = new AnonymousClass0YV(this, stringExtra5);
            AnonymousClass0QN.A01(stringExtra5);
            String string2 = ((AnonymousClass0MS) AnonymousClass0WY.A00(r02.A00, r02.A01, "registrations")).getString(stringExtra5, "");
            if (TextUtils.isEmpty(string2)) {
                r4.CWV((String) null);
            } else {
                try {
                    r4.CWV(C199111q.A00(string2).A01);
                } catch (JSONException e2) {
                    C14270pR.A0R("RegistrationState", e2, "Parse failed");
                    r4.CWV((String) null);
                }
            }
        } else {
            C14270pR.A0F("FbnsServiceDelegate", "service/doIntent/unrecognized_action");
            return;
        }
        ArrayList A0t = AnonymousClass001.A0t();
        ArrayList A0t2 = AnonymousClass001.A0t();
        Context applicationContext = this.A01.getApplicationContext();
        C15800sA.A09(applicationContext);
        C04640Mn.A01(applicationContext, A0t, A0t2);
        ArrayList A0t3 = AnonymousClass001.A0t();
        A0q(A0t3);
        AnonymousClass12O r1 = this.A05;
        r1.A0K = AnonymousClass12O.A02(A0t);
        r1.A0H = AnonymousClass12O.A02(A0t2);
        r1.A0J = AnonymousClass12O.A02(A0t3);
    }

    public final void A0h(AnonymousClass0T5 r4, Integer num) {
        A0C("start", AnonymousClass12C.A00(num), r4.A03);
        super.A0h(r4, num);
    }

    public final void A0o(AnonymousClass11U r16, AnonymousClass13K r17, String str, String str2) {
        C05160Pw r0;
        AnonymousClass13K r5 = r17;
        C05160Pw r4 = r5.A01;
        C05160Pw r1 = r5.A03;
        String obj = r16.toString();
        long j = r5.A00;
        if (r1.A03()) {
            r0 = C05160Pw.A00(Long.valueOf(System.currentTimeMillis() - AnonymousClass001.A06(r1.A02())));
        } else {
            r0 = AnonymousClass0MB.A00;
        }
        String str3 = r5.A06;
        String str4 = str;
        this.A03.CIO(AnonymousClass0WY.A0i("Error: Fail to deliver notifId = ", str4));
        String str5 = str2;
        if (r0.A03()) {
            this.A08.A01("fbns_e2e_latency", new String[]{"discard", AnonymousClass0QN.A00(this), str5}, AnonymousClass001.A06(r0.A02()));
        }
        this.A08.A01("fbns_latency", new String[]{"discard", AnonymousClass0QN.A00(this), str5}, j);
        HashMap A012 = C05160Pw.A01(r4);
        A012.put("src", str3);
        A0B(this, "discard", str4, str5, obj, A012, j);
    }

    static {
        HashMap A0w = AnonymousClass001.A0w();
        A0H = A0w;
        A0w.put("com.instagram.android", 30);
        A0w.put("com.facebook.lite", 100);
        A0w.put("com.oculus.horizon", 10);
    }

    public FbnsServiceDelegate(AnonymousClass0QM r3) {
        super(r3);
        C14240pO r1 = new C14240pO();
        this.A0C = r1;
        this.A0B = new C14190pG(r1);
    }

    public static String A05(String str) {
        if (C04640Mn.A02(str)) {
            return ((AnonymousClass0MO) AnonymousClass0M9.A00).A04;
        }
        return FbnsService.class.getName();
    }

    private final void A06(Intent intent) {
        String str = intent.getPackage();
        if (!TextUtils.isEmpty(str)) {
            AnonymousClass0MC r2 = this.A00;
            AnonymousClass0QP A012 = ((AnonymousClass0MO) AnonymousClass0M9.A00).A01(intent, r2);
            if (str.equals(AnonymousClass0QN.A00(this)) || A012.CEw()) {
                r2.A02(intent);
                AnonymousClass0MR.A01(intent, r2, str);
                return;
            }
            AnonymousClass117 r0 = this.A07;
            AnonymousClass0Y9 r4 = new AnonymousClass0Y9(this, str);
            AnonymousClass0QN.A01(str);
            String string = ((AnonymousClass0MS) AnonymousClass0WY.A00(r0.A00, r0.A01, "registrations")).getString(str, "");
            if (TextUtils.isEmpty(string)) {
                r4.CWV((String) null);
                return;
            }
            try {
                r4.CWV(C199111q.A00(string).A01);
            } catch (JSONException e) {
                C14270pR.A0R("RegistrationState", e, "Parse failed");
                r4.CWV((String) null);
            }
        }
    }

    public static final void A08(FbnsServiceDelegate fbnsServiceDelegate, String str, String str2) {
        String str3;
        String str4;
        HashMap A0w = AnonymousClass001.A0w();
        String str5 = str;
        FbnsServiceDelegate fbnsServiceDelegate2 = fbnsServiceDelegate;
        String str6 = str2;
        if (TextUtils.isEmpty(str5) || TextUtils.isEmpty(str6)) {
            str4 = "reg_fail";
            str3 = "invalid input";
        } else {
            try {
                C09500dv r3 = fbnsServiceDelegate2.A05;
                C15800sA.A0D(str5, 0);
                long j = ((AnonymousClass0MS) r3.A04).getLong(str5, 120000);
                Intent A072 = AnonymousClass001.A07("com.facebook.rti.fbns.intent.REGISTER_RETRY");
                A072.putExtra("pkg_name", str5);
                A072.putExtra("appid", str6);
                r3.A02.A02(A072);
                AnonymousClass0MF r4 = new AnonymousClass0MF();
                Context context = r3.A01;
                r4.A0B(A072, context.getClassLoader());
                r4.A09();
                r4.A08 = r3.A09;
                PendingIntent A032 = r4.A03(context, 0, 134217728);
                r3.A08.put(str5, A032);
                r3.A06.A06(context, r3.A00, 2, SystemClock.elapsedRealtime() + j, A032);
                long j2 = j * 2;
                if (j2 > CatchMeIfYouCan.REMEDY_TIMEOUT_MS) {
                    j2 = CatchMeIfYouCan.REMEDY_TIMEOUT_MS;
                }
                AnonymousClass0W2 Ab9 = r3.A04.Ab9();
                Ab9.Deb(str5, j2);
                Ab9.ANu();
            } catch (Exception e) {
                C14270pR.A0R("FbnsServiceDelegate", e, "service/register_retry/schedule_failed");
                A0A(fbnsServiceDelegate2, "reg_retry_schedule_fail", str5, str6, e.getMessage(), A0w);
            }
            AnonymousClass117 r1 = fbnsServiceDelegate2.A07;
            AnonymousClass0QN.A01(str5);
            AnonymousClass0QN.A01(str6);
            C199111q r32 = new C199111q();
            r32.A02 = str5;
            r32.A01 = str6;
            r32.A00 = AnonymousClass001.A0Q();
            AnonymousClass117.A01(AnonymousClass0WY.A00(r1.A00, r1.A01, "registrations"), r32, str5);
            Context applicationContext = fbnsServiceDelegate2.A01.getApplicationContext();
            C15800sA.A09(applicationContext);
            if (AnonymousClass11Z.A00(applicationContext)) {
                fbnsServiceDelegate2.A0C.A0T.Br3();
                throw null;
            }
            try {
                JSONObject A19 = AnonymousClass001.A19();
                A19.putOpt("pkg_name", str5);
                A19.putOpt("appid", str6);
                String obj = A19.toString();
                C07040Zd r5 = new C07040Zd(fbnsServiceDelegate2, str5, str6, A0w);
                try {
                    if (fbnsServiceDelegate2.A09.A08(r5, AnonymousClass0X6.A01, "/fbns_reg_req", obj.getBytes("UTF-8")) == -1) {
                        str4 = "reg_fail";
                        str3 = "mqtt not connected";
                    } else {
                        return;
                    }
                } catch (UnsupportedEncodingException unused) {
                    throw AnonymousClass001.A0V("UTF-8 not supported");
                } catch (AnonymousClass153 unused2) {
                }
            } catch (JSONException e2) {
                C14270pR.A0R("FbnsServiceDelegate", e2, "service/register/serialize_exception");
                A0A(fbnsServiceDelegate2, "reg_fail", str5, str6, "serialization exception: unknown client", A0w);
                return;
            }
        }
        A0A(fbnsServiceDelegate2, str4, str5, str6, str3, A0w);
    }

    public final void A0I() {
        super.A0I();
    }

    public final void A0J(Intent intent) {
        A0C("rebind", intent.getAction(), intent.getStringExtra("caller"));
        super.A0J(intent);
    }

    public final boolean A0K(Intent intent) {
        A0C("unbind", intent.getAction(), intent.getStringExtra("caller"));
        return this.A01.A09(intent);
    }

    public final void A0N() {
        super.A0N();
        if (A0E == this) {
            A0E = null;
        }
    }

    public final AnonymousClass0T5 A0S(Intent intent, int i, int i2) {
        return super.A0S(intent, i, i2);
    }

    public final Integer A0T() {
        return AnonymousClass0X6.A01;
    }

    public final String A0U() {
        return "FBNS_ALWAYS";
    }

    public final Future A0V(C207714z r4) {
        A0C("stop", r4.toString(), (String) null);
        return super.A0V(r4);
    }

    public final void A0X() {
        super.A0X();
        this.A05.A0I = "S";
    }

    public final void A0Y() {
        super.A0Y();
        C14620q4 r0 = (C14620q4) this.A0C;
        AnonymousClass117 r8 = r0.A03;
        C14830qR r7 = r0.A01;
        C09500dv r6 = r0.A02;
        AnonymousClass0MC r5 = r0.A00;
        C12630kx r4 = new C12630kx(r5, r0.A05, this, AnonymousClass001.A0w());
        Context applicationContext = this.A01.getApplicationContext();
        C15800sA.A09(applicationContext);
        FbnsAIDLService fbnsAIDLService = new FbnsAIDLService(applicationContext, new C18790y3(this), this.A03);
        this.A07 = r8;
        this.A02 = r7;
        this.A05 = r6;
        this.A00 = r5;
        this.A04 = r4;
        this.A01 = fbnsAIDLService;
    }

    public final C05160Pw A0n(String str, String str2) {
        C05160Pw r0;
        C208415g A042 = A04(str2);
        synchronized (C208415g.A02) {
            AnonymousClass13K r1 = (AnonymousClass13K) A042.A00.remove(str);
            if (r1 != null) {
                r0 = new C198011e(r1);
            } else {
                r0 = AnonymousClass0MB.A00;
            }
        }
        return r0;
    }

    public final void A0p(C05160Pw r10, String str, String str2, String str3, String str4, String str5) {
        if (!TextUtils.isEmpty(str4)) {
            this.A03.CIO(str4);
        }
        HashMap A012 = C05160Pw.A01(r10);
        A012.put("src", str5);
        A0B(this, "fail", str3, str, str2, A012, 0);
    }

    public final void A0i(AnonymousClass0AT r1) {
    }

    /* JADX WARNING: Removed duplicated region for block: B:162:0x0515 A[Catch:{ JSONException -> 0x06ef }] */
    /* JADX WARNING: Removed duplicated region for block: B:164:0x054e A[Catch:{ JSONException -> 0x06ef }] */
    /* JADX WARNING: Removed duplicated region for block: B:269:0x0745 A[Catch:{ all -> 0x0748 }] */
    /* JADX WARNING: Removed duplicated region for block: B:277:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A0g(X.AnonymousClass127 r41, java.lang.Long r42, java.lang.String r43, byte[] r44, int r45, long r46) {
        /*
            r40 = this;
            r11 = 0
            r14 = 1
            java.lang.String r7 = "FbnsServiceDelegate"
            r13 = r43
            r2 = r44
            if (r44 != 0) goto L_0x0015
            java.lang.Object[] r1 = new java.lang.Object[]{r13}
            java.lang.String r0 = "receive/publish/empty_payload; topic=%s"
            X.C14270pR.A0O(r7, r0, r1)
            goto L_0x073f
        L_0x0015:
            r3 = r40
            java.lang.String r1 = "UTF-8"
            java.lang.String r18 = new java.lang.String     // Catch:{ UnsupportedEncodingException -> 0x06e4 }
            r0 = r18
            r0.<init>(r2, r1)     // Catch:{ UnsupportedEncodingException -> 0x06e4 }
            java.lang.String r0 = "/fbns_msg"
            boolean r0 = r0.equals(r13)     // Catch:{ JSONException -> 0x06ef }
            if (r0 != 0) goto L_0x0227
            java.lang.String r0 = "/fbns_msg_hp"
            boolean r0 = r0.equals(r13)     // Catch:{ JSONException -> 0x06ef }
            if (r0 != 0) goto L_0x0227
            java.lang.String r0 = "/fbns_reg_resp"
            boolean r0 = r0.equals(r13)     // Catch:{ JSONException -> 0x06ef }
            if (r0 == 0) goto L_0x01db
            X.0if r2 = new X.0if     // Catch:{ JSONException -> 0x06ef }
            r2.<init>()     // Catch:{ JSONException -> 0x06ef }
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ JSONException -> 0x06ef }
            r0 = r18
            r1.<init>(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "pkg_name"
            java.lang.String r0 = r1.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            r2.A01 = r0     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "token"
            java.lang.String r0 = r1.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            r2.A02 = r0     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "error"
            java.lang.String r0 = r1.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            r2.A00 = r0     // Catch:{ JSONException -> 0x06ef }
            boolean r1 = android.text.TextUtils.isEmpty(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            boolean r0 = android.text.TextUtils.isEmpty(r0)     // Catch:{ JSONException -> 0x06ef }
            if (r1 == 0) goto L_0x0174
            java.lang.String r1 = "resp_fail"
            if (r0 == 0) goto L_0x008b
            java.lang.String r0 = "service/register/response/invalid"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x06ef }
            X.10W r2 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "invalid_package_name"
            r2.A00(r1, r0)     // Catch:{ JSONException -> 0x06ef }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x06ef }
            r22 = 0
            java.lang.String r23 = "server response with invalid package name"
            java.lang.String r21 = ""
            r19 = r3
            r20 = r1
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x008b:
            java.lang.String r0 = r2.A02     // Catch:{ JSONException -> 0x06ef }
            boolean r0 = android.text.TextUtils.isEmpty(r0)     // Catch:{ JSONException -> 0x06ef }
            if (r0 == 0) goto L_0x00b4
            java.lang.String r0 = "service/register/response/empty_token"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x06ef }
            X.10W r4 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "empty_token"
            r4.A00(r1, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x06ef }
            r22 = 0
            java.lang.String r23 = "server response with invalid token"
            r19 = r3
            r20 = r1
            r21 = r0
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x00b4:
            X.117 r0 = r3.A07     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r6 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = r2.A02     // Catch:{ JSONException -> 0x06ef }
            X.AnonymousClass0QN.A01(r6)     // Catch:{ JSONException -> 0x06ef }
            X.AnonymousClass0QN.A01(r8)     // Catch:{ JSONException -> 0x06ef }
            X.0MM r9 = r0.A01     // Catch:{ JSONException -> 0x06ef }
            android.content.Context r5 = r0.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "fbns_state"
            X.0QS r0 = X.AnonymousClass0WY.A00(r5, r9, r0)     // Catch:{ JSONException -> 0x06ef }
            X.0W2 r1 = r0.Ab9()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "auto_reg_retry"
            r1.DjH(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r4 = "RegistrationState"
            r1.ANu()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "registrations"
            X.0QS r5 = X.AnonymousClass0WY.A00(r5, r9, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = ""
            r0 = r5
            X.0MS r0 = (X.AnonymousClass0MS) r0     // Catch:{ JSONException -> 0x06ef }
            X.C15800sA.A0D(r6, r11)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = r0.getString(r6, r1)     // Catch:{ JSONException -> 0x06ef }
            boolean r0 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r0 == 0) goto L_0x010f
            java.lang.String r0 = "Missing entry"
            X.C14270pR.A0F(r4, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "service/register/response/cache_update_failed"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x06ef }
            r22 = 0
            java.lang.String r20 = "cache_update_fail"
            r19 = r3
            r21 = r0
            r23 = r22
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x010f:
            X.11q r1 = X.C199111q.A00(r1)     // Catch:{ JSONException -> 0x014f }
            r1.A03 = r8     // Catch:{ JSONException -> 0x014f }
            java.lang.Long r0 = X.AnonymousClass001.A0Q()     // Catch:{ JSONException -> 0x014f }
            r1.A00 = r0     // Catch:{ JSONException -> 0x014f }
            boolean r0 = X.AnonymousClass117.A01(r5, r1, r6)     // Catch:{ JSONException -> 0x014f }
            if (r0 == 0) goto L_0x013f
            java.lang.String r5 = r2.A01     // Catch:{ JSONException -> 0x014f }
            java.lang.String r1 = r2.A02     // Catch:{ JSONException -> 0x014f }
            java.lang.String r0 = "unknown"
            A09(r3, r5, r1, r0)     // Catch:{ JSONException -> 0x014f }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x014f }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x014f }
            r22 = 0
            java.lang.String r20 = "resp_success"
        L_0x0134:
            r19 = r3
            r21 = r0
            r23 = r22
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x014f }
            goto L_0x073f
        L_0x013f:
            java.lang.String r0 = "service/register/response/cache_update_failed"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x014f }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x014f }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x014f }
            r22 = 0
            java.lang.String r20 = "cache_update_fail"
            goto L_0x0134
        L_0x014f:
            r1 = move-exception
            java.lang.String r0 = "Parse failed"
            X.C14270pR.A0R(r4, r1, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "Missing entry"
            X.C14270pR.A0F(r4, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "service/register/response/cache_update_failed"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x06ef }
            r22 = 0
            java.lang.String r20 = "cache_update_fail"
            r19 = r3
            r21 = r0
            r23 = r22
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x0174:
            if (r0 == 0) goto L_0x017c
            java.lang.String r0 = "service/register/response/empty_package"
            X.C14270pR.A0F(r7, r0)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x01a6
        L_0x017c:
            X.117 r0 = r3.A07     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r6 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            X.AnonymousClass0QN.A01(r6)     // Catch:{ JSONException -> 0x06ef }
            X.0MM r4 = r0.A01     // Catch:{ JSONException -> 0x06ef }
            android.content.Context r1 = r0.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "registrations"
            X.0QS r5 = X.AnonymousClass0WY.A00(r1, r4, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r4 = ""
            r0 = r5
            X.0MS r0 = (X.AnonymousClass0MS) r0     // Catch:{ JSONException -> 0x06ef }
            X.C15800sA.A0D(r6, r11)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = r0.getString(r6, r4)     // Catch:{ JSONException -> 0x06ef }
            boolean r0 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r0 == 0) goto L_0x01bd
            java.lang.String r1 = "RegistrationState"
            java.lang.String r0 = "Missing entry"
            X.C14270pR.A0F(r1, r0)     // Catch:{ JSONException -> 0x06ef }
        L_0x01a6:
            java.lang.String r1 = r2.A01     // Catch:{ JSONException -> 0x06ef }
            java.util.Map r24 = java.util.Collections.emptyMap()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r22 = ""
            java.lang.String r0 = r2.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r20 = "resp_fail"
            r19 = r3
            r21 = r1
            r23 = r0
            A0A(r19, r20, r21, r22, r23, r24)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x01bd:
            X.11q r1 = X.C199111q.A00(r1)     // Catch:{ JSONException -> 0x01cd }
            r1.A03 = r4     // Catch:{ JSONException -> 0x01cd }
            java.lang.Long r0 = X.AnonymousClass001.A0Q()     // Catch:{ JSONException -> 0x01cd }
            r1.A00 = r0     // Catch:{ JSONException -> 0x01cd }
            X.AnonymousClass117.A01(r5, r1, r6)     // Catch:{ JSONException -> 0x01cd }
            goto L_0x01a6
        L_0x01cd:
            r4 = move-exception
            java.lang.String r1 = "RegistrationState"
            java.lang.String r0 = "Parse failed"
            X.C14270pR.A0R(r1, r4, r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "Missing entry"
            X.C14270pR.A0F(r1, r0)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x01a6
        L_0x01db:
            java.lang.String r0 = "/pp"
            boolean r0 = r0.equals(r13)     // Catch:{ JSONException -> 0x06ef }
            if (r0 != 0) goto L_0x073f
            java.lang.String r1 = "receive/publish/wrong_topic; topic=%s"
            java.lang.Object[] r0 = new java.lang.Object[]{r13}     // Catch:{ JSONException -> 0x06ef }
            X.C14270pR.A0O(r7, r1, r0)     // Catch:{ JSONException -> 0x06ef }
            X.10W r0 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "UNEXPECTED_TOPIC"
            r0.A00(r1, r13)     // Catch:{ JSONException -> 0x06ef }
            X.0qR r8 = r3.A02     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "event_type"
            java.lang.String[] r0 = new java.lang.String[]{r0, r1}     // Catch:{ JSONException -> 0x06ef }
            java.util.HashMap r6 = X.C196810r.A01(r0)     // Catch:{ JSONException -> 0x06ef }
            boolean r0 = android.text.TextUtils.isEmpty(r13)     // Catch:{ JSONException -> 0x06ef }
            if (r0 != 0) goto L_0x020a
            java.lang.String r0 = "event_extra_info"
            r6.put(r0, r13)     // Catch:{ JSONException -> 0x06ef }
        L_0x020a:
            java.lang.String r5 = "fbns_service_event"
            java.util.Locale r0 = java.util.Locale.getDefault()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r4 = r0.toString()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r2 = android.os.Build.MODEL     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = android.os.Build.MANUFACTURER     // Catch:{ JSONException -> 0x06ef }
            X.10p r1 = new X.10p     // Catch:{ JSONException -> 0x06ef }
            r1.<init>(r5, r4, r2, r0)     // Catch:{ JSONException -> 0x06ef }
            r1.A04(r6)     // Catch:{ JSONException -> 0x06ef }
            X.10q r0 = r8.A01     // Catch:{ JSONException -> 0x06ef }
            r0.DmU(r1)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x0227:
            java.lang.String r30 = ""
            X.0MB r4 = X.AnonymousClass0MB.A00     // Catch:{ JSONException -> 0x06ef }
            org.json.JSONObject r2 = new org.json.JSONObject     // Catch:{ JSONException -> 0x06ef }
            r0 = r18
            r2.<init>(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r27 = "pim"
            r0 = r27
            java.lang.String r26 = r2.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r25 = "token"
            r0 = r25
            java.lang.String r24 = r2.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "ck"
            r2.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r0 = "pn"
            java.lang.String r0 = r2.optString(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "cp"
            java.lang.String r23 = r2.optString(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "fbpushnotif"
            java.lang.String r15 = r2.optString(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "nid"
            java.lang.String r5 = r2.optString(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "bu"
            r2.optString(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r6 = "l"
            boolean r1 = r2.has(r6)     // Catch:{ JSONException -> 0x06ef }
            if (r1 == 0) goto L_0x0295
            boolean r1 = r2.isNull(r6)     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x0295
            boolean r1 = r2.getBoolean(r6)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)     // Catch:{ JSONException -> 0x06ef }
            X.11e r19 = X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x027e:
            java.lang.String r1 = "qt"
            long r16 = r2.optLong(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "j"
            java.lang.String r31 = r2.optString(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "at"
            r22 = 0
            int r8 = r2.optInt(r1, r11)     // Catch:{ JSONException -> 0x06ef }
            if (r8 == r14) goto L_0x029e
            goto L_0x0298
        L_0x0295:
            r19 = r4
            goto L_0x027e
        L_0x0298:
            r1 = 2
            if (r8 == r1) goto L_0x02a1
            java.lang.Integer r21 = X.AnonymousClass0X6.A00     // Catch:{ JSONException -> 0x06ef }
            goto L_0x02a3
        L_0x029e:
            java.lang.Integer r21 = X.AnonymousClass0X6.A01     // Catch:{ JSONException -> 0x06ef }
            goto L_0x02a3
        L_0x02a1:
            java.lang.Integer r21 = X.AnonymousClass0X6.A0C     // Catch:{ JSONException -> 0x06ef }
        L_0x02a3:
            java.lang.String r8 = "s"
            java.lang.String r1 = "MQTT"
            java.lang.String r20 = r2.optString(r8, r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "mt"
            boolean r8 = r2.has(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r8 == 0) goto L_0x02ff
            long r8 = r2.getLong(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Long r1 = java.lang.Long.valueOf(r8)     // Catch:{ JSONException -> 0x06ef }
            X.11e r28 = X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x02bf:
            java.lang.String r1 = "ttl"
            boolean r8 = r2.has(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r8 == 0) goto L_0x02fc
            long r8 = r2.getLong(r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Long r1 = java.lang.Long.valueOf(r8)     // Catch:{ JSONException -> 0x06ef }
            X.11e r29 = X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x02d3:
            java.lang.String r1 = "st"
            boolean r8 = r2.has(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r8 == 0) goto L_0x02e5
            boolean r8 = r2.isNull(r1)     // Catch:{ JSONException -> 0x06ef }
            if (r8 != 0) goto L_0x02e5
            boolean r22 = r2.optBoolean(r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x02e5:
            X.12t r10 = r3.A06     // Catch:{ JSONException -> 0x06ef }
            boolean r1 = r19.A03()     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x0385
            java.util.concurrent.CountDownLatch r12 = new java.util.concurrent.CountDownLatch     // Catch:{ JSONException -> 0x06ef }
            r12.<init>(r14)     // Catch:{ JSONException -> 0x06ef }
            X.0TA[] r1 = X.AnonymousClass0TA.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = "LOG_SR"
            java.lang.String r1 = "/"
            r2 = r0
            if (r0 != 0) goto L_0x0304
            goto L_0x0302
        L_0x02fc:
            r29 = r4
            goto L_0x02d3
        L_0x02ff:
            r28 = r4
            goto L_0x02bf
        L_0x0302:
            r2 = r30
        L_0x0304:
            java.lang.String r8 = X.AnonymousClass0WY.A0w(r9, r1, r2)     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.atomic.AtomicInteger r2 = new java.util.concurrent.atomic.AtomicInteger     // Catch:{ JSONException -> 0x06ef }
            r2.<init>(r11)     // Catch:{ JSONException -> 0x06ef }
            X.0QS r1 = r10.A00     // Catch:{ JSONException -> 0x06ef }
            X.0MS r1 = (X.AnonymousClass0MS) r1     // Catch:{ JSONException -> 0x06ef }
            X.C15800sA.A0D(r8, r11)     // Catch:{ JSONException -> 0x06ef }
            boolean r19 = r1.contains(r8)     // Catch:{ JSONException -> 0x06ef }
            X.0QS r1 = r10.A00     // Catch:{ JSONException -> 0x06ef }
            if (r19 != 0) goto L_0x031d
            r8 = r9
        L_0x031d:
            X.0MS r1 = (X.AnonymousClass0MS) r1     // Catch:{ JSONException -> 0x06ef }
            int r1 = r1.getInt(r8, r11)     // Catch:{ JSONException -> 0x06ef }
            r2.set(r1)     // Catch:{ JSONException -> 0x06ef }
            r12.countDown()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = "Waiting for sampleRate was interrupted"
            X.AnonymousClass002.A0o(r12)     // Catch:{ InterruptedException -> 0x032f }
            goto L_0x0335
        L_0x032f:
            r9 = move-exception
            java.lang.String r1 = "NotificationLifecycleEventsSampler"
            X.C14270pR.A0I(r1, r8, r9)     // Catch:{ JSONException -> 0x06ef }
        L_0x0335:
            int r9 = r2.get()     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.CountDownLatch r8 = new java.util.concurrent.CountDownLatch     // Catch:{ JSONException -> 0x06ef }
            r8.<init>(r14)     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.atomic.AtomicBoolean r2 = new java.util.concurrent.atomic.AtomicBoolean     // Catch:{ JSONException -> 0x06ef }
            r2.<init>(r11)     // Catch:{ JSONException -> 0x06ef }
            X.0QS r10 = r10.A00     // Catch:{ JSONException -> 0x06ef }
            X.0TA r1 = X.AnonymousClass0TA.A02     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = r1.mPrefKey     // Catch:{ JSONException -> 0x06ef }
            X.0MS r10 = (X.AnonymousClass0MS) r10     // Catch:{ JSONException -> 0x06ef }
            X.C15800sA.A0D(r1, r11)     // Catch:{ JSONException -> 0x06ef }
            boolean r1 = r10.getBoolean(r1, r11)     // Catch:{ JSONException -> 0x06ef }
            r2.set(r1)     // Catch:{ JSONException -> 0x06ef }
            r8.countDown()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r10 = "Waiting for isEmployee was interrupted"
            X.AnonymousClass002.A0o(r8)     // Catch:{ InterruptedException -> 0x035e }
            goto L_0x0364
        L_0x035e:
            r8 = move-exception
            java.lang.String r1 = "NotificationLifecycleEventsSampler"
            X.C14270pR.A0I(r1, r10, r8)     // Catch:{ JSONException -> 0x06ef }
        L_0x0364:
            boolean r10 = r2.get()     // Catch:{ JSONException -> 0x06ef }
            java.util.Random r2 = new java.util.Random     // Catch:{ JSONException -> 0x06ef }
            r2.<init>()     // Catch:{ JSONException -> 0x06ef }
            r1 = 10000(0x2710, float:1.4013E-41)
            int r1 = r2.nextInt(r1)     // Catch:{ JSONException -> 0x06ef }
            r8 = 1
            r2 = 0
            if (r1 >= r9) goto L_0x0378
            r2 = 1
        L_0x0378:
            if (r10 != 0) goto L_0x037d
            if (r2 != 0) goto L_0x037d
            r8 = 0
        L_0x037d:
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r8)     // Catch:{ JSONException -> 0x06ef }
            X.11e r19 = X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x0385:
            r1 = 0
            int r8 = (r16 > r1 ? 1 : (r16 == r1 ? 0 : -1))
            if (r8 == 0) goto L_0x03a7
            long r9 = java.lang.System.currentTimeMillis()     // Catch:{ JSONException -> 0x06ef }
            long r9 = r9 - r16
            int r8 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r8 < 0) goto L_0x0396
            r1 = r9
        L_0x0396:
            X.10W r10 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = X.AnonymousClass0QN.A00(r3)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = "receive"
            java.lang.String[] r9 = new java.lang.String[]{r8, r9, r0}     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = "fbns_e2e_latency"
            r10.A01(r8, r9, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x03a7:
            X.0mX r10 = r3.A03     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = "===Received Notif: target = "
            java.lang.String r8 = "; notifId = "
            java.lang.String r8 = X.AnonymousClass0WY.A18(r9, r0, r8, r5)     // Catch:{ JSONException -> 0x06ef }
            r10.CIO(r8)     // Catch:{ JSONException -> 0x06ef }
            java.util.HashMap r9 = X.AnonymousClass001.A0w()     // Catch:{ JSONException -> 0x06ef }
            boolean r12 = r19.A03()     // Catch:{ JSONException -> 0x06ef }
            if (r12 == 0) goto L_0x03c9
            java.lang.Object r8 = r19.A02()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = java.lang.String.valueOf(r8)     // Catch:{ JSONException -> 0x06ef }
            r9.put(r6, r8)     // Catch:{ JSONException -> 0x06ef }
        L_0x03c9:
            java.lang.String r8 = "src"
            r10 = r20
            r9.put(r8, r10)     // Catch:{ JSONException -> 0x06ef }
            r10 = r24
            java.lang.String r10 = X.AnonymousClass0WY.A0w(r15, r0, r10)     // Catch:{ JSONException -> 0x06ef }
            int r10 = r10.hashCode()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r11 = java.lang.String.valueOf(r10)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r10 = "hash"
            r9.put(r10, r11)     // Catch:{ JSONException -> 0x06ef }
            r36 = 0
            java.lang.String r33 = "receive"
            r32 = r3
            r34 = r5
            r35 = r0
            r37 = r9
            r38 = r1
            A0B(r32, r33, r34, r35, r36, r37, r38)     // Catch:{ JSONException -> 0x06ef }
            X.15g r9 = r3.A04(r0)     // Catch:{ JSONException -> 0x06ef }
            boolean r1 = android.text.TextUtils.isEmpty(r5)     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x0449
            android.util.Pair r2 = new android.util.Pair     // Catch:{ JSONException -> 0x06ef }
            r2.<init>(r5, r0)     // Catch:{ JSONException -> 0x06ef }
            java.util.LinkedList r1 = r9.A01     // Catch:{ JSONException -> 0x06ef }
            boolean r10 = r1.contains(r2)     // Catch:{ JSONException -> 0x06ef }
            if (r10 == 0) goto L_0x043e
            java.lang.Long r1 = java.lang.Long.valueOf(r16)     // Catch:{ JSONException -> 0x06ef }
            X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
            X.0mX r2 = r3.A03     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "Duplicated Notif: notifId = "
            java.lang.String r1 = X.AnonymousClass0WY.A0i(r1, r5)     // Catch:{ JSONException -> 0x06ef }
            r2.CIO(r1)     // Catch:{ JSONException -> 0x06ef }
            java.util.HashMap r2 = X.AnonymousClass001.A0w()     // Catch:{ JSONException -> 0x06ef }
            if (r12 == 0) goto L_0x042e
            java.lang.Object r1 = r19.A02()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ JSONException -> 0x06ef }
            r2.put(r6, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x042e:
            r1 = r20
            r2.put(r8, r1)     // Catch:{ JSONException -> 0x06ef }
            r38 = 0
            java.lang.String r33 = "duplicate"
            r37 = r2
            A0B(r32, r33, r34, r35, r36, r37, r38)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x043e:
            int r8 = r1.size()     // Catch:{ JSONException -> 0x06ef }
            r6 = 100
            if (r8 > r6) goto L_0x049d
            r1.add(r2)     // Catch:{ JSONException -> 0x06ef }
        L_0x0449:
            java.util.LinkedList r6 = r9.A01     // Catch:{ JSONException -> 0x06ef }
            int r1 = r6.size()     // Catch:{ JSONException -> 0x06ef }
            r8 = 100
            if (r1 <= r8) goto L_0x0494
            java.lang.Integer r1 = java.lang.Integer.valueOf(r8)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object[] r2 = new java.lang.Object[]{r1}     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "notifications %d size limit reached"
            X.C14270pR.A0P(r7, r1, r2)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r1 = r6.removeFirst()     // Catch:{ JSONException -> 0x06ef }
            android.util.Pair r1 = (android.util.Pair) r1     // Catch:{ JSONException -> 0x06ef }
            if (r1 == 0) goto L_0x0494
            X.0kx r11 = r3.A04     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r10 = r1.first     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r10 = (java.lang.String) r10     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r9 = r1.second     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = (java.lang.String) r9     // Catch:{ JSONException -> 0x06ef }
            X.0MU r6 = X.AnonymousClass0MU.DATA_EXPIRED     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = "Oldest"
            X.11e r2 = new X.11e     // Catch:{ JSONException -> 0x06ef }
            r2.<init>(r1)     // Catch:{ JSONException -> 0x06ef }
            X.11U r1 = new X.11U     // Catch:{ JSONException -> 0x06ef }
            r1.<init>(r6, r2)     // Catch:{ JSONException -> 0x06ef }
            r11.A05(r1, r10, r9)     // Catch:{ JSONException -> 0x06ef }
            X.10W r10 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r1 = X.AnonymousClass0QN.A00(r3)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String[] r9 = new java.lang.String[]{r1, r0}     // Catch:{ JSONException -> 0x06ef }
            r1 = 1
            java.lang.String r6 = "notifications_store_limit_reached"
            r10.A01(r6, r9, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x0494:
            java.lang.String r1 = "message"
            int r2 = r21.intValue()     // Catch:{ JSONException -> 0x06ef }
            if (r2 == r14) goto L_0x04a9
            goto L_0x04a3
        L_0x049d:
            java.lang.String r1 = "Limit reached: Ignore notification. Missing limitSize() call?"
            X.C14270pR.A0G(r7, r1)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x0449
        L_0x04a3:
            r6 = 2
            if (r2 == r6) goto L_0x04ac
            java.lang.String r2 = "com.facebook.rti.fbns.intent.RECEIVE"
            goto L_0x04ae
        L_0x04a9:
            java.lang.String r2 = "com.facebook.rti.fbns.intent.RECEIVE_RTC"
            goto L_0x04ae
        L_0x04ac:
            java.lang.String r2 = "com.facebook.rti.fbns.intent.RECEIVE_VR"
        L_0x04ae:
            android.content.Intent r2 = X.AnonymousClass001.A07(r2)     // Catch:{ JSONException -> 0x06ef }
            r2.setPackage(r0)     // Catch:{ JSONException -> 0x06ef }
            r2.addCategory(r0)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r6 = "receive_type"
            r2.putExtra(r6, r1)     // Catch:{ JSONException -> 0x06ef }
            if (r15 == 0) goto L_0x04c4
            java.lang.String r1 = "data"
            r2.putExtra(r1, r15)     // Catch:{ JSONException -> 0x06ef }
        L_0x04c4:
            if (r26 == 0) goto L_0x04cd
            r6 = r27
            r1 = r26
            r2.putExtra(r6, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x04cd:
            boolean r1 = android.text.TextUtils.isEmpty(r24)     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x04da
            r6 = r25
            r1 = r24
            r2.putExtra(r6, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x04da:
            boolean r1 = android.text.TextUtils.isEmpty(r23)     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x04e7
            java.lang.String r6 = "collapse_key"
            r1 = r23
            r2.putExtra(r6, r1)     // Catch:{ JSONException -> 0x06ef }
        L_0x04e7:
            X.0kx r1 = r3.A04     // Catch:{ JSONException -> 0x06ef }
            boolean r6 = android.text.TextUtils.isEmpty(r5)     // Catch:{ JSONException -> 0x06ef }
            if (r6 == 0) goto L_0x0560
            com.facebook.rti.push.service.FbnsServiceDelegate r1 = r1.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r31 = "null pnid"
            r28 = r1
            r29 = r19
            r32 = r36
            r33 = r36
            r34 = r20
            r28.A0p(r29, r30, r31, r32, r33, r34)     // Catch:{ JSONException -> 0x06ef }
            X.0MU r2 = X.AnonymousClass0MU.DATA_INVALID     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r33 = "Missing pnid"
        L_0x0504:
            X.11e r4 = X.C05160Pw.A00(r33)     // Catch:{ JSONException -> 0x06ef }
        L_0x0508:
            X.11U r8 = new X.11U     // Catch:{ JSONException -> 0x06ef }
            r8.<init>(r2, r4)     // Catch:{ JSONException -> 0x06ef }
        L_0x050d:
            X.0MU r2 = r8.A00     // Catch:{ JSONException -> 0x06ef }
            boolean r1 = r2.A00()     // Catch:{ JSONException -> 0x06ef }
            if (r1 != 0) goto L_0x054e
            java.lang.String r4 = r2.name()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r2 = "Error: Delivery helper failed notifId = "
            java.lang.String r1 = "; reason = "
            java.lang.String r26 = X.AnonymousClass0WY.A18(r2, r5, r1, r4)     // Catch:{ JSONException -> 0x06ef }
            r21 = r3
            r22 = r19
            r23 = r0
            r24 = r4
            r25 = r5
            r27 = r20
            r21.A0p(r22, r23, r24, r25, r26, r27)     // Catch:{ JSONException -> 0x06ef }
        L_0x0530:
            java.lang.Long r1 = java.lang.Long.valueOf(r16)     // Catch:{ JSONException -> 0x06ef }
            X.C05160Pw.A00(r1)     // Catch:{ JSONException -> 0x06ef }
            X.12O r1 = r3.A05     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.ConcurrentMap r2 = r1.A03     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.atomic.AtomicLong r1 = new java.util.concurrent.atomic.AtomicLong     // Catch:{ JSONException -> 0x06ef }
            r1.<init>()     // Catch:{ JSONException -> 0x06ef }
            r2.putIfAbsent(r0, r1)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r0 = r2.get(r0)     // Catch:{ JSONException -> 0x06ef }
            java.util.concurrent.atomic.AtomicLong r0 = (java.util.concurrent.atomic.AtomicLong) r0     // Catch:{ JSONException -> 0x06ef }
            r0.incrementAndGet()     // Catch:{ JSONException -> 0x06ef }
            goto L_0x073f
        L_0x054e:
            X.10W r6 = r3.A08     // Catch:{ JSONException -> 0x06ef }
            if (r6 == 0) goto L_0x0530
            java.lang.String r1 = "broadcast_sent"
            java.lang.String[] r5 = new java.lang.String[]{r1, r0}     // Catch:{ JSONException -> 0x06ef }
            r1 = 1
            java.lang.String r4 = "notifications"
            r6.A01(r4, r5, r1)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x0530
        L_0x0560:
            java.lang.String r6 = r2.getPackage()     // Catch:{ JSONException -> 0x06ef }
            boolean r9 = android.text.TextUtils.isEmpty(r6)     // Catch:{ JSONException -> 0x06ef }
            if (r9 == 0) goto L_0x0582
            java.lang.String r2 = "Error: invalid receiver = "
            java.lang.String r33 = X.AnonymousClass0WY.A0i(r2, r6)     // Catch:{ JSONException -> 0x06ef }
            com.facebook.rti.push.service.FbnsServiceDelegate r1 = r1.A00     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r31 = "invalid dpn"
            r28 = r1
            r29 = r19
            r32 = r5
            r34 = r20
            r28.A0p(r29, r30, r31, r32, r33, r34)     // Catch:{ JSONException -> 0x06ef }
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_INVALID     // Catch:{ JSONException -> 0x06ef }
            goto L_0x0504
        L_0x0582:
            java.lang.Object r10 = X.AnonymousClass0M9.A00     // Catch:{ JSONException -> 0x06ef }
            X.0MO r10 = (X.AnonymousClass0MO) r10     // Catch:{ JSONException -> 0x06ef }
            X.0MC r9 = r1.A05     // Catch:{ JSONException -> 0x06ef }
            X.0QP r9 = r10.A01(r2, r9)     // Catch:{ JSONException -> 0x06ef }
            r9.EQp()     // Catch:{ 11V -> 0x06cd }
            android.content.Context r9 = r1.A04     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r10 = r9.getPackageName()     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = "extra_notification_sender"
            r2.putExtra(r9, r10)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r9 = "extra_notification_id"
            r2.putExtra(r9, r5)     // Catch:{ JSONException -> 0x06ef }
            if (r22 != 0) goto L_0x05f4
            X.14J r24 = r1.A02(r6)     // Catch:{ IllegalStateException -> 0x06d1 }
            r10 = 0
            int r9 = (r16 > r10 ? 1 : (r16 == r10 ? 0 : -1))
            if (r9 != 0) goto L_0x05ae
            r27 = r4
            goto L_0x05b6
        L_0x05ae:
            java.lang.Long r9 = java.lang.Long.valueOf(r16)     // Catch:{ IllegalStateException -> 0x06d1 }
            X.11e r27 = X.C05160Pw.A00(r9)     // Catch:{ IllegalStateException -> 0x06d1 }
        L_0x05b6:
            r25 = r2
            r26 = r19
            r30 = r5
            r32 = r20
            r24.A03(r25, r26, r27, r28, r29, r30, r31, r32)     // Catch:{ IllegalStateException -> 0x06d1 }
            X.14J r9 = r1.A02(r6)     // Catch:{ IllegalStateException -> 0x06d1 }
            monitor-enter(r9)     // Catch:{ IllegalStateException -> 0x06d1 }
            java.util.LinkedHashSet r11 = r9.A03     // Catch:{ all -> 0x05f1 }
            int r10 = r11.size()     // Catch:{ all -> 0x05f1 }
            if (r10 <= r8) goto L_0x05ee
            java.util.Iterator r11 = r11.iterator()     // Catch:{ all -> 0x05f1 }
            boolean r8 = r11.hasNext()     // Catch:{ all -> 0x05f1 }
            if (r8 == 0) goto L_0x05ee
            java.lang.String r10 = X.AnonymousClass001.A0j(r11)     // Catch:{ all -> 0x05f1 }
            r11.remove()     // Catch:{ all -> 0x05f1 }
            X.AnonymousClass14J.A00(r9, r10)     // Catch:{ all -> 0x05f1 }
            X.0QS r8 = r9.A02     // Catch:{ all -> 0x05f1 }
            X.0W2 r8 = r8.Ab9()     // Catch:{ all -> 0x05f1 }
            r8.DjH(r10)     // Catch:{ all -> 0x05f1 }
            X.AnonymousClass14J.A01(r8, r9)     // Catch:{ all -> 0x05f1 }
        L_0x05ee:
            monitor-exit(r9)     // Catch:{ IllegalStateException -> 0x06d1 }
            goto L_0x067c
        L_0x05f1:
            r1 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x05f1 }
            throw r1     // Catch:{ IllegalStateException -> 0x06d1 }
        L_0x05f4:
            com.facebook.rti.push.service.FbnsServiceDelegate r11 = r1.A00     // Catch:{ JSONException -> 0x06ef }
            r10 = r5
            if (r6 == 0) goto L_0x05ff
            r9 = 95
            java.lang.String r10 = X.AnonymousClass0WY.A0l(r5, r6, r9)     // Catch:{ JSONException -> 0x06ef }
        L_0x05ff:
            r29 = 0
            int r9 = (r16 > r29 ? 1 : (r16 == r29 ? 0 : -1))
            if (r9 != 0) goto L_0x0608
            r24 = r4
            goto L_0x0610
        L_0x0608:
            java.lang.Long r9 = java.lang.Long.valueOf(r16)     // Catch:{ JSONException -> 0x06ef }
            X.11e r24 = X.C05160Pw.A00(r9)     // Catch:{ JSONException -> 0x06ef }
        L_0x0610:
            X.13K r9 = new X.13K     // Catch:{ JSONException -> 0x06ef }
            r22 = r9
            r23 = r19
            r25 = r28
            r26 = r20
            r27 = r5
            r28 = r6
            r22.<init>(r23, r24, r25, r26, r27, r28, r29)     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r12 = r9.A04     // Catch:{ JSONException -> 0x06ef }
            X.15g r12 = r11.A04(r12)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r15 = X.C208415g.A02     // Catch:{ JSONException -> 0x06ef }
            monitor-enter(r15)     // Catch:{ JSONException -> 0x06ef }
            java.util.LinkedHashMap r14 = r12.A00     // Catch:{ all -> 0x06e1 }
            int r12 = r14.size()     // Catch:{ all -> 0x06e1 }
            if (r12 < r8) goto L_0x064b
            java.util.Set r8 = r14.keySet()     // Catch:{ all -> 0x06e1 }
            java.util.Iterator r8 = r8.iterator()     // Catch:{ all -> 0x06e1 }
            java.lang.Object r8 = r8.next()     // Catch:{ all -> 0x06e1 }
            java.lang.Object r8 = r14.remove(r8)     // Catch:{ all -> 0x06e1 }
            X.13K r8 = (X.AnonymousClass13K) r8     // Catch:{ all -> 0x06e1 }
            if (r8 == 0) goto L_0x064b
            X.11e r4 = new X.11e     // Catch:{ all -> 0x06e1 }
            r4.<init>(r8)     // Catch:{ all -> 0x06e1 }
        L_0x064b:
            r14.put(r10, r9)     // Catch:{ all -> 0x06e1 }
            monitor-exit(r15)     // Catch:{ all -> 0x06e1 }
            boolean r8 = r4.A03()     // Catch:{ JSONException -> 0x06ef }
            if (r8 == 0) goto L_0x067c
            java.lang.Object r8 = r4.A02()     // Catch:{ JSONException -> 0x06ef }
            X.13K r8 = (X.AnonymousClass13K) r8     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r14 = r8.A05     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r8 = r4.A02()     // Catch:{ JSONException -> 0x06ef }
            X.13K r8 = (X.AnonymousClass13K) r8     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r12 = r8.A04     // Catch:{ JSONException -> 0x06ef }
            X.0MU r10 = X.AnonymousClass0MU.DATA_EXPIRED     // Catch:{ JSONException -> 0x06ef }
            java.lang.String r8 = "Oldest in non-persistent cache"
            X.11e r9 = new X.11e     // Catch:{ JSONException -> 0x06ef }
            r9.<init>(r8)     // Catch:{ JSONException -> 0x06ef }
            X.11U r8 = new X.11U     // Catch:{ JSONException -> 0x06ef }
            r8.<init>(r10, r9)     // Catch:{ JSONException -> 0x06ef }
            java.lang.Object r4 = r4.A02()     // Catch:{ JSONException -> 0x06ef }
            X.13K r4 = (X.AnonymousClass13K) r4     // Catch:{ JSONException -> 0x06ef }
            r11.A0o(r8, r4, r14, r12)     // Catch:{ JSONException -> 0x06ef }
        L_0x067c:
            r8 = r19
            r4 = r20
            X.11U r8 = X.C12630kx.A00(r2, r8, r1, r4)     // Catch:{ JSONException -> 0x06ef }
            X.0MU r4 = r8.A00     // Catch:{ JSONException -> 0x06ef }
            X.0MU r2 = X.AnonymousClass0MU.DATA_INVALID     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.DATA_EXPIRED     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_INVALID     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_UNSUPPORTED     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_INCOMPATIBLE     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_NOT_INSTALLED     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_DISABLED     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            X.0MU r2 = X.AnonymousClass0MU.PACKAGE_NOT_TRUSTED     // Catch:{ JSONException -> 0x06ef }
            if (r4 == r2) goto L_0x06c8
            boolean r2 = r4.A00()     // Catch:{ JSONException -> 0x06ef }
            if (r2 != 0) goto L_0x050d
            java.lang.Long r2 = java.lang.Long.valueOf(r16)     // Catch:{ JSONException -> 0x06ef }
            X.C05160Pw.A00(r2)     // Catch:{ JSONException -> 0x06ef }
            com.facebook.rti.push.service.FbnsServiceDelegate r1 = r1.A00     // Catch:{ JSONException -> 0x06ef }
            X.10W r9 = r1.A08     // Catch:{ JSONException -> 0x06ef }
            if (r9 == 0) goto L_0x050d
            java.lang.String r1 = "intermittent_fail"
            java.lang.String[] r6 = new java.lang.String[]{r1, r6}     // Catch:{ JSONException -> 0x06ef }
            r1 = 1
            java.lang.String r4 = "notifications"
            r9.A01(r4, r6, r1)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x050d
        L_0x06c8:
            r1.A05(r8, r5, r6)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x050d
        L_0x06cd:
            r1 = move-exception
            X.0MU r2 = r1.mResult     // Catch:{ JSONException -> 0x06ef }
            goto L_0x06d4
        L_0x06d1:
            r1 = move-exception
            X.0MU r2 = X.AnonymousClass0MU.DATA_INVALID     // Catch:{ JSONException -> 0x06ef }
        L_0x06d4:
            java.lang.String r1 = r1.getMessage()     // Catch:{ JSONException -> 0x06ef }
            if (r1 == 0) goto L_0x0508
            X.11e r4 = new X.11e     // Catch:{ JSONException -> 0x06ef }
            r4.<init>(r1)     // Catch:{ JSONException -> 0x06ef }
            goto L_0x0508
        L_0x06e1:
            r0 = move-exception
            monitor-exit(r15)     // Catch:{ all -> 0x06e1 }
            throw r0     // Catch:{ JSONException -> 0x06ef }
        L_0x06e4:
            java.lang.String r0 = "UTF-8 not supported"
            java.lang.RuntimeException r0 = X.AnonymousClass001.A0V(r0)     // Catch:{ JSONException -> 0x06eb }
            throw r0     // Catch:{ JSONException -> 0x06eb }
        L_0x06eb:
            r2 = move-exception
            r18 = 0
            goto L_0x06f0
        L_0x06ef:
            r2 = move-exception
        L_0x06f0:
            java.lang.Object[] r1 = new java.lang.Object[]{r13}
            java.lang.String r0 = "receive/publish/payload_exception; topic=%s"
            X.C14270pR.A0L(r7, r0, r2, r1)
            X.10W r0 = r3.A08
            java.lang.String r1 = "JSON_PARSE_ERROR"
            r0.A00(r1, r13)
            X.0qR r7 = r3.A02
            java.lang.String r0 = "event_type"
            java.lang.String[] r0 = new java.lang.String[]{r0, r1}
            java.util.HashMap r6 = X.C196810r.A01(r0)
            boolean r0 = android.text.TextUtils.isEmpty(r13)
            if (r0 != 0) goto L_0x0717
            java.lang.String r0 = "event_extra_info"
            r6.put(r0, r13)
        L_0x0717:
            java.lang.String r5 = "fbns_service_event"
            java.util.Locale r0 = java.util.Locale.getDefault()
            java.lang.String r4 = r0.toString()
            java.lang.String r2 = android.os.Build.MODEL
            java.lang.String r0 = android.os.Build.MANUFACTURER
            X.10p r1 = new X.10p
            r1.<init>(r5, r4, r2, r0)
            r1.A04(r6)
            X.10q r0 = r7.A01
            r0.DmU(r1)
            X.0mX r2 = r3.A03
            java.lang.String r1 = "Error: invalid payload = "
            r0 = r18
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r1, r0)
            r2.CIO(r0)
        L_0x073f:
            r0 = r41
            android.os.PowerManager$WakeLock r0 = r0.A00     // Catch:{ all -> 0x0748 }
            if (r0 == 0) goto L_0x0748
            X.AnonymousClass0UH.A00(r0)     // Catch:{ all -> 0x0748 }
        L_0x0748:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.rti.push.service.FbnsServiceDelegate.A0g(X.127, java.lang.Long, java.lang.String, byte[], int, long):void");
    }
}
