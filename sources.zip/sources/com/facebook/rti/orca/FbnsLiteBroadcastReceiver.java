package com.facebook.rti.orca;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.AnonymousClass0T5;
import X.AnonymousClass0T6;
import X.AnonymousClass0WY;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import com.facebook.rti.push.service.FbnsServiceDelegate;

public class FbnsLiteBroadcastReceiver extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
        String str;
        String packageName;
        String A05;
        String str2;
        String str3;
        int i;
        int A01 = AnonymousClass0BS.A01(-377315342);
        if (intent == null) {
            i = 1749805353;
        } else {
            Context context2 = context;
            if (AnonymousClass001.A1Y("android.intent.action.USER_PRESENT", intent)) {
                str = "USER_PRESENT";
            } else if (AnonymousClass001.A1Y("android.net.conn.CONNECTIVITY_CHANGE", intent)) {
                NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
                if (networkInfo != null) {
                    String upperCase = networkInfo.getTypeName().toUpperCase();
                    if (networkInfo.isConnected()) {
                        str3 = "-1";
                    } else {
                        str3 = "-0";
                    }
                    str = AnonymousClass0WY.A0i(upperCase, str3);
                } else {
                    str = "NET_NULL";
                }
            } else {
                if (AnonymousClass001.A1Y("com.facebook.rti.mqtt.intent.ACTION_WAKEUP", intent)) {
                    str = "GCM_WAKEUP";
                    packageName = context.getPackageName();
                    A05 = FbnsServiceDelegate.A05(packageName);
                    str2 = "Orca.FORCE_KICK";
                    AnonymousClass0T6.A03(context2, (AnonymousClass0T5) null, A05, str, packageName, str2, false);
                }
                i = 1381417081;
            }
            packageName = context.getPackageName();
            A05 = FbnsServiceDelegate.A05(packageName);
            str2 = "Orca.START";
            AnonymousClass0T6.A03(context2, (AnonymousClass0T5) null, A05, str, packageName, str2, false);
            i = 1381417081;
        }
        AnonymousClass0BS.A0D(i, A01, intent);
    }
}
