package com.facebook.fdidlite;

import X.C03880Jd;
import X.C06130Uw;
import X.C15800sA;
import X.C18260wd;
import X.C18280wf;
import X.C18290wh;
import android.content.Context;
import android.database.MatrixCursor;
import android.net.Uri;
import java.util.HashMap;

public final class FDIDLiteProvider extends C18280wf {
    public final C06130Uw A00;
    public final C06130Uw A01;

    public final MatrixCursor A05(Uri uri, String str) {
        long j;
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{"COL_PHONE_ID", "COL_TIMESTAMP", "COL_ORIGIN"});
        String callingPackage = getCallingPackage();
        Context context = getContext();
        if (!(context == null || callingPackage == null || !C18260wd.A01(context, callingPackage))) {
            try {
                Context context2 = getContext();
                if (context2 == null) {
                    return new MatrixCursor(new String[]{"COL_PHONE_ID", "COL_TIMESTAMP", "COL_ORIGIN"});
                }
                HashMap A002 = C18290wh.A00(context2);
                if (!A002.containsKey("phone_id")) {
                    new MatrixCursor(new String[]{"COL_PHONE_ID", "COL_TIMESTAMP", "COL_ORIGIN"});
                }
                Object obj = A002.get("phone_id");
                if (A002.get("phone_id_ts") == null) {
                    j = 0;
                } else {
                    Long l = (Long) A002.get("phone_id_ts");
                    C15800sA.A0C(l);
                    j = l.longValue();
                }
                Object obj2 = A002.get("origin");
                MatrixCursor matrixCursor2 = new MatrixCursor(new String[]{"COL_PHONE_ID", "COL_TIMESTAMP", "COL_ORIGIN"});
                matrixCursor2.addRow(new String[]{(String) obj, String.valueOf(j), (String) obj2});
                return matrixCursor2;
            } catch (Exception unused) {
            }
        }
        return matrixCursor;
    }

    public FDIDLiteProvider(int i) {
        C03880Jd r0 = C03880Jd.A00;
        this.A00 = r0;
        this.A01 = r0;
    }

    public final C06130Uw A07() {
        return this.A00;
    }

    public final C06130Uw A08() {
        return this.A01;
    }

    public FDIDLiteProvider() {
        this(0);
    }
}
