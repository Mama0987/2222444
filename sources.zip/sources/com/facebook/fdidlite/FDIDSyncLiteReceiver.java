package com.facebook.fdidlite;

import X.AnonymousClass001;
import X.AnonymousClass038;
import X.AnonymousClass0HG;
import X.C05970Uc;
import X.C15800sA;
import X.C18260wd;
import X.C18290wh;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import java.util.HashMap;

public final class FDIDSyncLiteReceiver extends C05970Uc {
    public final void doReceive(Context context, Intent intent, AnonymousClass0HG r11) {
        String creatorPackage;
        long longValue;
        C15800sA.A0E(context, 0, r11);
        Bundle resultExtras = r11.getResultExtras(true);
        AnonymousClass038 r0 = C18260wd.A00;
        C15800sA.A0D(resultExtras, 1);
        PendingIntent pendingIntent = (PendingIntent) resultExtras.getParcelable("auth");
        if (pendingIntent != null && (creatorPackage = pendingIntent.getCreatorPackage()) != null && C18260wd.A01(context, creatorPackage)) {
            HashMap A00 = C18290wh.A00(context);
            String str = (String) A00.get("phone_id");
            if (A00.get("phone_id_ts") == null) {
                longValue = 0;
            } else {
                Number number = (Number) A00.get("phone_id_ts");
                C15800sA.A0C(number);
                longValue = number.longValue();
            }
            Bundle A08 = AnonymousClass001.A08();
            A08.putLong("timestamp", longValue);
            A08.putString("origin", (String) A00.get("origin"));
            if (str != null) {
                r11.setResult(-1, str, A08);
            } else {
                r11.setResult(0, "FDIDSyncLiteReceiver", A08);
            }
        }
    }
}
