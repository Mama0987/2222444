package com.facebook.quicklog;

import X.AnonymousClass03M;
import X.C14270pR;

public class QuickPerformanceLoggerProvider {
    public static QuickPerformanceLogger A00;
    public static final AnonymousClass03M A01 = new Object();

    public static QuickPerformanceLogger getQPLInstance() {
        QuickPerformanceLogger quickPerformanceLogger = A00;
        if (quickPerformanceLogger != null) {
            return quickPerformanceLogger;
        }
        C14270pR.A0I("QPLProvider", "QuickPerformanceLogger instance wasn't installed in provider, returning noop. Please call QuickPerformanceLoggerProvider.setQuickPerformanceLogger() before getting the instance.", new IllegalStateException("No QPL instance provided"));
        return null;
    }

    public static QuickPerformanceLogger A00() {
        QuickPerformanceLogger qPLInstance = getQPLInstance();
        if (qPLInstance == null) {
            return A01;
        }
        return qPLInstance;
    }
}
