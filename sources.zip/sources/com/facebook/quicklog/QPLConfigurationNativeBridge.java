package com.facebook.quicklog;

import X.AnonymousClass0EX;

public class QPLConfigurationNativeBridge {
    public static AnonymousClass0EX mQPLConfiguration;

    public static long[] getMarkerConfigForNativeQPLOnly(int i) {
        long[] jArr = new long[2];
        AnonymousClass0EX r0 = mQPLConfiguration;
        if (r0 != null) {
            long Bg6 = r0.Bg6(i);
            long BRC = mQPLConfiguration.BRC(i);
            jArr[0] = Bg6;
            jArr[1] = BRC;
        }
        return jArr;
    }

    public static void setQPLConfiguration(AnonymousClass0EX r0) {
        mQPLConfiguration = r0;
    }
}
