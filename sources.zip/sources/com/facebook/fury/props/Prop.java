package com.facebook.fury.props;

public interface Prop {
    int key();

    Object value();
}
