package com.facebook.fury.props;

public interface ReqChainProps extends ReadableProps {
}
