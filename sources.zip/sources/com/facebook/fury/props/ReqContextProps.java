package com.facebook.fury.props;

public interface ReqContextProps extends ReadableProps {
}
