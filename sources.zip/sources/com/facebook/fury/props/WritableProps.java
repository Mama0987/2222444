package com.facebook.fury.props;

public interface WritableProps {
    void putBoolean(int i, boolean z);

    void putInt(int i, int i2);

    void putLong(int i, long j);

    @Deprecated
    void putObject(int i, Object obj);

    void putString(int i, String str);
}
