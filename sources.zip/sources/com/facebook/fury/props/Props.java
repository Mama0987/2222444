package com.facebook.fury.props;

public interface Props extends ReadableProps, WritableProps {
}
