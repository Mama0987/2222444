package com.facebook.fury.context;

public interface ThreadIdProvider {
    long getCurrentThreadId();
}
