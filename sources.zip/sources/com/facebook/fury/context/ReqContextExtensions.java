package com.facebook.fury.context;

public interface ReqContextExtensions {
    void onReqContextFailure(ReqContext reqContext, Throwable th);
}
