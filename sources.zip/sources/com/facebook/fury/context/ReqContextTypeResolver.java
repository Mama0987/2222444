package com.facebook.fury.context;

import X.AnonymousClass0F2;

public class ReqContextTypeResolver {
    public static volatile AnonymousClass0F2 sProvider;

    public static int resolveName(String str) {
        if (sProvider != null) {
            switch (str.hashCode()) {
                case -1882332753:
                    if (str.equals("graphservice_native")) {
                        return 10;
                    }
                    break;
                case -1514153744:
                    if (str.equals("react_native_http")) {
                        return 16;
                    }
                    break;
                case -1333328661:
                    if (str.equals("app_choreographer")) {
                        return 5;
                    }
                    break;
                case -1266389914:
                    if (str.equals("fresco")) {
                        return 6;
                    }
                    break;
                case -985638250:
                    if (str.equals("csr_data_loader_handler")) {
                        return 26;
                    }
                    break;
                case -568365225:
                    if (str.equals("conditional_worker")) {
                        return 27;
                    }
                    break;
                case -396208949:
                    if (str.equals("fb_async_task")) {
                        return 23;
                    }
                    break;
                case -146027442:
                    if (!str.equals("handler_background_handler")) {
                        return 0;
                    }
                    return 18;
                case -114195352:
                    if (str.equals("omnistore")) {
                        return 25;
                    }
                    break;
                case -35192912:
                    if (str.equals("tigon_java")) {
                        return 7;
                    }
                    break;
                case -21052727:
                    if (str.equals("nt_async_action_controller")) {
                        return 15;
                    }
                    break;
                case 102983134:
                    if (str.equals("litho")) {
                        return 1;
                    }
                    break;
                case 174662391:
                    if (str.equals("combined_thread_pool")) {
                        return 13;
                    }
                    break;
                case 518502584:
                    if (str.equals("graphql_java")) {
                        return 3;
                    }
                    break;
                case 653818405:
                    if (str.equals("tigon_native")) {
                        return 9;
                    }
                    break;
                case 768185389:
                    if (str.equals("tigon_liger_native")) {
                        return 8;
                    }
                    break;
                case 784970252:
                    if (str.equals("android_thread_utils")) {
                        return 14;
                    }
                    break;
                case 960556259:
                    if (str.equals("geo_location")) {
                        return 17;
                    }
                    break;
                case 1026950114:
                    if (str.equals("blue_service_queue")) {
                        return 22;
                    }
                    break;
                case 1128316993:
                    if (str.equals("fb_app_initializer")) {
                        return 12;
                    }
                    break;
                case 1167542196:
                    if (str.equals("app_jobs")) {
                        return 4;
                    }
                    break;
                case 1205998601:
                    if (str.equals("fresh_feed_network_handler")) {
                        return 19;
                    }
                    break;
                case 1341236641:
                    if (str.equals("ui_components")) {
                        return 20;
                    }
                    break;
                case 1607234021:
                    if (str.equals("data_fetch")) {
                        return 2;
                    }
                    break;
                case 1627468045:
                    if (str.equals("graphservice_jni")) {
                        return 11;
                    }
                    break;
                case 1742353506:
                    if (str.equals("handler_listening_executor_service")) {
                        return 24;
                    }
                    break;
                case 1798256165:
                    if (str.equals("fb4a_activity")) {
                        return 21;
                    }
                    break;
            }
        }
        return 0;
    }

    public static String resolveType(int i) {
        if (sProvider == null) {
            return null;
        }
        switch (i) {
            case 1:
                return "litho";
            case 2:
                return "data_fetch";
            case 3:
                return "graphql_java";
            case 4:
                return "app_jobs";
            case 5:
                return "app_choreographer";
            case 6:
                return "fresco";
            case 7:
                return "tigon_java";
            case 8:
                return "tigon_liger_native";
            case 9:
                return "tigon_native";
            case 10:
                return "graphservice_native";
            case 11:
                return "graphservice_jni";
            case 12:
                return "fb_app_initializer";
            case 13:
                return "combined_thread_pool";
            case 14:
                return "android_thread_utils";
            case 15:
                return "nt_async_action_controller";
            case 16:
                return "react_native_http";
            case 17:
                return "geo_location";
            case 18:
                return "handler_background_handler";
            case 19:
                return "fresh_feed_network_handler";
            case 20:
                return "ui_components";
            case 21:
                return "fb4a_activity";
            case 22:
                return "blue_service_queue";
            case 23:
                return "fb_async_task";
            case 24:
                return "handler_listening_executor_service";
            case 25:
                return "omnistore";
            case 26:
                return "csr_data_loader_handler";
            case 27:
                return "conditional_worker";
            default:
                return "";
        }
    }

    public static void setProvider(AnonymousClass0F2 r0) {
        sProvider = r0;
    }
}
