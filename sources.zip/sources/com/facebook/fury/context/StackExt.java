package com.facebook.fury.context;

public interface StackExt {
    int currentCapacity();

    boolean isEmpty();

    Object peek();

    Object pop();

    void push(Object obj);

    int size();
}
