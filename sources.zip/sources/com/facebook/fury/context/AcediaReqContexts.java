package com.facebook.fury.context;

import X.AnonymousClass002;
import X.AnonymousClass0Ip;
import X.AnonymousClass0PB;
import X.C18300wm;
import X.C18310wn;
import X.C18320wp;
import X.C18330wq;
import X.C18340wr;
import X.C18400x1;
import X.C18440x7;
import X.C18510xF;
import com.facebook.fury.props.ReadableProps;
import com.facebook.fury.props.ReqChainProps;
import com.facebook.fury.props.ReqContextProps;
import com.facebook.fury.props.ReqPropsProvider;
import com.facebook.fury.props.WritableProps;
import com.facebook.jni.HybridData;
import java.util.LinkedList;

public class AcediaReqContexts implements ReqContextsPlugin, WritableProps {
    public static final int NOT_SET = -1;
    public final ThreadLocal mActiveContexts = new ThreadLocal();
    public final ReqContextsCallbacks mCallbacks;
    public final C18320wp mFromReqContextReader = new C18320wp(this);
    public final C18330wq mGlobalPropsReader = new C18330wq(this, 0);
    public final HybridData mHybridData;
    public final C18330wq mLocalPropsReader = new C18330wq(this, 1);
    public final C18340wr mSequenceIdGenerator = new ThreadLocal();

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0007, code lost:
        r0 = r3.mCallbacks.provideReqPropsProvider();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean canEnhanceCurrentScope(int r4, int r5) {
        /*
            r3 = this;
            r2 = 1
            com.facebook.fury.context.AcediaReqContext r1 = r3.getActiveInternal(r2)
            if (r1 == 0) goto L_0x0015
            com.facebook.fury.context.ReqContextsCallbacks r0 = r3.mCallbacks
            com.facebook.fury.props.ReqPropsProvider r0 = r0.provideReqPropsProvider()
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.canEnhanceCurrentScope(r1, r4, r5)
            if (r0 == 0) goto L_0x0016
        L_0x0015:
            return r2
        L_0x0016:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.fury.context.AcediaReqContexts.canEnhanceCurrentScope(int, int):boolean");
    }

    private C18300wm createReqContextNode(AcediaReqContext acediaReqContext, String str, int i, int i2) {
        ReadableProps reqChainProps;
        long currentTid;
        int currentSeqId;
        long currentThreadId = this.mCallbacks.getCurrentThreadId();
        C18340wr r1 = this.mSequenceIdGenerator;
        int A05 = AnonymousClass002.A05(r1) + 1;
        r1.set(Integer.valueOf(A05));
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        int i3 = i;
        int i4 = i2;
        if (acediaReqContext == null) {
            reqChainProps = createChainProps(provideReqPropsProvider, i3, i4);
        } else {
            reqChainProps = acediaReqContext.getReqChainProps();
        }
        ReqContextProps createContextProps = createContextProps(provideReqPropsProvider, acediaReqContext, i3, i4);
        if (acediaReqContext == null) {
            currentTid = -1;
            currentSeqId = -1;
        } else {
            currentTid = acediaReqContext.getCurrentTid();
            currentSeqId = acediaReqContext.getCurrentSeqId();
        }
        return new C18300wm(this, reqChainProps, createContextProps, str, currentSeqId, A05, i3, i4, currentTid, currentThreadId);
    }

    private int getFlags() {
        AcediaReqContext activeInternal = getActiveInternal(false);
        if (activeInternal == null || activeInternal.isPlaceholder()) {
            return -1;
        }
        return activeInternal.getFlags();
    }

    private int getParentSeqId() {
        AcediaReqContext activeInternal = getActiveInternal(false);
        if (activeInternal == null || activeInternal.isPlaceholder()) {
            return -1;
        }
        return activeInternal.getParentSeqId();
    }

    private long getParentTid() {
        AcediaReqContext activeInternal = getActiveInternal(false);
        if (activeInternal == null || activeInternal.isPlaceholder()) {
            return -1;
        }
        return activeInternal.getParentTid();
    }

    private String getTag() {
        AcediaReqContext activeInternal = getActiveInternal(false);
        if (activeInternal == null || activeInternal.isPlaceholder()) {
            return "";
        }
        return activeInternal.getTag();
    }

    private int getType() {
        AcediaReqContext activeInternal = getActiveInternal(false);
        if (activeInternal == null || activeInternal.isPlaceholder()) {
            return -1;
        }
        return activeInternal.getType();
    }

    public static native HybridData initHybrid(AcediaReqContexts acediaReqContexts, ReqContextsCallbacks reqContextsCallbacks);

    private C18300wm materializePlaceholder() {
        String nativeGetTag = nativeGetTag();
        long nativeGetParentTid = nativeGetParentTid();
        int nativeGetParentSeqId = nativeGetParentSeqId();
        long currentThreadId = this.mCallbacks.getCurrentThreadId();
        return new C18300wm(this, materializeProps(this.mGlobalPropsReader), materializeProps(this.mLocalPropsReader), nativeGetTag, nativeGetParentSeqId, AnonymousClass002.A05(this.mSequenceIdGenerator), nativeGetFlags(), nativeGetType(), nativeGetParentTid, currentThreadId);
    }

    /* access modifiers changed from: private */
    public native boolean nativeFromReqContextBooleanProp(int i, boolean z, int i2);

    /* access modifiers changed from: private */
    public native int nativeFromReqContextCurrentSeqId();

    /* access modifiers changed from: private */
    public native long nativeFromReqContextCurrentTid();

    /* access modifiers changed from: private */
    public native boolean nativeFromReqContextFlagOn(int i);

    /* access modifiers changed from: private */
    public native String nativeFromReqContextGetTag();

    /* access modifiers changed from: private */
    public native boolean nativeFromReqContextHasParent();

    /* access modifiers changed from: private */
    public native int nativeFromReqContextIntProp(int i, int i2, int i3);

    /* access modifiers changed from: private */
    public native long nativeFromReqContextLongProp(int i, long j, int i2);

    /* access modifiers changed from: private */
    public native int nativeFromReqContextParentSeqId();

    /* access modifiers changed from: private */
    public native long nativeFromReqContextParentTid();

    /* access modifiers changed from: private */
    public native String nativeFromReqContextStringProp(int i, int i2);

    /* access modifiers changed from: private */
    public native int nativeFromReqContextType();

    /* access modifiers changed from: private */
    public native boolean nativeGetBooleanProp(int i, boolean z, int i2);

    private native int nativeGetFlags();

    /* access modifiers changed from: private */
    public native int nativeGetIntProp(int i, int i2, int i3);

    /* access modifiers changed from: private */
    public native long nativeGetLongProp(int i, long j, int i2);

    private native int nativeGetParentSeqId();

    private native long nativeGetParentTid();

    /* access modifiers changed from: private */
    public native int nativeGetPropCount(int i);

    /* access modifiers changed from: private */
    public native String nativeGetStringProp(int i, int i2);

    private native String nativeGetTag();

    private native int nativeGetType();

    private native void nativePopReqContext();

    private native void nativePushPlaceholder();

    private native void nativePutBooleanProp(int i, boolean z);

    private native void nativePutIntProp(int i, int i2);

    private native void nativePutLongProp(int i, long j);

    private native void nativePutStringProp(int i, String str);

    private native void nativeReset();

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0007, code lost:
        r0 = r3.mCallbacks.provideReqPropsProvider();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean shouldFillReqContextProps(int r4, int r5) {
        /*
            r3 = this;
            r2 = 1
            com.facebook.fury.context.AcediaReqContext r1 = r3.getActiveInternal(r2)
            if (r1 == 0) goto L_0x0015
            com.facebook.fury.context.ReqContextsCallbacks r0 = r3.mCallbacks
            com.facebook.fury.props.ReqPropsProvider r0 = r0.provideReqPropsProvider()
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.shouldFillReqContextProps(r1, r4, r5)
            if (r0 == 0) goto L_0x0016
        L_0x0015:
            return r2
        L_0x0016:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.fury.context.AcediaReqContexts.shouldFillReqContextProps(int, int):boolean");
    }

    public AcediaReqContext create(String str, int i, C18510xF r11) {
        AcediaReqContext activeInternal = getActiveInternal(true);
        String str2 = str;
        int i2 = i;
        if (activeInternal != null) {
            return continueReqContext(activeInternal, str2, 3, i2, r11);
        }
        C18300wm createReqContextNode = createReqContextNode((AcediaReqContext) null, str, 3, i);
        onActivate(createReqContextNode);
        return createReqContextNode;
    }

    public void deactivate(AcediaReqContext acediaReqContext) {
        if (acediaReqContext.equals(getActiveInternal(false))) {
            nativePopReqContext();
            onDeactivate();
        }
    }

    public AcediaReqContext getActive() {
        return getActiveInternal(true);
    }

    static {
        C18440x7.loadLibrary("fury");
    }

    private void copyProps(int i) {
        AcediaReqContext activeInternal;
        ReadableProps reqChainProps;
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        if (provideReqPropsProvider != null && (activeInternal = getActiveInternal(false)) != null) {
            if (i == 0) {
                reqChainProps = activeInternal.getReqChainProps();
            } else if (i == 1) {
                reqChainProps = activeInternal.getReqContextProps();
            } else {
                return;
            }
            provideReqPropsProvider.copyProps(reqChainProps, this);
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [X.0PB, com.facebook.fury.props.WritableProps, com.facebook.fury.props.ReqChainProps] */
    public static ReqChainProps createChainProps(ReqPropsProvider reqPropsProvider, int i, int i2) {
        if (reqPropsProvider == null || !reqPropsProvider.shouldFillReqChainProps(i, i2)) {
            return AnonymousClass0Ip.A00;
        }
        ? r0 = new AnonymousClass0PB();
        reqPropsProvider.fillReqChainProps(r0, i, i2);
        return r0;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [X.0PB, com.facebook.fury.props.WritableProps, com.facebook.fury.props.ReqContextProps] */
    public static ReqContextProps createContextProps(ReqPropsProvider reqPropsProvider, ReqContext reqContext, int i, int i2) {
        if (reqPropsProvider == null || !reqPropsProvider.shouldFillReqContextProps(reqContext, i, i2)) {
            return C18400x1.A00;
        }
        ? r0 = new AnonymousClass0PB();
        reqPropsProvider.fillReqContextProps(r0, reqContext, i, i2);
        return r0;
    }

    private void fillReqChainProps(int i, int i2) {
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        if (provideReqPropsProvider != null) {
            provideReqPropsProvider.fillReqChainProps(this, i, i2);
        }
    }

    private void fillReqContextProps(int i, int i2) {
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        if (provideReqPropsProvider != null) {
            provideReqPropsProvider.fillReqContextProps(this, this.mFromReqContextReader, i, i2);
        }
    }

    private AcediaReqContext getActiveInternal(boolean z) {
        AcediaReqContext acediaReqContext;
        LinkedList linkedList = (LinkedList) this.mActiveContexts.get();
        if (linkedList == null || (acediaReqContext = (AcediaReqContext) linkedList.peekFirst()) == null) {
            return null;
        }
        if (!z || !acediaReqContext.isPlaceholder()) {
            return acediaReqContext;
        }
        C18300wm materializePlaceholder = materializePlaceholder();
        linkedList.pollFirst();
        linkedList.push(materializePlaceholder);
        return materializePlaceholder;
    }

    private LinkedList getOrCreateReqContextsStack() {
        LinkedList linkedList = (LinkedList) this.mActiveContexts.get();
        if (linkedList != null) {
            return linkedList;
        }
        LinkedList linkedList2 = new LinkedList();
        this.mActiveContexts.set(linkedList2);
        return linkedList2;
    }

    private ReadableProps materializeProps(C18330wq r3) {
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        if (provideReqPropsProvider == null || r3.isEmpty()) {
            return C18400x1.A00;
        }
        AnonymousClass0PB r0 = new AnonymousClass0PB();
        provideReqPropsProvider.copyProps(r3, r0);
        return r0;
    }

    private void onDeactivate() {
        AcediaReqContext acediaReqContext;
        ReqContextLifecycleCallbacks provideLifecycleCallbacks;
        LinkedList linkedList = (LinkedList) this.mActiveContexts.get();
        if (linkedList != null && (acediaReqContext = (AcediaReqContext) linkedList.pollFirst()) != null && !acediaReqContext.isPlaceholder() && (provideLifecycleCallbacks = this.mCallbacks.provideLifecycleCallbacks()) != null) {
            provideLifecycleCallbacks.onDeactivate(acediaReqContext);
        }
    }

    private void pushPlaceHolder() {
        C18340wr r1 = this.mSequenceIdGenerator;
        r1.set(Integer.valueOf(AnonymousClass002.A05(r1) + 1));
        onActivate(C18310wn.A00);
    }

    private boolean shouldActivateSameContext(AcediaReqContext acediaReqContext, int i, int i2, C18510xF r6) {
        ReqPropsProvider provideReqPropsProvider;
        if (r6 != C18510xF.COARSE || (provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider()) == null || provideReqPropsProvider.canEnhanceCurrentScope(acediaReqContext, i, i2)) {
            return false;
        }
        return true;
    }

    private boolean shouldFillReqChainProps(int i, int i2) {
        ReqPropsProvider provideReqPropsProvider = this.mCallbacks.provideReqPropsProvider();
        if (provideReqPropsProvider == null || !provideReqPropsProvider.shouldFillReqChainProps(i, i2)) {
            return false;
        }
        return true;
    }

    public void fail(AcediaReqContext acediaReqContext, Throwable th) {
        ReqContextExtensions provideReqContextExtensions = this.mCallbacks.provideReqContextExtensions();
        if (provideReqContextExtensions != null) {
            provideReqContextExtensions.onReqContextFailure(acediaReqContext, th);
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.ThreadLocal, X.0wr] */
    public AcediaReqContexts(ReqContextsCallbacks reqContextsCallbacks) {
        this.mCallbacks = reqContextsCallbacks;
        this.mHybridData = initHybrid(this, reqContextsCallbacks);
    }

    private void onActivate(AcediaReqContext acediaReqContext) {
        AcediaReqContext activeInternal;
        getOrCreateReqContextsStack().push(acediaReqContext);
        if (!acediaReqContext.isPlaceholder()) {
            nativePushPlaceholder();
        }
        ReqContextLifecycleCallbacks provideLifecycleCallbacks = this.mCallbacks.provideLifecycleCallbacks();
        if (provideLifecycleCallbacks != null) {
            C18510xF Brp = provideLifecycleCallbacks.Brp();
            if ((!acediaReqContext.isPlaceholder() || Brp != C18510xF.NONE) && (activeInternal = getActiveInternal(true)) != null) {
                provideLifecycleCallbacks.onActivate(activeInternal);
            }
        }
    }

    private void popReqContext() {
        onDeactivate();
    }

    public AcediaReqContext continueReqContext(AcediaReqContext acediaReqContext, String str, int i, int i2, C18510xF r7) {
        if (shouldActivateSameContext(acediaReqContext, i, i2, r7)) {
            C18340wr r1 = this.mSequenceIdGenerator;
            r1.set(Integer.valueOf(AnonymousClass002.A05(r1) + 1));
        } else {
            acediaReqContext = createReqContextNode(acediaReqContext, str, i, i2);
        }
        onActivate(acediaReqContext);
        return acediaReqContext;
    }

    public void reset() {
        nativeReset();
    }

    public boolean accepts(ReqContext reqContext) {
        return reqContext instanceof AcediaReqContext;
    }

    public void putBoolean(int i, boolean z) {
        nativePutBooleanProp(i, z);
    }

    public void putInt(int i, int i2) {
        nativePutIntProp(i, i2);
    }

    public void putLong(int i, long j) {
        nativePutLongProp(i, j);
    }

    public void putObject(int i, Object obj) {
    }

    public void putString(int i, String str) {
        nativePutStringProp(i, str);
    }
}
