package com.facebook.fury.context;

import X.C18510xF;

public interface ReqContextsPlugin {
    boolean accepts(ReqContext reqContext);

    ReqContext continueReqContext(ReqContext reqContext, String str, int i, int i2, C18510xF r5);

    ReqContext create(String str, int i, C18510xF r3);

    void deactivate(ReqContext reqContext);

    void fail(ReqContext reqContext, Throwable th);

    ReqContext getActive();

    void reset();
}
