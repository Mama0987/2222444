package com.facebook.fury.context;

public interface EventQueueReqContextLifecycle$TimeProvider {
    long currentTime();
}
