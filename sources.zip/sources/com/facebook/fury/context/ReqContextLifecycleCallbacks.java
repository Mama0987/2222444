package com.facebook.fury.context;

import X.AnonymousClass0HA;

public interface ReqContextLifecycleCallbacks extends AnonymousClass0HA {
    void onActivate(ReqContext reqContext);

    void onDeactivate(ReqContext reqContext);
}
