package com.facebook.fury.context;

public interface ReqContextLog {
    void d(String str, String str2);

    void w(String str, String str2);
}
