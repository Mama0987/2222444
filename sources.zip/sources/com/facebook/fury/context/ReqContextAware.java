package com.facebook.fury.context;

public interface ReqContextAware {
    void contextCleanup();

    void contextPrepare();
}
