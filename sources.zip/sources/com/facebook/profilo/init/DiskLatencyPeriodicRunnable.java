package com.facebook.profilo.init;

import X.AnonymousClass001;
import X.C001901d;
import android.util.Log;
import com.facebook.jni.HybridData;
import com.facebook.profilo.logger.MultiBufferLogger;
import java.io.IOException;

public class DiskLatencyPeriodicRunnable implements Runnable {
    public String LOG_TAG;
    public HybridData mHybridData;
    public String mTestFilePath;

    public static native HybridData initHybrid(MultiBufferLogger multiBufferLogger);

    public native void logDiskLatency(String str);

    public void run() {
        try {
            String str = this.mTestFilePath;
            if (str == null) {
                str = AnonymousClass001.A0D(C001901d.A00().A03.A06, "disk_latency_test.bin").getCanonicalPath();
                this.mTestFilePath = str;
            }
            logDiskLatency(str);
        } catch (IOException e) {
            Log.e("DiskLatencyPeriodicRunnable", "failed to logDiskLatency", e);
        }
    }
}
