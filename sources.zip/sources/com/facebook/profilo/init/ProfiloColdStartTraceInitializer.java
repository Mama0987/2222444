package com.facebook.profilo.init;

import X.AnonymousClass01A;
import X.AnonymousClass01G;
import X.AnonymousClass01I;
import X.AnonymousClass01L;
import X.AnonymousClass01O;
import X.AnonymousClass01P;
import X.AnonymousClass01h;
import X.AnonymousClass01q;
import X.AnonymousClass01s;
import X.AnonymousClass0DE;
import X.AnonymousClass0DG;
import X.AnonymousClass0DQ;
import X.AnonymousClass0DU;
import X.AnonymousClass0DW;
import X.AnonymousClass0DX;
import X.AnonymousClass0DZ;
import X.C001901d;
import X.C002401r;
import X.C02660Da;
import X.C02730Di;
import X.C03430Gx;
import X.C12670l1;
import X.C14840qS;
import X.C14870qV;
import X.C19180z7;
import X.C19550zy;
import android.content.Context;
import android.util.SparseArray;
import com.facebook.profilo.logger.api.ProfiloLogger;
import com.facebook.profilo.provider.device_info.DeviceInfoProvider;
import com.facebook.profilo.provider.qpl.QplEventsProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class ProfiloColdStartTraceInitializer {
    public static void maybeTraceColdStart(Context context) {
        maybeTraceColdStartWithArgs(context, (C02730Di) null, (AnonymousClass01I) null);
    }

    public static void maybeTraceColdStartWithArgs(Context context, C02730Di r13, AnonymousClass01I r14) {
        C02730Di r0;
        AnonymousClass01I r8 = r14;
        SparseArray sparseArray = new SparseArray(5);
        sparseArray.put(AnonymousClass0DU.A00, AnonymousClass0DU.A00());
        sparseArray.put(AnonymousClass0DW.A01, new AnonymousClass0DW());
        sparseArray.put(AnonymousClass0DX.A01, new AnonymousClass0DX());
        Context context2 = context;
        C12670l1 A00 = AnonymousClass0DZ.A00(context);
        sparseArray.put(C02660Da.A00, new AnonymousClass0DE());
        C19180z7[] A02 = A02(context);
        if (r14 == null) {
            r8 = new AnonymousClass01I(context);
        }
        if (!A00.A01()) {
            AnonymousClass01O.A02();
        }
        r8.A03();
        QplEventsProvider qplEventsProvider = QplEventsProvider.get();
        if (AnonymousClass0DZ.A00(context).A02()) {
            qplEventsProvider.enableNativeQPLTracing();
        }
        if (A00.A03()) {
            r0 = AnonymousClass01L.A00(C14840qS.A00());
        } else {
            r0 = null;
        }
        ArrayList arrayList = new ArrayList();
        if (r0 != null) {
            arrayList.add(r0);
        }
        if (r13 != null) {
            arrayList.add(r13);
        }
        if (AnonymousClass01O.A03()) {
            arrayList.add(new C19550zy());
        }
        AnonymousClass01P.A00(context2, sparseArray, r8, "main", A02, (C02730Di[]) arrayList.toArray(new C02730Di[arrayList.size()]), true);
        AnonymousClass01h A002 = AnonymousClass01h.A00();
        if (AnonymousClass0DZ.A00(context2).A04() && A002 != null) {
            A002.A0A();
        }
        if (AnonymousClass01O.A03()) {
            C03430Gx A07 = C001901d.A00().A07();
            Iterator it = C002401r.A03().iterator();
            while (it.hasNext()) {
                long longValue = ((Long) it.next()).longValue();
                C02660Da A01 = C002401r.A01();
                if (A01 != null) {
                    AnonymousClass01O.A00().A02(A01.AFK(longValue), Integer.valueOf(A01.Bg4(A07, longValue)), Long.valueOf(A07.getID()), "ProfiloColdStartTraceInitializer", "maybeTraceColdStartWithArgs(); Blackbox context = %s, Sampling rate = %d, cfg_id = %d");
                }
            }
        }
        ProfiloLogger.A00 = true;
        ProfiloLogger.installClassLoadTracer();
        AnonymousClass01q.A00();
        C002401r.A06();
        AnonymousClass0DQ.A01();
        C14870qV.A00().A01(new AnonymousClass01s());
        A00();
        A01();
        AnonymousClass01h A003 = AnonymousClass01h.A00();
        if (A003 != null) {
            A003.A0D((long) r8.A02(), AnonymousClass0DX.A01, 0);
        }
    }

    public static void A00() {
    }

    public static void A01() {
    }

    public static C19180z7[] A02(Context context) {
        C19180z7[] A00 = AnonymousClass0DG.A00(context);
        C19180z7[] r4 = (C19180z7[]) Arrays.copyOf(A00, A00.length + 5);
        int length = r4.length;
        r4[length - 5] = new C19180z7((String) null, (Runnable) null);
        r4[length - 4] = new DeviceInfoProvider(context);
        r4[length - 3] = new AnonymousClass01A(context);
        r4[length - 2] = AnonymousClass01G.A01;
        r4[length - 1] = QplEventsProvider.sInstance;
        return r4;
    }

    public static void maybeAbortExistingColdStartTrace(int i) {
        AnonymousClass01h A00 = AnonymousClass01h.A00();
        if (A00 != null) {
            A00.A0C((Object) null, (long) i, AnonymousClass0DX.A01);
        }
    }
}
