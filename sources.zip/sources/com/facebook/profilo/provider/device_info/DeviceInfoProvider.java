package com.facebook.profilo.provider.device_info;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0E1;
import X.AnonymousClass0WY;
import X.C013007f;
import X.C013107g;
import X.C03450Gz;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.BufferLogger;
import com.facebook.profilo.mmapbuf.core.Buffer;

public final class DeviceInfoProvider extends AnonymousClass0E1 {
    public final Context A00;

    public DeviceInfoProvider(Context context) {
        super((String) null, (Runnable) null);
        Context applicationContext = context.getApplicationContext();
        if (applicationContext != null || !(context instanceof Application)) {
            this.A00 = applicationContext;
        } else {
            this.A00 = context;
        }
    }

    static {
        ProvidersRegistry.A00.A02("device_info");
    }

    public final void logOnTraceEnd(TraceContext traceContext, C03450Gz r16) {
        long j;
        Buffer buffer = traceContext.A09;
        AnonymousClass002.A0f(buffer, "os_ver", Build.VERSION.RELEASE, 8126483);
        AnonymousClass002.A0f(buffer, "device_type", Build.MODEL, 8126478);
        AnonymousClass002.A0f(buffer, "brand", Build.BRAND, 8126479);
        AnonymousClass002.A0f(buffer, "manufacturer", Build.MANUFACTURER, 8126480);
        Context context = this.A00;
        AnonymousClass002.A0f(buffer, "year_class", Integer.toString(C013007f.A00(context)), 8126481);
        AnonymousClass002.A0f(buffer, "os_sdk", Integer.toString(Build.VERSION.SDK_INT), 8126537);
        BufferLogger.writeStandardEntry(buffer, 6, 52, 0, 0, 8126503, 0, (long) C013107g.A00());
        BufferLogger.writeStandardEntry(buffer, 6, 52, 0, 0, 8126502, 0, C013107g.A03(context));
        try {
            AnonymousClass002.A0f(buffer, "Kernel version", System.getProperty("os.version", "undefined"), 8126527);
        } catch (SecurityException e) {
            Log.w("Profilo/DeviceInfo", AnonymousClass0WY.A1Q("SecurityException: ", e));
        }
        if (AnonymousClass001.A1X("/proc/sys/kernel/perf_event_paranoid")) {
            j = 1;
        } else {
            j = 0;
        }
        BufferLogger.writeStandardEntry(buffer, 6, 52, 0, 0, 8126490, 0, j);
    }
}
