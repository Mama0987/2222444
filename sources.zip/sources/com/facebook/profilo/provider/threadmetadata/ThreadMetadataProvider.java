package com.facebook.profilo.provider.threadmetadata;

import X.AnonymousClass00T;
import X.AnonymousClass0E1;
import X.C03450Gz;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.mmapbuf.core.Buffer;

public final class ThreadMetadataProvider extends AnonymousClass0E1 {
    public static native void nativeLogThreadMetadata(Buffer buffer);

    public ThreadMetadataProvider() {
        super("profilo_threadmetadata", new AnonymousClass00T());
    }

    public void logOnTraceEnd(TraceContext traceContext, C03450Gz r3) {
        nativeLogThreadMetadata(traceContext.A09);
    }
}
