package com.facebook.profilo.provider.constants;

import X.AnonymousClass0BS;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.logger.MultiBufferLogger;

public class ExternalProvider extends C19180z7 {
    public MultiBufferLoggerLike A00;
    public final int A01;
    public final String A02;
    public volatile int A03 = 0;
    public volatile boolean A04 = false;
    public volatile int A05;

    public final class MultiBufferLoggerLike {
        public int A00;
        public MultiBufferLogger A01;
        public boolean A02;

        public final int A01(int i, int i2, int i3, long j, int i4) {
            return A00(0, i, i2, i3, i4, j);
        }

        /* JADX WARNING: Removed duplicated region for block: B:23:0x0071  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final int A00(int r19, int r20, int r21, int r22, int r23, long r24) {
            /*
                r18 = this;
                r11 = 0
                r13 = 0
                r4 = 0
                r6 = 0
                r7 = 0
                r5 = r18
                com.facebook.profilo.logger.MultiBufferLogger r8 = r5.A01
                if (r8 != 0) goto L_0x000d
                return r13
            L_0x000d:
                boolean r0 = r5.A02
                if (r0 == 0) goto L_0x005e
                int r0 = r5.A00
                r0 = r0 & r19
                if (r0 == 0) goto L_0x005e
                int r2 = android.os.Process.myTid()
                java.lang.String r1 = "/proc/self/task/"
                java.lang.String r0 = "/stat"
                java.lang.String r0 = X.AnonymousClass0WY.A0t(r1, r0, r2)
                java.io.FileReader r1 = new java.io.FileReader     // Catch:{ IOException -> 0x0060 }
                r1.<init>(r0)     // Catch:{ IOException -> 0x0060 }
                java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0060 }
                r0.<init>(r1)     // Catch:{ IOException -> 0x0060 }
                java.lang.String r1 = r0.readLine()     // Catch:{ IOException -> 0x0060 }
                if (r1 == 0) goto L_0x0060
                r0 = 41
                int r0 = r1.indexOf(r0)     // Catch:{ IOException -> 0x0060 }
                if (r0 < 0) goto L_0x005e
                int r0 = r0 + 2
                java.lang.String r1 = r1.substring(r0)     // Catch:{ IOException -> 0x0060 }
                java.lang.String r0 = " "
                java.lang.String[] r3 = r1.split(r0)     // Catch:{ IOException -> 0x0060 }
                if (r3 == 0) goto L_0x0060
                int r1 = r3.length     // Catch:{ IOException -> 0x0060 }
                r0 = 17
                if (r1 < r0) goto L_0x0060
                r0 = 11
                r2 = r3[r0]     // Catch:{ IOException -> 0x0060 }
                r0 = 12
                r1 = r3[r0]     // Catch:{ IOException -> 0x0060 }
                r0 = 16
                r4 = r3[r0]     // Catch:{ IOException -> 0x0060 }
                r7 = r2
                r6 = r1
                r0 = 1
                goto L_0x0061
            L_0x005e:
                r0 = 0
                goto L_0x0061
            L_0x0060:
                r0 = 0
            L_0x0061:
                r9 = r20
                r10 = r21
                r14 = r22
                r15 = r23
                r16 = r24
                int r3 = r8.writeStandardEntry(r9, r10, r11, r13, r14, r15, r16)
                if (r0 == 0) goto L_0x0096
                java.lang.String r0 = "utm"
                r2 = 56
                int r0 = r5.A02(r13, r2, r3, r0)
                r1 = 57
                if (r0 == 0) goto L_0x0080
                r5.A02(r13, r1, r0, r7)
            L_0x0080:
                java.lang.String r0 = "stm"
                int r0 = r5.A02(r13, r2, r3, r0)
                if (r0 == 0) goto L_0x008b
                r5.A02(r13, r1, r0, r6)
            L_0x008b:
                java.lang.String r0 = "nice"
                int r0 = r5.A02(r13, r2, r3, r0)
                if (r0 == 0) goto L_0x0096
                r5.A02(r13, r1, r0, r4)
            L_0x0096:
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.constants.ExternalProvider.MultiBufferLoggerLike.A00(int, int, int, int, int, long):int");
        }

        public final int A02(int i, int i2, int i3, String str) {
            MultiBufferLogger multiBufferLogger = this.A01;
            if (multiBufferLogger == null) {
                return 0;
            }
            return multiBufferLogger.writeBytesEntry(i, i2, i3, str);
        }
    }

    public ExternalProvider(String str) {
        super((String) null, (Runnable) null);
        this.A01 = ProvidersRegistry.A00.A02(str);
        this.A02 = str;
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [com.facebook.profilo.provider.constants.ExternalProvider$MultiBufferLoggerLike, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v6, types: [com.facebook.profilo.provider.constants.ExternalProvider$MultiBufferLoggerLike, java.lang.Object] */
    public final MultiBufferLoggerLike A00() {
        if (this.A05 != 2) {
            if (this.mLoggerInitialized) {
                MultiBufferLogger logger = getLogger();
                boolean z = this.A04;
                int i = this.A03;
                ? obj = new Object();
                obj.A01 = logger;
                obj.A02 = z;
                obj.A00 = i;
                this.A00 = obj;
                this.A05 = 2;
            } else if (this.A05 == 0) {
                ? obj2 = new Object();
                obj2.A01 = null;
                obj2.A02 = false;
                obj2.A00 = 0;
                this.A00 = obj2;
                this.A05 = 1;
            }
        }
        return this.A00;
    }

    public final int getTracingProviders() {
        return this.A01 & TraceEvents.sProviders;
    }

    public final void disable() {
        AnonymousClass0BS.A09(1916978890, AnonymousClass0BS.A03(1185053069));
    }

    public void enable() {
        AnonymousClass0BS.A09(863822343, AnonymousClass0BS.A03(-1882151981));
    }

    public final int getSupportedProviders() {
        return this.A01;
    }

    public final boolean requiresSynchronousCallbacks() {
        return true;
    }
}
