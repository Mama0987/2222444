package com.facebook.profilo.provider.mappings;

import X.AnonymousClass00p;
import X.AnonymousClass0BS;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class MemoryMappingsProvider extends C19180z7 {
    public static final int PROVIDER_MAPPINGS = ProvidersRegistry.A00.A02("memory_mappings");

    public static native void nativeLogMappings(MultiBufferLogger multiBufferLogger);

    public MemoryMappingsProvider() {
        super("profilo_mappings", new AnonymousClass00p());
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(-885041157);
        nativeLogMappings(getLogger());
        AnonymousClass0BS.A09(2064528385, A03);
    }

    public void enable() {
        AnonymousClass0BS.A09(-704850538, AnonymousClass0BS.A03(-1170798414));
    }

    public int getSupportedProviders() {
        return PROVIDER_MAPPINGS;
    }

    public int getTracingProviders() {
        return PROVIDER_MAPPINGS;
    }
}
