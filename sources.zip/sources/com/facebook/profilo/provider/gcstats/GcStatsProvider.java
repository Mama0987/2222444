package com.facebook.profilo.provider.gcstats;

import X.AnonymousClass015;
import X.AnonymousClass0BS;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.logger.MultiBufferLogger;

public class GcStatsProvider extends C19180z7 {
    public static final int PROVIDER_GC_STATS = ProvidersRegistry.A00.A02("gc_stats");

    public static native void nativeAddDummySystemWeakHolder();

    public static native boolean nativeInitializeProfiling(boolean z);

    public static native int nativeStartProfiling(MultiBufferLogger multiBufferLogger, boolean z, boolean z2, boolean z3, boolean z4);

    public static native void nativeStopProfiling();

    public synchronized int getTracingProviders() {
        int i;
        i = PROVIDER_GC_STATS;
        if (!TraceEvents.isEnabled(i)) {
            i = 0;
        }
        return i;
    }

    public GcStatsProvider() {
        super("profilo_gcstats", new AnonymousClass015());
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(-1765197055);
        nativeStopProfiling();
        AnonymousClass0BS.A09(349173398, A03);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0029, code lost:
        r3 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0032, code lost:
        if (r7.A08.A02("provider.gc_stats.add_dummy_system_weak_holder", false) != false) goto L_0x0037;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0034, code lost:
        r3 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0035, code lost:
        if (r7 == null) goto L_0x0042;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0037, code lost:
        r1 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0040, code lost:
        if (r7.A08.A02("provider.gc_stats.use_long_suspend", false) != false) goto L_0x0043;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0042, code lost:
        r1 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0045, code lost:
        if (r6 == false) goto L_0x0059;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x004b, code lost:
        if (nativeInitializeProfiling(true) != false) goto L_0x0059;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004d, code lost:
        X.C14270pR.A0G("GcStatsProvider", "Failed to initialize GC stats tracing");
        r0 = -1873011227;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0055, code lost:
        X.AnonymousClass0BS.A09(r0, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0058, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0059, code lost:
        if (r3 == false) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x005b, code lost:
        new X.C19370zg(r9).start();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0063, code lost:
        r0 = nativeStartProfiling(getLogger(), r6, r5, r3, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x006b, code lost:
        if (r0 == 0) goto L_0x0076;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x006d, code lost:
        X.C14270pR.A0P("GcStatsProvider", "Failed to start GC stats tracing: %d", X.AnonymousClass001.A1a(r0));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0076, code lost:
        r0 = -1377530007;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0016, code lost:
        if (r7.A08.A02("provider.gc_stats.suspend_threads_to_install", false) == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0019, code lost:
        if (r7 != null) goto L_0x001b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001b, code lost:
        r5 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0024, code lost:
        if (r7.A08.A02("provider.gc_stats.log_sweep_system_weaks_details", false) != false) goto L_0x0029;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0026, code lost:
        r5 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0027, code lost:
        if (r7 == null) goto L_0x0034;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void enable() {
        /*
            r9 = this;
            r0 = 1650720379(0x6263fe7b, float:1.05143704E21)
            int r4 = X.AnonymousClass0BS.A03(r0)
            com.facebook.profilo.ipc.TraceContext r7 = r9.mEnablingContext
            r8 = 1
            r2 = 0
            if (r7 == 0) goto L_0x0018
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08
            java.lang.String r0 = "provider.gc_stats.suspend_threads_to_install"
            boolean r0 = r1.A02(r0, r2)
            r6 = 1
            if (r0 != 0) goto L_0x001b
        L_0x0018:
            r6 = 0
            if (r7 == 0) goto L_0x0026
        L_0x001b:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08
            java.lang.String r0 = "provider.gc_stats.log_sweep_system_weaks_details"
            boolean r0 = r1.A02(r0, r2)
            r5 = 1
            if (r0 != 0) goto L_0x0029
        L_0x0026:
            r5 = 0
            if (r7 == 0) goto L_0x0034
        L_0x0029:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08
            java.lang.String r0 = "provider.gc_stats.add_dummy_system_weak_holder"
            boolean r0 = r1.A02(r0, r2)
            r3 = 1
            if (r0 != 0) goto L_0x0037
        L_0x0034:
            r3 = 0
            if (r7 == 0) goto L_0x0042
        L_0x0037:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08
            java.lang.String r0 = "provider.gc_stats.use_long_suspend"
            boolean r0 = r1.A02(r0, r2)
            r1 = 1
            if (r0 != 0) goto L_0x0043
        L_0x0042:
            r1 = 0
        L_0x0043:
            java.lang.String r2 = "GcStatsProvider"
            if (r6 == 0) goto L_0x0059
            boolean r0 = nativeInitializeProfiling(r8)
            if (r0 != 0) goto L_0x0059
            java.lang.String r0 = "Failed to initialize GC stats tracing"
            X.C14270pR.A0G(r2, r0)
            r0 = -1873011227(0xffffffff905c1de5, float:-4.341038E-29)
        L_0x0055:
            X.AnonymousClass0BS.A09(r0, r4)
            return
        L_0x0059:
            if (r3 == 0) goto L_0x0063
            X.0zg r0 = new X.0zg
            r0.<init>(r9)
            r0.start()
        L_0x0063:
            com.facebook.profilo.logger.MultiBufferLogger r0 = r9.getLogger()
            int r0 = nativeStartProfiling(r0, r6, r5, r3, r1)
            if (r0 == 0) goto L_0x0076
            java.lang.Object[] r1 = X.AnonymousClass001.A1a(r0)
            java.lang.String r0 = "Failed to start GC stats tracing: %d"
            X.C14270pR.A0P(r2, r0, r1)
        L_0x0076:
            r0 = -1377530007(0xffffffffade48f69, float:-2.5984286E-11)
            goto L_0x0055
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.gcstats.GcStatsProvider.enable():void");
    }

    public int getSupportedProviders() {
        return PROVIDER_GC_STATS;
    }
}
