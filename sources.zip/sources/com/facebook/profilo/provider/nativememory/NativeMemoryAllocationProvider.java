package com.facebook.profilo.provider.nativememory;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.AnonymousClass0Dv;
import X.AnonymousClass0UR;
import X.C001200u;
import X.C03450Gz;
import X.C14840qS;
import X.C19180z7;
import X.C19350zb;
import android.content.Context;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.MultiBufferLogger;
import java.io.File;
import java.io.IOException;

public final class NativeMemoryAllocationProvider extends C19180z7 implements AnonymousClass0Dv {
    public static final int PROVIDER_MEMORY = ProvidersRegistry.A00.A02("native_memory_allocation");
    public boolean isProfiling;
    public final Context mContext;
    public String mErrorMessage;
    public boolean mIsFileBackedBuffer;
    public C19350zb mProviderTriggerMonitor;
    public boolean mReuseDispatchTable;

    public static native int nativeInitializeProfiling(Object obj, MultiBufferLogger multiBufferLogger, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, String str, boolean z, boolean z2, int i9, boolean z3, boolean z4, boolean z5, int i10, boolean z6, int i11, String str2, boolean z7, int i12, int i13, int i14, boolean z8, String str3, boolean z9, int i15, boolean z10);

    public static native void nativeStartProfiling(boolean z);

    public static native void nativeStopProfiling();

    private synchronized void startProfiling() {
        File file;
        if (!this.isProfiling) {
            nativeStartProfiling(this.mReuseDispatchTable);
            if (!(!this.mIsFileBackedBuffer || C14840qS.A05 == null || (file = C14840qS.A05.A0E) == null)) {
                try {
                    AnonymousClass001.A0D(file, "nativemp").createNewFile();
                } catch (IOException unused) {
                }
            }
            this.isProfiling = true;
        }
    }

    private synchronized void stopTraceIfRunning() {
        if (this.isProfiling) {
            nativeStopProfiling();
            this.isProfiling = false;
        }
        C19350zb r0 = this.mProviderTriggerMonitor;
        if (r0 != null) {
            r0.A02();
            this.mProviderTriggerMonitor = null;
        }
        synchronized (AnonymousClass0UR.class) {
            AnonymousClass0UR.A07 = false;
            AnonymousClass0UR.A00();
        }
    }

    public synchronized int getTracingProviders() {
        int i;
        if (this.isProfiling) {
            i = PROVIDER_MEMORY;
            if (TraceEvents.isEnabled(i)) {
            }
        }
        i = 0;
        return i;
    }

    public NativeMemoryAllocationProvider(Context context) {
        super("profilo_native_memory", new C001200u());
        this.mContext = context;
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(1026252937);
        stopTraceIfRunning();
        AnonymousClass0BS.A09(-467005302, A03);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x026a, code lost:
        if (r6 == 0) goto L_0x026e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x026c, code lost:
        r60 = r60 | true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x026e, code lost:
        r1 = nativeInitializeProfiling(r9, getLogger(), r35, r34, r33, r7, r8, r19, r13, r12, r47, r48, r32, r20, r31, r30, r29, r22, r28, r21, r27, r26, r23, r60 ? 1 : 0, r61, r25, r63, r24, r14, r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x02a6, code lost:
        if (r1 == 0) goto L_0x02ae;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x02a8, code lost:
        X.AnonymousClass0UR.A01(r1, r9.mErrorMessage);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x02ae, code lost:
        if (r5 != 0) goto L_0x02b4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x02b0, code lost:
        startProfiling();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:0x02b4, code lost:
        r9.mProviderTriggerMonitor = new X.C19350zb(r9, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x02bc, code lost:
        X.AnonymousClass0UR.A01(r2, X.AnonymousClass0WY.A0i("Cannot install hooks: ", com.facebook.common.mallochooks.jni.NativeAllocationHooksUtil$NativeImpl.sErrorMessage));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x02c7, code lost:
        X.AnonymousClass0BS.A09(1019505328, r36);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x02cf, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004e, code lost:
        if (r3 != null) goto L_0x0050;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0050, code lost:
        r30 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x005b, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.use_lock_free_queue_async_unwinder", true) == false) goto L_0x0126;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x005d, code lost:
        r30 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005f, code lost:
        if (r3 != null) goto L_0x0126;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0061, code lost:
        r2 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0062, code lost:
        r29 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0064, code lost:
        if (r3 != null) goto L_0x0135;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0066, code lost:
        r22 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0068, code lost:
        r28 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x006a, code lost:
        if (r3 != null) goto L_0x014b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x006c, code lost:
        r21 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x006e, code lost:
        r47 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0070, code lost:
        if (r3 == null) goto L_0x0122;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0072, code lost:
        r27 = r3.A08.A01("provider.native_memory_allocation.dynamic_sampling_config");
        r26 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0084, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.log_async_unwinder_failure", false) != false) goto L_0x00d8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0086, code lost:
        r26 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0088, code lost:
        if (r3 != null) goto L_0x00d8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x008a, code lost:
        r23 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x008c, code lost:
        r11 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x008d, code lost:
        if (r3 != null) goto L_0x00ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x008f, code lost:
        r10 = false;
        r6 = 1;
        r5 = 0;
        r61 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0094, code lost:
        r0 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0095, code lost:
        r9.mReuseDispatchTable = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0097, code lost:
        if (r3 == null) goto L_0x00a5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0099, code lost:
        r25 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00a3, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.resolve_names_on_client", r2) != false) goto L_0x00a9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00a5, code lost:
        r25 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00a7, code lost:
        if (r3 == null) goto L_0x00b5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00a9, code lost:
        r24 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00b3, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.enable_jit_unwinding", r2) != false) goto L_0x00c4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00b5, code lost:
        r24 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00b7, code lost:
        if (r3 != null) goto L_0x00c4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00b9, code lost:
        r14 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x00ba, code lost:
        r15 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00bb, code lost:
        r1 = r9.mContext;
        r0 = r9.mReuseDispatchTable;
        r4 = X.C13350nj.class;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00c1, code lost:
        monitor-enter(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x00c4, code lost:
        r14 = r3.A08.A00("provider.native_memory_allocation.allocation_threshold_for_sync_unwinding", r2);
        r15 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x00d5, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.avoid_unwinding_if_deallocated", r2) != false) goto L_0x00bb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x00d8, code lost:
        r23 = r3.A08.A00("provider.native_memory_allocation.unwind_on_free_chance", 0);
        r11 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00ea, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.log_memory_events", true) == false) goto L_0x00ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x00ed, code lost:
        r10 = X.AnonymousClass001.A1R(r3.A08.A02("provider.native_memory_allocation.use_no_op_allocation_registry", r2) ? 1 : 0);
        r6 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0102, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.enable_allocation_tracker", true) != false) goto L_0x0105;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0104, code lost:
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x0105, code lost:
        r5 = r3.A08.A00("provider.native_memory_allocation.when_to_start", r2 ? 1 : 0);
        r61 = r3.A08.A00("provider.native_memory_allocation.hash_mode", r2);
        r0 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x011e, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.reuse_dispatch_table", r2) != false) goto L_0x0095;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0122, code lost:
        r27 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0126, code lost:
        r2 = false;
        r29 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0131, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.log_async_unwider_queue_stats", false) != false) goto L_0x0135;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0135, code lost:
        r22 = r3.A08.A00("provider.native_memory_allocation.async_unwinder_thread_priority", 0);
        r28 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0147, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.log_mapping_status_per_frame", false) != false) goto L_0x014b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x014b, code lost:
        r21 = r3.A08.A00("provider.native_memory_allocation.elements_to_discard_on_unwinder_overflow", 0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0167, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.share_async_unwinder_thread", false) == false) goto L_0x004c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:0x0191, code lost:
        if (r3.A08.A02("provider.native_memory_allocation.mixed_stack", false) == false) goto L_0x0044;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:?, code lost:
        r0 = X.C13350nj.A00(r1, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x01b9, code lost:
        monitor-exit(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x01ba, code lost:
        if (r0 != false) goto L_0x01be;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x01be, code lost:
        r9.mIsFileBackedBuffer = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x01c0, code lost:
        if (r3 == null) goto L_0x01e0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x01c2, code lost:
        r1 = r3.A09;
        r0 = X.AnonymousClass001.A1U(r1.getFilePath());
        r9.mIsFileBackedBuffer = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x01ce, code lost:
        if (r0 == false) goto L_0x01e0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x01d0, code lost:
        r47 = r1.generateMemoryMappingFilePath();
        r63 = r1.generateLocalSymbolsFilePath();
        r48 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x01da, code lost:
        r0 = r9.mIsFileBackedBuffer;
        r18 = X.AnonymousClass0UR.class;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:0x01de, code lost:
        monitor-enter(r18);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x01e0, code lost:
        r48 = false;
        r63 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:?, code lost:
        r17 = X.C16090sj.A00;
        r4 = X.AnonymousClass001.A0n(120);
        r4.append(r0 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r35, r34, r33);
        X.AnonymousClass002.A0k(r4, ',', r7, r8, r19);
        X.AnonymousClass002.A0k(r4, ',', r13, r12, r32 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r20, r31 ? 1 : 0, r30 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r29 ? 1 : 0, r22, r28 ? 1 : 0);
        r4.append(',');
        r4.append(r21);
        r4.append(",(");
        r4.append(r27);
        r4.append("),");
        r4.append(r26 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r23, r11, r10 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r6, r25 ? 1 : 0, r24 ? 1 : 0);
        r4.append(',');
        r4.append(r14);
        r4.append(',');
        r4.append(r15 ? 1 : 0);
        r17.A06(X.C14990qj.A7s, X.C15660rs.CRITICAL_REPORT, r4.toString());
        X.AnonymousClass0UR.A0B = true;
        X.AnonymousClass0UR.A07 = true;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x0261, code lost:
        monitor-exit(r18);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x0262, code lost:
        r60 = X.AnonymousClass001.A1R(r11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0266, code lost:
        if (r10 != false) goto L_0x026a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0268, code lost:
        r60 = r60 | true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void enable() {
        /*
            r67 = this;
            r0 = 2126727659(0x7ec349eb, float:1.2979163E38)
            int r36 = X.AnonymousClass0BS.A03(r0)
            r9 = r67
            com.facebook.profilo.ipc.TraceContext r3 = r9.mEnablingContext
            r8 = 2
            if (r3 != 0) goto L_0x01ab
            r35 = 2
        L_0x0010:
            r4 = 0
            if (r3 != 0) goto L_0x0195
            r34 = 0
            r33 = 0
        L_0x0017:
            r7 = 262144(0x40000, float:3.67342E-40)
            if (r3 == 0) goto L_0x0023
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.big_allocation_threshold"
            int r7 = r1.A00(r0, r7)
        L_0x0023:
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 29
            if (r1 < r0) goto L_0x0030
            boolean r0 = com.facebook.common.build.BuildConstants.A04()
            if (r0 == 0) goto L_0x0030
            r8 = 3
        L_0x0030:
            if (r3 == 0) goto L_0x003a
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.unwinder_type"
            int r8 = r1.A00(r0, r8)
        L_0x003a:
            r2 = 256(0x100, float:3.59E-43)
            if (r3 != 0) goto L_0x016b
            r19 = 256(0x100, float:3.59E-43)
            r13 = 100
            r12 = 8
        L_0x0044:
            r32 = 0
        L_0x0046:
            r2 = 512(0x200, float:7.175E-43)
            if (r3 != 0) goto L_0x0155
            r20 = 512(0x200, float:7.175E-43)
        L_0x004c:
            r31 = 0
            if (r3 == 0) goto L_0x005d
        L_0x0050:
            com.facebook.profilo.ipc.TraceConfigExtras r2 = r3.A08
            java.lang.String r1 = "provider.native_memory_allocation.use_lock_free_queue_async_unwinder"
            r0 = 1
            boolean r0 = r2.A02(r1, r0)
            r30 = 0
            if (r0 == 0) goto L_0x0126
        L_0x005d:
            r30 = 1
            if (r3 != 0) goto L_0x0126
            r2 = 0
        L_0x0062:
            r29 = 0
            if (r3 != 0) goto L_0x0135
            r22 = 0
        L_0x0068:
            r28 = 0
            if (r3 != 0) goto L_0x014b
            r21 = 0
        L_0x006e:
            r47 = 0
            if (r3 == 0) goto L_0x0122
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.dynamic_sampling_config"
            java.lang.String r27 = r1.A01(r0)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.log_async_unwinder_failure"
            boolean r0 = r1.A02(r0, r4)
            r26 = 1
            if (r0 != 0) goto L_0x00d8
        L_0x0086:
            r26 = 0
            if (r3 != 0) goto L_0x00d8
            r23 = 0
        L_0x008c:
            r11 = 1
            if (r3 != 0) goto L_0x00ed
            r10 = 0
            r6 = 1
            r5 = 0
            r61 = 0
        L_0x0094:
            r0 = 0
        L_0x0095:
            r9.mReuseDispatchTable = r0
            if (r3 == 0) goto L_0x00a5
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.resolve_names_on_client"
            boolean r0 = r1.A02(r0, r2)
            r25 = 1
            if (r0 != 0) goto L_0x00a9
        L_0x00a5:
            r25 = 0
            if (r3 == 0) goto L_0x00b5
        L_0x00a9:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.enable_jit_unwinding"
            boolean r0 = r1.A02(r0, r2)
            r24 = 1
            if (r0 != 0) goto L_0x00c4
        L_0x00b5:
            r24 = 0
            if (r3 != 0) goto L_0x00c4
            r14 = 0
        L_0x00ba:
            r15 = 0
        L_0x00bb:
            android.content.Context r1 = r9.mContext
            boolean r0 = r9.mReuseDispatchTable
            java.lang.Class<X.0nj> r4 = X.C13350nj.class
            monitor-enter(r4)
            goto L_0x01b5
        L_0x00c4:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.allocation_threshold_for_sync_unwinding"
            int r14 = r1.A00(r0, r2)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.avoid_unwinding_if_deallocated"
            boolean r0 = r1.A02(r0, r2)
            r15 = 1
            if (r0 != 0) goto L_0x00bb
            goto L_0x00ba
        L_0x00d8:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.unwind_on_free_chance"
            int r23 = r1.A00(r0, r4)
            com.facebook.profilo.ipc.TraceConfigExtras r4 = r3.A08
            java.lang.String r1 = "provider.native_memory_allocation.log_memory_events"
            r0 = 1
            boolean r0 = r4.A02(r1, r0)
            r11 = 0
            if (r0 == 0) goto L_0x00ed
            goto L_0x008c
        L_0x00ed:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.use_no_op_allocation_registry"
            boolean r0 = r1.A02(r0, r2)
            boolean r10 = X.AnonymousClass001.A1R(r0)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.enable_allocation_tracker"
            r6 = 1
            boolean r0 = r1.A02(r0, r6)
            if (r0 != 0) goto L_0x0105
            r6 = 0
        L_0x0105:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.when_to_start"
            int r5 = r1.A00(r0, r2)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.hash_mode"
            int r61 = r1.A00(r0, r2)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.reuse_dispatch_table"
            boolean r1 = r1.A02(r0, r2)
            r0 = 1
            if (r1 != 0) goto L_0x0095
            goto L_0x0094
        L_0x0122:
            r27 = r47
            goto L_0x0086
        L_0x0126:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.log_async_unwider_queue_stats"
            r2 = 0
            boolean r0 = r1.A02(r0, r4)
            r29 = 1
            if (r0 != 0) goto L_0x0135
            goto L_0x0062
        L_0x0135:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.async_unwinder_thread_priority"
            int r22 = r1.A00(r0, r4)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.log_mapping_status_per_frame"
            boolean r0 = r1.A02(r0, r4)
            r28 = 1
            if (r0 != 0) goto L_0x014b
            goto L_0x0068
        L_0x014b:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.elements_to_discard_on_unwinder_overflow"
            int r21 = r1.A00(r0, r4)
            goto L_0x006e
        L_0x0155:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.async_unwinder_queue_size"
            int r20 = r1.A00(r0, r2)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.share_async_unwinder_thread"
            boolean r0 = r1.A02(r0, r4)
            r31 = 1
            if (r0 != 0) goto L_0x0050
            goto L_0x004c
        L_0x016b:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.max_unwind_depth"
            int r19 = r1.A00(r0, r2)
            r2 = 100
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.allocation_tracker_buffer_size"
            int r13 = r1.A00(r0, r2)
            r2 = 8
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.allocation_tracker_bucket_count"
            int r12 = r1.A00(r0, r2)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.mixed_stack"
            boolean r0 = r1.A02(r0, r4)
            r32 = 1
            if (r0 != 0) goto L_0x0046
            goto L_0x0044
        L_0x0195:
            com.facebook.profilo.ipc.TraceConfigExtras r2 = r3.A08
            java.lang.String r1 = "provider.native_memory_allocation.small_allocation_sample_rate"
            r0 = 1000(0x3e8, float:1.401E-42)
            int r34 = r2.A00(r1, r0)
            com.facebook.profilo.ipc.TraceConfigExtras r2 = r3.A08
            java.lang.String r1 = "provider.native_memory_allocation.big_allocation_sample_rate"
            r0 = 10
            int r33 = r2.A00(r1, r0)
            goto L_0x0017
        L_0x01ab:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r3.A08
            java.lang.String r0 = "provider.native_memory_allocation.sampling_strategy"
            int r35 = r1.A00(r0, r8)
            goto L_0x0010
        L_0x01b5:
            boolean r0 = X.C13350nj.A00(r1, r0)     // Catch:{ all -> 0x02d3 }
            monitor-exit(r4)
            if (r0 != 0) goto L_0x01be
            goto L_0x02bc
        L_0x01be:
            r9.mIsFileBackedBuffer = r2
            if (r3 == 0) goto L_0x01e0
            com.facebook.profilo.mmapbuf.core.Buffer r1 = r3.A09
            java.lang.String r0 = r1.getFilePath()
            boolean r0 = X.AnonymousClass001.A1U(r0)
            r9.mIsFileBackedBuffer = r0
            if (r0 == 0) goto L_0x01e0
            java.lang.String r47 = r1.generateMemoryMappingFilePath()
            java.lang.String r63 = r1.generateLocalSymbolsFilePath()
            r48 = 1
        L_0x01da:
            boolean r0 = r9.mIsFileBackedBuffer
            java.lang.Class<X.0UR> r18 = X.AnonymousClass0UR.class
            monitor-enter(r18)
            goto L_0x01e5
        L_0x01e0:
            r48 = 0
            r63 = 0
            goto L_0x01da
        L_0x01e5:
            X.0sd r17 = X.C16090sj.A00     // Catch:{ all -> 0x02d0 }
            r16 = 1
            r1 = 120(0x78, float:1.68E-43)
            java.lang.StringBuilder r4 = X.AnonymousClass001.A0n(r1)     // Catch:{ all -> 0x02d0 }
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            r3 = 44
            r2 = r35
            r1 = r34
            r0 = r33
            X.AnonymousClass002.A0k(r4, r3, r2, r1, r0)     // Catch:{ all -> 0x02d0 }
            r0 = r19
            X.AnonymousClass002.A0k(r4, r3, r7, r8, r0)     // Catch:{ all -> 0x02d0 }
            r0 = r32
            X.AnonymousClass002.A0k(r4, r3, r13, r12, r0)     // Catch:{ all -> 0x02d0 }
            r2 = r20
            r1 = r31
            r0 = r30
            X.AnonymousClass002.A0k(r4, r3, r2, r1, r0)     // Catch:{ all -> 0x02d0 }
            r2 = r29
            r1 = r22
            r0 = r28
            X.AnonymousClass002.A0k(r4, r3, r2, r1, r0)     // Catch:{ all -> 0x02d0 }
            r4.append(r3)     // Catch:{ all -> 0x02d0 }
            r0 = r21
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            java.lang.String r0 = ",("
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            r0 = r27
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            java.lang.String r0 = "),"
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            r0 = r26
            r4.append(r0)     // Catch:{ all -> 0x02d0 }
            r0 = r23
            X.AnonymousClass002.A0k(r4, r3, r0, r11, r10)     // Catch:{ all -> 0x02d0 }
            r1 = r25
            r0 = r24
            X.AnonymousClass002.A0k(r4, r3, r6, r1, r0)     // Catch:{ all -> 0x02d0 }
            r4.append(r3)     // Catch:{ all -> 0x02d0 }
            r4.append(r14)     // Catch:{ all -> 0x02d0 }
            r4.append(r3)     // Catch:{ all -> 0x02d0 }
            r4.append(r15)     // Catch:{ all -> 0x02d0 }
            com.facebook.errorreporting.field.ReportFieldString r2 = X.C14990qj.A7s     // Catch:{ all -> 0x02d0 }
            java.lang.String r3 = r4.toString()     // Catch:{ all -> 0x02d0 }
            X.0rs r1 = X.C15660rs.CRITICAL_REPORT     // Catch:{ all -> 0x02d0 }
            r0 = r17
            r0.A06(r2, r1, r3)     // Catch:{ all -> 0x02d0 }
            X.AnonymousClass0UR.A0B = r16     // Catch:{ all -> 0x02d0 }
            X.AnonymousClass0UR.A07 = r16     // Catch:{ all -> 0x02d0 }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x02d0 }
            monitor-exit(r18)
            boolean r60 = X.AnonymousClass001.A1R(r11)
            if (r10 != 0) goto L_0x026a
            r60 = r60 | 2
        L_0x026a:
            if (r6 == 0) goto L_0x026e
            r60 = r60 | 4
        L_0x026e:
            com.facebook.profilo.logger.MultiBufferLogger r38 = r9.getLogger()
            r42 = r7
            r43 = r8
            r44 = r19
            r45 = r13
            r46 = r12
            r49 = r32
            r50 = r20
            r51 = r31
            r52 = r30
            r53 = r29
            r54 = r22
            r55 = r28
            r56 = r21
            r57 = r27
            r58 = r26
            r59 = r23
            r62 = r25
            r64 = r24
            r65 = r14
            r66 = r15
            r37 = r9
            r39 = r35
            r40 = r34
            r41 = r33
            int r1 = nativeInitializeProfiling(r37, r38, r39, r40, r41, r42, r43, r44, r45, r46, r47, r48, r49, r50, r51, r52, r53, r54, r55, r56, r57, r58, r59, r60, r61, r62, r63, r64, r65, r66)
            if (r1 == 0) goto L_0x02ae
            java.lang.String r0 = r9.mErrorMessage
            X.AnonymousClass0UR.A01(r1, r0)
            goto L_0x02c7
        L_0x02ae:
            if (r5 != 0) goto L_0x02b4
            r9.startProfiling()
            goto L_0x02c7
        L_0x02b4:
            X.0zb r0 = new X.0zb
            r0.<init>(r9, r5)
            r9.mProviderTriggerMonitor = r0
            goto L_0x02c7
        L_0x02bc:
            java.lang.String r1 = "Cannot install hooks: "
            java.lang.String r0 = com.facebook.common.mallochooks.jni.NativeAllocationHooksUtil$NativeImpl.sErrorMessage
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r1, r0)
            X.AnonymousClass0UR.A01(r2, r0)
        L_0x02c7:
            r1 = 1019505328(0x3cc46ab0, float:0.023976654)
            r0 = r36
            X.AnonymousClass0BS.A09(r1, r0)
            return
        L_0x02d0:
            r0 = move-exception
            monitor-exit(r18)     // Catch:{ all -> 0x02d0 }
            throw r0
        L_0x02d3:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x02d3 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.nativememory.NativeMemoryAllocationProvider.enable():void");
    }

    public int getSupportedProviders() {
        return PROVIDER_MEMORY;
    }

    public void onTraceEnded(TraceContext traceContext, C03450Gz r4) {
        int A03 = AnonymousClass0BS.A03(-78574562);
        stopTraceIfRunning();
        AnonymousClass0BS.A09(-1884952386, A03);
    }

    public void onTrigger() {
        startProfiling();
    }

    public void setErrorMessage(String str) {
        this.mErrorMessage = str;
    }
}
