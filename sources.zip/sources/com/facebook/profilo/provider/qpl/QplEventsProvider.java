package com.facebook.profilo.provider.qpl;

import X.AnonymousClass001;
import X.AnonymousClass01h;
import X.AnonymousClass03S;
import X.AnonymousClass03X;
import X.AnonymousClass04C;
import X.AnonymousClass0BS;
import X.AnonymousClass0DW;
import X.AnonymousClass0Ee;
import X.AnonymousClass0WY;
import X.C02740Dm;
import X.C03450Gz;
import X.C19180z7;
import X.C19460zp;
import android.util.SparseIntArray;
import androidx.core.graphics.drawable.IconCompat;
import com.facebook.jni.HybridData;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.MultiBufferLogger;
import com.facebook.quicklog.QuickPerformanceLogger;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class QplEventsProvider extends C19180z7 implements C02740Dm {
    public static final long ACTION_ID_MASK = 65535;
    public static final int[] ALWAYS_ON_QPL_EVENTS = {8136209};
    public static final long EVENT_LEVEL_MASK = -1152921504606846976L;
    public static final long FLAGS_MASK = 1152640029630136320L;
    public static final int MAX_STRING_ANNOTATION = 512;
    public static final int MAX_STRING_TAGS = 1024;
    public static final int PROVIDER_QPL = ProvidersRegistry.A00.A02("qpl");
    public static final String QPL_ALL_USER_FLOW_EVENTS = "provider.qpl.all_user_flow_events";
    public static final String QPL_BUFFERS = "provider.qpl.buffers";
    public static final String QPL_POINT_MAX_LEVEL_CONFIG_PARAM = "provider.qpl.point_max_level";
    public static final String QPL_WHITELIST_CONFIG_PARAM = "provider.qpl.event_whitelist";
    public static final long SUSPECT_TIMESTAMP_FLAG = 281474976710656L;
    public static final String TAG_IDENTIFIER = "tags";
    public static final long TRIGGER_EVENT_FLAG = 562949953421312L;
    public static final long UNIQUE_ID_MASK = 281474976645120L;
    public static final QplEventsProvider sInstance = new QplEventsProvider();
    public HybridData mHybridData;
    public boolean mIgnoreNativeLibrary;
    public volatile boolean mIsNativeTracingEnabled;
    public QuickPerformanceLogger mQPL;
    public final CopyOnWriteArrayList mQplLoggerInstances = new CopyOnWriteArrayList();
    public volatile SparseIntArray mTracingEvents = new SparseIntArray(4);
    public final ThreadLocal triggerTimestamp = new ThreadLocal();

    public QplEventsProvider() {
        super((String) null, (Runnable) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0029, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized boolean ensureNativeLibrary() {
        /*
            r5 = this;
            monitor-enter(r5)
            boolean r0 = r5.mIgnoreNativeLibrary     // Catch:{ all -> 0x002c }
            r4 = 0
            if (r0 != 0) goto L_0x002a
            com.facebook.jni.HybridData r0 = r5.mHybridData     // Catch:{ all -> 0x002c }
            r3 = 1
            if (r0 != 0) goto L_0x0028
            java.lang.String r0 = "profilo_qplprovider"
            boolean r0 = X.C18440x7.loadLibrary(r0)     // Catch:{ UnsatisfiedLinkError -> 0x001d }
            if (r0 != 0) goto L_0x0016
            r5.mIgnoreNativeLibrary = r3     // Catch:{ UnsatisfiedLinkError -> 0x001d }
            goto L_0x002a
        L_0x0016:
            com.facebook.jni.HybridData r0 = initHybrid()     // Catch:{ all -> 0x002c }
            r5.mHybridData = r0     // Catch:{ all -> 0x002c }
            goto L_0x0028
        L_0x001d:
            r2 = move-exception
            java.lang.String r1 = "Profilo/QplEventsProvider"
            java.lang.String r0 = "Failed to load native library"
            android.util.Log.w(r1, r0, r2)     // Catch:{ all -> 0x002c }
            r5.mIgnoreNativeLibrary = r3     // Catch:{ all -> 0x002c }
            goto L_0x002a
        L_0x0028:
            monitor-exit(r5)
            return r3
        L_0x002a:
            monitor-exit(r5)
            return r4
        L_0x002c:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x002c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.qpl.QplEventsProvider.ensureNativeLibrary():boolean");
    }

    private int[] extendQplAllowlistWithDefaults(int[] iArr) {
        int length = iArr.length;
        int[] iArr2 = ALWAYS_ON_QPL_EVENTS;
        int[] iArr3 = new int[(iArr2.length + length)];
        System.arraycopy(iArr, 0, iArr3, 0, length);
        System.arraycopy(iArr2, 0, iArr3, length, iArr2.length);
        return iArr3;
    }

    public static String getBufferSpecificParamIfAny(String str, int i, int i2) {
        if (i > 1) {
            return AnonymousClass0WY.A0U(str, '.', i2);
        }
        return str;
    }

    public static native HybridData initHybrid();

    private native void nativeUpdateTracingState(int[] iArr);

    public synchronized void enableNativeQPLTracing() {
        this.mIsNativeTracingEnabled = true;
    }

    private int[] getDesiredNormalEventsForTracing(int[] iArr) {
        int length;
        int i;
        SparseIntArray sparseIntArray = this.mTracingEvents;
        int size = sparseIntArray.size();
        int[] iArr2 = null;
        if (!(iArr == null && size == 0)) {
            if (sparseIntArray.get(-1) > 0) {
                return C02740Dm.A00;
            }
            int i2 = 0;
            if (iArr == null) {
                length = 0;
            } else {
                length = iArr.length;
            }
            int i3 = length + size;
            if (i3 != 0) {
                iArr2 = new int[i3];
                if (iArr != null) {
                    int length2 = iArr.length;
                    int i4 = 0;
                    i = 0;
                    while (i4 < length2) {
                        iArr2[i] = iArr[i4];
                        i4++;
                        i++;
                    }
                } else {
                    i = 0;
                }
                while (i2 < size) {
                    iArr2[i] = sparseIntArray.keyAt(i2);
                    i2++;
                    i++;
                }
            }
        }
        return iArr2;
    }

    public static String getLoggerInstanceID(TraceContext traceContext, int i) {
        return AnonymousClass0WY.A0U(traceContext.A0D, '-', i);
    }

    public static int[] getTraceQPLBufferIdxs(TraceContext traceContext) {
        int[] A03 = traceContext.A08.A03(QPL_BUFFERS);
        if (A03 == null) {
            return new int[]{0};
        }
        return A03;
    }

    public static QplEventsProvider newInstance() {
        return new QplEventsProvider();
    }

    private void updateNativeTracingState() {
        if (this.mIsNativeTracingEnabled && ensureNativeLibrary()) {
            nativeUpdateTracingState(getListenerMarkers().A00);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x003a, code lost:
        if (r0 == null) goto L_0x003c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public X.AnonymousClass03Q getListenerMarkers() {
        /*
            r8 = this;
            X.01h r2 = X.AnonymousClass01h.A0C
            if (r2 == 0) goto L_0x003c
            int r1 = X.AnonymousClass0DW.A01
            android.util.SparseArray r0 = r2.A01
            java.lang.Object r1 = r0.get(r1)
            X.0Dk r1 = (X.AnonymousClass0Dk) r1
            X.0Dp r1 = (X.C02750Dp) r1
            r7 = 0
            if (r1 == 0) goto L_0x0036
            java.util.concurrent.atomic.AtomicReference r0 = r2.A05
            java.lang.Object r0 = r0.get()
            X.0Gx r0 = (X.C03430Gx) r0
            java.lang.Object r0 = r1.A07(r0)
            X.03N r0 = (X.AnonymousClass03N) r0
            X.03O[] r6 = r0.A01
            int r5 = r6.length
            int[] r4 = new int[r5]
            r3 = 0
            r2 = 0
        L_0x0028:
            if (r3 >= r5) goto L_0x003f
            r0 = r6[r3]
            int r1 = r2 + 1
            int r0 = r0.A01
            r4[r2] = r0
            int r3 = r3 + 1
            r2 = r1
            goto L_0x0028
        L_0x0036:
            int[] r0 = r8.getDesiredNormalEventsForTracing(r7)
            if (r0 != 0) goto L_0x0045
        L_0x003c:
            X.03Q r1 = X.AnonymousClass03Q.A03
            return r1
        L_0x003f:
            if (r5 == 0) goto L_0x0036
            int[] r0 = r8.getDesiredNormalEventsForTracing(r4)
        L_0x0045:
            X.03Q r1 = new X.03Q
            r1.<init>(r0, r7)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.qpl.QplEventsProvider.getListenerMarkers():X.03Q");
    }

    public int getTracingProviders() {
        return PROVIDER_QPL & TraceEvents.sProviders;
    }

    public boolean hasQuickPerformanceLogger() {
        if (this.mQPL != null) {
            return true;
        }
        return false;
    }

    public boolean isNormalEventAllowed(int i) {
        SparseIntArray sparseIntArray = this.mTracingEvents;
        if (sparseIntArray.get(-1) > 0 || sparseIntArray.get(i) > 0) {
            return true;
        }
        return false;
    }

    public void onMarkEvent(AnonymousClass0Ee r25) {
        C19460zp r0;
        int i;
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r2 = (AnonymousClass04C) it.next();
            AnonymousClass0Ee r3 = r25;
            if (AnonymousClass04C.A05(r2, r3.getMarkerId(), r3.CEa()) && ((r0 = r2.A00) == null || !r0.A0C(r3))) {
                MultiBufferLogger multiBufferLogger = r2.A04;
                int i2 = 0;
                multiBufferLogger.writeStandardEntry(7, 51, 0, 0, r3.getMarkerId(), 0, ((((long) r3.BAL()) << 60) & EVENT_LEVEL_MASK) | ((((long) r3.Bt9()) << 16) & UNIQUE_ID_MASK));
                int writeStandardEntry = multiBufferLogger.writeStandardEntry(7, 59, 0, 0, r3.getMarkerId(), 0, (((long) r3.Bt9()) << 16) & UNIQUE_ID_MASK);
                multiBufferLogger.writeBytesEntry(1, 57, multiBufferLogger.writeBytesEntry(1, 56, writeStandardEntry, IconCompat.EXTRA_TYPE), r3.Bne());
                List BB8 = r3.BB8();
                int size = BB8.size();
                while (i2 < size) {
                    int i3 = i2 + 1;
                    i2 = i3 + 1;
                    String str = (String) BB8.get(i3);
                    int writeBytesEntry = multiBufferLogger.writeBytesEntry(1, 56, writeStandardEntry, (String) BB8.get(i2));
                    if (str == null) {
                        str = "null";
                    }
                    int length = str.length();
                    if (length > 512) {
                        int i4 = 0;
                        do {
                            i = i4 + 512;
                            writeBytesEntry = multiBufferLogger.writeBytesEntry(1, 57, writeBytesEntry, str.substring(i4, Math.min(length, i)));
                            i4 = i;
                        } while (i < length);
                    } else {
                        multiBufferLogger.writeBytesEntry(1, 57, writeBytesEntry, str);
                    }
                }
            }
        }
    }

    public void onMarkerAnnotate(AnonymousClass0Ee r13) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r2 = (AnonymousClass04C) it.next();
            C19460zp r0 = r2.A00;
            if (r0 == null || !r0.A0D(r13)) {
                int markerId = r13.getMarkerId();
                boolean CEa = r13.CEa();
                AnonymousClass04C.A03(r2, r13.BLu(), r13.BLv(), markerId, r13.Bt9(), r13.BJo(), r13.BMA(), r13.BLo(), CEa);
            }
        }
    }

    public void onMarkerDrop(AnonymousClass0Ee r11) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r2 = (AnonymousClass04C) it.next();
            C19460zp r0 = r2.A00;
            if (r0 == null || !r0.A0E(r11)) {
                AnonymousClass04C.A01(r2, r11.getMarkerId(), r11.Bt9(), r11.BJo(), r11.BMA(), r11.CEa(), !r11.CEh());
            }
        }
    }

    public void onMarkerPoint(AnonymousClass0Ee r15, String str, AnonymousClass03X r17, long j, long j2, boolean z, int i) {
        String str2;
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r3 = (AnonymousClass04C) it.next();
            int i2 = i;
            if (i2 <= r3.A02 && AnonymousClass04C.A05(r3, r15.getMarkerId(), r15.CEa())) {
                C19460zp r0 = r3.A00;
                String str3 = str;
                AnonymousClass03X r1 = r17;
                if (r0 == null || !r0.A0B(r1, r15, str3)) {
                    if (r17 != null) {
                        str2 = r1.toString();
                    } else {
                        str2 = null;
                    }
                    AnonymousClass04C.A04(r3, str3, str2, r15.getMarkerId(), i2, r15.BMA(), (((long) r15.Bt9()) << 16) & UNIQUE_ID_MASK, r15.CEa(), z);
                }
            }
        }
    }

    public void onMarkerRestart(AnonymousClass0Ee r3) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            ((AnonymousClass04C) it.next()).A06(r3);
        }
    }

    public void onMarkerStart(AnonymousClass0Ee r8) {
        AnonymousClass01h r6 = AnonymousClass01h.A0C;
        if (r6 != null) {
            this.triggerTimestamp.set(Long.valueOf(System.nanoTime()));
            int markerId = r8.getMarkerId();
            r6.A0D((((long) r8.BJo()) << 32) | ((long) markerId), AnonymousClass0DW.A01, 0);
        }
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            ((AnonymousClass04C) it.next()).A06(r8);
        }
    }

    public void onMarkerStop(AnonymousClass0Ee r14) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r2 = (AnonymousClass04C) it.next();
            C19460zp r0 = r2.A00;
            if (r0 == null || !r0.A0G(r14)) {
                int markerId = r14.getMarkerId();
                boolean CEa = r14.CEa();
                int Bt9 = r14.Bt9();
                int BJo = r14.BJo();
                short BLo = r14.BLo();
                AnonymousClass04C.A00(r2, markerId, Bt9, BJo, r14.B8F(), r14.BMA(), BLo, CEa, !r14.CEh(), false);
            }
        }
    }

    public void onMarkerSwap(int i, int i2, AnonymousClass0Ee r5) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            it.next();
        }
    }

    public static QplEventsProvider get() {
        return sInstance;
    }

    private int[] getListenerMarkersForNative() {
        return getListenerMarkers().A00;
    }

    public void disable() {
        AnonymousClass0BS.A09(-561358212, AnonymousClass0BS.A03(-1883740770));
    }

    public void enable() {
        AnonymousClass0BS.A09(1942287159, AnonymousClass0BS.A03(800229478));
    }

    public AnonymousClass03S getListenerFlags() {
        return null;
    }

    public String getName() {
        return "profilo_event_provider";
    }

    public int getSupportedProviders() {
        return PROVIDER_QPL;
    }

    public void onTraceEnded(TraceContext traceContext, C03450Gz r13) {
        int A03 = AnonymousClass0BS.A03(-1387458835);
        int[] traceQPLBufferIdxs = getTraceQPLBufferIdxs(traceContext);
        SparseIntArray clone = this.mTracingEvents.clone();
        int i = 0;
        while (true) {
            int length = traceQPLBufferIdxs.length;
            if (i < length) {
                int i2 = traceQPLBufferIdxs[i];
                int[] A032 = traceContext.A08.A03(getBufferSpecificParamIfAny(QPL_WHITELIST_CONFIG_PARAM, length, i2));
                if (A032 == null) {
                    A032 = new int[]{-1};
                } else if (i == 0) {
                    extendQplAllowlistWithDefaults(A032);
                }
                int length2 = A032.length;
                int i3 = 0;
                while (i3 < length2) {
                    int i4 = A032[i3];
                    if (clone != null) {
                        int i5 = clone.get(i4);
                        if (i5 == 1) {
                            clone.delete(i4);
                        } else if (i5 > 1) {
                            clone.put(i4, i5 - 1);
                        }
                        i3++;
                    } else {
                        throw AnonymousClass001.A0S();
                    }
                }
                String loggerInstanceID = getLoggerInstanceID(traceContext, i2);
                Iterator it = this.mQplLoggerInstances.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    AnonymousClass04C r1 = (AnonymousClass04C) it.next();
                    if (r1.A05.equals(loggerInstanceID)) {
                        C19460zp r0 = r1.A00;
                        if (r0 != null) {
                            r0.A09();
                        }
                        this.mQplLoggerInstances.remove(r1);
                    }
                }
                i++;
            } else {
                this.mTracingEvents = clone;
                QuickPerformanceLogger quickPerformanceLogger = this.mQPL;
                if (quickPerformanceLogger != null) {
                    quickPerformanceLogger.updateListenerMarkers();
                }
                if (this.mIsNativeTracingEnabled) {
                    updateNativeTracingState();
                }
                AnonymousClass0BS.A09(734793714, A03);
                return;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0039, code lost:
        if (r5.A08.A02(QPL_ALL_USER_FLOW_EVENTS, true) == false) goto L_0x003b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onTraceStarted(com.facebook.profilo.ipc.TraceContext r24, X.C03450Gz r25) {
        /*
            r23 = this;
            r0 = -1845284512(0xffffffff92033160, float:-4.139717E-28)
            int r4 = X.AnonymousClass0BS.A03(r0)
            r5 = r24
            int[] r7 = getTraceQPLBufferIdxs(r5)
            r3 = r23
            android.util.SparseIntArray r0 = r3.mTracingEvents
            android.util.SparseIntArray r2 = r0.clone()
            r14 = 0
            r6 = 0
        L_0x0017:
            int r12 = r7.length
            if (r6 >= r12) goto L_0x00ab
            r10 = r7[r6]
            com.facebook.profilo.mmapbuf.core.Buffer[] r0 = r5.A0F
            r11 = r0[r10]
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r5.A08
            java.lang.String r0 = "provider.qpl.event_whitelist"
            java.lang.String r0 = getBufferSpecificParamIfAny(r0, r12, r10)
            int[] r9 = r1.A03(r0)
            r8 = 1
            if (r6 != 0) goto L_0x003b
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r5.A08
            java.lang.String r0 = "provider.qpl.all_user_flow_events"
            boolean r0 = r1.A02(r0, r8)
            r22 = 1
            if (r0 != 0) goto L_0x003d
        L_0x003b:
            r22 = 0
        L_0x003d:
            if (r9 != 0) goto L_0x009f
            r0 = -1
            int[] r9 = new int[]{r0}
        L_0x0044:
            java.util.Arrays.sort(r9)
            int r13 = r9.length
            r8 = 0
        L_0x0049:
            if (r8 >= r13) goto L_0x005b
            r1 = r9[r8]
            if (r2 == 0) goto L_0x00a6
            int r0 = r2.get(r1)
            int r0 = r0 + 1
            r2.put(r1, r0)
            int r8 = r8 + 1
            goto L_0x0049
        L_0x005b:
            com.facebook.profilo.ipc.TraceConfigExtras r8 = r5.A08
            java.lang.String r0 = "provider.qpl.point_max_level"
            java.lang.String r1 = getBufferSpecificParamIfAny(r0, r12, r10)
            r0 = 9
            int r19 = r8.A00(r1, r0)
            com.facebook.profilo.logger.MultiBufferLogger r8 = new com.facebook.profilo.logger.MultiBufferLogger
            r8.<init>()
            r8.addBuffer(r11)
            long r0 = r5.A05
            java.lang.String r17 = getLoggerInstanceID(r5, r10)
            X.04C r15 = new X.04C
            r20 = r0
            r18 = r9
            r16 = r8
            r15.<init>(r16, r17, r18, r19, r20, r22)
            java.util.concurrent.CopyOnWriteArrayList r0 = r3.mQplLoggerInstances
            r0.add(r15)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r5.A08
            java.lang.String r0 = "trace_config.aggregator.enabled"
            boolean r0 = r1.A02(r0, r14)
            if (r0 == 0) goto L_0x009b
            X.0zp r0 = new X.0zp
            r0.<init>(r15)
            r15.A00 = r0
            r0.A0A(r5)
        L_0x009b:
            int r6 = r6 + 1
            goto L_0x0017
        L_0x009f:
            if (r6 != 0) goto L_0x0044
            int[] r9 = r3.extendQplAllowlistWithDefaults(r9)
            goto L_0x0044
        L_0x00a6:
            java.lang.NullPointerException r0 = X.AnonymousClass001.A0S()
            throw r0
        L_0x00ab:
            java.lang.ThreadLocal r0 = r3.triggerTimestamp
            java.lang.Object r0 = r0.get()
            java.lang.Number r0 = (java.lang.Number) r0
            if (r0 == 0) goto L_0x00cb
            com.facebook.profilo.mmapbuf.core.Buffer r9 = r5.A09
            long r12 = r0.longValue()
            r17 = 0
            r10 = 4
            r11 = 42
            r15 = r14
            r16 = r14
            com.facebook.profilo.logger.BufferLogger.writeStandardEntry(r9, r10, r11, r12, r14, r15, r16, r17)
            java.lang.ThreadLocal r0 = r3.triggerTimestamp
            r0.remove()
        L_0x00cb:
            r3.mTracingEvents = r2
            com.facebook.quicklog.QuickPerformanceLogger r0 = r3.mQPL
            if (r0 == 0) goto L_0x00d4
            r0.updateListenerMarkers()
        L_0x00d4:
            boolean r0 = r3.mIsNativeTracingEnabled
            if (r0 == 0) goto L_0x00db
            r3.updateNativeTracingState()
        L_0x00db:
            r0 = 186457599(0xb1d1dff, float:3.0259667E-32)
            X.AnonymousClass0BS.A09(r0, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.qpl.QplEventsProvider.onTraceStarted(com.facebook.profilo.ipc.TraceContext, X.0Gz):void");
    }

    public boolean requiresSynchronousCallbacks() {
        return true;
    }

    public void onMetadataCollected(AnonymousClass0Ee r1) {
    }

    public void setQuickPerformanceLogger(QuickPerformanceLogger quickPerformanceLogger) {
        this.mQPL = quickPerformanceLogger;
    }

    public void onMarkerDrop(int i, int i2, long j) {
        onMarkerDrop(i, false, i2, j);
    }

    public void onMarkerPoint(int i, boolean z, String str, String str2, int i2, int i3, long j, boolean z2) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            String str3 = str;
            String str4 = str2;
            AnonymousClass04C.A04((AnonymousClass04C) it.next(), str3, str4, i, i2, j, (((long) i3) << 16) & UNIQUE_ID_MASK, z, z2);
        }
    }

    public void onMarkerStart(int i, boolean z, int i2, long j, boolean z2) {
        AnonymousClass01h r5 = AnonymousClass01h.A0C;
        int i3 = i;
        int i4 = i2;
        if (r5 != null) {
            this.triggerTimestamp.set(Long.valueOf(System.nanoTime()));
            r5.A0D((((long) i4) << 32) | ((long) i), AnonymousClass0DW.A01, 0);
        }
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            int i5 = i4;
            AnonymousClass04C.A02((AnonymousClass04C) it.next(), i3, i4, i5, j, z, z2, true);
        }
    }

    public void onMarkerStop(int i, boolean z, int i2, long j, boolean z2) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            int i3 = i2;
            int i4 = i3;
            AnonymousClass04C.A00((AnonymousClass04C) it.next(), i, i3, i4, 0, j, 0, z, z2, true);
        }
    }

    public void onMarkEvent(int i, boolean z, String str, int i2, String[] strArr, long j) {
        int i3;
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            AnonymousClass04C r1 = (AnonymousClass04C) it.next();
            int i4 = i;
            if (AnonymousClass04C.A05(r1, i4, z)) {
                MultiBufferLogger multiBufferLogger = r1.A04;
                long j2 = (((long) i2) << 60) & EVENT_LEVEL_MASK;
                long j3 = (((long) i4) << 16) & UNIQUE_ID_MASK;
                int i5 = 0;
                int i6 = i4;
                multiBufferLogger.writeStandardEntry(7, 51, 0, 0, i6, 0, j2 | j3);
                int writeStandardEntry = multiBufferLogger.writeStandardEntry(7, 59, 0, 0, i6, 0, j3);
                multiBufferLogger.writeBytesEntry(1, 57, multiBufferLogger.writeBytesEntry(1, 56, writeStandardEntry, IconCompat.EXTRA_TYPE), str);
                int length = strArr.length;
                while (i5 < length) {
                    int i7 = i5 + 1;
                    String str2 = strArr[i5];
                    i5 = i7 + 1;
                    String str3 = strArr[i7];
                    int writeBytesEntry = multiBufferLogger.writeBytesEntry(1, 56, writeStandardEntry, str2);
                    if (str3 == null) {
                        str3 = "null";
                    }
                    int length2 = str3.length();
                    if (length2 > 512) {
                        int i8 = 0;
                        do {
                            i3 = i8 + 512;
                            writeBytesEntry = multiBufferLogger.writeBytesEntry(1, 57, writeBytesEntry, str3.substring(i8, Math.min(length2, i3)));
                            i8 = i3;
                        } while (i3 < length2);
                    } else {
                        multiBufferLogger.writeBytesEntry(1, 57, writeBytesEntry, str3);
                    }
                }
            }
        }
    }

    public void onMarkerAnnotate(int i, boolean z, int i2, String str, String str2, long j) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            String str3 = str;
            String str4 = str2;
            int i3 = i2;
            AnonymousClass04C.A03((AnonymousClass04C) it.next(), str3, str4, i, i2, i3, j, 0, z);
        }
    }

    public void onMarkEvent(int i, String str, int i2, String[] strArr, long j) {
        onMarkEvent(i, false, str, i2, strArr, j);
    }

    public void onMarkerAnnotate(int i, int i2, String str, String str2, long j) {
        onMarkerAnnotate(i, false, i2, str, str2, j);
    }

    public void onMarkerDrop(int i, boolean z, int i2, long j) {
        Iterator it = this.mQplLoggerInstances.iterator();
        while (it.hasNext()) {
            int i3 = i2;
            AnonymousClass04C.A01((AnonymousClass04C) it.next(), i, i2, i3, j, z, false);
        }
    }

    public void onMarkerPoint(int i, String str, String str2, int i2, int i3, long j, boolean z) {
        onMarkerPoint(i, false, str, str2, i2, i3, j, z);
    }

    public void onMarkerStart(int i, int i2, long j, boolean z) {
        onMarkerStart(i, false, i2, j, z);
    }

    public void onMarkerStop(int i, int i2, long j, boolean z) {
        onMarkerStop(i, false, i2, j, z);
    }
}
