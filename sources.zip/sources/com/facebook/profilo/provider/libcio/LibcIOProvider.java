package com.facebook.profilo.provider.libcio;

import X.AnonymousClass00j;
import X.AnonymousClass0BS;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class LibcIOProvider extends C19180z7 {
    public static final int PROVIDER_LIBC_IO = ProvidersRegistry.A00.A02("libc_io");

    public native void nativeCleanup();

    public native void nativeInitialize(MultiBufferLogger multiBufferLogger);

    public native boolean nativeIsTracingEnabled();

    public LibcIOProvider() {
        super("profilo_libcio", new AnonymousClass00j());
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(-50977711);
        nativeCleanup();
        AnonymousClass0BS.A09(-1560096535, A03);
    }

    public void enable() {
        int A03 = AnonymousClass0BS.A03(1483191554);
        nativeInitialize(getLogger());
        AnonymousClass0BS.A09(25905291, A03);
    }

    public int getSupportedProviders() {
        return PROVIDER_LIBC_IO;
    }

    public int getTracingProviders() {
        if (nativeIsTracingEnabled()) {
            return PROVIDER_LIBC_IO;
        }
        return 0;
    }
}
