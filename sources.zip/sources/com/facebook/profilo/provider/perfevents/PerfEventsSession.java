package com.facebook.profilo.provider.perfevents;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.C19440zn;
import com.facebook.profilo.logger.MultiBufferLogger;

public class PerfEventsSession {
    public long mNativeHandle;
    public final Runnable mSessionRunnable = new C19440zn(this);
    public Thread mThread;

    public static native long nativeAttach(boolean z, int i, int i2, float f, MultiBufferLogger multiBufferLogger);

    public static native void nativeDetach(long j);

    public static native void nativeRun(long j);

    public static native void nativeStop(long j);

    public synchronized void stop() {
        Throwable A0X;
        long j = this.mNativeHandle;
        if (j != 0) {
            nativeStop(j);
            try {
                this.mThread.join();
                this.mThread = null;
            } catch (InterruptedException e) {
                A0X = AnonymousClass001.A0X(e);
            }
        } else if (this.mThread != null) {
            A0X = AnonymousClass001.A0P("Inconsistent state: have thread but no handle");
        }
        throw A0X;
    }

    public void finalize() {
        int A03 = AnonymousClass0BS.A03(1734357246);
        stop();
        synchronized (this) {
            try {
                long j = this.mNativeHandle;
                if (j != 0) {
                    nativeDetach(j);
                }
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(1111556274, A03);
                    throw th;
                }
            }
        }
        AnonymousClass0BS.A09(76533778, A03);
    }
}
