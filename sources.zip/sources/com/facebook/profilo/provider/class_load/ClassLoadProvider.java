package com.facebook.profilo.provider.class_load;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.C14060oy;
import X.C14080p0;
import X.C19180z7;
import X.C19300zV;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;

public final class ClassLoadProvider extends C19180z7 {
    public static final int A01 = ProvidersRegistry.A00.A02("class_load");
    public C14060oy A00 = new C19300zV(getLogger());

    public ClassLoadProvider() {
        super((String) null, (Runnable) null);
    }

    public final void disable() {
        int A03 = AnonymousClass0BS.A03(-1042262447);
        C14080p0 A002 = C14080p0.A00();
        if (A002 != null) {
            C14060oy r4 = this.A00;
            synchronized (A002) {
                AtomicReference atomicReference = A002.A00;
                ArrayList A0u = AnonymousClass001.A0u(((ArrayList) atomicReference.get()).size() - 1);
                Iterator it = ((ArrayList) atomicReference.get()).iterator();
                while (it.hasNext()) {
                    C14060oy r0 = (C14060oy) it.next();
                    if (r0 != r4) {
                        A0u.add(r0);
                    }
                }
                atomicReference.set(A0u);
                if (((ArrayList) atomicReference.get()).isEmpty()) {
                    A002.A03();
                }
            }
        }
        AnonymousClass0BS.A09(-1174448314, A03);
    }

    public final void enable() {
        int A03 = AnonymousClass0BS.A03(849025068);
        C14080p0 A002 = C14080p0.A00();
        if (A002 != null) {
            A002.A05(this.A00);
        }
        AnonymousClass0BS.A09(-1867853427, A03);
    }

    public final int getSupportedProviders() {
        return A01;
    }

    public final int getTracingProviders() {
        boolean z;
        C14080p0 A002 = C14080p0.A00();
        int i = A01;
        if (!TraceEvents.isEnabled(i) || A002 == null) {
            return 0;
        }
        synchronized (A002) {
            z = A002.A01;
        }
        if (z) {
            return i;
        }
        return 0;
    }
}
