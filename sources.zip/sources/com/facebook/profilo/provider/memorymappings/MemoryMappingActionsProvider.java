package com.facebook.profilo.provider.memorymappings;

import X.AnonymousClass0BS;
import X.AnonymousClass0UR;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class MemoryMappingActionsProvider extends C19180z7 {
    public static final int PROVIDER_MAPPINGS = ProvidersRegistry.A00.A02("memory_mapping_actions");
    public boolean isProfiling;

    public static native void nativeStartProfiling(MultiBufferLogger multiBufferLogger, int i, int i2, String str, boolean z, boolean z2, int i3, boolean z3, boolean z4, int i4, String str2);

    public static native void nativeStopProfiling();

    public int getTracingProviders() {
        if (!this.isProfiling) {
            return 0;
        }
        int i = PROVIDER_MAPPINGS;
        if (TraceEvents.isEnabled(i)) {
            return i;
        }
        return 0;
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(2132660497);
        nativeStopProfiling();
        this.isProfiling = false;
        synchronized (AnonymousClass0UR.class) {
            AnonymousClass0UR.A06 = false;
            AnonymousClass0UR.A00();
        }
        AnonymousClass0BS.A09(-930113607, A03);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x002a, code lost:
        if (r5.A08.A02("provider.memory_mapping_actions.log_unmapping", true) == false) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002c, code lost:
        r12 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002f, code lost:
        if (r5 != null) goto L_0x006c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0031, code lost:
        r13 = com.facebook.common.dextricks.DalvikInternals.ART_HACK_DEX_PC_LINENUM;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0033, code lost:
        r14 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0034, code lost:
        if (r5 == null) goto L_0x0041;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0036, code lost:
        r15 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x003f, code lost:
        if (r5.A08.A02("provider.memory_mapping_actions.use_lock_free_queue_async_unwinder", true) != false) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0041, code lost:
        r15 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0042, code lost:
        if (r5 != null) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0044, code lost:
        r16 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0046, code lost:
        if (r8 == 0) goto L_0x005e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0048, code lost:
        if (r5 == null) goto L_0x005e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004a, code lost:
        r5 = r5.A09;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0050, code lost:
        if (r5.getFilePath() == null) goto L_0x005e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0052, code lost:
        r10 = r5.generateMemoryMappingFilePath();
        r17 = r5.generateLocalSymbolsFilePath();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x005a, code lost:
        r6 = X.AnonymousClass0UR.class;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005c, code lost:
        monitor-enter(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x005e, code lost:
        r17 = null;
        r10 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0063, code lost:
        r16 = r5.A08.A00("provider.memory_mapping_actions.async_unwinder_thread_priority", 0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x006c, code lost:
        r13 = r5.A08.A00("provider.memory_mapping_actions.async_unwinder_queue_size", com.facebook.common.dextricks.DalvikInternals.ART_HACK_DEX_PC_LINENUM);
        r14 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007d, code lost:
        if (r5.A08.A02("provider.memory_mapping_actions.share_async_unwinder_thread", false) != false) goto L_0x0036;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
        X.AnonymousClass0UR.A0A = true;
        X.AnonymousClass0UR.A06 = true;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0098, code lost:
        monitor-exit(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
        nativeStartProfiling(getLogger(), r8, r9, r10, r11, r12, r13, r14, r15, r16, r17);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00a0, code lost:
        r4.isProfiling = true;
        r0 = 596278585;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00a6, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00a7, code lost:
        r5 = r0.getMessage();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00ab, code lost:
        monitor-enter(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:?, code lost:
        r0 = X.AnonymousClass0UR.A00;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00ae, code lost:
        if (r0 != null) goto L_0x00b0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00b0, code lost:
        r1 = r0.A00.markEventBuilder(21375349, "mappings_provider");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00bf, code lost:
        if (r1.isSampled() != false) goto L_0x00c1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00c1, code lost:
        if (r5 != null) goto L_0x00c3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00c3, code lost:
        r1.annotate("error_message", r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00c8, code lost:
        r1.report();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00cb, code lost:
        X.AnonymousClass0UR.A0A = false;
        X.AnonymousClass0UR.A06 = false;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00d3, code lost:
        r0 = 849709483;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001c, code lost:
        if (r5.A08.A02("provider.memory_mapping_actions.detail_fd", true) != false) goto L_0x001e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001f, code lost:
        if (r5 != null) goto L_0x0021;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0021, code lost:
        r12 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void enable() {
        /*
            r18 = this;
            r0 = 1667667562(0x6366966a, float:4.2535896E21)
            int r2 = X.AnonymousClass0BS.A03(r0)
            r4 = r18
            com.facebook.profilo.ipc.TraceContext r5 = r4.mEnablingContext
            r3 = 0
            if (r5 != 0) goto L_0x0080
            r8 = 0
            r9 = 0
        L_0x0010:
            r0 = 1
            if (r5 == 0) goto L_0x001e
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.detail_fd"
            boolean r1 = r6.A02(r1, r0)
            r11 = 0
            if (r1 == 0) goto L_0x0021
        L_0x001e:
            r11 = 1
            if (r5 == 0) goto L_0x002c
        L_0x0021:
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.log_unmapping"
            boolean r1 = r6.A02(r1, r0)
            r12 = 0
            if (r1 == 0) goto L_0x002d
        L_0x002c:
            r12 = 1
        L_0x002d:
            r7 = 256(0x100, float:3.59E-43)
            if (r5 != 0) goto L_0x006c
            r13 = 256(0x100, float:3.59E-43)
        L_0x0033:
            r14 = 0
            if (r5 == 0) goto L_0x0041
        L_0x0036:
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.use_lock_free_queue_async_unwinder"
            boolean r1 = r6.A02(r1, r0)
            r15 = 1
            if (r1 != 0) goto L_0x0063
        L_0x0041:
            r15 = 0
            if (r5 != 0) goto L_0x0063
            r16 = 0
        L_0x0046:
            if (r8 == 0) goto L_0x005e
            if (r5 == 0) goto L_0x005e
            com.facebook.profilo.mmapbuf.core.Buffer r5 = r5.A09
            java.lang.String r1 = r5.getFilePath()
            if (r1 == 0) goto L_0x005e
            java.lang.String r10 = r5.generateMemoryMappingFilePath()
            java.lang.String r17 = r5.generateLocalSymbolsFilePath()
        L_0x005a:
            java.lang.Class<X.0UR> r6 = X.AnonymousClass0UR.class
            monitor-enter(r6)
            goto L_0x0091
        L_0x005e:
            r17 = 0
            r10 = r17
            goto L_0x005a
        L_0x0063:
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.async_unwinder_thread_priority"
            int r16 = r6.A00(r1, r3)
            goto L_0x0046
        L_0x006c:
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.async_unwinder_queue_size"
            int r13 = r6.A00(r1, r7)
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r5.A08
            java.lang.String r1 = "provider.memory_mapping_actions.share_async_unwinder_thread"
            boolean r1 = r6.A02(r1, r3)
            r14 = 1
            if (r1 != 0) goto L_0x0036
            goto L_0x0033
        L_0x0080:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r5.A08
            java.lang.String r0 = "provider.memory_mapping_actions.unwinder_type"
            int r8 = r1.A00(r0, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r5.A08
            java.lang.String r0 = "provider.memory_mapping_actions.max_unwind_depth"
            int r9 = r1.A00(r0, r3)
            goto L_0x0010
        L_0x0091:
            X.AnonymousClass0UR.A0A = r0     // Catch:{ all -> 0x00dd }
            X.AnonymousClass0UR.A06 = r0     // Catch:{ all -> 0x00dd }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x00dd }
            monitor-exit(r6)
            com.facebook.profilo.logger.MultiBufferLogger r7 = r4.getLogger()     // Catch:{ RuntimeException -> 0x00a6 }
            nativeStartProfiling(r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17)     // Catch:{ RuntimeException -> 0x00a6 }
            r4.isProfiling = r0
            r0 = 596278585(0x238a7d39, float:1.5015024E-17)
            goto L_0x00d6
        L_0x00a6:
            r0 = move-exception
            java.lang.String r5 = r0.getMessage()
            monitor-enter(r6)
            X.0UQ r0 = X.AnonymousClass0UR.A00     // Catch:{ all -> 0x00da }
            if (r0 == 0) goto L_0x00cb
            com.facebook.quicklog.QuickPerformanceLogger r4 = r0.A00     // Catch:{ all -> 0x00da }
            r1 = 21375349(0x1462975, float:3.63966E-38)
            java.lang.String r0 = "mappings_provider"
            com.facebook.quicklog.EventBuilder r1 = r4.markEventBuilder(r1, r0)     // Catch:{ all -> 0x00da }
            boolean r0 = r1.isSampled()     // Catch:{ all -> 0x00da }
            if (r0 == 0) goto L_0x00cb
            if (r5 == 0) goto L_0x00c8
            java.lang.String r0 = "error_message"
            r1.annotate((java.lang.String) r0, (java.lang.String) r5)     // Catch:{ all -> 0x00da }
        L_0x00c8:
            r1.report()     // Catch:{ all -> 0x00da }
        L_0x00cb:
            X.AnonymousClass0UR.A0A = r3     // Catch:{ all -> 0x00da }
            X.AnonymousClass0UR.A06 = r3     // Catch:{ all -> 0x00da }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x00da }
            monitor-exit(r6)
            r0 = 849709483(0x32a589ab, float:1.9271132E-8)
        L_0x00d6:
            X.AnonymousClass0BS.A09(r0, r2)
            return
        L_0x00da:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x00da }
            throw r0
        L_0x00dd:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x00dd }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.memorymappings.MemoryMappingActionsProvider.enable():void");
    }

    public int getSupportedProviders() {
        return PROVIDER_MAPPINGS;
    }
}
