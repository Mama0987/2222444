package com.facebook.profilo.provider.aslsession;

import X.AnonymousClass002;
import X.AnonymousClass0E1;
import X.C14840qS;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.ipc.TraceContext;

public final class AslSessionIdProvider extends AnonymousClass0E1 {
    public AslSessionIdProvider() {
        super((String) null, (Runnable) null);
    }

    static {
        ProvidersRegistry.A00.A02("asl_session");
    }

    public final void A01(TraceContext traceContext) {
        AnonymousClass002.A0f(traceContext.A09, "Asl Session Id", C14840qS.A03(), 8134124);
    }
}
