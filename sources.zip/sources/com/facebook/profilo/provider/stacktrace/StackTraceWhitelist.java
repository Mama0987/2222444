package com.facebook.profilo.provider.stacktrace;

import X.C18440x7;

public class StackTraceWhitelist {
    public static native void nativeAddToWhitelist(int i);

    public static native void nativeRemoveFromWhitelist(int i);

    static {
        C18440x7.loadLibrary("profilo_stacktrace");
    }
}
