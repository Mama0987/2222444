package com.facebook.profilo.provider.stacktrace;

import X.AnonymousClass001;
import X.AnonymousClass00X;
import X.AnonymousClass0BS;
import X.C03450Gz;
import X.C19180z7;
import X.C19190z8;
import android.app.Application;
import android.content.Context;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class StackFrameThread extends C19180z7 {
    public static final int PROVIDER_NATIVE_STACK_TRACE;
    public static final int PROVIDER_STACK_FRAME;
    public static final int PROVIDER_WALL_TIME_STACK_TRACE;
    public final Context mContext;
    public volatile boolean mEnabled;
    public Thread mProfilerThread;
    public TraceContext mSavedTraceContext;
    public int mSystemClockTimeIntervalMs = -1;

    public static native int nativeCpuClockResolutionMicros();

    static {
        C19190z8 r1 = ProvidersRegistry.A00;
        PROVIDER_STACK_FRAME = r1.A02("stack_trace");
        PROVIDER_WALL_TIME_STACK_TRACE = r1.A02("wall_time_stack_trace");
        PROVIDER_NATIVE_STACK_TRACE = r1.A02("native_stack_trace");
    }

    public StackFrameThread(Context context) {
        super("profilo_stacktrace", new AnonymousClass00X());
        Context applicationContext = context.getApplicationContext();
        if (applicationContext != null || !(context instanceof Application)) {
            this.mContext = applicationContext;
        } else {
            this.mContext = context;
        }
    }

    public int getSupportedProviders() {
        return PROVIDER_NATIVE_STACK_TRACE | PROVIDER_STACK_FRAME | PROVIDER_WALL_TIME_STACK_TRACE;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0015, code lost:
        if ((r2 & r1) != 0) goto L_0x0017;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getTracingProviders() {
        /*
            r4 = this;
            com.facebook.profilo.ipc.TraceContext r1 = r4.mSavedTraceContext
            boolean r0 = r4.mEnabled
            r3 = 0
            if (r0 == 0) goto L_0x001d
            if (r1 == 0) goto L_0x001d
            int r2 = r1.A02
            int r1 = PROVIDER_WALL_TIME_STACK_TRACE
            r0 = r2 & r1
            if (r0 != 0) goto L_0x0017
            int r1 = PROVIDER_STACK_FRAME
            r0 = r2 & r1
            if (r0 == 0) goto L_0x0018
        L_0x0017:
            r3 = r3 | r1
        L_0x0018:
            int r0 = PROVIDER_NATIVE_STACK_TRACE
            r2 = r2 & r0
            r2 = r2 | r3
            return r2
        L_0x001d:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.stacktrace.StackFrameThread.getTracingProviders():int");
    }

    public void disable() {
        int i;
        int A03 = AnonymousClass0BS.A03(-1136144109);
        if (!this.mEnabled) {
            this.mProfilerThread = null;
            i = 1610381143;
        } else {
            this.mSavedTraceContext = null;
            this.mEnabled = false;
            synchronized (CPUProfiler.class) {
                if (CPUProfiler.sInitialized) {
                    CPUProfiler.nativeStopProfiling();
                }
            }
            Thread thread = this.mProfilerThread;
            if (thread != null) {
                try {
                    thread.join();
                    this.mProfilerThread = null;
                } catch (InterruptedException e) {
                    RuntimeException A0X = AnonymousClass001.A0X(e);
                    AnonymousClass0BS.A09(-831141173, A03);
                    throw A0X;
                }
            }
            i = -1057524221;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:698)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:698)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:698)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00e2  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00e9  */
    public void enable() {
        /*
            r24 = this;
            r0 = 1018280768(0x3cb1bb40, float:0.021695733)
            int r5 = X.AnonymousClass0BS.A03(r0)
            r2 = r24
            com.facebook.profilo.ipc.TraceContext r1 = r2.mEnablingContext
            int r4 = r1.A02
            int r15 = PROVIDER_STACK_FRAME
            int r14 = PROVIDER_WALL_TIME_STACK_TRACE
            r0 = r15 | r14
            r0 = r0 & r4
            r3 = 0
            if (r0 == 0) goto L_0x0019
            r3 = 32752(0x7ff0, float:4.5895E-41)
        L_0x0019:
            int r0 = PROVIDER_NATIVE_STACK_TRACE
            r4 = r4 & r0
            if (r4 == 0) goto L_0x0020
            r3 = r3 | 4
        L_0x0020:
            if (r3 != 0) goto L_0x0029
            r0 = 813362116(0x307aebc4, float:9.1284513E-10)
        L_0x0025:
            X.AnonymousClass0BS.A09(r0, r5)
            return
        L_0x0029:
            java.lang.Thread r0 = r2.mProfilerThread
            if (r0 == 0) goto L_0x0038
            java.lang.String r1 = "StackFrameThread"
            java.lang.String r0 = "Duplicate attempt to enable sampling profiler."
            android.util.Log.e(r1, r0)
            r0 = -769628773(0xffffffffd220659b, float:-1.72224856E11)
            goto L_0x0025
        L_0x0038:
            com.facebook.profilo.ipc.TraceConfigExtras r3 = r1.A08
            java.lang.String r0 = "provider.stack_trace.time_source"
            java.lang.String r3 = r3.A01(r0)
            r13 = r2
            if (r3 == 0) goto L_0x0061
            int r0 = r3.length()
            if (r0 == 0) goto L_0x0061
            java.util.Locale r0 = java.util.Locale.US     // Catch:{ IllegalArgumentException -> 0x0054 }
            java.lang.String r0 = r3.toUpperCase(r0)     // Catch:{ IllegalArgumentException -> 0x0054 }
            X.0zs r11 = X.C19490zs.valueOf(r0)     // Catch:{ IllegalArgumentException -> 0x0054 }
            goto L_0x0063
        L_0x0054:
            r4 = move-exception
            java.lang.String r3 = "StackFrameThread"
            java.lang.String r0 = r4.getMessage()
            android.util.Log.e(r3, r0, r4)
            X.0zs r11 = X.C19490zs.NONE
            goto L_0x0063
        L_0x0061:
            X.0zs r11 = X.C19490zs.NONE
        L_0x0063:
            com.facebook.profilo.ipc.TraceConfigExtras r4 = r1.A08
            java.lang.String r3 = "provider.stack_trace.cpu_sampling_rate_ms"
            r0 = 0
            int r4 = r4.A00(r3, r0)
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r1.A08
            java.lang.String r3 = "provider.stack_trace.thread_detect_interval_ms"
            int r9 = r6.A00(r3, r0)
            int r7 = r1.A02
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r1.A08
            java.lang.String r3 = "provider.native_stack_trace.unwind_dex_frames"
            boolean r18 = r6.A02(r3, r0)
            com.facebook.profilo.ipc.TraceConfigExtras r8 = r1.A08
            java.lang.String r6 = "provider.native_stack_trace.unwind_jit_frames"
            r3 = 1
            boolean r19 = r8.A02(r6, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r8 = r1.A08
            java.lang.String r6 = "provider.native_stack_trace.unwinder_thread_pri"
            r3 = 5
            int r20 = r8.A00(r6, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r8 = r1.A08
            java.lang.String r6 = "provider.native_stack_trace.unwinder_queue_size"
            r3 = 256(0x100, float:3.59E-43)
            int r21 = r8.A00(r6, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r1.A08
            java.lang.String r3 = "provider.native_stack_trace.log_partial_stacks"
            boolean r22 = r6.A02(r3, r0)
            com.facebook.profilo.ipc.TraceConfigExtras r6 = r1.A08
            java.lang.String r3 = "provider.stack_trace.allow_pause_resume"
            boolean r23 = r6.A02(r3, r0)
            monitor-enter(r13)
            android.content.Context r3 = r2.mContext     // Catch:{ Exception -> 0x013e }
            com.facebook.profilo.logger.MultiBufferLogger r17 = r2.getLogger()     // Catch:{ Exception -> 0x013e }
            r16 = r3
            boolean r3 = com.facebook.profilo.provider.stacktrace.CPUProfiler.init(r16, r17, r18, r19, r20, r21, r22, r23)     // Catch:{ Exception -> 0x013e }
            if (r3 == 0) goto L_0x0148
            r10 = 23
            if (r4 > 0) goto L_0x00bf
            r4 = 23
        L_0x00bf:
            if (r9 <= 0) goto L_0x00c2
            r10 = r9
        L_0x00c2:
            r8 = r14 & r7
            r6 = 1
            r3 = 3
            if (r8 != 0) goto L_0x00db
            int r8 = r11.ordinal()     // Catch:{ all -> 0x0153 }
            if (r8 == r3) goto L_0x00d9
            if (r8 == r6) goto L_0x00db
            if (r8 == r0) goto L_0x00d6
            r3 = 2
            r9 = 0
            if (r8 != r3) goto L_0x00d7
        L_0x00d6:
            r9 = 1
        L_0x00d7:
            r12 = 0
            goto L_0x00dd
        L_0x00d9:
            r9 = 1
            goto L_0x00dc
        L_0x00db:
            r9 = 0
        L_0x00dc:
            r12 = 1
        L_0x00dd:
            r15 = r15 | r14
            r15 = r15 & r7
            r11 = 0
            if (r15 == 0) goto L_0x00e4
            r11 = 32752(0x7ff0, float:4.5895E-41)
        L_0x00e4:
            int r3 = PROVIDER_NATIVE_STACK_TRACE     // Catch:{ all -> 0x0153 }
            r7 = r7 & r3
            if (r7 == 0) goto L_0x00eb
            r11 = r11 | 4
        L_0x00eb:
            java.lang.Class<com.facebook.profilo.provider.stacktrace.CPUProfiler> r8 = com.facebook.profilo.provider.stacktrace.CPUProfiler.class
            monitor-enter(r8)     // Catch:{ all -> 0x0153 }
            r7 = 0
            if (r9 != 0) goto L_0x00f4
            if (r12 != 0) goto L_0x00f4
            goto L_0x0106
        L_0x00f4:
            int r3 = android.os.Process.myPid()     // Catch:{ all -> 0x014e }
            com.facebook.profilo.provider.stacktrace.StackTraceWhitelist.nativeAddToWhitelist(r3)     // Catch:{ all -> 0x014e }
            boolean r3 = com.facebook.profilo.provider.stacktrace.CPUProfiler.sInitialized     // Catch:{ all -> 0x014e }
            if (r3 == 0) goto L_0x0106
            boolean r3 = com.facebook.profilo.provider.stacktrace.CPUProfiler.nativeStartProfiling(r11, r4, r10, r9, r12)     // Catch:{ all -> 0x014e }
            if (r3 == 0) goto L_0x0106
            r7 = 1
        L_0x0106:
            monitor-exit(r8)     // Catch:{ all -> 0x0153 }
            if (r7 == 0) goto L_0x0148
            com.facebook.profilo.logger.MultiBufferLogger r14 = r2.getLogger()     // Catch:{ all -> 0x0153 }
            long r3 = (long) r4     // Catch:{ all -> 0x0153 }
            r15 = 6
            r16 = 52
            r17 = 0
            r20 = 8126495(0x7c001f, float:1.1387645E-38)
            r19 = r0
            r21 = r0
            r22 = r3
            r14.writeStandardEntry(r15, r16, r17, r19, r20, r21, r22)     // Catch:{ all -> 0x0153 }
            r2.mEnabled = r6     // Catch:{ all -> 0x0153 }
            boolean r0 = r2.mEnabled     // Catch:{ all -> 0x0153 }
            monitor-exit(r13)
            if (r0 == 0) goto L_0x0149
            r2.mSavedTraceContext = r1
            X.0zq r3 = new X.0zq
            r3.<init>(r2)
            java.lang.String r1 = "Prflo:Profiler"
            java.lang.Thread r0 = new java.lang.Thread
            r0.<init>(r3, r1)
            r2.mProfilerThread = r0
            r0.start()
            r0 = -158407692(0xfffffffff68ee3f4, float:-1.4490812E33)
            goto L_0x0025
        L_0x013e:
            r2 = move-exception
            java.lang.String r1 = "StackFrameThread"
            java.lang.String r0 = r2.getMessage()     // Catch:{ all -> 0x0151 }
            android.util.Log.e(r1, r0, r2)     // Catch:{ all -> 0x0151 }
        L_0x0148:
            monitor-exit(r13)
        L_0x0149:
            r0 = 169862066(0xa1fe3b2, float:7.698396E-33)
            goto L_0x0025
        L_0x014e:
            r0 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x014e }
            goto L_0x0152
        L_0x0151:
            r0 = move-exception
        L_0x0152:
            throw r0     // Catch:{ all -> 0x0153 }
        L_0x0153:
            r0 = move-exception
            monitor-exit(r13)     // Catch:{ all -> 0x0153 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.stacktrace.StackFrameThread.enable():void");
    }

    public void onTraceEnded(TraceContext traceContext, C03450Gz r20) {
        int i;
        int A03 = AnonymousClass0BS.A03(-80213858);
        TraceContext traceContext2 = traceContext;
        int i2 = traceContext2.A02;
        int i3 = PROVIDER_STACK_FRAME;
        int i4 = PROVIDER_WALL_TIME_STACK_TRACE;
        if ((i2 & (i3 | i4)) != 0) {
            String bool = Boolean.toString(ArtCompatibility.isCompatible(this.mContext));
            MultiBufferLogger logger = getLogger();
            C19180z7.A01(logger, "provider.stack_trace.art_compatibility", bool, logger.writeStandardEntry(6, 52, 0, 0, 0, 0, 0));
            int i5 = traceContext2.A02;
            int i6 = 0;
            if (((i3 | i4) & i5) != 0) {
                i6 = 32752;
            }
            if ((i5 & PROVIDER_NATIVE_STACK_TRACE) != 0) {
                i6 |= 4;
            }
            synchronized (CPUProfiler.class) {
                i = CPUProfiler.sAvailableTracers;
            }
            String binaryString = Integer.toBinaryString(i6 & i);
            MultiBufferLogger logger2 = getLogger();
            C19180z7.A01(logger2, "provider.stack_trace.tracers", binaryString, logger2.writeStandardEntry(6, 52, 0, 0, 0, 0, 0));
        }
        if ((traceContext2.A02 & getSupportedProviders()) != 0) {
            String num = Integer.toString(nativeCpuClockResolutionMicros());
            MultiBufferLogger logger3 = getLogger();
            C19180z7.A01(logger3, "provider.stack_trace.cpu_timer_res_us", num, logger3.writeStandardEntry(6, 52, 0, 0, 0, 0, 0));
        }
        AnonymousClass0BS.A09(1439812052, A03);
    }

    public void onTraceStarted(TraceContext traceContext, C03450Gz r4) {
        int A03 = AnonymousClass0BS.A03(-51282705);
        if (CPUProfiler.sInitialized) {
            CPUProfiler.nativeResetFrameworkNamesSet();
        }
        AnonymousClass0BS.A09(2081947076, A03);
    }
}
