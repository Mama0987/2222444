package com.facebook.profilo.provider.memory;

import X.AnonymousClass0BS;
import X.AnonymousClass0Dl;
import X.AnonymousClass0Dv;
import X.AnonymousClass0UR;
import X.C000200e;
import X.C02790Dw;
import X.C03450Gz;
import X.C18840yG;
import X.C18870yK;
import X.C18890yM;
import X.C19180z7;
import X.C19350zb;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class MemoryAllocationProvider extends C19180z7 implements AnonymousClass0Dv, C02790Dw, AnonymousClass0Dl {
    public static final int PROVIDER_MEMORY = ProvidersRegistry.A00.A02("memory_allocation");
    public C18890yM mDeallocationMonitor;
    public String mErrorMessage;
    public boolean mIsFileBackedBuffer;
    public C19350zb mProviderTriggerMonitor;
    public boolean mRunning = false;
    public boolean mStarted = false;

    public static native void nativeAddPhantomReferenceLoop();

    public static native int nativeInitialize(Object obj, Object obj2, MultiBufferLogger multiBufferLogger, int i, int i2, int i3, int i4, int i5, boolean z, String str, int i6, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, int i7, int i8, boolean z7, boolean z8, int i9, String str2, boolean z9, int i10, String str3, boolean z10);

    public static native boolean nativeIsTracingEnabled();

    public static native void nativeRegisterDeallocation(long[] jArr, int i);

    public static native void nativeResetFrameworkNamesSet();

    public static native void nativeStartProfiling();

    public static native void nativeStopAddPhantomThread();

    public static native void nativeStopProfiling();

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x000f, code lost:
        r0.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0012, code lost:
        nativeStartProfiling();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0017, code lost:
        if (r2.mIsFileBackedBuffer == false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001b, code lost:
        if (X.C14840qS.A05 == null) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x001d, code lost:
        r1 = X.C14840qS.A05.A0E;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0021, code lost:
        if (r1 == null) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
        X.AnonymousClass001.A0D(r1, "javamp").createNewFile();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x000b, code lost:
        r0 = r2.mDeallocationMonitor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x000d, code lost:
        if (r0 == null) goto L_0x0012;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void startProfiling() {
        /*
            r2 = this;
            monitor-enter(r2)
            boolean r0 = r2.mStarted     // Catch:{ all -> 0x002d }
            if (r0 == 0) goto L_0x0007
            monitor-exit(r2)     // Catch:{ all -> 0x002d }
            return
        L_0x0007:
            r0 = 1
            r2.mStarted = r0     // Catch:{ all -> 0x002d }
            monitor-exit(r2)     // Catch:{ all -> 0x002d }
            X.0yM r0 = r2.mDeallocationMonitor
            if (r0 == 0) goto L_0x0012
            r0.A00()
        L_0x0012:
            nativeStartProfiling()
            boolean r0 = r2.mIsFileBackedBuffer
            if (r0 == 0) goto L_0x002c
            X.0u2 r0 = X.C14840qS.A05
            if (r0 == 0) goto L_0x002c
            X.0u2 r0 = X.C14840qS.A05
            java.io.File r1 = r0.A0E
            if (r1 == 0) goto L_0x002c
            java.lang.String r0 = "javamp"
            java.io.File r0 = X.AnonymousClass001.A0D(r1, r0)
            r0.createNewFile()     // Catch:{ IOException -> 0x002c }
        L_0x002c:
            return
        L_0x002d:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x002d }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.memory.MemoryAllocationProvider.startProfiling():void");
    }

    private synchronized void stopTraceIfRunning() {
        if (this.mRunning) {
            nativeStopProfiling();
            C18890yM r2 = this.mDeallocationMonitor;
            if (r2 != null) {
                C18870yK r1 = r2.A01;
                if (r1 != null) {
                    r1.A01 = false;
                    r2.A01 = null;
                }
                C18840yG r0 = r2.A00;
                if (r0 != null) {
                    r0.A00.A04.finishProcessor();
                    r2.A00 = null;
                }
                this.mDeallocationMonitor = null;
            }
            this.mRunning = false;
            this.mStarted = false;
        }
        C19350zb r02 = this.mProviderTriggerMonitor;
        if (r02 != null) {
            r02.A02();
            this.mProviderTriggerMonitor = null;
        }
        synchronized (AnonymousClass0UR.class) {
            AnonymousClass0UR.A05 = false;
            AnonymousClass0UR.A00();
        }
    }

    public MemoryAllocationProvider() {
        super("profilo_memory", new C000200e());
    }

    public void disable() {
        int A03 = AnonymousClass0BS.A03(-526372287);
        stopTraceIfRunning();
        AnonymousClass0BS.A09(502832503, A03);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0252, code lost:
        r1 = r0.A00.markEventBuilder(21375349, "java_provider");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0261, code lost:
        if (r1.isSampled() == false) goto L_0x0272;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x0263, code lost:
        r1.annotate("error_code", r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x0268, code lost:
        if (r3 == null) goto L_0x026f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x026a, code lost:
        r1.annotate("error_message", r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x026f, code lost:
        r1.report();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x0272, code lost:
        X.AnonymousClass0UR.A08 = false;
        X.AnonymousClass0UR.A05 = false;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:?, code lost:
        monitor-exit(r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x027e, code lost:
        r3 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x027f, code lost:
        X.C14270pR.A0J("MemoryAllocationProvider", "Exception while initializing java memory allocation provider.", r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0286, code lost:
        monitor-enter(r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:?, code lost:
        r0 = X.AnonymousClass0UR.A00;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x0289, code lost:
        if (r0 != null) goto L_0x028b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x028b, code lost:
        r2 = r0.A00.markEventBuilder(21375349, "java_provider");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x029a, code lost:
        if (r2.isSampled() != false) goto L_0x029c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:123:0x029c, code lost:
        r2.annotate("exception", r3.toString());
        r2.report();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:124:0x02a8, code lost:
        X.AnonymousClass0UR.A08 = false;
        X.AnonymousClass0UR.A05 = false;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0036, code lost:
        if (r2.A08.A02("provider.memory_allocation.track_deallocation", true) != false) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x004f, code lost:
        if (r2.A08.A02("provider.memory_allocation.share_async_unwinder_thread", false) == false) goto L_0x0051;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0053, code lost:
        if (r2 != null) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0055, code lost:
        r31 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x005f, code lost:
        if (r2.A08.A02("provider.memory_allocation.use_lock_free_queue_async_unwinder", true) == false) goto L_0x0065;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0061, code lost:
        r31 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0063, code lost:
        if (r2 == null) goto L_0x0071;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0065, code lost:
        r30 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x006f, code lost:
        if (r2.A08.A02("provider.memory_allocation.skip_intercepted_refs_step", false) != false) goto L_0x0075;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0071, code lost:
        r30 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0073, code lost:
        if (r2 == null) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0075, code lost:
        r29 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007f, code lost:
        if (r2.A08.A02("provider.memory_allocation.log_async_unwider_queue_stats", false) != false) goto L_0x0085;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0081, code lost:
        r29 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0083, code lost:
        if (r2 == null) goto L_0x0090;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0085, code lost:
        r7 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x008e, code lost:
        if (r2.A08.A02("provider.memory_allocation.use_weak_ref_to_track_deallocation", false) != false) goto L_0x0093;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0090, code lost:
        r7 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0091, code lost:
        if (r2 == null) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0093, code lost:
        r28 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x009d, code lost:
        if (r2.A08.A02("provider.memory_allocation.use_global_weak_ref", false) != false) goto L_0x0139;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x009f, code lost:
        r28 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00a1, code lost:
        if (r2 != null) goto L_0x0139;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00a3, code lost:
        r19 = 0;
        r18 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00a7, code lost:
        r27 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00a9, code lost:
        if (r2 == null) goto L_0x00b7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00ab, code lost:
        r26 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00b5, code lost:
        if (r2.A08.A02("provider.memory_allocation.unwind_jit_frames", true) == false) goto L_0x0130;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00b7, code lost:
        r26 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00b9, code lost:
        if (r2 != null) goto L_0x0130;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00bb, code lost:
        r20 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00bd, code lost:
        r43 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00bf, code lost:
        if (r2 == null) goto L_0x012d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00c1, code lost:
        r25 = r2.A08.A01("provider.memory_allocation.dynamic_sampling_config");
        r24 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00d3, code lost:
        if (r2.A08.A02("provider.memory_allocation.log_async_unwinder_failure", false) != false) goto L_0x00d7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00d5, code lost:
        r24 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00d9, code lost:
        if (r2 != null) goto L_0x0110;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x00db, code lost:
        r21 = com.facebook.common.dextricks.DalvikInternals.ART_HACK_DEX_PC_LINENUM;
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00de, code lost:
        r23 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00e0, code lost:
        r12.mIsFileBackedBuffer = false;
        r1 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x00e3, code lost:
        if (r2 == null) goto L_0x00f1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x00e5, code lost:
        r1 = X.AnonymousClass001.A1U(r2.A09.getFilePath());
        r12.mIsFileBackedBuffer = r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00f2, code lost:
        if (r10 != -1) goto L_0x00fe;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x00f4, code lost:
        r10 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00f5, code lost:
        r58 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00f7, code lost:
        r1 = r12.mIsFileBackedBuffer;
        r22 = X.AnonymousClass0UR.class;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x00fb, code lost:
        monitor-enter(r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x00ff, code lost:
        if (r10 != 3) goto L_0x00f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0101, code lost:
        if (r2 == null) goto L_0x00f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0103, code lost:
        if (r1 == false) goto L_0x00f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0105, code lost:
        r0 = r2.A09;
        r43 = r0.generateMemoryMappingFilePath();
        r58 = r0.generateLocalSymbolsFilePath();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0110, code lost:
        r21 = r2.A08.A00("provider.memory_allocation.max_unwind_depth", com.facebook.common.dextricks.DalvikInternals.ART_HACK_DEX_PC_LINENUM);
        r6 = r2.A08.A00("provider.memory_allocation.when_to_start", 0);
        r23 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x012a, code lost:
        if (r2.A08.A02("provider.memory_allocation.log_allocation_failures", false) != false) goto L_0x00e0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x012d, code lost:
        r25 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0130, code lost:
        r20 = r2.A08.A00("provider.memory_allocation.elements_to_discard_on_unwinder_overflow", 0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0139, code lost:
        r19 = r2.A08.A00("provider.memory_allocation.async_unwinder_thread_priority", 0);
        r18 = r2.A08.A00("provider.memory_allocation.time_auto_process_refs", 0);
        r27 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:0x0153, code lost:
        if (r2.A08.A02("provider.memory_allocation.log_mapping_status_per_frame", false) != false) goto L_0x00ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0172, code lost:
        if (r2.A08.A02("provider.memory_allocation.unwind_stacks", true) != false) goto L_0x001a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:?, code lost:
        r16 = X.C16090sj.A00;
        r4 = X.AnonymousClass001.A0n(120);
        r4.append(r1 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r5, r14, r17);
        X.AnonymousClass002.A0k(r4, ',', r15, r10, r9 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r8, r32 ? 1 : 0, r31 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r30 ? 1 : 0, r29 ? 1 : 0, r28 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r19, r18, r27 ? 1 : 0);
        r4.append(',');
        r4.append(r26 ? 1 : 0);
        r4.append(',');
        r4.append(r20);
        r4.append(",(");
        r4.append(r25);
        r4.append("),");
        r4.append(r24 ? 1 : 0);
        X.AnonymousClass002.A0k(r4, ',', r21, r6, r23 ? 1 : 0);
        r16.A06(X.C14990qj.A6Y, X.C15660rs.CRITICAL_REPORT, r4.toString());
        X.AnonymousClass0UR.A08 = true;
        X.AnonymousClass0UR.A05 = true;
        X.AnonymousClass0UR.A00();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x01f9, code lost:
        monitor-exit(r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x01fa, code lost:
        if (r9 == false) goto L_0x0203;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:?, code lost:
        r12.mDeallocationMonitor = new X.C18890yM(r12, r12, false, r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x0203, code lost:
        r4 = nativeInitialize(r12.mDeallocationMonitor, r12, getLogger(), r5, r14, r17, r15, r10, r9, r43, r8, r32, r31, r30, r29, r28, r19, r18, r27, r26, r20, r25, r24, r21, r58, r23);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x023b, code lost:
        if (r4 != 0) goto L_0x024b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:0x023d, code lost:
        if (r6 != 0) goto L_0x0243;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x023f, code lost:
        startProfiling();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0243, code lost:
        r12.mProviderTriggerMonitor = new X.C19350zb(r12, r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x024b, code lost:
        r3 = r12.mErrorMessage;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x024d, code lost:
        monitor-enter(r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:?, code lost:
        r0 = X.AnonymousClass0UR.A00;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0250, code lost:
        if (r0 == null) goto L_0x0272;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void enable() {
        /*
            r60 = this;
            r0 = -22906218(0xfffffffffea27a96, float:-1.0798572E38)
            int r33 = X.AnonymousClass0BS.A03(r0)
            r12 = r60
            com.facebook.profilo.ipc.TraceContext r2 = r12.mEnablingContext
            r3 = 2
            if (r2 != 0) goto L_0x0182
            r5 = 2
        L_0x000f:
            r11 = 0
            if (r2 != 0) goto L_0x0176
            r14 = 0
        L_0x0013:
            r13 = 1
            if (r2 != 0) goto L_0x0157
            r17 = 0
            r15 = 65536(0x10000, float:9.18355E-41)
        L_0x001a:
            r4 = 1
        L_0x001b:
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 29
            r10 = 1
            if (r1 < r0) goto L_0x0023
            r10 = 3
        L_0x0023:
            if (r2 == 0) goto L_0x0038
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.unwinder_type"
            int r10 = r1.A00(r0, r10)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.track_deallocation"
            boolean r0 = r1.A02(r0, r13)
            r9 = 0
            if (r0 == 0) goto L_0x0039
        L_0x0038:
            r9 = 1
        L_0x0039:
            r8 = 512(0x200, float:7.175E-43)
            if (r2 == 0) goto L_0x0051
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.async_unwinder_queue_size"
            int r8 = r1.A00(r0, r8)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.share_async_unwinder_thread"
            boolean r0 = r1.A02(r0, r11)
            r32 = 1
            if (r0 != 0) goto L_0x0055
        L_0x0051:
            r32 = 0
            if (r2 == 0) goto L_0x0061
        L_0x0055:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.use_lock_free_queue_async_unwinder"
            boolean r0 = r1.A02(r0, r13)
            r31 = 0
            if (r0 == 0) goto L_0x0065
        L_0x0061:
            r31 = 1
            if (r2 == 0) goto L_0x0071
        L_0x0065:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.skip_intercepted_refs_step"
            boolean r0 = r1.A02(r0, r11)
            r30 = 1
            if (r0 != 0) goto L_0x0075
        L_0x0071:
            r30 = 0
            if (r2 == 0) goto L_0x0081
        L_0x0075:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.log_async_unwider_queue_stats"
            boolean r0 = r1.A02(r0, r11)
            r29 = 1
            if (r0 != 0) goto L_0x0085
        L_0x0081:
            r29 = 0
            if (r2 == 0) goto L_0x0090
        L_0x0085:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.use_weak_ref_to_track_deallocation"
            boolean r0 = r1.A02(r0, r11)
            r7 = 1
            if (r0 != 0) goto L_0x0093
        L_0x0090:
            r7 = 0
            if (r2 == 0) goto L_0x009f
        L_0x0093:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.use_global_weak_ref"
            boolean r0 = r1.A02(r0, r11)
            r28 = 1
            if (r0 != 0) goto L_0x0139
        L_0x009f:
            r28 = 0
            if (r2 != 0) goto L_0x0139
            r19 = 0
            r18 = 0
        L_0x00a7:
            r27 = 0
            if (r2 == 0) goto L_0x00b7
        L_0x00ab:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.unwind_jit_frames"
            boolean r0 = r1.A02(r0, r13)
            r26 = 0
            if (r0 == 0) goto L_0x0130
        L_0x00b7:
            r26 = 1
            if (r2 != 0) goto L_0x0130
            r20 = 0
        L_0x00bd:
            r43 = 0
            if (r2 == 0) goto L_0x012d
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.dynamic_sampling_config"
            java.lang.String r25 = r1.A01(r0)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.log_async_unwinder_failure"
            boolean r0 = r1.A02(r0, r11)
            r24 = 1
            if (r0 != 0) goto L_0x00d7
        L_0x00d5:
            r24 = 0
        L_0x00d7:
            r3 = 256(0x100, float:3.59E-43)
            if (r2 != 0) goto L_0x0110
            r21 = 256(0x100, float:3.59E-43)
            r6 = 0
        L_0x00de:
            r23 = 0
        L_0x00e0:
            r12.mIsFileBackedBuffer = r11
            r1 = 0
            if (r2 == 0) goto L_0x00f1
            com.facebook.profilo.mmapbuf.core.Buffer r0 = r2.A09
            java.lang.String r0 = r0.getFilePath()
            boolean r1 = X.AnonymousClass001.A1U(r0)
            r12.mIsFileBackedBuffer = r1
        L_0x00f1:
            r0 = -1
            if (r10 != r0) goto L_0x00fe
            r10 = r4
        L_0x00f5:
            r58 = 0
        L_0x00f7:
            boolean r1 = r12.mIsFileBackedBuffer
            java.lang.Class<X.0UR> r22 = X.AnonymousClass0UR.class
            monitor-enter(r22)
            goto L_0x018c
        L_0x00fe:
            r0 = 3
            if (r10 != r0) goto L_0x00f5
            if (r2 == 0) goto L_0x00f5
            if (r1 == 0) goto L_0x00f5
            com.facebook.profilo.mmapbuf.core.Buffer r0 = r2.A09
            java.lang.String r43 = r0.generateMemoryMappingFilePath()
            java.lang.String r58 = r0.generateLocalSymbolsFilePath()
            goto L_0x00f7
        L_0x0110:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.max_unwind_depth"
            int r21 = r1.A00(r0, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.when_to_start"
            int r6 = r1.A00(r0, r11)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.log_allocation_failures"
            boolean r0 = r1.A02(r0, r11)
            r23 = 1
            if (r0 != 0) goto L_0x00e0
            goto L_0x00de
        L_0x012d:
            r25 = r43
            goto L_0x00d5
        L_0x0130:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.elements_to_discard_on_unwinder_overflow"
            int r20 = r1.A00(r0, r11)
            goto L_0x00bd
        L_0x0139:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.async_unwinder_thread_priority"
            int r19 = r1.A00(r0, r11)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.time_auto_process_refs"
            int r18 = r1.A00(r0, r11)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.log_mapping_status_per_frame"
            boolean r0 = r1.A02(r0, r11)
            r27 = 1
            if (r0 != 0) goto L_0x00ab
            goto L_0x00a7
        L_0x0157:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.big_allocation_sample_rate"
            int r17 = r1.A00(r0, r13)
            r3 = 65536(0x10000, float:9.18355E-41)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.big_allocation_threshold"
            int r15 = r1.A00(r0, r3)
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.unwind_stacks"
            boolean r0 = r1.A02(r0, r13)
            r4 = 0
            if (r0 == 0) goto L_0x001b
            goto L_0x001a
        L_0x0176:
            com.facebook.profilo.ipc.TraceConfigExtras r3 = r2.A08
            java.lang.String r1 = "provider.memory_allocation.small_allocation_sample_rate"
            r0 = 500(0x1f4, float:7.0E-43)
            int r14 = r3.A00(r1, r0)
            goto L_0x0013
        L_0x0182:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r2.A08
            java.lang.String r0 = "provider.memory_allocation.sampling_strategy"
            int r5 = r1.A00(r0, r3)
            goto L_0x000f
        L_0x018c:
            X.0sd r16 = X.C16090sj.A00     // Catch:{ all -> 0x02bc }
            r0 = 120(0x78, float:1.68E-43)
            java.lang.StringBuilder r4 = X.AnonymousClass001.A0n(r0)     // Catch:{ all -> 0x02bc }
            r4.append(r1)     // Catch:{ all -> 0x02bc }
            r3 = 44
            r0 = r17
            X.AnonymousClass002.A0k(r4, r3, r5, r14, r0)     // Catch:{ all -> 0x02bc }
            X.AnonymousClass002.A0k(r4, r3, r15, r10, r9)     // Catch:{ all -> 0x02bc }
            r1 = r32
            r0 = r31
            X.AnonymousClass002.A0k(r4, r3, r8, r1, r0)     // Catch:{ all -> 0x02bc }
            r2 = r30
            r1 = r29
            r0 = r28
            X.AnonymousClass002.A0k(r4, r3, r2, r1, r0)     // Catch:{ all -> 0x02bc }
            r2 = r19
            r1 = r27
            r0 = r18
            X.AnonymousClass002.A0k(r4, r3, r2, r0, r1)     // Catch:{ all -> 0x02bc }
            r4.append(r3)     // Catch:{ all -> 0x02bc }
            r0 = r26
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            r4.append(r3)     // Catch:{ all -> 0x02bc }
            r0 = r20
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            java.lang.String r0 = ",("
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            r0 = r25
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            java.lang.String r0 = "),"
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            r0 = r24
            r4.append(r0)     // Catch:{ all -> 0x02bc }
            r1 = r21
            r0 = r23
            X.AnonymousClass002.A0k(r4, r3, r1, r6, r0)     // Catch:{ all -> 0x02bc }
            com.facebook.errorreporting.field.ReportFieldString r2 = X.C14990qj.A6Y     // Catch:{ all -> 0x02bc }
            java.lang.String r3 = r4.toString()     // Catch:{ all -> 0x02bc }
            X.0rs r1 = X.C15660rs.CRITICAL_REPORT     // Catch:{ all -> 0x02bc }
            r0 = r16
            r0.A06(r2, r1, r3)     // Catch:{ all -> 0x02bc }
            X.AnonymousClass0UR.A08 = r13     // Catch:{ all -> 0x02bc }
            X.AnonymousClass0UR.A05 = r13     // Catch:{ all -> 0x02bc }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x02bc }
            monitor-exit(r22)
            if (r9 == 0) goto L_0x0203
            X.0yM r0 = new X.0yM     // Catch:{ all -> 0x027e }
            r0.<init>(r12, r12, r11, r7)     // Catch:{ all -> 0x027e }
            r12.mDeallocationMonitor = r0     // Catch:{ all -> 0x027e }
        L_0x0203:
            X.0yM r0 = r12.mDeallocationMonitor     // Catch:{ all -> 0x027e }
            com.facebook.profilo.logger.MultiBufferLogger r36 = r12.getLogger()     // Catch:{ all -> 0x027e }
            r40 = r15
            r41 = r10
            r42 = r9
            r44 = r8
            r45 = r32
            r46 = r31
            r47 = r30
            r48 = r29
            r49 = r28
            r50 = r19
            r51 = r18
            r52 = r27
            r53 = r26
            r54 = r20
            r55 = r25
            r56 = r24
            r57 = r21
            r59 = r23
            r34 = r0
            r35 = r12
            r37 = r5
            r38 = r14
            r39 = r17
            int r4 = nativeInitialize(r34, r35, r36, r37, r38, r39, r40, r41, r42, r43, r44, r45, r46, r47, r48, r49, r50, r51, r52, r53, r54, r55, r56, r57, r58, r59)     // Catch:{ all -> 0x027e }
            if (r4 != 0) goto L_0x024b
            if (r6 != 0) goto L_0x0243
            r12.startProfiling()     // Catch:{ all -> 0x027e }
            goto L_0x02b0
        L_0x0243:
            X.0zb r0 = new X.0zb     // Catch:{ all -> 0x027e }
            r0.<init>(r12, r6)     // Catch:{ all -> 0x027e }
            r12.mProviderTriggerMonitor = r0     // Catch:{ all -> 0x027e }
            goto L_0x02b0
        L_0x024b:
            java.lang.String r3 = r12.mErrorMessage     // Catch:{ all -> 0x027e }
            monitor-enter(r22)     // Catch:{ all -> 0x027e }
            X.0UQ r0 = X.AnonymousClass0UR.A00     // Catch:{ all -> 0x027b }
            if (r0 == 0) goto L_0x0272
            com.facebook.quicklog.QuickPerformanceLogger r2 = r0.A00     // Catch:{ all -> 0x027b }
            r1 = 21375349(0x1462975, float:3.63966E-38)
            java.lang.String r0 = "java_provider"
            com.facebook.quicklog.EventBuilder r1 = r2.markEventBuilder(r1, r0)     // Catch:{ all -> 0x027b }
            boolean r0 = r1.isSampled()     // Catch:{ all -> 0x027b }
            if (r0 == 0) goto L_0x0272
            java.lang.String r0 = "error_code"
            r1.annotate((java.lang.String) r0, (int) r4)     // Catch:{ all -> 0x027b }
            if (r3 == 0) goto L_0x026f
            java.lang.String r0 = "error_message"
            r1.annotate((java.lang.String) r0, (java.lang.String) r3)     // Catch:{ all -> 0x027b }
        L_0x026f:
            r1.report()     // Catch:{ all -> 0x027b }
        L_0x0272:
            X.AnonymousClass0UR.A08 = r11     // Catch:{ all -> 0x027b }
            X.AnonymousClass0UR.A05 = r11     // Catch:{ all -> 0x027b }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x027b }
            monitor-exit(r22)     // Catch:{ all -> 0x027e }
            goto L_0x02b0
        L_0x027b:
            r0 = move-exception
            monitor-exit(r22)     // Catch:{ all -> 0x027b }
            throw r0     // Catch:{ all -> 0x027e }
        L_0x027e:
            r3 = move-exception
            java.lang.String r1 = "MemoryAllocationProvider"
            java.lang.String r0 = "Exception while initializing java memory allocation provider."
            X.C14270pR.A0J(r1, r0, r3)
            monitor-enter(r22)
            X.0UQ r0 = X.AnonymousClass0UR.A00     // Catch:{ all -> 0x02b9 }
            if (r0 == 0) goto L_0x02a8
            com.facebook.quicklog.QuickPerformanceLogger r2 = r0.A00     // Catch:{ all -> 0x02b9 }
            r1 = 21375349(0x1462975, float:3.63966E-38)
            java.lang.String r0 = "java_provider"
            com.facebook.quicklog.EventBuilder r2 = r2.markEventBuilder(r1, r0)     // Catch:{ all -> 0x02b9 }
            boolean r0 = r2.isSampled()     // Catch:{ all -> 0x02b9 }
            if (r0 == 0) goto L_0x02a8
            java.lang.String r1 = "exception"
            java.lang.String r0 = r3.toString()     // Catch:{ all -> 0x02b9 }
            r2.annotate((java.lang.String) r1, (java.lang.String) r0)     // Catch:{ all -> 0x02b9 }
            r2.report()     // Catch:{ all -> 0x02b9 }
        L_0x02a8:
            X.AnonymousClass0UR.A08 = r11     // Catch:{ all -> 0x02b9 }
            X.AnonymousClass0UR.A05 = r11     // Catch:{ all -> 0x02b9 }
            X.AnonymousClass0UR.A00()     // Catch:{ all -> 0x02b9 }
            monitor-exit(r22)
        L_0x02b0:
            r1 = 65702128(0x3ea88f0, float:1.3784723E-36)
            r0 = r33
            X.AnonymousClass0BS.A09(r1, r0)
            return
        L_0x02b9:
            r0 = move-exception
            monitor-exit(r22)     // Catch:{ all -> 0x02b9 }
            throw r0
        L_0x02bc:
            r0 = move-exception
            monitor-exit(r22)     // Catch:{ all -> 0x02bc }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.memory.MemoryAllocationProvider.enable():void");
    }

    public void finishProcessor() {
        nativeStopAddPhantomThread();
    }

    public int getSupportedProviders() {
        return PROVIDER_MEMORY;
    }

    public int getTracingProviders() {
        if (!nativeIsTracingEnabled()) {
            return 0;
        }
        int i = PROVIDER_MEMORY;
        if (TraceEvents.isEnabled(i)) {
            return i;
        }
        return 0;
    }

    public void onTraceEnded(TraceContext traceContext, C03450Gz r4) {
        int A03 = AnonymousClass0BS.A03(543012337);
        stopTraceIfRunning();
        AnonymousClass0BS.A09(1232010347, A03);
    }

    public void onTraceStarted(TraceContext traceContext, C03450Gz r5) {
        int A03 = AnonymousClass0BS.A03(331605494);
        super.onTraceStarted(traceContext, r5);
        synchronized (this) {
            try {
                this.mRunning = true;
                nativeResetFrameworkNamesSet();
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(2099817828, A03);
                    throw th;
                }
            }
        }
        AnonymousClass0BS.A09(1400048898, A03);
    }

    public void onTrigger() {
        startProfiling();
    }

    public void startProcessor() {
        nativeAddPhantomReferenceLoop();
    }

    public void setErrorMessage(String str) {
        this.mErrorMessage = str;
    }

    public void onDeallocation(long[] jArr, String[] strArr, int i) {
        nativeRegisterDeallocation(jArr, i);
    }
}
