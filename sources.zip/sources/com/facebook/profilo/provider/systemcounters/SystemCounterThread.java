package com.facebook.profilo.provider.systemcounters;

import X.AnonymousClass00Z;
import X.AnonymousClass0BS;
import X.C000000a;
import X.C19180z7;
import X.C19190z8;
import X.C19500zt;
import X.C19520zv;
import android.os.Debug;
import com.facebook.jni.HybridData;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.logger.MultiBufferLogger;

public final class SystemCounterThread extends C19180z7 {
    public static final int PROVIDER_HIGH_FREQ_THREAD_COUNTERS;
    public static final int PROVIDER_SYSTEM_COUNTERS;
    public boolean mAllThreadsMode;
    public final AnonymousClass00Z mCounterCollector;
    public boolean mEnabled;
    public volatile boolean mHighFrequencyMode;
    public HybridData mHybridData;
    public boolean mLogAllocationStats;
    public C19500zt mSystemCounterLogger;
    public C19520zv mSystemCounterTrigger;

    private native HybridData initHybrid(MultiBufferLogger multiBufferLogger);

    public static native void nativeAddToWhitelist(int i);

    public static native void nativeRemoveFromWhitelist(int i);

    public synchronized void disable() {
        C19500zt r0;
        int A03 = AnonymousClass0BS.A03(493192633);
        if (this.mEnabled && this.mSystemCounterTrigger != null) {
            if (this.mLogAllocationStats && (r0 = this.mSystemCounterLogger) != null) {
                r0.A01();
            }
            if (this.mAllThreadsMode) {
                logCounters();
                logExpensiveCounters();
            }
            if (this.mHighFrequencyMode) {
                logHighFrequencyThreadCounters();
                logTraceAnnotations();
            }
        }
        C19520zv r3 = this.mSystemCounterTrigger;
        if (r3 != null) {
            synchronized (r3.A03) {
                r3.A00 = false;
                r3.A02.quit();
            }
            this.mSystemCounterTrigger = null;
        } else {
            stopNativeThreadScheduler(this.mAllThreadsMode);
        }
        this.mEnabled = false;
        this.mAllThreadsMode = false;
        this.mHighFrequencyMode = false;
        nativeSetHighFrequencyMode(false);
        HybridData hybridData = this.mHybridData;
        if (hybridData != null) {
            hybridData.resetNative();
            this.mHybridData = null;
        }
        if (this.mLogAllocationStats) {
            Debug.stopAllocCounting();
        }
        AnonymousClass0BS.A09(1054018765, A03);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0017, code lost:
        if (r7.A08.A02("provider.system_counters.log_allocation_stats", true) != false) goto L_0x0019;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void enable() {
        /*
            r9 = this;
            monitor-enter(r9)
            r0 = -158531286(0xfffffffff68d012a, float:-1.429956E33)
            int r4 = X.AnonymousClass0BS.A03(r0)     // Catch:{ all -> 0x00f5 }
            com.facebook.profilo.ipc.TraceContext r7 = r9.mEnablingContext     // Catch:{ all -> 0x00f5 }
            r6 = 0
            r8 = 1
            if (r7 == 0) goto L_0x0019
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08     // Catch:{ all -> 0x00f5 }
            java.lang.String r0 = "provider.system_counters.log_allocation_stats"
            boolean r1 = r1.A02(r0, r8)     // Catch:{ all -> 0x00f5 }
            r0 = 0
            if (r1 == 0) goto L_0x001a
        L_0x0019:
            r0 = 1
        L_0x001a:
            r9.mLogAllocationStats = r0     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x002d
            X.0zt r0 = r9.mSystemCounterLogger     // Catch:{ all -> 0x00f5 }
            if (r0 != 0) goto L_0x002d
            com.facebook.profilo.logger.MultiBufferLogger r1 = r9.getLogger()     // Catch:{ all -> 0x00f5 }
            X.0zt r0 = new X.0zt     // Catch:{ all -> 0x00f5 }
            r0.<init>(r1)     // Catch:{ all -> 0x00f5 }
            r9.mSystemCounterLogger = r0     // Catch:{ all -> 0x00f5 }
        L_0x002d:
            com.facebook.profilo.logger.MultiBufferLogger r0 = r9.getLogger()     // Catch:{ all -> 0x00f5 }
            com.facebook.jni.HybridData r0 = r9.initHybrid(r0)     // Catch:{ all -> 0x00f5 }
            r9.mHybridData = r0     // Catch:{ all -> 0x00f5 }
            r9.mEnabled = r8     // Catch:{ all -> 0x00f5 }
            if (r7 == 0) goto L_0x004c
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08     // Catch:{ all -> 0x00f5 }
            java.lang.String r0 = "provider.system_counters.use_native_thread_scheduler"
            boolean r0 = r1.A02(r0, r6)     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x004c
            r0 = 0
            r9.mSystemCounterTrigger = r0     // Catch:{ all -> 0x00f5 }
            r9.initNativeThreadScheduler()     // Catch:{ all -> 0x00f5 }
            goto L_0x0053
        L_0x004c:
            X.0zv r0 = new X.0zv     // Catch:{ all -> 0x00f5 }
            r0.<init>(r9)     // Catch:{ all -> 0x00f5 }
            r9.mSystemCounterTrigger = r0     // Catch:{ all -> 0x00f5 }
        L_0x0053:
            int r0 = PROVIDER_SYSTEM_COUNTERS     // Catch:{ all -> 0x00f5 }
            boolean r0 = com.facebook.profilo.core.TraceEvents.isEnabled(r0)     // Catch:{ all -> 0x00f5 }
            r2 = -1
            if (r0 == 0) goto L_0x0095
            r9.mHighFrequencyMode = r6     // Catch:{ all -> 0x00f5 }
            r9.nativeSetHighFrequencyMode(r6)     // Catch:{ all -> 0x00f5 }
            r9.mAllThreadsMode = r8     // Catch:{ all -> 0x00f5 }
            boolean r0 = r9.mLogAllocationStats     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x0084
            android.os.Debug.startAllocCounting()     // Catch:{ all -> 0x00f5 }
            X.0zt r3 = r9.mSystemCounterLogger     // Catch:{ all -> 0x00f5 }
            if (r3 == 0) goto L_0x0084
            r0 = 0
            r3.A00 = r0     // Catch:{ all -> 0x00f5 }
            r3.A01 = r0     // Catch:{ all -> 0x00f5 }
            r3.A04 = r0     // Catch:{ all -> 0x00f5 }
            r3.A05 = r0     // Catch:{ all -> 0x00f5 }
            r3.A02 = r0     // Catch:{ all -> 0x00f5 }
            r3.A03 = r0     // Catch:{ all -> 0x00f5 }
            r3.A06 = r0     // Catch:{ all -> 0x00f5 }
            r3.A07 = r0     // Catch:{ all -> 0x00f5 }
            r3.A08 = r0     // Catch:{ all -> 0x00f5 }
            r3.A09 = r0     // Catch:{ all -> 0x00f5 }
        L_0x0084:
            r5 = 50
            if (r7 == 0) goto L_0x0090
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08     // Catch:{ all -> 0x00f5 }
            java.lang.String r0 = "provider.system_counters.sampling_rate_ms"
            int r5 = r1.A00(r0, r5)     // Catch:{ all -> 0x00f5 }
        L_0x0090:
            r3 = 1000(0x3e8, float:1.401E-42)
            if (r7 == 0) goto L_0x00a0
            goto L_0x0098
        L_0x0095:
            r5 = -1
            r3 = -1
            goto L_0x00b9
        L_0x0098:
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08     // Catch:{ all -> 0x00f5 }
            java.lang.String r0 = "provider.system_counters.expensive_sampling_rate_ms"
            int r3 = r1.A00(r0, r3)     // Catch:{ all -> 0x00f5 }
        L_0x00a0:
            X.0zv r0 = r9.mSystemCounterTrigger     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x00b9
            android.os.Handler r0 = r0.A01     // Catch:{ all -> 0x00f5 }
            android.os.Message r0 = r0.obtainMessage(r8, r5, r6)     // Catch:{ all -> 0x00f5 }
            r0.sendToTarget()     // Catch:{ all -> 0x00f5 }
            X.0zv r0 = r9.mSystemCounterTrigger     // Catch:{ all -> 0x00f5 }
            android.os.Handler r1 = r0.A01     // Catch:{ all -> 0x00f5 }
            r0 = 3
            android.os.Message r0 = r1.obtainMessage(r0, r3, r6)     // Catch:{ all -> 0x00f5 }
            r0.sendToTarget()     // Catch:{ all -> 0x00f5 }
        L_0x00b9:
            int r0 = PROVIDER_HIGH_FREQ_THREAD_COUNTERS     // Catch:{ all -> 0x00f5 }
            boolean r0 = com.facebook.profilo.core.TraceEvents.isEnabled(r0)     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x00e6
            int r0 = android.os.Process.myPid()     // Catch:{ all -> 0x00f5 }
            X.C19510zu.A00(r0)     // Catch:{ all -> 0x00f5 }
            r9.mHighFrequencyMode = r8     // Catch:{ all -> 0x00f5 }
            r9.nativeSetHighFrequencyMode(r8)     // Catch:{ all -> 0x00f5 }
            r2 = 7
            if (r7 == 0) goto L_0x00d8
            com.facebook.profilo.ipc.TraceConfigExtras r1 = r7.A08     // Catch:{ all -> 0x00f5 }
            java.lang.String r0 = "provider.high_freq_main_thread_counters.sampling_rate_ms"
            int r2 = r1.A00(r0, r2)     // Catch:{ all -> 0x00f5 }
        L_0x00d8:
            X.0zv r0 = r9.mSystemCounterTrigger     // Catch:{ all -> 0x00f5 }
            if (r0 == 0) goto L_0x00e6
            android.os.Handler r1 = r0.A01     // Catch:{ all -> 0x00f5 }
            r0 = 2
            android.os.Message r0 = r1.obtainMessage(r0, r5, r6)     // Catch:{ all -> 0x00f5 }
            r0.sendToTarget()     // Catch:{ all -> 0x00f5 }
        L_0x00e6:
            X.0zv r0 = r9.mSystemCounterTrigger     // Catch:{ all -> 0x00f5 }
            if (r0 != 0) goto L_0x00ed
            r9.triggerSystemCounterCollection(r5, r3, r2)     // Catch:{ all -> 0x00f5 }
        L_0x00ed:
            r0 = -1242989419(0xffffffffb5e97c95, float:-1.7396111E-6)
            X.AnonymousClass0BS.A09(r0, r4)     // Catch:{ all -> 0x00f5 }
            monitor-exit(r9)
            return
        L_0x00f5:
            r0 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x00f5 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.provider.systemcounters.SystemCounterThread.enable():void");
    }

    public native void initNativeThreadScheduler();

    public native void logCounters();

    public native void logExpensiveCounters();

    public native void logHighFrequencyThreadCounters();

    public native void logTraceAnnotations();

    public native void nativeSetHighFrequencyMode(boolean z);

    public native void stopNativeThreadScheduler(boolean z);

    public native void triggerSystemCounterCollection(int i, int i2, int i3);

    static {
        C19190z8 r1 = ProvidersRegistry.A00;
        PROVIDER_SYSTEM_COUNTERS = r1.A02("system_counters");
        PROVIDER_HIGH_FREQ_THREAD_COUNTERS = r1.A02("high_freq_main_thread_counters");
    }

    public SystemCounterThread(AnonymousClass00Z r3) {
        super("profilo_systemcounters", new C000000a());
        this.mCounterCollector = r3;
    }

    public int getSupportedProviders() {
        return PROVIDER_SYSTEM_COUNTERS | PROVIDER_HIGH_FREQ_THREAD_COUNTERS;
    }

    public int getTracingProviders() {
        int i = 0;
        if (!this.mEnabled) {
            return 0;
        }
        if (this.mAllThreadsMode) {
            i = 0 | PROVIDER_SYSTEM_COUNTERS;
        }
        if (this.mHighFrequencyMode) {
            return i | PROVIDER_HIGH_FREQ_THREAD_COUNTERS;
        }
        return i;
    }

    public SystemCounterThread() {
        this((AnonymousClass00Z) null);
    }
}
