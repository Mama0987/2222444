package com.facebook.profilo.provider.threadlifecycle;

import X.AnonymousClass011;
import X.AnonymousClass0BS;
import X.C03450Gz;
import X.C19180z7;
import com.facebook.profilo.core.ProvidersRegistry;
import com.facebook.profilo.core.TraceEvents;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.MultiBufferLogger;
import com.facebook.profilo.mmapbuf.core.Buffer;

public final class ThreadLifecycleProvider extends C19180z7 {
    public static final int PROVIDER_THREADS = ProvidersRegistry.A00.A02("thread_lifecycle");
    public boolean mTracing;

    public static native void nativeStartProfiling(MultiBufferLogger multiBufferLogger, String str, String str2, boolean z, boolean z2);

    public static native void nativeStopProfiling();

    public synchronized void onTraceEnded(TraceContext traceContext, C03450Gz r4) {
        int i;
        int A03 = AnonymousClass0BS.A03(-1756914383);
        if (!this.mTracing) {
            i = 2040742512;
        } else {
            nativeStopProfiling();
            this.mTracing = false;
            i = 2032426037;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public synchronized void onTraceStarted(TraceContext traceContext, C03450Gz r9) {
        int i;
        boolean A02;
        String str;
        String str2;
        int A03 = AnonymousClass0BS.A03(-432367486);
        super.onTraceStarted(traceContext, r9);
        if (this.mTracing) {
            i = -575756378;
        } else {
            boolean z = false;
            if (traceContext == null) {
                A02 = false;
            } else {
                A02 = traceContext.A08.A02("provider.thread_lifecycle.capture_stacks", false);
            }
            if (traceContext != null && traceContext.A08.A02("provider.thread_lifecycle.mixed_stack", false)) {
                z = true;
            }
            if (A02 && traceContext != null) {
                Buffer buffer = traceContext.A09;
                if (buffer.getFilePath() != null) {
                    str = buffer.generateMemoryMappingFilePath();
                    str2 = buffer.generateLocalSymbolsFilePath();
                    nativeStartProfiling(getLogger(), str, str2, A02, z);
                    this.mTracing = true;
                    i = 1786176923;
                }
            }
            str = null;
            str2 = null;
            nativeStartProfiling(getLogger(), str, str2, A02, z);
            this.mTracing = true;
            i = 1786176923;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public ThreadLifecycleProvider() {
        super("profilo_thread_lifecycle", new AnonymousClass011());
    }

    public int getTracingProviders() {
        int i = PROVIDER_THREADS;
        if (!TraceEvents.isEnabled(i)) {
            return 0;
        }
        return i;
    }

    public void disable() {
        AnonymousClass0BS.A09(-307049239, AnonymousClass0BS.A03(58540697));
    }

    public void enable() {
        AnonymousClass0BS.A09(1687708055, AnonymousClass0BS.A03(-601805988));
    }

    public int getSupportedProviders() {
        return PROVIDER_THREADS;
    }
}
