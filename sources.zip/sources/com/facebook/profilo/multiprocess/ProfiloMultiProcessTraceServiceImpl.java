package com.facebook.profilo.multiprocess;

import X.AnonymousClass01h;
import X.AnonymousClass0BS;
import X.C03440Gy;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;
import androidx.core.view.inputmethod.EditorInfoCompat;
import com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener;
import com.facebook.profilo.ipc.IProfiloMultiProcessTraceService;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.BufferLogger;
import com.facebook.profilo.mmapbuf.core.Buffer;
import com.facebook.profilo.provider.constants.ExternalProviders;
import java.util.Iterator;
import java.util.List;

public final class ProfiloMultiProcessTraceServiceImpl extends Binder implements C03440Gy, IProfiloMultiProcessTraceService {
    public final SparseArray A00;

    public ProfiloMultiProcessTraceServiceImpl(int i) {
        int A03 = AnonymousClass0BS.A03(835381719);
        attachInterface(this, "com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
        AnonymousClass0BS.A09(-1535492582, A03);
    }

    private void A00(TraceContext traceContext, int i) {
        int i2;
        SparseArray clone;
        int A03 = AnonymousClass0BS.A03(-1152971675);
        SparseArray sparseArray = this.A00;
        synchronized (sparseArray) {
            try {
                clone = sparseArray.clone();
            } catch (Throwable th) {
                while (true) {
                    th = th;
                    break;
                }
                i2 = -486387893;
            }
        }
        int size = clone.size();
        for (int i3 = 0; i3 < size; i3++) {
            IProfiloMultiProcessTraceListener iProfiloMultiProcessTraceListener = (IProfiloMultiProcessTraceListener) clone.valueAt(i3);
            if (iProfiloMultiProcessTraceListener != null) {
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (traceContext != null) {
                                try {
                                    iProfiloMultiProcessTraceListener.ERZ(traceContext.A06);
                                } catch (RemoteException unused) {
                                    synchronized (sparseArray) {
                                        sparseArray.remove(clone.keyAt(i3));
                                    }
                                } catch (Throwable th2) {
                                    th = th2;
                                    i2 = 946254027;
                                    AnonymousClass0BS.A09(i2, A03);
                                    throw th;
                                }
                            }
                        } else if (traceContext != null) {
                            iProfiloMultiProcessTraceListener.onTraceAbort(traceContext);
                        }
                    } else if (traceContext != null) {
                        iProfiloMultiProcessTraceListener.onTraceStop(traceContext);
                    }
                } else if (traceContext != null) {
                    iProfiloMultiProcessTraceListener.onTraceStart(traceContext);
                }
            }
        }
        AnonymousClass0BS.A09(-230244603, A03);
    }

    public final void DRo(long j, int i) {
        int i2;
        int A03 = AnonymousClass0BS.A03(1936890469);
        int A032 = AnonymousClass0BS.A03(-1944644427);
        boolean z = true;
        if (Binder.getCallingUid() != Process.myUid()) {
            z = false;
            Log.e("ProfiloMultiProcessTraceServiceImpl", "UID of caller is different from UID of listener");
        }
        AnonymousClass0BS.A09(-2104514617, A032);
        if (!z) {
            i2 = 1154176488;
        } else {
            int callingPid = Binder.getCallingPid();
            SparseArray sparseArray = this.A00;
            synchronized (sparseArray) {
                try {
                    if (((IProfiloMultiProcessTraceListener) sparseArray.get(callingPid)) == null) {
                        Log.e("ProfiloMultiProcessTraceServiceImpl", "Unknown listener sent trace abort in secondary");
                        i2 = -773353956;
                    } else {
                        AnonymousClass01h r6 = AnonymousClass01h.A0C;
                        if (r6 == null) {
                            i2 = 520329523;
                        } else {
                            Iterator it = r6.A09().iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    break;
                                }
                                TraceContext traceContext = (TraceContext) it.next();
                                if (traceContext.A06 == j) {
                                    int i3 = traceContext.A01;
                                    AnonymousClass01h.A07(r6, traceContext.A0B, i3, 0, i | EditorInfoCompat.IME_FLAG_FORCE_ASCII, traceContext.A05);
                                    break;
                                }
                            }
                            i2 = 97671473;
                        }
                    }
                } catch (Throwable th) {
                    while (true) {
                        AnonymousClass0BS.A09(-1332906130, A03);
                        throw th;
                    }
                }
            }
        }
        AnonymousClass0BS.A09(i2, A03);
    }

    public final void DRr(TraceContext traceContext) {
        int A03 = AnonymousClass0BS.A03(1254792233);
        A00(traceContext, 0);
        AnonymousClass0BS.A09(749827866, A03);
    }

    public final void DRs(TraceContext traceContext) {
        AnonymousClass0BS.A09(476565859, AnonymousClass0BS.A03(-1014289658));
    }

    public final void DhQ(IProfiloMultiProcessTraceListener iProfiloMultiProcessTraceListener) {
        int i;
        int i2;
        int A03 = AnonymousClass0BS.A03(805729410);
        int A032 = AnonymousClass0BS.A03(-1944644427);
        boolean z = true;
        if (Binder.getCallingUid() != Process.myUid()) {
            z = false;
            Log.e("ProfiloMultiProcessTraceServiceImpl", "UID of caller is different from UID of listener");
        }
        AnonymousClass0BS.A09(-2104514617, A032);
        if (!z) {
            i2 = -379711468;
        } else {
            int callingPid = Binder.getCallingPid();
            SparseArray sparseArray = this.A00;
            synchronized (sparseArray) {
                try {
                    if (sparseArray.get(callingPid) != null) {
                        i2 = 1405122721;
                    } else {
                        sparseArray.put(callingPid, iProfiloMultiProcessTraceListener);
                        AnonymousClass01h r0 = AnonymousClass01h.A0C;
                        if (r0 == null) {
                            i2 = -1490498473;
                        } else {
                            List<TraceContext> A09 = r0.A09();
                            if (!A09.isEmpty()) {
                                for (TraceContext traceContext : A09) {
                                    if ((traceContext.A02 & ExternalProviders.A06.A01) != 0) {
                                        try {
                                            iProfiloMultiProcessTraceListener.onTraceStart(traceContext);
                                        } catch (RemoteException unused) {
                                            synchronized (sparseArray) {
                                                sparseArray.remove(callingPid);
                                            }
                                        } catch (Throwable th) {
                                            th = th;
                                            i = -165993526;
                                            AnonymousClass0BS.A09(i, A03);
                                            throw th;
                                        }
                                    }
                                }
                            }
                            i2 = -1685209922;
                        }
                    }
                } catch (Throwable th2) {
                    while (true) {
                        th = th2;
                        break;
                    }
                    i = 1276855034;
                }
            }
        }
        AnonymousClass0BS.A09(i2, A03);
    }

    public final IBinder asBinder() {
        AnonymousClass0BS.A09(1315957551, AnonymousClass0BS.A03(1431318740));
        return this;
    }

    public final void onTraceAbort(TraceContext traceContext) {
        int A03 = AnonymousClass0BS.A03(704364162);
        A00(traceContext, 2);
        AnonymousClass0BS.A09(-2037965405, A03);
    }

    public final void onTraceStop(TraceContext traceContext) {
        int size;
        int A03 = AnonymousClass0BS.A03(-790101250);
        TraceContext traceContext2 = traceContext;
        A00(traceContext2, 1);
        A00(traceContext2, 3);
        SparseArray sparseArray = this.A00;
        synchronized (sparseArray) {
            try {
                size = sparseArray.size();
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(-1040840966, A03);
                    throw th;
                }
            }
        }
        Buffer buffer = traceContext2.A09;
        BufferLogger.writeBytesEntry(buffer, 0, 57, BufferLogger.writeBytesEntry(buffer, 0, 56, BufferLogger.writeStandardEntry(buffer, 6, 52, 0, 0, 8126500, 0, 0), "num_connected_processes"), String.valueOf(size));
        AnonymousClass0BS.A09(-273491228, A03);
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener$Stub$Proxy, java.lang.Object] */
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int i3;
        IProfiloMultiProcessTraceListener iProfiloMultiProcessTraceListener;
        int A03 = AnonymousClass0BS.A03(-1530826872);
        if (i >= 1) {
            if (i <= 16777215) {
                parcel.enforceInterface("com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
                if (i == 1) {
                    IBinder readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder == null) {
                        iProfiloMultiProcessTraceListener = null;
                    } else {
                        IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
                        if (queryLocalInterface == null || !(queryLocalInterface instanceof IProfiloMultiProcessTraceListener)) {
                            ? obj = new Object();
                            int A032 = AnonymousClass0BS.A03(-1543957421);
                            obj.A00 = readStrongBinder;
                            AnonymousClass0BS.A09(-1889045360, A032);
                            iProfiloMultiProcessTraceListener = obj;
                        } else {
                            iProfiloMultiProcessTraceListener = (IProfiloMultiProcessTraceListener) queryLocalInterface;
                        }
                    }
                    DhQ(iProfiloMultiProcessTraceListener);
                } else if (i == 2) {
                    DRo(parcel.readLong(), parcel.readInt());
                }
                parcel2.writeNoException();
                i3 = 1727197235;
            } else if (i == 1598968902) {
                parcel2.writeString("com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
                i3 = 8790207;
            }
            AnonymousClass0BS.A09(i3, A03);
            return true;
        }
        boolean onTransact = super.onTransact(i, parcel, parcel2, i2);
        AnonymousClass0BS.A09(-2007215651, A03);
        return onTransact;
    }

    public ProfiloMultiProcessTraceServiceImpl() {
        this(0);
        int A03 = AnonymousClass0BS.A03(-285691361);
        this.A00 = new SparseArray(0);
        AnonymousClass0BS.A09(-1011155476, A03);
    }
}
