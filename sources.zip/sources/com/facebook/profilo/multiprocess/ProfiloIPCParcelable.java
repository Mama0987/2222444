package com.facebook.profilo.multiprocess;

import X.AnonymousClass16Q;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

public final class ProfiloIPCParcelable implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16Q(2);
    public final IBinder A00;

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.A00);
    }

    public ProfiloIPCParcelable(Parcel parcel) {
        this.A00 = parcel.readStrongBinder();
    }

    public final int describeContents() {
        return 0;
    }

    public ProfiloIPCParcelable(IBinder iBinder) {
        this.A00 = iBinder;
    }
}
