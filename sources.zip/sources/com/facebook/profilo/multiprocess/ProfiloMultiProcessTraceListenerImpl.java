package com.facebook.profilo.multiprocess;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass01h;
import X.AnonymousClass0BS;
import X.AnonymousClass0HD;
import X.AnonymousClass0WY;
import X.AnonymousClass0z1;
import X.C03430Gx;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener;
import com.facebook.profilo.ipc.IProfiloMultiProcessTraceService;
import com.facebook.profilo.ipc.TraceConfigExtras;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.mmapbuf.core.Buffer;
import java.io.File;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class ProfiloMultiProcessTraceListenerImpl extends Binder implements AnonymousClass0HD, IProfiloMultiProcessTraceListener {
    public IProfiloMultiProcessTraceService A00;
    public final HashMap A01;

    public final void DCB(IProfiloMultiProcessTraceService iProfiloMultiProcessTraceService) {
        int i;
        int A03 = AnonymousClass0BS.A03(-992970326);
        if (!A00()) {
            i = -414715261;
        } else {
            synchronized (this) {
                try {
                    this.A00 = iProfiloMultiProcessTraceService;
                } catch (Throwable th) {
                    while (true) {
                        AnonymousClass0BS.A09(-1188091436, A03);
                        throw th;
                    }
                }
            }
            try {
                synchronized (this) {
                    this.A00.DhQ(this);
                }
            } catch (RemoteException unused) {
                synchronized (this) {
                    int A032 = AnonymousClass0BS.A03(69579572);
                    this.A00 = null;
                    AnonymousClass0BS.A09(-235434113, A032);
                }
            } catch (Throwable th2) {
                AnonymousClass0BS.A09(-743416045, A03);
                throw th2;
            }
            i = -1144711224;
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public final void DRv(TraceContext traceContext, int i) {
        int i2;
        int A03 = AnonymousClass0BS.A03(339504157);
        HashMap hashMap = this.A01;
        synchronized (hashMap) {
            try {
                CountDownLatch countDownLatch = (CountDownLatch) hashMap.get(Long.valueOf(traceContext.A06));
                if (countDownLatch != null) {
                    countDownLatch.countDown();
                    hashMap.remove(Long.valueOf(traceContext.A06));
                }
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(154389192, A03);
                    throw th;
                }
            }
        }
        try {
            synchronized (this) {
                IProfiloMultiProcessTraceService iProfiloMultiProcessTraceService = this.A00;
                if (iProfiloMultiProcessTraceService == null) {
                    i2 = -2110295355;
                } else {
                    iProfiloMultiProcessTraceService.DRo(traceContext.A06, i);
                    i2 = 119649642;
                }
            }
        } catch (RemoteException unused) {
            synchronized (this) {
                int A032 = AnonymousClass0BS.A03(69579572);
                this.A00 = null;
                AnonymousClass0BS.A09(-235434113, A032);
            }
        } catch (Throwable th2) {
            AnonymousClass0BS.A09(-1800080562, A03);
            throw th2;
        }
        AnonymousClass0BS.A09(i2, A03);
    }

    public ProfiloMultiProcessTraceListenerImpl(int i) {
        int A03 = AnonymousClass0BS.A03(-1700600152);
        attachInterface(this, "com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
        AnonymousClass0BS.A09(752003360, A03);
    }

    private boolean A00() {
        int A03 = AnonymousClass0BS.A03(1197914342);
        boolean z = true;
        if (Binder.getCallingUid() != Process.myUid()) {
            z = false;
            Log.e("ProfiloMultiProcessTraceListenerImpl", "UID of caller is different from UID of listener");
        }
        AnonymousClass0BS.A09(-547652694, A03);
        return z;
    }

    public final void DRw(TraceContext traceContext) {
        CountDownLatch countDownLatch;
        int i;
        int A03 = AnonymousClass0BS.A03(936142770);
        long j = traceContext.A06;
        int A032 = AnonymousClass0BS.A03(-2121771009);
        HashMap hashMap = this.A01;
        synchronized (hashMap) {
            try {
                countDownLatch = (CountDownLatch) hashMap.get(Long.valueOf(j));
            } catch (Throwable th) {
                while (true) {
                    AnonymousClass0BS.A09(-1039508583, A032);
                    throw th;
                }
            }
        }
        if (countDownLatch == null) {
            i = 1957562891;
        } else {
            countDownLatch.countDown();
            i = 795111174;
        }
        AnonymousClass0BS.A09(i, A032);
        AnonymousClass0BS.A09(-1763976283, A03);
    }

    public final void DRx(TraceContext traceContext, Throwable th) {
        int A03 = AnonymousClass0BS.A03(1252042321);
        DRv(traceContext, 8);
        AnonymousClass0BS.A09(1764261891, A03);
    }

    public final void DRy(TraceContext traceContext) {
        AnonymousClass0BS.A09(217330980, AnonymousClass0BS.A03(-851942497));
    }

    public final void ERZ(long j) {
        int i;
        Long valueOf;
        CountDownLatch countDownLatch;
        int i2;
        int A03 = AnonymousClass0BS.A03(1290806219);
        if (!A00()) {
            i2 = 1930330186;
        } else {
            HashMap hashMap = this.A01;
            synchronized (hashMap) {
                try {
                    valueOf = Long.valueOf(j);
                    countDownLatch = (CountDownLatch) hashMap.get(valueOf);
                } catch (Throwable th) {
                    while (true) {
                        th = th;
                        break;
                    }
                    i = -303834439;
                }
            }
            if (countDownLatch == null) {
                i2 = -1786122101;
            } else {
                try {
                    countDownLatch.await(5, TimeUnit.MINUTES);
                } catch (Exception unused) {
                }
                synchronized (hashMap) {
                    try {
                        hashMap.remove(valueOf);
                    } catch (Throwable th2) {
                        while (true) {
                            th = th2;
                            break;
                        }
                        i = 402003534;
                    }
                }
                i2 = 1508858733;
            }
        }
        AnonymousClass0BS.A09(i2, A03);
        return;
        AnonymousClass0BS.A09(i, A03);
        throw th;
    }

    public final IBinder asBinder() {
        AnonymousClass0BS.A09(2043779956, AnonymousClass0BS.A03(-2001458459));
        return this;
    }

    public final void onTraceAbort(TraceContext traceContext) {
        int i;
        int A03 = AnonymousClass0BS.A03(-1487147206);
        if (!A00()) {
            i = -1773653082;
        } else {
            AnonymousClass01h r4 = AnonymousClass01h.A0C;
            if (r4 == null) {
                i = -181490466;
            } else {
                r4.A0C(Long.valueOf(traceContext.A06), traceContext.A05, AnonymousClass0z1.A00);
                HashMap hashMap = this.A01;
                synchronized (hashMap) {
                    try {
                        hashMap.remove(Long.valueOf(traceContext.A06));
                    } catch (Throwable th) {
                        while (true) {
                            AnonymousClass0BS.A09(-1050354720, A03);
                            throw th;
                        }
                    }
                }
                i = 1140658230;
            }
        }
        AnonymousClass0BS.A09(i, A03);
    }

    /* JADX WARNING: type inference failed for: r1v10, types: [com.facebook.profilo.ipc.TraceContext, java.lang.Object] */
    public final void onTraceStart(TraceContext traceContext) {
        int i;
        IllegalArgumentException illegalArgumentException;
        int A03 = AnonymousClass0BS.A03(96175303);
        if (!A00()) {
            i = -1228103772;
        } else {
            AnonymousClass01h r9 = AnonymousClass01h.A0C;
            if (r9 == null) {
                i = -1199604506;
            } else {
                HashMap hashMap = this.A01;
                synchronized (hashMap) {
                    TraceContext traceContext2 = traceContext;
                    try {
                        Long valueOf = Long.valueOf(traceContext2.A06);
                        traceContext2.A0B = valueOf;
                        if (!hashMap.containsKey(valueOf)) {
                            int i2 = AnonymousClass0z1.A00;
                            int i3 = traceContext2.A03;
                            Object obj = r9.A01.get(i2);
                            if (obj != null) {
                                C03430Gx r13 = (C03430Gx) r9.A05.get();
                                if (r13 != null) {
                                    Buffer[] A08 = AnonymousClass01h.A08(r13, r9, traceContext2.A08);
                                    long j = traceContext2.A06;
                                    String str = traceContext2.A0D;
                                    Object obj2 = traceContext2.A0B;
                                    long j2 = traceContext2.A05;
                                    int i4 = traceContext2.A02;
                                    int i5 = traceContext2.A03;
                                    int i6 = traceContext2.A00;
                                    int i7 = traceContext2.A04;
                                    TraceConfigExtras traceConfigExtras = traceContext2.A08;
                                    Buffer buffer = A08[0];
                                    File A0C = AnonymousClass002.A0C(r9.A02, str);
                                    String str2 = r9.A03;
                                    ? obj3 = new Object();
                                    obj3.A06 = j;
                                    obj3.A0D = str;
                                    obj3.A07 = r13;
                                    obj3.A01 = i2;
                                    obj3.A0C = obj;
                                    obj3.A0B = obj2;
                                    obj3.A05 = j2;
                                    obj3.A02 = i4;
                                    obj3.A03 = i5;
                                    obj3.A00 = i6;
                                    obj3.A04 = i7;
                                    obj3.A08 = traceConfigExtras;
                                    obj3.A09 = buffer;
                                    obj3.A0F = A08;
                                    obj3.A0A = A0C;
                                    obj3.A0E = str2;
                                    if (!AnonymousClass01h.A06(r9, obj3, i3)) {
                                        i = -2115359557;
                                    } else {
                                        hashMap.put(Long.valueOf(traceContext2.A06), AnonymousClass001.A16());
                                    }
                                } else {
                                    illegalArgumentException = AnonymousClass001.A0L("No config available");
                                }
                            } else {
                                illegalArgumentException = AnonymousClass0WY.A03("Unregistered controller for id = ", i2);
                            }
                            throw illegalArgumentException;
                        }
                        i = -1630590431;
                    } catch (Throwable th) {
                        while (true) {
                            AnonymousClass0BS.A09(502393630, A03);
                            throw th;
                        }
                    }
                }
            }
        }
        AnonymousClass0BS.A09(i, A03);
    }

    public final void onTraceStop(TraceContext traceContext) {
        int i;
        int A03 = AnonymousClass0BS.A03(-1949919233);
        if (!A00()) {
            i = 1377863948;
        } else {
            AnonymousClass01h r4 = AnonymousClass01h.A0C;
            if (r4 == null) {
                i = 2030762139;
            } else {
                if (!AnonymousClass01h.A07(r4, Long.valueOf(traceContext.A06), AnonymousClass0z1.A00, 1, 0, traceContext.A05)) {
                    HashMap hashMap = this.A01;
                    synchronized (hashMap) {
                        try {
                            hashMap.remove(Long.valueOf(traceContext.A06));
                        } catch (Throwable th) {
                            AnonymousClass0BS.A09(1197349285, A03);
                            throw th;
                        }
                    }
                }
                i = 2128687375;
            }
        }
        AnonymousClass0BS.A09(i, A03);
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [com.facebook.profilo.ipc.IProfiloMultiProcessTraceService$Stub$Proxy, java.lang.Object] */
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int i3;
        IProfiloMultiProcessTraceService iProfiloMultiProcessTraceService;
        int A03 = AnonymousClass0BS.A03(-1498424839);
        if (i >= 1) {
            if (i <= 16777215) {
                parcel.enforceInterface("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
                if (i == 1) {
                    IBinder readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder == null) {
                        iProfiloMultiProcessTraceService = null;
                    } else {
                        IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
                        if (queryLocalInterface == null || !(queryLocalInterface instanceof IProfiloMultiProcessTraceService)) {
                            ? obj = new Object();
                            int A032 = AnonymousClass0BS.A03(-1878909366);
                            obj.A00 = readStrongBinder;
                            AnonymousClass0BS.A09(2058609843, A032);
                            iProfiloMultiProcessTraceService = obj;
                        } else {
                            iProfiloMultiProcessTraceService = (IProfiloMultiProcessTraceService) queryLocalInterface;
                        }
                    }
                    DCB(iProfiloMultiProcessTraceService);
                } else if (i == 2) {
                    onTraceStart((TraceContext) AnonymousClass002.A0J(parcel, TraceContext.CREATOR));
                } else if (i == 3) {
                    onTraceStop((TraceContext) AnonymousClass002.A0J(parcel, TraceContext.CREATOR));
                } else if (i == 4) {
                    onTraceAbort((TraceContext) AnonymousClass002.A0J(parcel, TraceContext.CREATOR));
                } else if (i == 5) {
                    ERZ(parcel.readLong());
                }
                parcel2.writeNoException();
                i3 = 1294838050;
            } else if (i == 1598968902) {
                parcel2.writeString("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
                i3 = -436317488;
            }
            AnonymousClass0BS.A09(i3, A03);
            return true;
        }
        boolean onTransact = super.onTransact(i, parcel, parcel2, i2);
        AnonymousClass0BS.A09(1964285259, A03);
        return onTransact;
    }

    public ProfiloMultiProcessTraceListenerImpl() {
        this(0);
        int A03 = AnonymousClass0BS.A03(-1288247727);
        this.A01 = AnonymousClass001.A0w();
        AnonymousClass0BS.A09(1858616048, A03);
    }
}
