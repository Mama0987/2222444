package com.facebook.profilo.mmapbuf.core;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.C002001g;
import X.C18440x7;
import android.util.Log;
import com.facebook.jni.HybridData;

public class Buffer {
    public final HybridData mHybridData;

    private native void nativeUpdateId(String str);

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0041, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized java.lang.String generateLocalSymbolsFilePath() {
        /*
            r3 = this;
            monitor-enter(r3)
            java.lang.String r0 = r3.getFilePath()     // Catch:{ all -> 0x0042 }
            boolean r0 = X.AnonymousClass001.A1U(r0)
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            r0 = 0
            return r0
        L_0x000e:
            java.lang.String r0 = r3.getLocalSymbolsFilePath()     // Catch:{ all -> 0x0042 }
            if (r0 != 0) goto L_0x0040
            java.lang.String r0 = r3.getFilePath()     // Catch:{ all -> 0x0042 }
            java.io.File r0 = X.AnonymousClass001.A0E(r0)     // Catch:{ all -> 0x0042 }
            java.io.File r0 = r0.getParentFile()     // Catch:{ all -> 0x0042 }
            X.01g r2 = new X.01g     // Catch:{ all -> 0x0042 }
            r2.<init>(r0)     // Catch:{ all -> 0x0042 }
            java.util.UUID r0 = java.util.UUID.randomUUID()     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0042 }
            java.lang.String r1 = X.C002001g.A00(r0)     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = ".sym"
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r1, r0)     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = r2.A01(r0)     // Catch:{ all -> 0x0042 }
            if (r0 == 0) goto L_0x0040
            r3.updateLocalSymbolsFilePath(r0)     // Catch:{ all -> 0x0042 }
        L_0x0040:
            monitor-exit(r3)
            return r0
        L_0x0042:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0042 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.mmapbuf.core.Buffer.generateLocalSymbolsFilePath():java.lang.String");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0041, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized java.lang.String generateMemoryMappingFilePath() {
        /*
            r3 = this;
            monitor-enter(r3)
            java.lang.String r0 = r3.getFilePath()     // Catch:{ all -> 0x0042 }
            boolean r0 = X.AnonymousClass001.A1U(r0)
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            r0 = 0
            return r0
        L_0x000e:
            java.lang.String r0 = r3.getMemoryMappingFilePath()     // Catch:{ all -> 0x0042 }
            if (r0 != 0) goto L_0x0040
            java.lang.String r0 = r3.getFilePath()     // Catch:{ all -> 0x0042 }
            java.io.File r0 = X.AnonymousClass001.A0E(r0)     // Catch:{ all -> 0x0042 }
            java.io.File r0 = r0.getParentFile()     // Catch:{ all -> 0x0042 }
            X.01g r2 = new X.01g     // Catch:{ all -> 0x0042 }
            r2.<init>(r0)     // Catch:{ all -> 0x0042 }
            java.util.UUID r0 = java.util.UUID.randomUUID()     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0042 }
            java.lang.String r1 = X.C002001g.A00(r0)     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = ".maps"
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r1, r0)     // Catch:{ all -> 0x0042 }
            java.lang.String r0 = r2.A01(r0)     // Catch:{ all -> 0x0042 }
            if (r0 == 0) goto L_0x0040
            r3.updateMemoryMappingFilePath(r0)     // Catch:{ all -> 0x0042 }
        L_0x0040:
            monitor-exit(r3)
            return r0
        L_0x0042:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0042 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.profilo.mmapbuf.core.Buffer.generateMemoryMappingFilePath():java.lang.String");
    }

    public native synchronized String getFilePath();

    public native synchronized String getLocalSymbolsFilePath();

    public native synchronized String getMemoryMappingFilePath();

    public native synchronized boolean isForeground();

    public synchronized void setForegroundState(boolean z) {
        setForegroundStateNative(z);
    }

    public native synchronized void setForegroundStateNative(boolean z);

    public native synchronized void updateFilePath(String str);

    public native synchronized void updateHeader(int i, long j, long j2, long j3);

    public synchronized void updateId(String str, String str2) {
        String str3;
        if (getFilePath() != null) {
            if (str == null) {
                str3 = str2;
            } else {
                str3 = AnonymousClass0WY.A0w(str, "_", str2);
            }
            String A01 = new C002001g(AnonymousClass001.A0E(getFilePath()).getParentFile()).A01(AnonymousClass0WY.A0i(C002001g.A00(str3), ".buff"));
            if (A01 != null) {
                try {
                    nativeUpdateId(str2);
                    updateFilePath(A01);
                } catch (Exception e) {
                    Log.e("Prflo/Buffer", "Id update failed", e);
                }
            }
        }
    }

    public native synchronized void updateLocalSymbolsFilePath(String str);

    public native synchronized void updateMemoryMappingFilePath(String str);

    static {
        C18440x7.loadLibrary("profilo_mmapbuf");
    }

    public Buffer(HybridData hybridData) {
        this.mHybridData = hybridData;
    }
}
