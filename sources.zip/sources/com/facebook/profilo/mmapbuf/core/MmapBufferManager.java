package com.facebook.profilo.mmapbuf.core;

import X.AnonymousClass0WY;
import X.C002001g;
import X.C18440x7;
import com.facebook.jni.HybridData;
import java.io.File;
import java.util.UUID;

public class MmapBufferManager {
    public static final MmapBufferManager $redex_init_class = null;
    public final C002001g mFileHelper;
    public final HybridData mHybridData = initHybrid();

    public static native HybridData initHybrid();

    private native Buffer nativeAllocateBuffer(int i);

    private native Buffer nativeAllocateBuffer(int i, String str);

    private native boolean nativeDeallocateBuffer(Buffer buffer);

    public synchronized boolean deallocateBuffer(Buffer buffer) {
        return nativeDeallocateBuffer(buffer);
    }

    static {
        C18440x7.loadLibrary("profilo_mmapbuf");
    }

    public Buffer allocateBuffer(int i, boolean z) {
        if (!z) {
            return nativeAllocateBuffer(i);
        }
        String A01 = this.mFileHelper.A01(AnonymousClass0WY.A0i(C002001g.A00(UUID.randomUUID().toString()), ".buff"));
        if (A01 == null) {
            return null;
        }
        return nativeAllocateBuffer(i, A01);
    }

    public MmapBufferManager(File file) {
        this.mFileHelper = new C002001g(file);
    }
}
