package com.facebook.profilo.mmapbuf.reader;

import X.C18440x7;
import com.facebook.jni.HybridData;

public class MmapBufferHeaderReader {
    public final HybridData mHybridData = initHybrid();

    public static native HybridData initHybrid();

    public native long readLongContext(String str);

    public native long readTraceId(String str);

    static {
        C18440x7.loadLibrary("profilo_mmapbuf_rdr");
    }
}
