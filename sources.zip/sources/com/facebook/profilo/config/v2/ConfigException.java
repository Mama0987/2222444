package com.facebook.profilo.config.v2;

public class ConfigException extends RuntimeException {
    public ConfigException(String str) {
        super(str);
    }
}
