package com.facebook.profilo.config.v2;

import X.C18440x7;
import com.facebook.jni.HybridData;

public class ConfigParser {
    public final HybridData mHybridData;

    public static native HybridData initHybrid(String str);

    public native Config parseConfig();

    static {
        C18440x7.loadLibrary("profilo_configjni");
    }

    public ConfigParser(String str) {
        this.mHybridData = initHybrid(str);
    }
}
