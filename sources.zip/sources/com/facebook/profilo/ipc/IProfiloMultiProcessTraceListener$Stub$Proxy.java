package com.facebook.profilo.ipc;

import X.AnonymousClass002;
import X.AnonymousClass0BS;
import android.os.IBinder;
import android.os.Parcel;

public final class IProfiloMultiProcessTraceListener$Stub$Proxy implements IProfiloMultiProcessTraceListener {
    public IBinder A00;

    public final void DCB(IProfiloMultiProcessTraceService iProfiloMultiProcessTraceService) {
        int A03 = AnonymousClass0BS.A03(1362976392);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
            obtain.writeStrongInterface(iProfiloMultiProcessTraceService);
            AnonymousClass002.A0Z(this.A00, obtain, obtain2, 1);
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(-696220556, A03);
        }
    }

    public final void ERZ(long j) {
        int A03 = AnonymousClass0BS.A03(998603740);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
            obtain.writeLong(j);
            AnonymousClass002.A0Z(this.A00, obtain, obtain2, 5);
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(-187866108, A03);
        }
    }

    public final IBinder asBinder() {
        int A03 = AnonymousClass0BS.A03(-257488506);
        IBinder iBinder = this.A00;
        AnonymousClass0BS.A09(110362939, A03);
        return iBinder;
    }

    public final void onTraceAbort(TraceContext traceContext) {
        int A03 = AnonymousClass0BS.A03(1986484698);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
            obtain.writeInt(1);
            traceContext.writeToParcel(obtain, 0);
            this.A00.transact(4, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(1267779512, A03);
        }
    }

    public final void onTraceStart(TraceContext traceContext) {
        int A03 = AnonymousClass0BS.A03(-1597150464);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
            obtain.writeInt(1);
            traceContext.writeToParcel(obtain, 0);
            this.A00.transact(2, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(-1368883312, A03);
        }
    }

    public final void onTraceStop(TraceContext traceContext) {
        int A03 = AnonymousClass0BS.A03(-1403041515);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceListener");
            obtain.writeInt(1);
            traceContext.writeToParcel(obtain, 0);
            this.A00.transact(3, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(219451110, A03);
        }
    }
}
