package com.facebook.profilo.ipc;

import android.os.IInterface;

public interface IProfiloMultiProcessTraceService extends IInterface {
    void DRo(long j, int i);

    void DhQ(IProfiloMultiProcessTraceListener iProfiloMultiProcessTraceListener);
}
