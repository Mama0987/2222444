package com.facebook.profilo.ipc;

import X.AnonymousClass002;
import X.AnonymousClass0BS;
import android.os.IBinder;
import android.os.Parcel;

public final class IProfiloMultiProcessTraceService$Stub$Proxy implements IProfiloMultiProcessTraceService {
    public IBinder A00;

    public final void DRo(long j, int i) {
        int A03 = AnonymousClass0BS.A03(1767577486);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
            obtain.writeLong(j);
            obtain.writeInt(i);
            AnonymousClass002.A0Z(this.A00, obtain, obtain2, 2);
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(578514478, A03);
        }
    }

    public final void DhQ(IProfiloMultiProcessTraceListener iProfiloMultiProcessTraceListener) {
        int A03 = AnonymousClass0BS.A03(-876090529);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.profilo.ipc.IProfiloMultiProcessTraceService");
            obtain.writeStrongInterface(iProfiloMultiProcessTraceListener);
            AnonymousClass002.A0Z(this.A00, obtain, obtain2, 1);
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(-1200062581, A03);
        }
    }

    public final IBinder asBinder() {
        int A03 = AnonymousClass0BS.A03(-1467117008);
        IBinder iBinder = this.A00;
        AnonymousClass0BS.A09(463775479, A03);
        return iBinder;
    }
}
