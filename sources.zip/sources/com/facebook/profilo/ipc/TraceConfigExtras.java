package com.facebook.profilo.ipc;

import X.AnonymousClass001;
import X.AnonymousClass16N;
import X.C003002b;
import X.C03430Gx;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.profilo.config.ConfigParams;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class TraceConfigExtras implements Parcelable {
    public static final TraceConfigExtras A07 = new TraceConfigExtras((TreeMap) null, (TreeMap) null, (TreeMap) null, (TreeMap) null, (TreeMap) null);
    public static final Parcelable.Creator CREATOR = new AnonymousClass16N(1);
    public final int A00;
    public final C03430Gx A01;
    public final TreeMap A02;
    public final TreeMap A03;
    public final TreeMap A04;
    public final TreeMap A05;
    public final TreeMap A06;

    public final String A01(String str) {
        String str2;
        C03430Gx r1 = this.A01;
        if (r1 != null) {
            return r1.optTraceConfigParamString(this.A00, str, (String) null);
        }
        TreeMap treeMap = this.A06;
        if (treeMap == null || (str2 = (String) treeMap.get(str)) == null) {
            return null;
        }
        return str2;
    }

    public final int A00(String str, int i) {
        Number number;
        C03430Gx r1 = this.A01;
        if (r1 != null) {
            return r1.optTraceConfigParamInt(this.A00, str, i);
        }
        TreeMap treeMap = this.A04;
        if (treeMap == null || (number = (Number) treeMap.get(str)) == null) {
            return i;
        }
        return number.intValue();
    }

    public final boolean A02(String str, boolean z) {
        Boolean bool;
        C03430Gx r1 = this.A01;
        if (r1 != null) {
            return r1.optTraceConfigParamBool(this.A00, str, z);
        }
        TreeMap treeMap = this.A02;
        if (treeMap == null || (bool = (Boolean) treeMap.get(str)) == null) {
            return z;
        }
        return bool.booleanValue();
    }

    public final int[] A03(String str) {
        C03430Gx r1 = this.A01;
        if (r1 != null) {
            return r1.optTraceConfigParamIntList(this.A00, str);
        }
        TreeMap treeMap = this.A03;
        if (treeMap == null) {
            return null;
        }
        return (int[]) treeMap.get(str);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C03430Gx r1;
        TreeMap treeMap = this.A04;
        TreeMap treeMap2 = this.A02;
        TreeMap treeMap3 = this.A03;
        TreeMap treeMap4 = this.A05;
        TreeMap treeMap5 = this.A06;
        int i2 = this.A00;
        if (i2 >= 0 && (r1 = this.A01) != null) {
            ConfigParams traceConfigParams = r1.getTraceConfigParams(i2);
            treeMap = traceConfigParams.intParams;
            treeMap2 = traceConfigParams.boolParams;
            treeMap3 = traceConfigParams.intListParams;
        }
        Bundle A08 = AnonymousClass001.A08();
        if (treeMap != null) {
            Iterator A10 = AnonymousClass001.A10(treeMap);
            while (A10.hasNext()) {
                Map.Entry A13 = AnonymousClass001.A13(A10);
                A08.putInt(AnonymousClass001.A0l(A13), AnonymousClass001.A02(A13.getValue()));
            }
        }
        parcel.writeBundle(A08);
        Bundle A082 = AnonymousClass001.A08();
        if (treeMap2 != null) {
            Iterator A102 = AnonymousClass001.A10(treeMap2);
            while (A102.hasNext()) {
                Map.Entry A132 = AnonymousClass001.A13(A102);
                A082.putBoolean(AnonymousClass001.A0l(A132), AnonymousClass001.A1V(A132.getValue()));
            }
        }
        parcel.writeBundle(A082);
        Bundle A083 = AnonymousClass001.A08();
        if (treeMap3 != null) {
            Iterator A103 = AnonymousClass001.A10(treeMap3);
            while (A103.hasNext()) {
                Map.Entry A133 = AnonymousClass001.A13(A103);
                A083.putIntArray(AnonymousClass001.A0l(A133), (int[]) A133.getValue());
            }
        }
        parcel.writeBundle(A083);
        Bundle A084 = AnonymousClass001.A08();
        if (treeMap4 != null) {
            Iterator A104 = AnonymousClass001.A10(treeMap4);
            while (A104.hasNext()) {
                Map.Entry A134 = AnonymousClass001.A13(A104);
                A084.putStringArrayList(AnonymousClass001.A0l(A134), (ArrayList) A134.getValue());
            }
        }
        parcel.writeBundle(A084);
        Bundle A085 = AnonymousClass001.A08();
        if (treeMap5 != null) {
            Iterator A105 = AnonymousClass001.A10(treeMap5);
            while (A105.hasNext()) {
                Map.Entry A135 = AnonymousClass001.A13(A105);
                A085.putCharArray(AnonymousClass001.A0l(A135), AnonymousClass001.A0k(A135).toCharArray());
            }
        }
        parcel.writeBundle(A085);
    }

    public TraceConfigExtras(C03430Gx r2, int i) {
        this.A01 = r2;
        this.A00 = i;
        this.A04 = null;
        this.A03 = null;
        this.A02 = null;
        this.A05 = null;
        this.A06 = null;
    }

    public final int describeContents() {
        return 0;
    }

    public TraceConfigExtras(Parcel parcel) {
        this.A01 = null;
        this.A00 = -1;
        Class<?> cls = getClass();
        Bundle readBundle = parcel.readBundle(cls.getClassLoader());
        C003002b.A00(readBundle);
        Set<String> keySet = readBundle.keySet();
        if (!keySet.isEmpty()) {
            this.A04 = new TreeMap();
            Iterator<String> it = keySet.iterator();
            while (it.hasNext()) {
                String A0j = AnonymousClass001.A0j(it);
                AnonymousClass001.A1G(A0j, this.A04, readBundle.getInt(A0j));
            }
        } else {
            this.A04 = null;
        }
        Bundle readBundle2 = parcel.readBundle(cls.getClassLoader());
        C003002b.A00(readBundle2);
        Set<String> keySet2 = readBundle2.keySet();
        if (!keySet2.isEmpty()) {
            this.A02 = new TreeMap();
            Iterator<String> it2 = keySet2.iterator();
            while (it2.hasNext()) {
                String A0j2 = AnonymousClass001.A0j(it2);
                this.A02.put(A0j2, Boolean.valueOf(readBundle2.getBoolean(A0j2)));
            }
        } else {
            this.A02 = null;
        }
        Bundle readBundle3 = parcel.readBundle(cls.getClassLoader());
        C003002b.A00(readBundle3);
        Set<String> keySet3 = readBundle3.keySet();
        if (!keySet3.isEmpty()) {
            this.A03 = new TreeMap();
            Iterator<String> it3 = keySet3.iterator();
            while (it3.hasNext()) {
                String A0j3 = AnonymousClass001.A0j(it3);
                this.A03.put(A0j3, readBundle3.getIntArray(A0j3));
            }
        } else {
            this.A03 = null;
        }
        Bundle readBundle4 = parcel.readBundle(cls.getClassLoader());
        Set<String> keySet4 = readBundle4.keySet();
        if (!keySet4.isEmpty()) {
            this.A05 = new TreeMap();
            Iterator<String> it4 = keySet4.iterator();
            while (it4.hasNext()) {
                String A0j4 = AnonymousClass001.A0j(it4);
                this.A05.put(A0j4, readBundle4.getStringArrayList(A0j4));
            }
        } else {
            this.A05 = null;
        }
        Bundle readBundle5 = parcel.readBundle(cls.getClassLoader());
        Set<String> keySet5 = readBundle5.keySet();
        if (!keySet5.isEmpty()) {
            this.A06 = new TreeMap();
            Iterator<String> it5 = keySet5.iterator();
            while (it5.hasNext()) {
                String A0j5 = AnonymousClass001.A0j(it5);
                this.A06.put(A0j5, new String(readBundle5.getCharArray(A0j5)));
            }
            return;
        }
        this.A06 = null;
    }

    public TraceConfigExtras(TreeMap treeMap, TreeMap treeMap2, TreeMap treeMap3, TreeMap treeMap4, TreeMap treeMap5) {
        this.A04 = treeMap;
        this.A02 = treeMap2;
        this.A03 = treeMap3;
        this.A05 = treeMap4;
        this.A06 = treeMap5;
        this.A01 = null;
        this.A00 = -1;
    }
}
