package com.facebook.profilo.ipc;

import android.os.IInterface;

public interface IProfiloMultiProcessTraceListener extends IInterface {
    void DCB(IProfiloMultiProcessTraceService iProfiloMultiProcessTraceService);

    void ERZ(long j);

    void onTraceAbort(TraceContext traceContext);

    void onTraceStart(TraceContext traceContext);

    void onTraceStop(TraceContext traceContext);
}
