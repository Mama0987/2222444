package com.facebook.profilo.core;

import X.C19190z8;

public final class TriggerRegistry {
    public static final C19190z8 A00 = new C19190z8();

    public static int getBitMaskFor(String str) {
        return A00.A01(str);
    }
}
