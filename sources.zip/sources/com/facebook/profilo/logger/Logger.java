package com.facebook.profilo.logger;

public final class Logger {
}
