package com.facebook.appcomponentmanager;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass02M;
import X.AnonymousClass0Pc;
import X.C11050hb;
import X.C11080he;
import X.C14270pR;
import X.C14860qU;
import X.C16730tw;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.io.File;

public class AppComponentManagerService extends AnonymousClass0Pc {
    public final void A05(Intent intent) {
        C16730tw r0;
        intent.getAction();
        if (AnonymousClass001.A1Y("com.facebook.appcomponentmanager.ACTION_ENABLE_COMPONENTS", intent)) {
            try {
                AnonymousClass02M.A05(this, "app_update");
                Intent A07 = AnonymousClass001.A07("com.facebook.appcomponentmanager.ENABLING_CMPS_DONE");
                A07.setPackage(getPackageName());
                sendBroadcast(A07);
            } catch (RuntimeException e) {
                th = e;
                C14270pR.A0I("AppComponentManagerService", "Exception while enabling components. Aborting.", th);
                r0 = C14860qU.A00();
                if (r0 == null) {
                    return;
                }
                r0.A00(th);
            }
        } else if (AnonymousClass001.A1Y("com.facebook.appcomponentmanager.ACTION_EFNORCE_MANIFEST_CONSISTENCY", intent)) {
            PackageManager packageManager = getPackageManager();
            C11080he r5 = new C11080he();
            File A0A = AnonymousClass002.A0A(this);
            try {
                PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
                C11050hb A04 = r5.A04(A0A);
                int i = packageInfo.versionCode;
                String num = Integer.toString(i);
                String str = A04.A01;
                if (!num.equals(str) || !packageInfo.versionName.equals(A04.A02) || !packageInfo.packageName.equals(A04.A00)) {
                    StringBuilder A0m = AnonymousClass001.A0m();
                    A0m.append("PackageInfo{package=");
                    AnonymousClass002.A0j(packageInfo.packageName, ",", "versionCode=", A0m);
                    A0m.append(i);
                    A0m.append(",");
                    A0m.append("versionName=");
                    A0m.append(packageInfo.versionName);
                    A0m.append("} ,");
                    A0m.append("Manifest{package=");
                    AnonymousClass002.A0j(A04.A00, ", ", "versionCode=", A0m);
                    AnonymousClass002.A0j(str, ", ", "versionName=", A0m);
                    A0m.append(A04.A02);
                    A0m.append(", ");
                    A0m.append("activities=");
                    A0m.append(A04.A03.size());
                    A0m.append(", ");
                    A0m.append("receivers=");
                    A0m.append(A04.A05.size());
                    A0m.append(", ");
                    A0m.append("services=");
                    A0m.append(A04.A06.size());
                    A0m.append(", ");
                    A0m.append("providers=");
                    A0m.append(A04.A04.size());
                    throw AnonymousClass002.A0I("}", A0m);
                }
            } catch (Throwable th) {
                th = th;
                r0 = C14860qU.A00();
                if (r0 == null) {
                    C14270pR.A0I("AppComponentManagerService", "enforceManifestConsistency failed", th);
                    return;
                }
                r0.A00(th);
            }
        }
    }
}
