package com.facebook.appcomponentmanager;

import java.io.Serializable;

public class AppComponentManagerProfiledRun implements Serializable {
    public static final long serialVersionUID = 1;
    public long mDurationInMilliseconds;
    public String mTrigger;
    public int mUpdatedComponents;
}
