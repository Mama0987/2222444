package com.facebook.appcomponentmanager.fb;

import X.AnonymousClass001;
import X.AnonymousClass02M;
import X.AnonymousClass0BS;
import X.AnonymousClass0Pc;
import X.C14270pR;
import X.C15800sA;
import android.accounts.AccountManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.facebook.appcomponentmanager.AppComponentManagerService;

public final class FbAppComponentReceiver extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
        int i;
        int A01 = AnonymousClass0BS.A01(-1383463471);
        intent.getAction();
        if (AnonymousClass001.A1Y("android.intent.action.MY_PACKAGE_REPLACED", intent)) {
            String[] list = AnonymousClass02M.getVersionsDir(context).list();
            if (list == null || list.length == 0) {
                C15800sA.A0D(context, 0);
                context.getPackageName();
                try {
                    if (AccountManager.get(context).getAccountsByType("com.facebook.auth.login").length > 0) {
                    }
                } catch (RuntimeException e) {
                    C14270pR.A0I("FbAppComponentReceiver", "Unexpected error while getting accounts", e);
                }
                i = -753553021;
                AnonymousClass0BS.A0D(i, A01, intent);
            }
            AnonymousClass0Pc.A00(context, AnonymousClass001.A07("com.facebook.appcomponentmanager.ACTION_ENABLE_COMPONENTS"), AppComponentManagerService.class, 137875812);
        }
        i = -1079568247;
        AnonymousClass0BS.A0D(i, A01, intent);
    }

    public FbAppComponentReceiver(int i) {
    }

    public FbAppComponentReceiver() {
    }
}
