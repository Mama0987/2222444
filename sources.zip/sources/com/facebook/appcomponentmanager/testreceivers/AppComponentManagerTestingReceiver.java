package com.facebook.appcomponentmanager.testreceivers;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.C003002b;
import X.C14270pR;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class AppComponentManagerTestingReceiver extends BroadcastReceiver {
    public static void A00(PackageManager packageManager, ComponentInfo[] componentInfoArr) {
        for (ComponentInfo componentInfo : componentInfoArr) {
            int componentEnabledSetting = packageManager.getComponentEnabledSetting(new ComponentName(componentInfo.packageName, componentInfo.name));
            if (!(componentEnabledSetting == 0 || componentEnabledSetting == 1 || componentEnabledSetting == 2)) {
                C14270pR.A0P("AppComponentManagerTestingReceiver", "%s is marked as currently in state %d, which is not an expected state. Conservatively assuming it's disabled.", AnonymousClass001.A1b(componentInfo.name, componentEnabledSetting));
            }
        }
    }

    public final void onReceive(Context context, Intent intent) {
        String str;
        int i;
        int A01 = AnonymousClass0BS.A01(1663029907);
        String action = intent.getAction();
        if (action == null) {
            C14270pR.A0G("AppComponentManagerTestingReceiver", "Intent Action was null. Please supply an action.");
            i = -486739972;
        } else {
            if (action.equals("com.facebook.appcomponentmanager.ACTION_GET_CURRENT_ENABLE_STAGE")) {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null) {
                    C14270pR.A0F("AppComponentManagerTestingReceiver", "PackageManager received from context was null. Aborting.");
                } else {
                    if (packageManager.getComponentEnabledSetting(new ComponentName(context.getPackageName(), SecondEnableStageTestReceiver.class.getCanonicalName())) == 1) {
                        str = "Enable Stage: Warm Pre-TOS.";
                    } else {
                        str = "Enable Stage: Cold Pre-TOS.";
                    }
                    C14270pR.A0G("AppComponentManagerTestingReceiver", str);
                }
            } else if (!action.equals("com.facebook.appcomponentmanager.ACTION_PRINT_COMPONENTS")) {
                C14270pR.A0P("AppComponentManagerTestingReceiver", "Intent Action %s is not a known action.", action);
            } else {
                PackageManager packageManager2 = context.getPackageManager();
                try {
                    C003002b.A00(packageManager2);
                    PackageInfo packageInfo = packageManager2.getPackageInfo(context.getPackageName(), 33423);
                    A00(packageManager2, packageInfo.activities);
                    A00(packageManager2, packageInfo.receivers);
                    A00(packageManager2, packageInfo.services);
                    A00(packageManager2, packageInfo.providers);
                } catch (PackageManager.NameNotFoundException e) {
                    C14270pR.A0R("AppComponentManagerTestingReceiver", e, "Ran into NameNotFoundException");
                }
            }
            i = -1666263287;
        }
        AnonymousClass0BS.A0D(i, A01, intent);
    }
}
