package com.facebook.appcomponentmanager.testreceivers;

import X.AnonymousClass0BS;
import X.C11100hh;
import android.content.Context;
import android.content.Intent;

public class FirstEnableStageTestReceiver extends C11100hh {
    public final void onReceive(Context context, Intent intent) {
        AnonymousClass0BS.A0D(-1339921071, AnonymousClass0BS.A01(-1162537165), intent);
    }
}
