package com.facebook.appcomponentmanager.testreceivers;

import X.AnonymousClass0BS;
import X.C11100hh;
import android.content.Context;
import android.content.Intent;

public class SecondEnableStageTestReceiver extends C11100hh {
    public final void onReceive(Context context, Intent intent) {
        AnonymousClass0BS.A0D(2123493461, AnonymousClass0BS.A01(-1085491673), intent);
    }
}
