package com.facebook.memorytimeline;

import X.AnonymousClass001;
import X.AnonymousClass0IW;
import X.AnonymousClass0T1;
import X.AnonymousClass0WY;
import X.C05730Sx;
import X.C05750Sz;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public abstract class MemoryTimelineSerializer {
    public static String A00(C05750Sz r12) {
        int size;
        if (r12 == null) {
            return "";
        }
        Map map = r12.A01;
        Collection<C05730Sx> collection = r12.A00;
        int i = 0;
        if (map == null) {
            size = 0;
        } else {
            size = map.size() * 60;
        }
        if (collection != null) {
            i = collection.size() * 35;
        }
        StringBuilder A0n = AnonymousClass001.A0n(size + 10 + i);
        boolean z = true;
        if (map != null) {
            Iterator A12 = AnonymousClass001.A12(map);
            while (A12.hasNext()) {
                Map.Entry A13 = AnonymousClass001.A13(A12);
                if (z) {
                    z = false;
                } else {
                    A0n.append(',');
                }
                A0n.append(AnonymousClass001.A0l(A13));
                A0n.append(':');
                A0n.append(AnonymousClass001.A0k(A13));
            }
        }
        if (collection != null) {
            for (C05730Sx r3 : collection) {
                if (z) {
                    z = false;
                } else {
                    A0n.append(',');
                }
                AnonymousClass0IW r10 = r3.A02;
                A0n.append(AnonymousClass0WY.A1E("cur", "_", r10.A01(), "_", AnonymousClass0T1.A00(r10.A01)));
                A0n.append(':');
                A0n.append(r3.A00);
                long j = r3.A01;
                if (j != -1) {
                    A0n.append(',');
                    A0n.append(AnonymousClass0WY.A1E("max", "_", r10.A01(), "_", AnonymousClass0T1.A00(r10.A01)));
                    A0n.append(':');
                    A0n.append(j);
                }
            }
        }
        return A0n.toString();
    }
}
