package com.facebook.memorytimeline;

import X.AnonymousClass0VC;
import X.C05750Sz;

public interface MemoryTimeline {
    void ABo(AnonymousClass0VC r1);

    C05750Sz BLw();

    void Dl4(AnonymousClass0VC r1);
}
