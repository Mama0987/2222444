package com.facebook.react.common;

public class JavascriptException extends RuntimeException {
    public String extraDataAsJson;
}
