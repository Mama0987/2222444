package com.facebook.sosource.bsod;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.ImageView;
import android.widget.TextView;

public class BSODActivity extends Activity {
    public static final String APP_NAME_KEY = "com.facebook.sosource.bsod.application_name";
    public static final String BSOD_CAUSE_KEY = "com.facebook.sosource.bsod.bsod_cause_text";
    public static final String BSOD_MSG_ICON = "com.facebook.sosource.bsod.bsod_msg_icon";
    public static final String BSOD_TITLE_KEY = "com.facebook.sosource.bsod.bsod_title_text";
    public boolean A00 = false;

    public final void onCreate(Bundle bundle) {
        RuntimeException runtimeException;
        int i;
        int A002 = AnonymousClass0BS.A00(444714414);
        super.onCreate(bundle);
        Resources resources = getResources();
        Intent intent = getIntent();
        setContentView(2132607243);
        TextView textView = (TextView) findViewById(2131362816);
        TextView textView2 = (TextView) findViewById(2131362819);
        TextView textView3 = (TextView) findViewById(2131362817);
        ImageView imageView = (ImageView) findViewById(2131362818);
        String stringExtra = intent.getStringExtra(APP_NAME_KEY);
        if (stringExtra != null) {
            String stringExtra2 = intent.getStringExtra(BSOD_CAUSE_KEY);
            if (stringExtra2 == null) {
                stringExtra2 = resources.getString(2132017263);
            }
            if (textView != null) {
                textView.setText(resources.getString(2132017263, new Object[]{stringExtra}));
            }
            if (textView3 != null) {
                if (stringExtra2 != null) {
                    textView3.setText(Html.fromHtml(stringExtra2));
                    textView3.setMovementMethod(LinkMovementMethod.getInstance());
                } else {
                    runtimeException = AnonymousClass001.A0V("Missing description");
                    i = 927405545;
                }
            }
            int intExtra = intent.getIntExtra(BSOD_MSG_ICON, 0);
            if (!(imageView == null || intExtra == 0)) {
                imageView.setImageResource(intExtra);
                imageView.setVisibility(0);
            }
            String stringExtra3 = intent.getStringExtra(BSOD_TITLE_KEY);
            if (!(stringExtra3 == null || textView2 == null)) {
                textView2.setText(stringExtra3);
                textView2.setVisibility(0);
            }
            AnonymousClass0BS.A07(-443158044, A002);
            return;
        }
        runtimeException = AnonymousClass001.A0V("Missing app name");
        i = 1765954956;
        AnonymousClass0BS.A07(i, A002);
        throw runtimeException;
    }

    public final void onStop() {
        int A002 = AnonymousClass0BS.A00(459820724);
        super.onStop();
        if (this.A00) {
            AnonymousClass0BS.A07(-1536352030, A002);
            return;
        }
        try {
            System.exit(10);
        } catch (Throwable unused) {
        }
        AnonymousClass0BS.A07(-1829284441, A002);
    }

    public void setTestModeDontExit(boolean z) {
        this.A00 = z;
    }
}
