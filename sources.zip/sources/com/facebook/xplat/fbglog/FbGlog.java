package com.facebook.xplat.fbglog;

import X.C06650Xh;
import X.C14270pR;
import X.C14280pS;
import X.C16810u4;
import java.util.List;

public class FbGlog {
    public static C14280pS sCallback;

    public static native void setLogLevel(int i);

    public static native void setSkipSubscribe(boolean z);

    static {
        C16810u4.loadLibrary("fb");
        if (C06650Xh.A00) {
            setSkipSubscribe(true);
            ensureSubscribedToBLogLevelChanges();
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [X.0pS, java.lang.Object] */
    public static synchronized void ensureSubscribedToBLogLevelChanges() {
        synchronized (FbGlog.class) {
            if (sCallback == null) {
                ? obj = new Object();
                sCallback = obj;
                List list = C14270pR.A00;
                synchronized (C14270pR.class) {
                    list.add(obj);
                }
                setLogLevel(C14270pR.A01.BRb());
            }
        }
    }
}
