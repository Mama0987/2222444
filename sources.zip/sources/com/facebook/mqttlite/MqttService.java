package com.facebook.mqttlite;

import X.AnonymousClass0BS;
import X.AnonymousClass0QM;
import X.AnonymousClass0TK;
import android.content.Intent;

public class MqttService extends AnonymousClass0QM {
    public final String A0A() {
        return "com.facebook.mqttlite.MqttServiceDelegate";
    }

    public final int onStartCommand(Intent intent, int i, int i2) {
        int A04 = AnonymousClass0BS.A04(-2102351232);
        super.onStartCommand(intent, i, i2);
        if (AnonymousClass0TK.A01(getApplicationContext())) {
            AnonymousClass0BS.A0A(-1774946580, A04);
            return 3;
        }
        AnonymousClass0BS.A0A(2077879395, A04);
        return 1;
    }
}
