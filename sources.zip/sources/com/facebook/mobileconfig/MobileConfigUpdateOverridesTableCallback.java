package com.facebook.mobileconfig;

public interface MobileConfigUpdateOverridesTableCallback {
    void onOverridesFileUpdated();
}
