package com.facebook.mobileconfig;

public interface MobileConfigCanaryChangeListener {
    void onConfigChanged();
}
