package com.facebook.xzdecoder;

import X.AnonymousClass001;
import X.C16810u4;
import com.facebook.common.dextricks.Constants;
import java.io.InputStream;

public class XzInputStream extends InputStream {
    public int clientOutPos;
    public byte[] inBuf = new byte[Constants.LOAD_RESULT_PGO];
    public InputStream inFile;
    public int inPos;
    public int inSize;
    public byte[] outBuf = new byte[Constants.LOAD_RESULT_PGO];
    public int outPos;
    public long state = initializeState();

    public static native long decompressStream(long j, byte[] bArr, int i, int i2, byte[] bArr2, int i3, int i4);

    public static native void end(long j);

    public static native void initializeLibrary();

    public static native long initializeState();

    static {
        C16810u4.loadLibrary("fb_xzdecoder");
        initializeLibrary();
    }

    public void close() {
        this.inFile.close();
        long j = this.state;
        if (j != 0) {
            end(j);
            this.state = 0;
        }
    }

    public int read(byte[] bArr, int i, int i2) {
        int i3 = i;
        int i4 = 0;
        int i5 = i2;
        byte[] bArr2 = bArr;
        if (i2 < 0 || i < 0 || i + i2 > bArr2.length) {
            throw new IndexOutOfBoundsException(String.format("buf.length = %d, off = %d, len = %d", new Object[]{Integer.valueOf(bArr2.length), Integer.valueOf(i3), Integer.valueOf(i5)}));
        }
        if (this.state != 0) {
            int i6 = i5;
            while (true) {
                if (i4 >= i5) {
                    break;
                }
                int i7 = this.clientOutPos;
                int i8 = this.outPos;
                if (i7 < i8) {
                    int min = Math.min(i6, i8 - i7);
                    System.arraycopy(this.outBuf, i7, bArr2, i3, min);
                    this.clientOutPos += min;
                    i6 -= min;
                    i3 += min;
                    i4 += min;
                } else {
                    int i9 = this.inPos;
                    int i10 = this.inSize;
                    if (i9 == i10) {
                        this.inSize = 0;
                        int i11 = 0;
                        this.inPos = 0;
                        while (true) {
                            InputStream inputStream = this.inFile;
                            byte[] bArr3 = this.inBuf;
                            int read = inputStream.read(bArr3, i11, bArr3.length - i11);
                            i10 = this.inSize;
                            if (read != -1) {
                                i10 += read;
                                this.inSize = i10;
                                i11 = i10;
                                if (i10 >= 32768) {
                                    break;
                                }
                            } else if (i10 <= 0) {
                                if (i4 == 0) {
                                    return -1;
                                }
                            }
                        }
                    }
                    long j = this.state;
                    byte[] bArr4 = this.inBuf;
                    int i12 = this.inPos;
                    byte[] bArr5 = this.outBuf;
                    long decompressStream = decompressStream(j, bArr4, i12, i10, bArr5, 0, bArr5.length);
                    this.inPos = (int) (decompressStream >>> 32);
                    this.outPos = (int) decompressStream;
                    this.clientOutPos = 0;
                }
            }
            return i4;
        }
        throw AnonymousClass001.A0G("Stream closed");
    }

    public XzInputStream(InputStream inputStream) {
        this.inFile = inputStream;
    }

    public int read() {
        if (this.state != 0) {
            int i = this.clientOutPos;
            if (i == this.outPos) {
                int i2 = this.inPos;
                int i3 = this.inSize;
                if (i2 == i3) {
                    this.inSize = 0;
                    int i4 = 0;
                    this.inPos = 0;
                    while (true) {
                        InputStream inputStream = this.inFile;
                        byte[] bArr = this.inBuf;
                        int read = inputStream.read(bArr, i4, bArr.length - i4);
                        i3 = this.inSize;
                        if (read != -1) {
                            i3 += read;
                            this.inSize = i3;
                            i4 = i3;
                            if (i3 >= 32768) {
                                break;
                            }
                        } else if (i3 <= 0) {
                            return -1;
                        }
                    }
                }
                long j = this.state;
                byte[] bArr2 = this.inBuf;
                int i5 = this.inPos;
                byte[] bArr3 = this.outBuf;
                long decompressStream = decompressStream(j, bArr2, i5, i3, bArr3, 0, bArr3.length);
                this.inPos = (int) (decompressStream >>> 32);
                this.outPos = (int) decompressStream;
                this.clientOutPos = 0;
                i = 0;
            }
            byte[] bArr4 = this.outBuf;
            this.clientOutPos = i + 1;
            return bArr4[i];
        }
        throw AnonymousClass001.A0G("Stream closed");
    }
}
