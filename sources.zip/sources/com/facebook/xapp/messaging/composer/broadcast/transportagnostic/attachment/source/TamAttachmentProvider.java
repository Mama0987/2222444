package com.facebook.xapp.messaging.composer.broadcast.transportagnostic.attachment.source;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.C014507v;
import X.C10640fx;
import X.C14390pf;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.FileNotFoundException;

public final class TamAttachmentProvider extends C10640fx {
    public static final String[] A00 = {C14390pf.ATTR_PATH};

    public static AssetFileDescriptor getFileDescriptorFromPath(Context context, String str) {
        Uri uri = null;
        try {
            uri = C014507v.A02(str);
        } catch (SecurityException | UnsupportedOperationException unused) {
        }
        if (uri == null) {
            throw new FileNotFoundException("path is invalid");
        } else if (!"content".equals(uri.getScheme()) || context == null) {
            if (uri.getPath() != null) {
                str = uri.getPath();
            }
            try {
                return new AssetFileDescriptor(ParcelFileDescriptor.open(AnonymousClass001.A0E(str), 268435456), 0, -1);
            } catch (FileNotFoundException e) {
                throw new FileNotFoundException(AnonymousClass0WY.A1Q("ParcelFileDescriptor.open : ", e));
            }
        } else {
            try {
                return context.getContentResolver().openAssetFileDescriptor(uri, "r");
            } catch (FileNotFoundException e2) {
                throw new FileNotFoundException(AnonymousClass0WY.A1Q("ContentResolver.openAssetFileDescriptor : ", e2));
            }
        }
    }
}
