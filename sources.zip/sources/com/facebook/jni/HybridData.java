package com.facebook.jni;

import X.C02800Dx;
import X.C16810u4;

public class HybridData {
    public static final HybridData $redex_init_class = null;
    public final Destructor mDestructor = new C02800Dx(this);

    public class Destructor extends C02800Dx {
        public volatile long mNativePointer;

        public static native void deleteNative(long j);

        public final void destruct() {
            deleteNative(this.mNativePointer);
            this.mNativePointer = 0;
        }

        public Destructor(Object obj) {
            super(obj);
        }
    }

    public synchronized void resetNative() {
        this.mDestructor.destruct();
    }

    static {
        C16810u4.loadLibrary("fbjni");
    }

    public boolean isValid() {
        if (this.mDestructor.mNativePointer != 0) {
            return true;
        }
        return false;
    }
}
