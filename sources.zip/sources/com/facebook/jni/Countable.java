package com.facebook.jni;

import X.AnonymousClass0BS;
import X.C16810u4;

public class Countable {
    public long mInstance = 0;

    public native void dispose();

    static {
        C16810u4.loadLibrary("fb");
    }

    public void finalize() {
        int A03 = AnonymousClass0BS.A03(-1205671323);
        dispose();
        AnonymousClass0BS.A09(-2037648308, A03);
    }
}
