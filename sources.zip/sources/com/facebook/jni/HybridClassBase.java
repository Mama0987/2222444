package com.facebook.jni;

public abstract class HybridClassBase extends HybridData {
}
