package com.facebook.jni;

import X.C16810u4;

public class ThreadScopeSupport {
    public static native void runStdFunctionImpl(long j);

    static {
        C16810u4.loadLibrary("fbjni");
    }

    public static void runStdFunction(long j) {
        runStdFunctionImpl(j);
    }
}
