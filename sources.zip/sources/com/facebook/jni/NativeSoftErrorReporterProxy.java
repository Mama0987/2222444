package com.facebook.jni;

import X.AnonymousClass001;
import X.AnonymousClass02Z;
import X.AnonymousClass0ER;
import X.AnonymousClass0WY;
import X.C011706p;
import X.C011906r;
import X.C012306w;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;

public final class NativeSoftErrorReporterProxy {
    public static ExecutorService sErrorReportingExecutorService;
    public static AnonymousClass0ER sErrorReportingGkReader;
    public static WeakReference sFbErrorReporterWeakReference;
    public static final LinkedList sSoftErrorCache = new LinkedList();

    public static native void generateNativeSoftError();

    public static void softReport(int i, String str, String str2, int i2) {
        softReport(i, str, str2, (Throwable) null, i2);
    }

    public static synchronized void flushSoftErrorCacheAsync() {
        AnonymousClass02Z r3;
        synchronized (NativeSoftErrorReporterProxy.class) {
            WeakReference weakReference = sFbErrorReporterWeakReference;
            if (!(weakReference == null || (r3 = (AnonymousClass02Z) weakReference.get()) == null || sErrorReportingGkReader == null)) {
                LinkedList linkedList = sSoftErrorCache;
                if (!linkedList.isEmpty()) {
                    ArrayList A0t = AnonymousClass001.A0t();
                    synchronized (linkedList) {
                        A0t.addAll(linkedList);
                        linkedList.clear();
                    }
                    sErrorReportingExecutorService.execute(new C012306w(r3, A0t));
                }
            }
        }
    }

    public static void softReport(int i, String str, String str2, Throwable th, int i2) {
        String str3;
        if (i == 1) {
            str3 = "<level:warning> ";
        } else if (i != 2) {
            str3 = "<level:unknown> ";
        } else {
            str3 = "<level:mustfix> ";
        }
        String A0w = AnonymousClass0WY.A0w("[Native] ", str3, str);
        synchronized (NativeSoftErrorReporterProxy.class) {
            LinkedList linkedList = sSoftErrorCache;
            synchronized (linkedList) {
                C011906r A01 = C011706p.A01(A0w, str2);
                A01.A04 = th;
                A01.A00 = i2;
                linkedList.addLast(new C011706p(A01));
                while (linkedList.size() >= 50) {
                    linkedList.removeFirst();
                }
            }
        }
        flushSoftErrorCacheAsync();
    }
}
