package com.facebook.jni.kotlin;

import X.C15800sA;
import X.C18640xZ;
import com.facebook.jni.HybridData;
import kotlin.jvm.functions.Function0;

public final class NativeFunction0 extends C18640xZ implements Function0 {
    public final HybridData mHybridData;

    public NativeFunction0(HybridData hybridData) {
        C15800sA.A0D(hybridData, 1);
        this.mHybridData = hybridData;
    }

    public native Object invoke();
}
