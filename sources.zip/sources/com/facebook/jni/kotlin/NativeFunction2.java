package com.facebook.jni.kotlin;

import X.C15800sA;
import X.C18640xZ;
import com.facebook.jni.HybridData;
import kotlin.jvm.functions.Function2;

public final class NativeFunction2 extends C18640xZ implements Function2 {
    public final HybridData mHybridData;

    public NativeFunction2(HybridData hybridData) {
        C15800sA.A0D(hybridData, 1);
        this.mHybridData = hybridData;
    }

    public native Object invoke(Object obj, Object obj2);
}
