package com.facebook.acra.asyncbroadcastreceiver;

import X.AnonymousClass001;
import X.C15800sA;
import android.content.BroadcastReceiver;
import android.os.SystemClock;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AsyncBroadcastReceiverObserver {
    public static final String ACTIVE_RECEIVERS = "active_receivers";
    public static final String ACTIVE_RECEIVERS_COUNT = "active_receivers_count";
    public static final String BROADCAST_UPTIME_MS = "broadcast_uptime_ms";
    public static final String CURRENT_UPTIME_MS = "current_uptime_ms";
    public static final AsyncBroadcastReceiverObserver INSTANCE = new Object();
    public static final String PENDING_RESULT = "pending_result";
    public static final String RECEIVER = "receiver";
    public static final String RECEIVER_CLASS = "receiver_class";
    public static final ConcurrentHashMap activeReceivers = new ConcurrentHashMap();

    public static final void finish(BroadcastReceiver.PendingResult pendingResult) {
        C15800sA.A0D(pendingResult, 0);
        activeReceivers.remove(pendingResult);
    }

    public static final String blameActiveReceivers() {
        ConcurrentHashMap concurrentHashMap = activeReceivers;
        if (concurrentHashMap.isEmpty()) {
            return null;
        }
        JSONObject A19 = AnonymousClass001.A19();
        try {
            A19.put(CURRENT_UPTIME_MS, SystemClock.uptimeMillis());
            A19.put(ACTIVE_RECEIVERS_COUNT, concurrentHashMap.size());
            JSONArray jSONArray = new JSONArray();
            Iterator A11 = AnonymousClass001.A11(concurrentHashMap);
            while (A11.hasNext()) {
                jSONArray.put(A11.next());
            }
            A19.put(ACTIVE_RECEIVERS, jSONArray);
            return A19.toString();
        } catch (JSONException e) {
            return e.toString();
        }
    }

    public static final void clear() {
        activeReceivers.clear();
    }

    private final JSONObject blame(BroadcastReceiver broadcastReceiver, BroadcastReceiver.PendingResult pendingResult) {
        JSONObject A19 = AnonymousClass001.A19();
        try {
            A19.put(BROADCAST_UPTIME_MS, SystemClock.uptimeMillis());
            A19.put(RECEIVER_CLASS, broadcastReceiver.getClass());
            A19.put(RECEIVER, broadcastReceiver.toString());
            A19.put(PENDING_RESULT, pendingResult.toString());
            return A19;
        } catch (JSONException e) {
            try {
                A19.put("error", e.toString());
                return A19;
            } catch (JSONException e2) {
                throw AnonymousClass001.A0X(e2);
            }
        }
    }

    public static final void goAsync(BroadcastReceiver broadcastReceiver, BroadcastReceiver.PendingResult pendingResult) {
        C15800sA.A0F(broadcastReceiver, pendingResult);
        activeReceivers.put(pendingResult, INSTANCE.blame(broadcastReceiver, pendingResult));
    }
}
