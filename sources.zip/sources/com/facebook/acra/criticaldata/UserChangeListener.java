package com.facebook.acra.criticaldata;

public interface UserChangeListener {
    void userHasChanged();
}
