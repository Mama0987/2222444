package com.facebook.acra.customdata;

import X.AnonymousClass001;
import java.util.Iterator;
import java.util.Map;

public class ProxyCustomDataStore implements CustomDataStore {
    public static CustomDataStore dataStore = new ACRACustomDataStore();

    public class Holder {
        public static final ProxyCustomDataStore CUSTOM_DATA = new Object();
    }

    public synchronized boolean containsKey(String str) {
        return dataStore.containsKey(str);
    }

    public synchronized String getCustomData(String str) {
        return dataStore.getCustomData(str);
    }

    public synchronized Map getSnapshot() {
        return dataStore.getSnapshot();
    }

    public synchronized void removeCustomData(String str) {
        dataStore.removeCustomData(str);
    }

    public synchronized void setCustomData(String str, String str2, Object... objArr) {
        dataStore.setCustomData(str, str2, objArr);
    }

    public synchronized void setDataStore(CustomDataStore customDataStore) {
        Iterator A12 = AnonymousClass001.A12(dataStore.getSnapshot());
        while (A12.hasNext()) {
            Map.Entry A13 = AnonymousClass001.A13(A12);
            customDataStore.setCustomData(AnonymousClass001.A0l(A13), AnonymousClass001.A0k(A13), new Object[0]);
        }
        dataStore = customDataStore;
    }

    public static ProxyCustomDataStore getInstance() {
        return Holder.CUSTOM_DATA;
    }
}
