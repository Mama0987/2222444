package com.facebook.acra.customdata;

import X.AnonymousClass001;
import java.util.Formatter;
import java.util.Map;
import java.util.TreeMap;

public class ACRACustomDataStore implements CustomDataStore {
    public final Map mInstanceCustomParameters = new TreeMap();

    public boolean containsKey(String str) {
        return this.mInstanceCustomParameters.containsKey(str);
    }

    public String getCustomData(String str) {
        return AnonymousClass001.A0e(str, this.mInstanceCustomParameters);
    }

    public Map getSnapshot() {
        return new TreeMap(this.mInstanceCustomParameters);
    }

    public void removeCustomData(String str) {
        if (str != null) {
            this.mInstanceCustomParameters.remove(str);
        }
    }

    public void setCustomData(String str, String str2, Object... objArr) {
        if (str == null) {
            return;
        }
        if (str2 != null) {
            if (objArr.length > 0) {
                StringBuilder A0m = AnonymousClass001.A0m();
                Formatter formatter = new Formatter(A0m);
                formatter.format(str2, objArr);
                formatter.close();
                str2 = A0m.toString();
            }
            this.mInstanceCustomParameters.put(str, str2);
            return;
        }
        removeCustomData(str);
    }
}
