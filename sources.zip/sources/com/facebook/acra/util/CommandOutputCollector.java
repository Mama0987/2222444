package com.facebook.acra.util;

public class CommandOutputCollector {
    /* JADX WARNING: Can't wrap try/catch for region: R(14:1|2|(1:4)|5|6|7|(2:8|(1:10)(1:11))|12|13|14|15|16|17|18) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x003f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String collect(java.lang.String... r8) {
        /*
            java.lang.StringBuilder r7 = X.AnonymousClass001.A0m()
            java.lang.ProcessBuilder r1 = new java.lang.ProcessBuilder
            r1.<init>(r8)
            r0 = 1
            java.lang.ProcessBuilder r0 = r1.redirectErrorStream(r0)
            java.lang.Process r6 = r0.start()
            java.io.OutputStream r0 = r6.getOutputStream()     // Catch:{ all -> 0x0058 }
            if (r0 == 0) goto L_0x001f
            java.io.OutputStream r0 = r6.getOutputStream()     // Catch:{ all -> 0x0058 }
            r0.close()     // Catch:{ all -> 0x0058 }
        L_0x001f:
            java.io.InputStream r0 = r6.getInputStream()     // Catch:{ all -> 0x0058 }
            java.io.InputStreamReader r5 = new java.io.InputStreamReader     // Catch:{ all -> 0x0058 }
            r5.<init>(r0)     // Catch:{ all -> 0x0058 }
            r4 = 4096(0x1000, float:5.74E-42)
            char[] r3 = new char[r4]     // Catch:{ all -> 0x004e }
        L_0x002c:
            r2 = 0
            int r1 = r5.read(r3, r2, r4)     // Catch:{ all -> 0x004e }
            r0 = -1
            if (r1 == r0) goto L_0x0038
            r7.append(r3, r2, r1)     // Catch:{ all -> 0x004e }
            goto L_0x002c
        L_0x0038:
            r5.close()     // Catch:{ all -> 0x0058 }
            r6.waitFor()     // Catch:{ InterruptedException -> 0x003f }
            goto L_0x0046
        L_0x003f:
            java.lang.Thread r0 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0058 }
            r0.interrupt()     // Catch:{ all -> 0x0058 }
        L_0x0046:
            r6.destroy()
            java.lang.String r0 = r7.toString()
            return r0
        L_0x004e:
            r1 = move-exception
            r5.close()     // Catch:{ all -> 0x0053 }
            goto L_0x0057
        L_0x0053:
            r0 = move-exception
            X.AnonymousClass0ZM.A00(r1, r0)     // Catch:{ all -> 0x0058 }
        L_0x0057:
            throw r1     // Catch:{ all -> 0x0058 }
        L_0x0058:
            r0 = move-exception
            r6.destroy()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.util.CommandOutputCollector.collect(java.lang.String[]):java.lang.String");
    }
}
