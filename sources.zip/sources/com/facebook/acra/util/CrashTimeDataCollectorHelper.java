package com.facebook.acra.util;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.C003002b;
import X.C14270pR;
import android.os.Build;
import android.os.Process;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class CrashTimeDataCollectorHelper {
    public static final String LOG_TAG = "ACRA";
    public static final String TIME_STAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.000ZZZZZ";

    public static String formatTimestamp(long j) {
        return new SimpleDateFormat(TIME_STAMP_FORMAT, Locale.US).format(new Date(j));
    }

    public static String getJailStatus() {
        String str = Build.TAGS;
        if (str != null && str.contains("test-keys")) {
            return "yes";
        }
        try {
            if (AnonymousClass001.A1X("/system/app/Superuser.apk")) {
                return "yes";
            }
        } catch (Exception e) {
            C14270pR.A0R(LOG_TAG, e, "Failed to find Superuser.pak");
        }
        Map<String, String> map = System.getenv();
        if (map == null) {
            return "no";
        }
        String str2 = map.get("PATH");
        C003002b.A00(str2);
        String[] split = str2.split(":");
        int length = split.length;
        int i = 0;
        while (i < length) {
            try {
                if (AnonymousClass001.A1X(AnonymousClass0WY.A0i(split[i], "/su"))) {
                    return "yes";
                }
                i++;
            } catch (Exception e2) {
                C14270pR.A0R(LOG_TAG, e2, "Failed to find su binary in the PATH");
            }
        }
        return "no";
    }

    public static String formatAppInstallTime(long j) {
        return formatTimestamp(j);
    }

    public static String formatAppUpgradeTime(long j) {
        return formatTimestamp(j);
    }

    public static UUID generateReportUuid() {
        try {
            return UUID.randomUUID();
        } catch (Throwable unused) {
            return UUID.nameUUIDFromBytes(String.format("%s-%s-%s", new Object[]{AnonymousClass001.A0Q(), Long.valueOf(System.nanoTime()), Integer.valueOf(Process.myTid())}).getBytes());
        }
    }
}
