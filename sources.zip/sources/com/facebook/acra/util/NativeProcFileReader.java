package com.facebook.acra.util;

import X.AnonymousClass001;
import com.facebook.acra.util.ProcFileReader;
import java.util.concurrent.atomic.AtomicBoolean;

public class NativeProcFileReader extends ProcFileReader {
    public static final String TAG = "NativeProcFileReader";
    public static NativeProcFileReader sInstance;
    public static Thread sLoadSoThread;
    public static final AtomicBoolean sReadyToUse = AnonymousClass001.A17();

    private native int[] getOpenFDLimitsNative();

    public native int getOpenFDCount();

    public native String getOpenFileDescriptors();

    public static synchronized NativeProcFileReader getInstance() {
        NativeProcFileReader nativeProcFileReader;
        synchronized (NativeProcFileReader.class) {
            nativeProcFileReader = sInstance;
            if (nativeProcFileReader == null) {
                nativeProcFileReader = new NativeProcFileReader();
                sInstance = nativeProcFileReader;
            }
        }
        return nativeProcFileReader;
    }

    public static boolean isReady() {
        return sReadyToUse.get();
    }

    public static void nativeLibraryLoaded() {
        Class<NativeProcFileReader> cls = NativeProcFileReader.class;
        synchronized (cls) {
            sReadyToUse.set(true);
            cls.notifyAll();
        }
    }

    public NativeProcFileReader() {
        if (!sReadyToUse.get()) {
            throw AnonymousClass001.A0P("Class is not ready");
        }
    }

    public ProcFileReader.OpenFDLimits getOpenFDLimits() {
        int[] openFDLimitsNative = getOpenFDLimitsNative();
        return new ProcFileReader.OpenFDLimits(openFDLimitsNative[0], openFDLimitsNative[1]);
    }
}
