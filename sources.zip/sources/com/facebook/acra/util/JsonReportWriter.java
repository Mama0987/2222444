package com.facebook.acra.util;

import X.AnonymousClass001;
import X.AnonymousClass0ZM;
import X.C14270pR;
import android.util.JsonWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

public class JsonReportWriter {
    public static String LOG_TAG = "JsonReportWriter";

    public static boolean writeGzipJsonReport(Map map, Map map2, File file) {
        FileOutputStream fileOutputStream;
        try {
            fileOutputStream = new FileOutputStream(file);
            writeGzipJsonReport(map, map2, (OutputStream) fileOutputStream);
            fileOutputStream.close();
            file.length();
            return true;
        } catch (IOException e) {
            C14270pR.A0L(LOG_TAG, "Could not write report %s", e, file.getPath());
            return false;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
        }
        throw th;
    }

    public static void writeJsonReport(Map map, Map map2, OutputStream outputStream) {
        JsonWriter jsonWriter = new JsonWriter(new OutputStreamWriter(outputStream, "UTF-8"));
        jsonWriter.setIndent("  ");
        jsonWriter.beginObject();
        Iterator A12 = AnonymousClass001.A12(map);
        while (A12.hasNext()) {
            Map.Entry A13 = AnonymousClass001.A13(A12);
            if (A13.getValue() == null) {
                C14270pR.A0O(LOG_TAG, "Ignoring NULL Field %s", A13.getKey());
            } else {
                jsonWriter.name(AnonymousClass001.A0l(A13)).value(AnonymousClass001.A0k(A13));
            }
        }
        Iterator A122 = AnonymousClass001.A12(map2);
        while (A122.hasNext()) {
            Map.Entry A132 = AnonymousClass001.A13(A122);
            A132.getKey();
            A132.getValue();
            InputStreamField inputStreamField = (InputStreamField) A132.getValue();
            InputStream inputStream = inputStreamField.mInputStream;
            if (inputStream instanceof FileInputStream) {
                ((FileInputStream) inputStream).getChannel().position(0);
            }
            try {
                jsonWriter.name(AnonymousClass001.A0l(A132)).value(AttachmentUtil.loadAttachment(inputStream, (int) inputStreamField.mLength));
            } catch (Throwable th) {
                jsonWriter.name(AnonymousClass001.A0l(A132)).value("");
                C14270pR.A0M(LOG_TAG, "Attachment skipped len %d ", th, Long.valueOf(inputStreamField.mLength));
            }
        }
        jsonWriter.endObject();
        jsonWriter.close();
    }

    public static void writeGzipJsonReport(Map map, Map map2, OutputStream outputStream) {
        GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(outputStream);
        try {
            writeJsonReport(map, map2, gZIPOutputStream);
            gZIPOutputStream.close();
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }
}
