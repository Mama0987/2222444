package com.facebook.acra.util;

public interface AcraRadioListener {
    void onRadioActive(long j, long j2, int i);
}
