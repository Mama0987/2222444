package com.facebook.acra.util.minidump;

import X.AnonymousClass001;
import X.AnonymousClass0ZM;
import X.C14270pR;
import android.text.TextUtils;
import android.util.JsonReader;
import android.util.JsonToken;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.util.HashSet;

public class MinidumpReader {
    public static final String ALT_STACK = "WriteThreadUnwindStream failed";
    public static final String CUSTOM_STREAM_GLOBAL = "global";
    public static final String LOG_TAG = "MinidumpReader";
    public static final int MD_FB_APP_CUSTOM_DATA = -87110918;
    public static final int MD_FB_APP_STATE_LOG = -87110452;
    public static final int MD_FB_APP_VERSION_CODE = -87110917;
    public static final int MD_FB_APP_VERSION_NAME = -87110916;
    public static final int MD_FB_DUMP_ERROR_LOG = -87110912;
    public static final int MD_FB_JAVA_STACK = -87110915;
    public static final int MD_FB_STREAM_MARKERS = -87162880;
    public static final long MD_FB_UNWIND_SYMBOLS_OFFSET = 17592186044416L;
    public static final int MD_HEADER_SIGNATURE = 1347241037;
    public static final int MD_LINUX_CMD_LINE = 1197932550;
    public static final int MD_MODULE_LIST_STREAM = 4;
    public static final int MD_MODULE_LIST_STREAM_OFFSET = 16;
    public static final int MD_THREAD_LIST_STREAM_OFFSET = 8;
    public static final int MODULE_FULL_SIZE = 108;
    public static final String MODULE_LIST = "WriteMappings failed";
    public static final int MODULE_LIST_OFFSET = 24;
    public static final String THREAD_LIST = "WriteThreadListStream failed";
    public RandomAccessFile mHandle;
    public int mStreamCount;
    public int mStreamsPos;

    public static JsonReader retrieveJsonNode(JsonReader jsonReader, String str) {
        if (jsonReader != null) {
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                String nextName = jsonReader.nextName();
                if (jsonReader.peek() != JsonToken.NULL) {
                    if (nextName.equals(str)) {
                        return jsonReader;
                    }
                    jsonReader.skipValue();
                }
            }
            jsonReader.endObject();
        }
        return null;
    }

    public HashSet getModuleList() {
        try {
            MDLocationDescription findStream = findStream(4);
            if (findStream == null) {
                C14270pR.A0F(LOG_TAG, "Stream is Null");
                return null;
            }
            this.mHandle.seek((long) findStream.pos);
            int readIntLE = readIntLE();
            HashSet A0x = AnonymousClass001.A0x();
            int i = findStream.pos;
            for (int i2 = 0; i2 < readIntLE; i2++) {
                this.mHandle.seek((long) (i + 24));
                this.mHandle.seek((long) readIntLE());
                String moduleString = getModuleString(new MDLocationDescription((int) this.mHandle.getFilePointer(), readIntLE()));
                if (isSystemModule(moduleString)) {
                    A0x.add(moduleString);
                }
                i += MODULE_FULL_SIZE;
            }
            return A0x;
        } catch (IOException e) {
            C14270pR.A0R(LOG_TAG, e, "getModuleList failed to read");
            return null;
        }
    }

    public class MDLocationDescription {
        public int pos;
        public int size;

        public MDLocationDescription(int i, int i2) {
            this.pos = i;
            this.size = i2;
        }
    }

    public class MinidumpMarkers {
        public long endMarker;
        public long startMarker;

        public MinidumpMarkers(long j, long j2) {
            this.startMarker = j;
            this.endMarker = j2;
        }
    }

    public static boolean checkMinidumpErrLogStream(String str) {
        if (str == null) {
            return false;
        }
        if (str.contains(MODULE_LIST)) {
            return true;
        }
        if (!str.contains(THREAD_LIST) || !str.contains(ALT_STACK)) {
            return false;
        }
        return true;
    }

    public static boolean checkMinidumpMarkerStream(long j) {
        boolean A1R = AnonymousClass001.A1R(((16 & j) > 0 ? 1 : ((16 & j) == 0 ? 0 : -1)));
        boolean A1R2 = AnonymousClass001.A1R(((8 & j) > 0 ? 1 : ((8 & j) == 0 ? 0 : -1)));
        boolean A1R3 = AnonymousClass001.A1R(((j & MD_FB_UNWIND_SYMBOLS_OFFSET) > 0 ? 1 : ((j & MD_FB_UNWIND_SYMBOLS_OFFSET) == 0 ? 0 : -1)));
        if (A1R || (A1R2 && A1R3)) {
            return true;
        }
        return false;
    }

    private MDLocationDescription findStream(int i) {
        this.mHandle.seek((long) this.mStreamsPos);
        for (int i2 = 0; i2 < this.mStreamCount; i2++) {
            int readIntLE = readIntLE();
            int readIntLE2 = readIntLE();
            int readIntLE3 = readIntLE();
            if (readIntLE == i) {
                return new MDLocationDescription(readIntLE3, readIntLE2);
            }
        }
        return null;
    }

    private Integer getInt(MDLocationDescription mDLocationDescription) {
        if (mDLocationDescription == null || mDLocationDescription.size != 4) {
            return null;
        }
        this.mHandle.seek((long) mDLocationDescription.pos);
        return Integer.valueOf(readIntLE());
    }

    private String getModuleString(MDLocationDescription mDLocationDescription) {
        this.mHandle.seek((long) mDLocationDescription.pos);
        int i = mDLocationDescription.size;
        byte[] bArr = new byte[i];
        byte[] bArr2 = new byte[(i / 2)];
        this.mHandle.read(bArr);
        for (int i2 = 0; i2 < mDLocationDescription.size / 2; i2++) {
            bArr2[i2] = bArr[i2 * 2];
        }
        return new String(bArr2);
    }

    private String getString(MDLocationDescription mDLocationDescription) {
        if (mDLocationDescription == null) {
            return null;
        }
        this.mHandle.seek((long) mDLocationDescription.pos);
        byte[] bArr = new byte[mDLocationDescription.size];
        this.mHandle.read(bArr);
        return new String(bArr);
    }

    public static boolean isSystemModule(String str) {
        if (str == null) {
            return false;
        }
        if (!str.startsWith("/system") && !str.startsWith("/apex") && !str.startsWith("/vendor") && !str.startsWith("/odm")) {
            return false;
        }
        if (str.endsWith(".so") || str.contains("app_process") || str.endsWith("linker")) {
            return true;
        }
        return false;
    }

    private int readIntLE() {
        int readInt = this.mHandle.readInt();
        return ((readInt >> 24) & 255) | ((readInt & 255) << 24) | ((65280 & readInt) << 8) | ((16711680 & readInt) >> 8);
    }

    private long readLongIntLE() {
        long readLong = this.mHandle.readLong();
        return (((readLong >> 56) & 255) << 0) | (((readLong >> 0) & 255) << 56) | (((readLong >> 8) & 255) << 48) | (((readLong >> 16) & 255) << 40) | (((readLong >> 24) & 255) << 32) | (((readLong >> 32) & 255) << 24) | (((readLong >> 40) & 255) << 16) | (((readLong >> 48) & 255) << 8);
    }

    public String getCustomDataFromJson(String str, String str2) {
        String str3;
        JsonReader jsonReader = new JsonReader(new StringReader(str));
        try {
            JsonReader retrieveJsonNode = retrieveJsonNode(retrieveJsonNode(jsonReader, CUSTOM_STREAM_GLOBAL), str2);
            if (retrieveJsonNode != null) {
                str3 = retrieveJsonNode.nextString();
            } else {
                str3 = null;
            }
            jsonReader.close();
            return str3;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
            throw th;
        }
    }

    public MinidumpMarkers getMinidumpMarkers() {
        try {
            MDLocationDescription findStream = findStream(MD_FB_STREAM_MARKERS);
            if (findStream == null) {
                return null;
            }
            this.mHandle.seek((long) findStream.pos);
            return new MinidumpMarkers(readLongIntLE(), readLongIntLE());
        } catch (IOException e) {
            C14270pR.A0R(LOG_TAG, e, "getMinidumpMarkers failed to read");
            return null;
        }
    }

    public MinidumpReader(RandomAccessFile randomAccessFile) {
        this.mHandle = randomAccessFile;
        randomAccessFile.seek(0);
        if (readIntLE() == 1347241037) {
            this.mHandle.skipBytes(4);
            this.mStreamCount = readIntLE();
            this.mStreamsPos = readIntLE();
            return;
        }
        throw AnonymousClass001.A0V("Invalid minidump signature");
    }

    public boolean checkIfMinidumpCorrupted() {
        boolean z;
        MinidumpMarkers minidumpMarkers = getMinidumpMarkers();
        if (minidumpMarkers != null) {
            z = checkMinidumpMarkerStream(minidumpMarkers.startMarker ^ minidumpMarkers.endMarker);
        } else {
            z = false;
        }
        boolean checkMinidumpErrLogStream = checkMinidumpErrLogStream(getErrorLogData());
        if (z || checkMinidumpErrLogStream) {
            return true;
        }
        return false;
    }

    public String getCustomData(String str) {
        String str2;
        try {
            str2 = getString((int) MD_FB_APP_CUSTOM_DATA);
            if (str2 != null) {
                try {
                    return getCustomDataFromJson(str2, str);
                } catch (Exception e) {
                    e = e;
                    C14270pR.A0L(LOG_TAG, "getCustomData error: %s", e, str2);
                    return null;
                }
            }
        } catch (Exception e2) {
            e = e2;
            str2 = "";
            C14270pR.A0L(LOG_TAG, "getCustomData error: %s", e, str2);
            return null;
        }
        return null;
    }

    public String getErrorLogData() {
        try {
            return getString((int) MD_FB_DUMP_ERROR_LOG);
        } catch (IOException e) {
            C14270pR.A0L(LOG_TAG, "getErrorLogData error: %s", e, "");
            return null;
        }
    }

    public String getJavaStack() {
        try {
            return getString((int) MD_FB_JAVA_STACK);
        } catch (IOException e) {
            C14270pR.A0R(LOG_TAG, e, "getJavaStack error");
            return null;
        }
    }

    public Integer getInt(int i) {
        return getInt(findStream(i));
    }

    public String getString(int i) {
        String string = getString(findStream(i));
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        return string;
    }
}
