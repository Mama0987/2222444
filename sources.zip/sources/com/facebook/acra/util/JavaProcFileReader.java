package com.facebook.acra.util;

import X.AnonymousClass001;
import X.AnonymousClass0ZM;
import X.C13940ok;
import X.C14270pR;
import android.os.Process;
import com.facebook.acra.util.ProcFileReader;
import com.facebook.common.dextricks.Constants;
import java.io.FileInputStream;
import java.io.IOException;

public class JavaProcFileReader extends ProcFileReader {
    public static final String FD_DIR = String.format("/proc/%s/fd", AnonymousClass001.A1a(Process.myPid()));
    public static final String FD_DIR_STRING = "/fd/";
    public static final String LS_SYMLINK_ARROW = " -> ";
    public static final String PIPE_STRING = "pipe";
    public static final int[] PROC_OPEN_FD_LIMITS_FORMAT = {32, 32, 288, 4384, 4384, 288};
    public static final String SOCKET_STRING = "socket";
    public static final String TAG = "JavaProcFileReader";
    public static JavaProcFileReader sInstance;

    public static int findNewLineOrEnd(byte[] bArr, int i) {
        int length = bArr.length;
        if (i >= length) {
            return -1;
        }
        while (i < length - 1 && (r1 = bArr[i]) != 10 && r1 != 0) {
            i++;
        }
        return i;
    }

    public static boolean startsWithOffset(byte[] bArr, int i, byte[] bArr2) {
        int length = bArr.length - i;
        int length2 = bArr2.length;
        if (length < length2) {
            return false;
        }
        for (int i2 = 0; i2 < length2; i2++) {
            if (bArr[i2 + i] != bArr2[i2]) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [java.lang.Object, com.facebook.acra.util.JavaProcFileReader] */
    public static synchronized JavaProcFileReader getInstance() {
        JavaProcFileReader javaProcFileReader;
        synchronized (JavaProcFileReader.class) {
            JavaProcFileReader javaProcFileReader2 = sInstance;
            javaProcFileReader = javaProcFileReader2;
            if (javaProcFileReader2 == null) {
                ? obj = new Object();
                sInstance = obj;
                javaProcFileReader = obj;
            }
        }
        return javaProcFileReader;
    }

    public int getOpenFDCount() {
        try {
            String[] list = AnonymousClass001.A0E(FD_DIR).list();
            if (list != null) {
                return list.length;
            }
            return -1;
        } catch (SecurityException e) {
            C14270pR.A0F(TAG, e.getMessage());
            return -2;
        }
    }

    public ProcFileReader.OpenFDLimits getOpenFDLimits() {
        FileInputStream fileInputStream;
        byte[] bArr = new byte[Constants.LOAD_RESULT_MIXED_MODE_ATTEMPTED];
        byte[] bytes = "Max open files".getBytes();
        String[] strArr = new String[2];
        try {
            fileInputStream = new FileInputStream("/proc/self/limits");
            int read = fileInputStream.read(bArr, 0, 8191);
            bArr[read] = 0;
            fileInputStream.close();
            int i = 0;
            while (true) {
                if ((read - 1) - i <= bytes.length) {
                    break;
                }
                int findNewLineOrEnd = findNewLineOrEnd(bArr, i);
                if (startsWithOffset(bArr, i, bytes)) {
                    if (C13940ok.A00.A02(bArr, PROC_OPEN_FD_LIMITS_FORMAT, (long[]) null, strArr, i, findNewLineOrEnd)) {
                        return new ProcFileReader.OpenFDLimits(Integer.parseInt(strArr[0]), Integer.parseInt(strArr[1]));
                    }
                } else {
                    i = findNewLineOrEnd + 1;
                }
            }
            return null;
        } catch (IOException e) {
            C14270pR.A0S(TAG, e, "Failed to read /proc/self/limits");
            return null;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
        }
        throw th;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v7, resolved type: com.facebook.acra.util.JavaProcFileReader$Counter} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v11, resolved type: com.facebook.acra.util.JavaProcFileReader$Counter} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v12, resolved type: com.facebook.acra.util.JavaProcFileReader$Counter} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String getOpenFileDescriptors() {
        /*
            r10 = this;
            java.lang.String r8 = "socket"
            java.lang.String r7 = "pipe"
            java.lang.String r4 = "\n"
            java.lang.StringBuilder r3 = X.AnonymousClass001.A0m()
            java.lang.String r5 = "/system/bin/ls"
            r0 = 0
            java.lang.String r2 = "-l"
            java.lang.String r1 = FD_DIR     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = java.lang.String.format(r1, r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String[] r0 = new java.lang.String[]{r5, r2, r0}     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = com.facebook.acra.util.CommandOutputCollector.collect(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String[] r6 = r0.split(r4)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.util.LinkedHashMap r5 = new java.util.LinkedHashMap     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r5.<init>()     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r2 = 1
        L_0x0029:
            int r0 = r6.length     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r2 >= r0) goto L_0x0075
            r9 = r6[r2]     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = " -> "
            int r0 = r9.lastIndexOf(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r1 = -1
            if (r0 == r1) goto L_0x0072
            int r0 = r0 + 4
            java.lang.String r9 = r9.substring(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = "/fd/"
            int r0 = r9.lastIndexOf(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r0 != r1) goto L_0x0047
            r1 = r9
            goto L_0x004d
        L_0x0047:
            int r0 = r0 + 4
            java.lang.String r1 = r9.substring(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
        L_0x004d:
            boolean r0 = r1.startsWith(r7)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r0 == 0) goto L_0x0055
            r9 = r7
            goto L_0x005c
        L_0x0055:
            boolean r0 = r1.startsWith(r8)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r0 == 0) goto L_0x005c
            r9 = r8
        L_0x005c:
            java.lang.Object r1 = r5.get(r9)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            com.facebook.acra.util.JavaProcFileReader$Counter r1 = (com.facebook.acra.util.JavaProcFileReader.Counter) r1     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r1 != 0) goto L_0x006c
            com.facebook.acra.util.JavaProcFileReader$Counter r1 = new com.facebook.acra.util.JavaProcFileReader$Counter     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r1.<init>()     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r5.put(r9, r1)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
        L_0x006c:
            int r0 = r1.count     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            int r0 = r0 + 1
            r1.count = r0     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
        L_0x0072:
            int r2 = r2 + 1
            goto L_0x0029
        L_0x0075:
            java.util.Iterator r2 = X.AnonymousClass001.A10(r5)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
        L_0x0079:
            boolean r0 = r2.hasNext()     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            if (r0 == 0) goto L_0x009e
            java.util.Map$Entry r1 = X.AnonymousClass001.A13(r2)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = X.AnonymousClass001.A0l(r1)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r3.append(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.String r0 = " "
            r3.append(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            java.lang.Object r0 = r1.getValue()     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            com.facebook.acra.util.JavaProcFileReader$Counter r0 = (com.facebook.acra.util.JavaProcFileReader.Counter) r0     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            int r0 = r0.count     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r3.append(r0)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            r3.append(r4)     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            goto L_0x0079
        L_0x009e:
            java.lang.String r2 = r3.toString()     // Catch:{ IOException | IndexOutOfBoundsException | SecurityException -> 0x00a3 }
            return r2
        L_0x00a3:
            r1 = move-exception
            java.lang.String r0 = TAG
            java.lang.String r2 = "Exception caught while reading open file descriptors"
            X.C14270pR.A0R(r0, r1, r2)
            java.lang.String r0 = r1.getMessage()
            if (r0 == 0) goto L_0x00b5
            java.lang.String r2 = r1.getMessage()
        L_0x00b5:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.util.JavaProcFileReader.getOpenFileDescriptors():java.lang.String");
    }

    public class Counter {
        public int count;

        public /* synthetic */ Counter(AnonymousClass1 r1) {
        }

        public Counter() {
        }
    }
}
