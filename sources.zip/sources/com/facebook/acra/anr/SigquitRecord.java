package com.facebook.acra.anr;

import X.AnonymousClass001;
import X.AnonymousClass0ZM;
import X.C14270pR;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class SigquitRecord {
    public static final long ERROR_READING_TIME_INFO = -1;
    public static final String TAG = "SigquitRecord";
    public static final ArrayList sRecords = AnonymousClass001.A0t();
    public final long callbackUptimeMs;
    public final long sigquitUptimeMs;

    public static long convertRawBytesToLong(byte[] bArr) {
        long j = 0;
        int i = 0;
        int i2 = 0;
        do {
            j += (((long) bArr[i]) & 255) << i2;
            i2 += 8;
            i++;
        } while (i < 8);
        return j;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockFinish
        jadx.core.utils.exceptions.JadxRuntimeException: Dominance frontier not set for block: B:18:0x0049
        	at jadx.core.dex.nodes.BlockNode.lock(BlockNode.java:75)
        	at jadx.core.utils.ImmutableList.forEach(ImmutableList.java:108)
        	at jadx.core.dex.nodes.MethodNode.finishBasicBlocks(MethodNode.java:472)
        	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:27)
        */
    public static synchronized java.lang.String getRecordsJson(java.lang.Long r9) {
        /*
            java.lang.Class<com.facebook.acra.anr.SigquitRecord> r8 = com.facebook.acra.anr.SigquitRecord.class
            monitor-enter(r8)
            org.json.JSONArray r6 = new org.json.JSONArray     // Catch:{ JSONException -> 0x0045 }
            r6.<init>()     // Catch:{ JSONException -> 0x0045 }
            java.util.ArrayList r0 = sRecords     // Catch:{ JSONException -> 0x0045 }
            java.util.Iterator r7 = r0.iterator()     // Catch:{ JSONException -> 0x0045 }
        L_0x000e:
            boolean r0 = r7.hasNext()     // Catch:{ JSONException -> 0x0045 }
            if (r0 == 0) goto L_0x0026
            java.lang.Object r5 = r7.next()     // Catch:{ JSONException -> 0x0045 }
            com.facebook.acra.anr.SigquitRecord r5 = (com.facebook.acra.anr.SigquitRecord) r5     // Catch:{ JSONException -> 0x0045 }
            if (r9 == 0) goto L_0x002f
            long r3 = r5.callbackUptimeMs     // Catch:{ JSONException -> 0x0045 }
            long r1 = r9.longValue()     // Catch:{ JSONException -> 0x0045 }
            int r0 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x002f
        L_0x0026:
            java.lang.String r0 = r6.toString()     // Catch:{ JSONException -> 0x0045 }
            if (r0 != 0) goto L_0x0047
            java.lang.String r0 = ""
            goto L_0x0047
        L_0x002f:
            org.json.JSONObject r3 = X.AnonymousClass001.A19()     // Catch:{ JSONException -> 0x0045 }
            java.lang.String r2 = "callback_uptime_ms"
            long r0 = r5.callbackUptimeMs     // Catch:{ JSONException -> 0x0045 }
            r3.put(r2, r0)     // Catch:{ JSONException -> 0x0045 }
            java.lang.String r2 = "sigquit_uptime_ms"
            long r0 = r5.sigquitUptimeMs     // Catch:{ JSONException -> 0x0045 }
            r3.put(r2, r0)     // Catch:{ JSONException -> 0x0045 }
            r6.put(r3)     // Catch:{ JSONException -> 0x0045 }
            goto L_0x000e
        L_0x0045:
            java.lang.String r0 = "\"json error\""
        L_0x0047:
            monitor-exit(r8)
            return r0
        L_0x0049:
            r0 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x0049 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.SigquitRecord.getRecordsJson(java.lang.Long):java.lang.String");
    }

    public static long readSigquitUptimeMs(String str) {
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(str);
            byte[] bArr = new byte[8];
            if (fileInputStream.read(bArr) != 8) {
                C14270pR.A0P(TAG, "Corrupted file %s", str);
                fileInputStream.close();
                return -1;
            }
            long convertRawBytesToLong = convertRawBytesToLong(bArr) / 1000000;
            fileInputStream.close();
            return convertRawBytesToLong;
        } catch (IOException e) {
            C14270pR.A0P(TAG, "Could not read from file %s", str, e);
            return -1;
        } catch (Throwable th) {
            AnonymousClass0ZM.A00(th, th);
        }
        throw th;
    }

    public static void updateRecords(long j, String str) {
        if (str != null) {
            synchronized (SigquitRecord.class) {
                ArrayList arrayList = sRecords;
                if (arrayList.size() <= 0 || ((SigquitRecord) arrayList.get(arrayList.size() - 1)).callbackUptimeMs != j) {
                    arrayList.add(new SigquitRecord(j, readSigquitUptimeMs(str)));
                }
            }
        }
    }

    public SigquitRecord(long j, long j2) {
        this.callbackUptimeMs = j;
        this.sigquitUptimeMs = j2;
    }
}
