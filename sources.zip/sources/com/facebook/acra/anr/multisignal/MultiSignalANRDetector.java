package com.facebook.acra.anr.multisignal;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass063;
import X.AnonymousClass0Ej;
import X.AnonymousClass0HP;
import X.AnonymousClass0LX;
import X.AnonymousClass0WY;
import X.C010705q;
import X.C011005t;
import X.C02850Ec;
import X.C08130bX;
import X.C14270pR;
import X.C14750qJ;
import X.C14840qS;
import android.os.ConditionVariable;
import android.os.Debug;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.os.SystemClock;
import com.facebook.acra.anr.ANRDetectorListener;
import com.facebook.acra.anr.ANRReportProvider;
import com.facebook.acra.anr.IANRDetector;
import com.facebook.acra.anr.processmonitor.DefaultProcessErrorStateListener;
import com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor;
import com.facebook.acra.anr.processmonitor.ProcessErrorStateListener;
import com.facebook.acra.anr.sigquit.SigquitDetector;
import com.facebook.acra.anr.sigquit.SigquitDetectorAcra;
import com.facebook.acra.anr.sigquit.SigquitDetectorLacrima;
import com.facebook.acra.anr.sigquit.SigquitDetectorListener;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class MultiSignalANRDetector implements SigquitDetectorListener, IANRDetector {
    public static final String MULTI_SIGNAL_DETECTOR_THREAD_NAME = "MultiSignalANRDetectorThread";
    public static Map sInstances = AnonymousClass001.A0w();
    public ANRReportProvider mANRReportProvider;
    public long mANRReportTime;
    public final C011005t mAnrDetectorConfig;
    public ANRDetectorListener mAnrDetectorListener;
    public final C14750qJ mAnrStagesListener;
    public final Runnable mConfirmationExpiredRunnable = new Runnable() {
        public void run() {
            C14270pR.A0G(MultiSignalANRDetector.this.mLogTag, "On confirmation expired");
            MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
            if (multiSignalANRDetector.mWaitingForConfirmation) {
                multiSignalANRDetector.setCurrentAnrState(Event.AM_EXPIRED);
                MultiSignalANRDetector multiSignalANRDetector2 = MultiSignalANRDetector.this;
                multiSignalANRDetector2.mWaitingForConfirmation = false;
                if (multiSignalANRDetector2.mHasPendingReport) {
                    C010705q r2 = (C010705q) multiSignalANRDetector2.mAnrDetectorConfig.A0A;
                    r2.A03 = SystemClock.uptimeMillis();
                    C010705q.A00(r2);
                }
                MultiSignalANRDetector multiSignalANRDetector3 = MultiSignalANRDetector.this;
                if (multiSignalANRDetector3.isCurrentStateNoAnrDetected()) {
                    multiSignalANRDetector3.errorCleared();
                }
                C011005t r22 = MultiSignalANRDetector.this.mAnrDetectorConfig;
                if (r22.A02 == 2 && r22.A00 != null && !C14840qS.A0B()) {
                    MultiSignalANRDetector.this.mForegroundTransitionListener.onBackground();
                }
            }
        }
    };
    public AnonymousClass063 mCurrentState;
    public long mDetectorStartTime;
    public AnonymousClass0LX mDurationHistoryAtSigquitTime = null;
    public AnonymousClass0LX mDurationHistoryAtTracesAvailableTime = null;
    public int mErrorCheckCounter;
    public final ProcessErrorStateListener mErrorMonitorListener = new DefaultProcessErrorStateListener() {
        public void onCheckFailed() {
            C14270pR.A0F(MultiSignalANRDetector.this.mLogTag, "onCheckFailed");
            MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
            multiSignalANRDetector.mLostErrorDetectionTime = SystemClock.uptimeMillis();
            multiSignalANRDetector.mProcessingThreadHandler.post(new Runnable() {
                public void run() {
                    MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
                    if (multiSignalANRDetector.mHasPendingReport) {
                        C010705q r3 = (C010705q) multiSignalANRDetector.mAnrDetectorConfig.A0A;
                        r3.A09 = multiSignalANRDetector.mLostErrorDetectionTime;
                        r3.A01 = 3;
                        C010705q.A00(r3);
                    }
                }
            });
        }

        public void onCheckPerformed() {
            MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
            if (multiSignalANRDetector.mAnrDetectorConfig.A04 > 0) {
                multiSignalANRDetector.mProcessingThreadHandler.post(new Runnable() {
                    public void run() {
                        MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
                        if (multiSignalANRDetector.mMovedToBackground) {
                            MultiSignalANRDetector.access$1912(multiSignalANRDetector, 1);
                            if (multiSignalANRDetector.mErrorCheckCounter % multiSignalANRDetector.mAnrDetectorConfig.A04 == 0) {
                                C14270pR.A0G(multiSignalANRDetector.mLogTag, "Pausing error state checks");
                                MultiSignalANRDetector.this.mProcessAnrErrorMonitor.pause();
                                MultiSignalANRDetector.this.mProcessAnrErrorMonitorPaused = true;
                            }
                        }
                    }
                });
            }
        }

        public void onErrorCleared() {
            C14270pR.A0G(MultiSignalANRDetector.this.mLogTag, "On onErrorCleared");
            C14750qJ r0 = MultiSignalANRDetector.this.mAnrStagesListener;
            if (r0 != null) {
                r0.DA8();
            }
            MultiSignalANRDetector.this.mProcessingThreadHandler.post(new Runnable() {
                public void run() {
                    MultiSignalANRDetector.this.setCurrentAnrState(Event.DIALOG_DISMISSED);
                    MultiSignalANRDetector.this.errorCleared();
                }
            });
        }

        /* JADX WARNING: Code restructure failed: missing block: B:13:0x002a, code lost:
            r0 = r3.this$0.mAnrStagesListener;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x002e, code lost:
            if (r0 == null) goto L_0x0033;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0030, code lost:
            r0.DA7();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0033, code lost:
            r3.this$0.mProcessingThreadHandler.post(new com.facebook.acra.anr.multisignal.MultiSignalANRDetector.AnonymousClass2.AnonymousClass1(r3));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x003f, code lost:
            return;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onErrorDetected(final java.lang.String r4, final java.lang.String r5) {
            /*
                r3 = this;
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this
                java.lang.String r2 = r0.mLogTag
                java.lang.String r1 = "On error detected %s %s"
                java.lang.Object[] r0 = new java.lang.Object[]{r4, r5}
                X.C14270pR.A0P(r2, r1, r0)
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r1 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this
                X.05t r0 = r1.mAnrDetectorConfig
                boolean r0 = r0.A0H
                if (r0 == 0) goto L_0x001c
                boolean r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.access$700(r1)
                if (r0 == 0) goto L_0x001c
                return
            L_0x001c:
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this
                java.lang.Object r1 = r0.mStartStopLock
                monitor-enter(r1)
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this     // Catch:{ all -> 0x0040 }
                boolean r0 = r0.mRunning     // Catch:{ all -> 0x0040 }
                if (r0 != 0) goto L_0x0029
                monitor-exit(r1)     // Catch:{ all -> 0x0040 }
                return
            L_0x0029:
                monitor-exit(r1)     // Catch:{ all -> 0x0040 }
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this
                X.0qJ r0 = r0.mAnrStagesListener
                if (r0 == 0) goto L_0x0033
                r0.DA7()
            L_0x0033:
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.this
                android.os.Handler r1 = r0.mProcessingThreadHandler
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$2$1 r0 = new com.facebook.acra.anr.multisignal.MultiSignalANRDetector$2$1
                r0.<init>(r4, r5)
                r1.post(r0)
                return
            L_0x0040:
                r0 = move-exception
                monitor-exit(r1)     // Catch:{ all -> 0x0040 }
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.AnonymousClass2.onErrorDetected(java.lang.String, java.lang.String):void");
        }

        public void onStart() {
            C14270pR.A0G(MultiSignalANRDetector.this.mLogTag, "Started monitoring");
        }

        public boolean onErrorDetectOnOtherProcess(String str, String str2, String str3) {
            final long uptimeMillis = SystemClock.uptimeMillis();
            final String str4 = str;
            final String str5 = str2;
            final String str6 = str3;
            MultiSignalANRDetector.this.mProcessingThreadHandler.post(new Runnable() {
                public void run() {
                    MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
                    if (multiSignalANRDetector.mHasPendingReport) {
                        C02850Ec r8 = multiSignalANRDetector.mAnrDetectorConfig.A0A;
                        String str = str4;
                        String str2 = str5;
                        String str3 = str6;
                        long j = uptimeMillis;
                        C010705q r82 = (C010705q) r8;
                        List list = r82.A0a;
                        if (list.size() < 5) {
                            StringBuilder A0o = AnonymousClass001.A0o(str);
                            A0o.append(',');
                            A0o.append(j);
                            A0o.append(',');
                            A0o.append(str2);
                            A0o.append(',');
                            list.add(AnonymousClass001.A0g(str3, A0o));
                            C010705q.A00(r82);
                        }
                    }
                }
            });
            return true;
        }
    };
    public final AnonymousClass0Ej mForegroundTransitionListener = new AnonymousClass0Ej() {
        public void onBackground() {
            MultiSignalANRDetector.this.mProcessingThreadHandler.post(new Runnable() {
                public void run() {
                    C14270pR.A0G(MultiSignalANRDetector.this.mLogTag, "Moving to background");
                    MultiSignalANRDetector.this.mMovedToBackground = true;
                }
            });
        }

        public void onForeground() {
            MultiSignalANRDetector.this.mProcessingThreadHandler.post(new Runnable() {
                public void run() {
                    MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
                    multiSignalANRDetector.mMovedToBackground = false;
                    if (multiSignalANRDetector.mProcessAnrErrorMonitorPaused) {
                        C14270pR.A0G(multiSignalANRDetector.mLogTag, "Resuming error state checks");
                        MultiSignalANRDetector.this.mProcessAnrErrorMonitor.resume();
                        MultiSignalANRDetector.this.mProcessAnrErrorMonitorPaused = false;
                    }
                }
            });
        }
    };
    public boolean mHasPendingReport;
    public long mLastSigquitReceivedTime;
    public long mLastSigquitReceivedUptime;
    public String mLogTag = "MultiSignalANRDetector";
    public long mLostErrorDetectionTime;
    public boolean mMovedToBackground;
    public boolean mNativeHookInPlace;
    public final AtomicBoolean mNativeLibraryInitialized = new AtomicBoolean(false);
    public final ConditionVariable mNativeLibraryInitializedCV = new ConditionVariable();
    public final OnMainThreadUnblockedRunnable mOnMainThreadUnblockedRunnable = new OnMainThreadUnblockedRunnable();
    public volatile boolean mPaused;
    public ProcessAnrErrorMonitor mProcessAnrErrorMonitor;
    public boolean mProcessAnrErrorMonitorPaused;
    public final HandlerThread mProcessingThread;
    public final Handler mProcessingThreadHandler;
    public boolean mRunning;
    public long mSigquitCallbackTime;
    public long mSigquitCallbackUptime;
    public String mSigquitData;
    public final SigquitDetector mSigquitDetector;
    public String mSigquitFileName;
    public final AtomicReference mSigquitHook = new AtomicReference();
    public long mSigquitReceivedTime;
    public long mSigquitReceivedUptime;
    public final Object mStartStopLock = AnonymousClass001.A0U();
    public boolean mStartedInForegroundV1;
    public boolean mStartedInForegroundV2;
    public String mSystemErrorMessage;
    public String mSystemErrorTag;
    public long mSystemErrorUptime;
    public final AtomicReference mTracesHook = new AtomicReference();
    public boolean mWaitingForConfirmation;
    public boolean mWaitingForMainThreadBlockedCheck;

    public enum ActionOnSigquit {
        IGNORE,
        CLEAR_CURRENT_ERROR_STATE,
        START_REPORT
    }

    public enum Event {
        SIGQUIT_RECEIVED,
        AM_CONFIRMED,
        AM_EXPIRED,
        MT_UNBLOCKED,
        DIALOG_DISMISSED
    }

    public class OnMainThreadUnblockedRunnable implements Runnable {
        public long mUptimeMillisWhenSomethingCouldRunOnMainThread;

        public OnMainThreadUnblockedRunnable() {
        }

        public void run() {
            MultiSignalANRDetector multiSignalANRDetector = MultiSignalANRDetector.this;
            multiSignalANRDetector.mWaitingForMainThreadBlockedCheck = false;
            multiSignalANRDetector.setCurrentAnrState(Event.MT_UNBLOCKED);
            MultiSignalANRDetector multiSignalANRDetector2 = MultiSignalANRDetector.this;
            if (multiSignalANRDetector2.mHasPendingReport) {
                C010705q r2 = (C010705q) multiSignalANRDetector2.mAnrDetectorConfig.A0A;
                r2.A07 = this.mUptimeMillisWhenSomethingCouldRunOnMainThread;
                C010705q.A00(r2);
            }
            MultiSignalANRDetector multiSignalANRDetector3 = MultiSignalANRDetector.this;
            if (multiSignalANRDetector3.isCurrentStateNoAnrDetected()) {
                multiSignalANRDetector3.errorCleared();
            }
        }

        public void setUptimeMillis(long j) {
            this.mUptimeMillisWhenSomethingCouldRunOnMainThread = j;
        }
    }

    public interface TraceDataHook {
        void handleTracesExternally(String str);
    }

    public class TraceDataResult {
        public String errMsg = null;
        public String tracesFilePath = null;

        public boolean setError(String str) {
            this.errMsg = str;
            this.tracesFilePath = null;
            return false;
        }

        public boolean setTracesFilePath(String str) {
            this.tracesFilePath = str;
            this.errMsg = null;
            return true;
        }

        public String getErrMsg() {
            return this.errMsg;
        }

        public String getTracesFilePath() {
            return this.tracesFilePath;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x004d  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0094  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x00ad  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void startReport(com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event r42) {
        /*
            r41 = this;
            r0 = 1
            r4 = r41
            r4.mHasPendingReport = r0
            long r0 = android.os.SystemClock.uptimeMillis()
            r4.mANRReportTime = r0
            com.facebook.acra.anr.ANRDetectorListener r8 = r4.mAnrDetectorListener
            r9 = 0
            if (r8 == 0) goto L_0x00bf
            java.lang.String r27 = r8.getBlackBoxTraceId()
            java.lang.String r28 = r8.getLongStallTraceId()
            r8.onStartANRDataCapture()
        L_0x001b:
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.SIGQUIT_RECEIVED
            r17 = 0
            r14 = r42
            if (r14 != r0) goto L_0x00b4
            java.lang.String r7 = r4.mSigquitData
            java.lang.String r13 = r4.mSigquitFileName
            long r0 = r4.mSigquitCallbackUptime
            long r2 = r4.mSigquitCallbackTime
            long r5 = r4.mSigquitReceivedUptime
            long r11 = r4.mSigquitReceivedTime
            if (r7 != 0) goto L_0x00b1
            if (r13 != 0) goto L_0x00b1
        L_0x0033:
            java.io.ByteArrayOutputStream r7 = new java.io.ByteArrayOutputStream
            r7.<init>()
            com.facebook.acra.anr.StackTraceDumper.dumpStackTraces(r7, r9, r9)
            java.lang.String r7 = r7.toString()
            r39 = 0
        L_0x0041:
            X.05t r9 = r4.mAnrDetectorConfig
            X.0Ec r10 = r9.A0A
            r21 = r10
            com.facebook.acra.anr.ANRReportProvider r10 = r4.mANRReportProvider
            r36 = 0
            if (r10 != 0) goto L_0x004f
            r36 = 1
        L_0x004f:
            int r10 = r9.A03
            r20 = r10
            boolean r10 = r4.mStartedInForegroundV1
            r19 = r10
            boolean r10 = r4.mStartedInForegroundV2
            long r32 = android.os.SystemClock.uptimeMillis()
            long r15 = r4.mDetectorStartTime
            boolean r9 = r9.A0M
            java.lang.Long r23 = java.lang.Long.valueOf(r0)
            java.lang.Long r24 = java.lang.Long.valueOf(r2)
            java.lang.Long r25 = java.lang.Long.valueOf(r5)
            java.lang.Long r26 = java.lang.Long.valueOf(r11)
            X.0LX r2 = r4.mDurationHistoryAtSigquitTime
            X.0LX r1 = r4.mDurationHistoryAtTracesAvailableTime
            X.063 r0 = r4.mCurrentState
            r22 = r0
            r29 = r7
            r30 = r13
            r31 = r20
            r34 = r15
            r37 = r19
            r38 = r10
            r40 = r9
            r19 = r21
            r20 = r2
            r21 = r1
            r19.EEu(r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r34, r36, r37, r38, r39, r40)
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.AM_CONFIRMED
            if (r14 != r0) goto L_0x0097
            r4.addActivityManagerConfirmationDataToReport()
        L_0x0097:
            long r2 = r4.mLostErrorDetectionTime
            int r0 = (r2 > r17 ? 1 : (r2 == r17 ? 0 : -1))
            if (r0 == 0) goto L_0x00ab
            X.05t r0 = r4.mAnrDetectorConfig
            X.0Ec r1 = r0.A0A
            r0 = 3
            X.05q r1 = (X.C010705q) r1
            r1.A09 = r2
            r1.A01 = r0
            X.C010705q.A00(r1)
        L_0x00ab:
            if (r8 == 0) goto L_0x00b0
            r8.onEndANRDataCapture()
        L_0x00b0:
            return
        L_0x00b1:
            r39 = 1
            goto L_0x0041
        L_0x00b4:
            r13 = r9
            r11 = 0
            r0 = 0
            r2 = 0
            r5 = 0
            goto L_0x0033
        L_0x00bf:
            r27 = r9
            r28 = r9
            goto L_0x001b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.startReport(com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0023, code lost:
        r0 = (com.facebook.acra.anr.multisignal.MultiSignalANRDetector.TraceDataHook) r11.mTracesHook.getAndSet((java.lang.Object) null);
        r3 = r13;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x002d, code lost:
        if (r0 == null) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x002f, code lost:
        r0.handleTracesExternally(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0032, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0033, code lost:
        r11.mDurationHistoryAtTracesAvailableTime = r11.mProcessAnrErrorMonitor.getDurationHistory();
        r0 = r11.mAnrStagesListener;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003d, code lost:
        if (r0 == null) goto L_0x0042;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x003f, code lost:
        r0.DJX();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        r4 = android.os.SystemClock.uptimeMillis();
        r7 = java.lang.System.currentTimeMillis();
        r6 = r12;
        r9 = r14;
        r10 = r15;
        r11.mProcessingThreadHandler.post(new com.facebook.acra.anr.multisignal.MultiSignalANRDetector.AnonymousClass5(r2));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0057, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onSigquitTracesAvailable(java.lang.String r12, java.lang.String r13, boolean r14, boolean r15) {
        /*
            r11 = this;
            r2 = r11
            boolean r0 = r11.mPaused
            if (r0 != 0) goto L_0x0018
            java.lang.String r1 = r11.mLogTag
            java.lang.String r0 = "On onSigquitTracesAvailable call"
            X.C14270pR.A0G(r1, r0)
            X.05t r0 = r11.mAnrDetectorConfig
            boolean r0 = r0.A0H
            if (r0 == 0) goto L_0x0019
            boolean r0 = r11.isDebuggerConnected()
            if (r0 == 0) goto L_0x0019
        L_0x0018:
            return
        L_0x0019:
            java.lang.Object r1 = r11.mStartStopLock
            monitor-enter(r1)
            boolean r0 = r11.mRunning     // Catch:{ all -> 0x0058 }
            if (r0 != 0) goto L_0x0022
            monitor-exit(r1)     // Catch:{ all -> 0x0058 }
            return
        L_0x0022:
            monitor-exit(r1)     // Catch:{ all -> 0x0058 }
            java.util.concurrent.atomic.AtomicReference r1 = r11.mTracesHook
            r0 = 0
            java.lang.Object r0 = r1.getAndSet(r0)
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$TraceDataHook r0 = (com.facebook.acra.anr.multisignal.MultiSignalANRDetector.TraceDataHook) r0
            r3 = r13
            if (r0 == 0) goto L_0x0033
            r0.handleTracesExternally(r13)
            return
        L_0x0033:
            com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = r11.mProcessAnrErrorMonitor
            X.0LX r0 = r0.getDurationHistory()
            r11.mDurationHistoryAtTracesAvailableTime = r0
            X.0qJ r0 = r11.mAnrStagesListener
            if (r0 == 0) goto L_0x0042
            r0.DJX()
        L_0x0042:
            long r4 = android.os.SystemClock.uptimeMillis()
            long r7 = java.lang.System.currentTimeMillis()
            android.os.Handler r0 = r11.mProcessingThreadHandler
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$5 r1 = new com.facebook.acra.anr.multisignal.MultiSignalANRDetector$5
            r6 = r12
            r9 = r14
            r10 = r15
            r1.<init>(r3, r4, r6, r7, r9, r10)
            r0.post(r1)
            return
        L_0x0058:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0058 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.onSigquitTracesAvailable(java.lang.String, java.lang.String, boolean, boolean):void");
    }

    public void pause() {
        this.mPaused = true;
        this.mProcessAnrErrorMonitor.pause();
        this.mSigquitDetector.stopDetector();
    }

    public void resume() {
        this.mPaused = false;
        this.mProcessAnrErrorMonitor.resume();
        this.mSigquitDetector.startDetector();
    }

    public void setCurrentAnrState(Event event) {
        setCurrentAnrState(event, false, false);
    }

    /* renamed from: com.facebook.acra.anr.multisignal.MultiSignalANRDetector$9  reason: invalid class name */
    public abstract /* synthetic */ class AnonymousClass9 {
        public static final /* synthetic */ int[] $SwitchMap$com$facebook$acra$anr$multisignal$MultiSignalANRDetector$Event;
        public static final /* synthetic */ int[] $SwitchMap$com$facebook$reliability$anr$AnrState;

        /* JADX WARNING: Can't wrap try/catch for region: R(35:0|1|2|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|21|22|23|24|25|26|27|28|29|31|32|33|35|36|37|(2:39|40)|41|43|44|46) */
        /* JADX WARNING: Can't wrap try/catch for region: R(37:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|21|22|23|24|25|26|27|28|29|31|32|33|35|36|37|39|40|41|43|44|46) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0042 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0044 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0046 */
        static {
            /*
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event[] r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.values()
                int r0 = r0.length
                int[] r2 = new int[r0]
                $SwitchMap$com$facebook$acra$anr$multisignal$MultiSignalANRDetector$Event = r2
                r6 = 1
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.SIGQUIT_RECEIVED     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r0 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2[r0] = r6     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r5 = 2
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.AM_CONFIRMED     // Catch:{ NoSuchFieldError -> 0x001b }
                int r0 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x001b }
                r2[r0] = r5     // Catch:{ NoSuchFieldError -> 0x001b }
            L_0x001b:
                r4 = 3
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.MT_UNBLOCKED     // Catch:{ NoSuchFieldError -> 0x0024 }
                int r0 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0024 }
                r2[r0] = r4     // Catch:{ NoSuchFieldError -> 0x0024 }
            L_0x0024:
                r3 = 4
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.AM_EXPIRED     // Catch:{ NoSuchFieldError -> 0x002d }
                int r0 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x002d }
                r2[r0] = r3     // Catch:{ NoSuchFieldError -> 0x002d }
            L_0x002d:
                r1 = 5
                com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.DIALOG_DISMISSED     // Catch:{ NoSuchFieldError -> 0x0036 }
                int r0 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0036 }
                r2[r0] = r1     // Catch:{ NoSuchFieldError -> 0x0036 }
            L_0x0036:
                X.063[] r0 = X.AnonymousClass063.values()
                int r0 = r0.length
                int[] r2 = new int[r0]
                $SwitchMap$com$facebook$reliability$anr$AnrState = r2
                r0 = 0
                r2[r0] = r6     // Catch:{ NoSuchFieldError -> 0x0042 }
            L_0x0042:
                r2[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0044 }
            L_0x0044:
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0046 }
            L_0x0046:
                r2[r1] = r3     // Catch:{ NoSuchFieldError -> 0x0048 }
            L_0x0048:
                r0 = 8
                r2[r0] = r1     // Catch:{ NoSuchFieldError -> 0x004c }
            L_0x004c:
                r1 = 9
                r0 = 6
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0051 }
            L_0x0051:
                r1 = 6
                r0 = 7
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0055 }
            L_0x0055:
                r1 = 7
                r0 = 8
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x005a }
            L_0x005a:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.AnonymousClass9.<clinit>():void");
        }
    }

    public static /* synthetic */ int access$1912(MultiSignalANRDetector multiSignalANRDetector, int i) {
        int i2 = multiSignalANRDetector.mErrorCheckCounter + i;
        multiSignalANRDetector.mErrorCheckCounter = i2;
        return i2;
    }

    public static /* synthetic */ boolean access$700(MultiSignalANRDetector multiSignalANRDetector) {
        if (multiSignalANRDetector.mAnrDetectorConfig.A0H) {
            return multiSignalANRDetector.isDebuggerConnected();
        }
        return false;
    }

    private void addActivityManagerConfirmationDataToReport() {
        C02850Ec r4 = this.mAnrDetectorConfig.A0A;
        String str = this.mSystemErrorMessage;
        String str2 = this.mSystemErrorTag;
        long j = this.mSystemErrorUptime;
        C010705q r42 = (C010705q) r4;
        r42.A0N = str;
        r42.A0O = str2;
        r42.A08 = j;
        C010705q.A00(r42);
    }

    private void addInfoToReport(Event event) {
        if (event == Event.SIGQUIT_RECEIVED) {
            addSigquitDataToReport();
        } else if (event == Event.AM_CONFIRMED) {
            addActivityManagerConfirmationDataToReport();
        } else {
            throw AnonymousClass001.A0L("Event should be SIGQUIT_RECEIVED or AM_CONFIRMED");
        }
    }

    private void addSigquitDataToReport() {
        C02850Ec r11 = this.mAnrDetectorConfig.A0A;
        String str = this.mSigquitData;
        String str2 = this.mSigquitFileName;
        long j = this.mSigquitCallbackUptime;
        long j2 = this.mSigquitCallbackTime;
        long j3 = this.mSigquitReceivedUptime;
        long j4 = this.mSigquitReceivedTime;
        AnonymousClass0LX r10 = this.mDurationHistoryAtSigquitTime;
        AnonymousClass0LX r1 = this.mDurationHistoryAtTracesAvailableTime;
        C010705q r112 = (C010705q) r11;
        r112.A0L = str;
        r112.A0M = str2;
        r112.A0P = null;
        r112.A0U = true;
        r112.A0G = Long.valueOf(j);
        r112.A0F = Long.valueOf(j2);
        r112.A0I = Long.valueOf(j3);
        r112.A0H = Long.valueOf(j4);
        r112.A0B = r10;
        r112.A0C = r1;
        C010705q.A00(r112);
    }

    /* access modifiers changed from: private */
    public void errorCleared() {
        C14270pR.A0P(this.mLogTag, "Clearing error state has pending report %b", Boolean.valueOf(this.mHasPendingReport));
        if (this.mHasPendingReport) {
            long uptimeMillis = SystemClock.uptimeMillis() - this.mANRReportTime;
            C010705q r0 = (C010705q) this.mAnrDetectorConfig.A0A;
            r0.A0A = uptimeMillis;
            C010705q.A00(r0);
            r0.A0Q = false;
            this.mHasPendingReport = false;
        }
        this.mSystemErrorMessage = null;
        this.mSystemErrorTag = null;
        this.mSystemErrorUptime = 0;
        this.mSigquitReceivedUptime = 0;
        this.mSigquitReceivedTime = 0;
        this.mSigquitCallbackUptime = 0;
        this.mSigquitData = null;
        this.mSigquitFileName = null;
        this.mSigquitCallbackTime = 0;
    }

    /* access modifiers changed from: private */
    public ActionOnSigquit getActionOnSigquit() {
        AnonymousClass063 r1 = this.mCurrentState;
        if (r1 == AnonymousClass063.NO_ANR_DETECTED || r1 == AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED || r1 == AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_UNBLOCKED) {
            return ActionOnSigquit.START_REPORT;
        }
        return ActionOnSigquit.IGNORE;
    }

    public static MultiSignalANRDetector getInstance(C011005t r3, C14750qJ r4) {
        String str;
        MultiSignalANRDetector multiSignalANRDetector = (MultiSignalANRDetector) sInstances.get(r3);
        if (multiSignalANRDetector == null) {
            multiSignalANRDetector = new MultiSignalANRDetector(r3, r4);
            sInstances.put(r3, multiSignalANRDetector);
        }
        if (r3.A0I) {
            str = "Lacrima";
        } else {
            str = "Acra";
        }
        multiSignalANRDetector.mLogTag = AnonymousClass0WY.A0i("MultiSignalANRDetector", str);
        return multiSignalANRDetector;
    }

    public static MultiSignalANRDetector getTestInstance(C011005t r0, SigquitDetector sigquitDetector, HandlerThread handlerThread) {
        throw new AssertionError();
    }

    public static void getTraceDataFromHook(final TraceDataHook traceDataHook) {
        Iterator it = sInstances.values().iterator();
        if (it.hasNext()) {
            MultiSignalANRDetector multiSignalANRDetector = (MultiSignalANRDetector) it.next();
            if (multiSignalANRDetector.mNativeLibraryInitialized.get()) {
                multiSignalANRDetector.triggerSigquit(traceDataHook);
            } else {
                new Thread() {
                    public void run() {
                        MultiSignalANRDetector.this.mNativeLibraryInitializedCV.block();
                        MultiSignalANRDetector.this.triggerSigquit(traceDataHook);
                    }
                }.start();
            }
        }
    }

    /* access modifiers changed from: private */
    public boolean isCurrentStateNoAnrDetected() {
        if (this.mCurrentState == AnonymousClass063.NO_ANR_DETECTED) {
            return true;
        }
        return false;
    }

    private boolean isCurrentStateUnconfirmed() {
        AnonymousClass063 r1 = this.mCurrentState;
        if (r1 == AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED || r1 == AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_UNBLOCKED) {
            return true;
        }
        return false;
    }

    private boolean isDebuggerConnected() {
        if (!this.mAnrDetectorConfig.A0H || !Debug.isDebuggerConnected()) {
            return false;
        }
        return true;
    }

    private void logUnexpectedStateTransition(Event event) {
        ANRReportProvider aNRReportProvider;
        C14270pR.A0P(this.mLogTag, "Unexpected event %s received in state %s", event, this.mCurrentState);
        if (event != Event.SIGQUIT_RECEIVED && (aNRReportProvider = this.mANRReportProvider) != null) {
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append("Unexpected event ");
            A0m.append(event);
            A0m.append(" received in state ");
            aNRReportProvider.reportSoftError("Unexpected event", AnonymousClass002.A0H(this.mCurrentState, A0m));
        }
    }

    /* access modifiers changed from: private */
    public void mainThreadUnblocked() {
        C14270pR.A0G(this.mLogTag, "Running on the main thread");
        OnMainThreadUnblockedRunnable onMainThreadUnblockedRunnable = this.mOnMainThreadUnblockedRunnable;
        onMainThreadUnblockedRunnable.mUptimeMillisWhenSomethingCouldRunOnMainThread = SystemClock.uptimeMillis();
        this.mProcessingThreadHandler.post(onMainThreadUnblockedRunnable);
    }

    private void maybeStartMainThreadBlockedCheck() {
        if (!this.mWaitingForMainThreadBlockedCheck) {
            AnonymousClass063 r1 = this.mCurrentState;
            if (r1 == AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED || r1 == AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED) {
                C14270pR.A0G(this.mLogTag, "Posting main thread check");
                this.mWaitingForMainThreadBlockedCheck = true;
                this.mAnrDetectorConfig.A09.post(new Runnable() {
                    public void run() {
                        MultiSignalANRDetector.this.mainThreadUnblocked();
                    }
                });
            }
        }
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0023, code lost:
        if (r7.mStartedInForegroundV1 != false) goto L_0x0025;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0048  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0075  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void maybeStartReport(com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event r8) {
        /*
            r7 = this;
            java.lang.String r5 = r7.mLogTag
            r2 = 2
            r4 = 0
            boolean r0 = r7.mHasPendingReport
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            r3 = 1
            java.lang.Object[] r1 = new java.lang.Object[]{r8, r0}
            java.lang.String r0 = "On maybeStartReport event: %s has pending report %b"
            X.C14270pR.A0P(r5, r0, r1)
            boolean r0 = r7.mHasPendingReport
            if (r0 == 0) goto L_0x001c
            r7.addInfoToReport(r8)
        L_0x001b:
            return
        L_0x001c:
            boolean r0 = r7.mStartedInForegroundV2
            if (r0 != 0) goto L_0x0025
            boolean r0 = r7.mStartedInForegroundV1
            r6 = 0
            if (r0 == 0) goto L_0x0026
        L_0x0025:
            r6 = 1
        L_0x0026:
            X.05t r0 = r7.mAnrDetectorConfig
            int r5 = r0.A02
            if (r6 != 0) goto L_0x002e
            if (r5 == 0) goto L_0x0088
        L_0x002e:
            boolean r1 = r7.shouldUploadAnrReports()
            if (r6 != 0) goto L_0x0043
            if (r5 != r2) goto L_0x0046
            boolean r0 = r7.mProcessAnrErrorMonitorPaused
            if (r0 == 0) goto L_0x0043
            r7.mMovedToBackground = r4
            com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = r7.mProcessAnrErrorMonitor
            r0.resume()
            r7.mProcessAnrErrorMonitorPaused = r4
        L_0x0043:
            r7.maybeStartTimerForActivityManagerConfirmation()
        L_0x0046:
            if (r1 == 0) goto L_0x0075
            java.lang.String r1 = r7.mLogTag
            java.lang.String r0 = "Reporting ANR start"
            X.C14270pR.A0G(r1, r0)
            r7.startReport(r8)     // Catch:{ IOException -> 0x0053 }
            goto L_0x005d
        L_0x0053:
            r2 = move-exception
            java.lang.String r1 = r7.mLogTag
            java.lang.String r0 = "Error starting ANR report"
            X.C14270pR.A0R(r1, r2, r0)
            r7.mHasPendingReport = r4
        L_0x005d:
            if (r6 != 0) goto L_0x001b
            if (r5 != r3) goto L_0x001b
            X.05t r0 = r7.mAnrDetectorConfig
            X.0HP r0 = r0.A00
            if (r0 == 0) goto L_0x001b
            X.063 r2 = r7.mCurrentState
            X.05s r0 = (X.C010905s) r0
            X.0vL r1 = r0.A00
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r4)
            X.C17570vL.A01(r1, r2, r0, r3)
            return
        L_0x0075:
            if (r6 == 0) goto L_0x0088
            X.05t r0 = r7.mAnrDetectorConfig
            X.0Ec r2 = r0.A0A
            boolean r1 = r7.mStartedInForegroundV1
            boolean r0 = r7.mStartedInForegroundV2
            X.05q r2 = (X.C010705q) r2
            r2.A0R = r1
            r2.A0S = r0
            X.C010705q.A00(r2)
        L_0x0088:
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.SIGQUIT_RECEIVED
            if (r8 != r0) goto L_0x001b
            java.lang.String r0 = r7.mSigquitFileName
            if (r0 == 0) goto L_0x001b
            java.io.File r0 = X.AnonymousClass001.A0E(r0)
            r0.delete()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.maybeStartReport(com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event):void");
    }

    private void maybeStartTimerForActivityManagerConfirmation() {
        if (!this.mWaitingForConfirmation && this.mAnrDetectorConfig.A07 > 0 && isCurrentStateUnconfirmed()) {
            C14270pR.A0G(this.mLogTag, "Starting timer for AM confirmation");
            this.mWaitingForConfirmation = true;
            this.mProcessingThreadHandler.postDelayed(this.mConfirmationExpiredRunnable, (long) this.mAnrDetectorConfig.A07);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0020, code lost:
        if (r3 == X.AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED) goto L_0x0022;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void setASLState(com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event r7, boolean r8, boolean r9) {
        /*
            r6 = this;
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event r0 = com.facebook.acra.anr.multisignal.MultiSignalANRDetector.Event.SIGQUIT_RECEIVED
            r2 = 0
            if (r7 != r0) goto L_0x0006
            r2 = 1
        L_0x0006:
            X.05t r0 = r6.mAnrDetectorConfig
            X.0HP r1 = r0.A00
            r5 = 0
            if (r2 == 0) goto L_0x0017
            com.facebook.acra.anr.multisignal.MultiSignalANRDetector$6 r0 = new com.facebook.acra.anr.multisignal.MultiSignalANRDetector$6
            r0.<init>()
            if (r1 != 0) goto L_0x005d
            r0.run()
        L_0x0017:
            X.063 r3 = r6.mCurrentState
            X.063 r0 = X.AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED
            if (r3 == r0) goto L_0x0022
            X.063 r0 = X.AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED
            r4 = 0
            if (r3 != r0) goto L_0x0023
        L_0x0022:
            r4 = 1
        L_0x0023:
            if (r1 == 0) goto L_0x0055
            if (r2 == 0) goto L_0x003c
            if (r4 == 0) goto L_0x003c
            X.05s r1 = (X.C010905s) r1
            X.0vL r2 = r1.A00
            r1 = 0
            r0 = 0
            X.C17570vL.A01(r2, r3, r1, r0)
            if (r5 == 0) goto L_0x0037
            r5.run()
        L_0x0037:
            r6.mStartedInForegroundV1 = r8
            r6.mStartedInForegroundV2 = r9
        L_0x003b:
            return
        L_0x003c:
            boolean r9 = X.C14840qS.A0B()
            X.0u2 r0 = X.C14840qS.A05
            if (r0 != 0) goto L_0x0058
            r8 = 0
        L_0x0045:
            X.063 r3 = r6.mCurrentState
            X.05s r1 = (X.C010905s) r1
            X.0vL r2 = r1.A00
            r1 = 0
            r0 = 0
            X.C17570vL.A01(r2, r3, r1, r0)
            if (r5 == 0) goto L_0x0055
            r5.run()
        L_0x0055:
            if (r4 == 0) goto L_0x003b
            goto L_0x0037
        L_0x0058:
            X.0u2 r0 = X.C14840qS.A05
            boolean r8 = r0.A06
            goto L_0x0045
        L_0x005d:
            r5 = r0
            goto L_0x0017
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.multisignal.MultiSignalANRDetector.setASLState(com.facebook.acra.anr.multisignal.MultiSignalANRDetector$Event, boolean, boolean):void");
    }

    private boolean shouldUploadAnrReports() {
        ANRReportProvider aNRReportProvider = this.mANRReportProvider;
        if (aNRReportProvider != null) {
            return aNRReportProvider.shouldCollectAndUploadANRReports();
        }
        return this.mAnrDetectorConfig.A0G;
    }

    /* access modifiers changed from: private */
    public void triggerSigquit(TraceDataHook traceDataHook) {
        this.mSigquitHook.set(traceDataHook);
        this.mSigquitDetector.doNotIgnoreNextSiguit();
        Process.sendSignal(Process.myPid(), 3);
    }

    public AnonymousClass063 getCurrentState() {
        throw new AssertionError();
    }

    public ProcessErrorStateListener getErrorMonitorListener() {
        throw new AssertionError();
    }

    public void nativeLibraryLoaded(boolean z) {
        this.mSigquitDetector.init(this.mAnrDetectorConfig, shouldUploadAnrReports());
        this.mSigquitDetector.installSignalHandler(this.mProcessingThreadHandler, z);
        this.mNativeLibraryInitialized.set(true);
        this.mNativeLibraryInitializedCV.open();
    }

    public void onHookedMethods(boolean z) {
        synchronized (this.mStartStopLock) {
            this.mNativeHookInPlace = z;
        }
    }

    public void onSigquit() {
        if (!this.mPaused) {
            Object andSet = this.mSigquitHook.getAndSet((Object) null);
            if (andSet != null) {
                this.mTracesHook.set(andSet);
                return;
            }
            this.mLastSigquitReceivedUptime = SystemClock.uptimeMillis();
            this.mLastSigquitReceivedTime = System.currentTimeMillis();
            this.mDurationHistoryAtSigquitTime = this.mProcessAnrErrorMonitor.getDurationHistory();
            C14750qJ r0 = this.mAnrStagesListener;
            if (r0 != null) {
                r0.onSigquit();
            }
        }
    }

    public void setAnrErrorMonitor(ProcessAnrErrorMonitor processAnrErrorMonitor) {
        throw new AssertionError();
    }

    public void setInternalState(AnonymousClass063 r2) {
        throw new AssertionError();
    }

    public void start() {
        synchronized (this.mStartStopLock) {
            if (!this.mRunning) {
                C14270pR.A0G(this.mLogTag, "Starting");
                this.mRunning = true;
                this.mDetectorStartTime = SystemClock.uptimeMillis();
                this.mProcessAnrErrorMonitor.startMonitoringAfterDelay(this.mErrorMonitorListener, 0);
                final AnonymousClass0HP r2 = this.mAnrDetectorConfig.A00;
                if (r2 != null) {
                    this.mProcessingThreadHandler.post(new Runnable() {
                        public void run() {
                            if (!C14840qS.A0B() && (C14840qS.A05 == null || !C14840qS.A05.A06)) {
                                MultiSignalANRDetector.this.mMovedToBackground = true;
                            }
                            AnonymousClass0HP r1 = r2;
                            AnonymousClass0Ej r0 = MultiSignalANRDetector.this.mForegroundTransitionListener;
                            List list = r1.A00;
                            synchronized (list) {
                                list.add(r0);
                            }
                        }
                    });
                }
            }
        }
    }

    public void startForTesting() {
        throw new AssertionError();
    }

    public void stop(IANRDetector.ANRDetectorStopListener aNRDetectorStopListener) {
        synchronized (this.mStartStopLock) {
            if (this.mRunning) {
                C14270pR.A0G(this.mLogTag, "Stopping");
                this.mRunning = false;
                this.mProcessAnrErrorMonitor.stopMonitoring();
                this.mProcessingThreadHandler.removeCallbacks(this.mConfirmationExpiredRunnable);
                if (this.mNativeHookInPlace) {
                    this.mSigquitDetector.stopDetector();
                }
                AnonymousClass0HP r1 = this.mAnrDetectorConfig.A00;
                if (r1 != null) {
                    AnonymousClass0Ej r0 = this.mForegroundTransitionListener;
                    List list = r1.A00;
                    synchronized (list) {
                        list.remove(r0);
                    }
                }
                if (aNRDetectorStopListener != null) {
                    aNRDetectorStopListener.onStop();
                }
            }
        }
    }

    public MultiSignalANRDetector(C011005t r10, C14750qJ r11) {
        SigquitDetector instance;
        this.mAnrDetectorConfig = r10;
        if (r10.A0I) {
            instance = SigquitDetectorLacrima.getInstance(this);
        } else {
            instance = SigquitDetectorAcra.getInstance(this);
        }
        this.mSigquitDetector = instance;
        this.mCurrentState = AnonymousClass063.NO_ANR_DETECTED;
        this.mProcessAnrErrorMonitor = new ProcessAnrErrorMonitor(r10.A08, r10.A0D, false, r10.A05, true, 0, 0, r10.A06);
        this.mAnrStagesListener = r11;
        HandlerThread handlerThread = new HandlerThread(AnonymousClass0WY.A0i("MultiSignalANRDetectorThread:", C14840qS.A03()));
        C08130bX.A00(handlerThread);
        this.mProcessingThread = handlerThread;
        handlerThread.start();
        this.mProcessingThreadHandler = new Handler(handlerThread.getLooper());
    }

    public static boolean isTest() {
        return false;
    }

    private void setCurrentAnrStateFromNoAnrDetected(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 0) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED;
        } else if (ordinal == 1) {
            r0 = AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED;
        } else if (ordinal != 3) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            return;
        }
        this.mCurrentState = r0;
    }

    private void setCurrentAnrStateFromNoSigquitAmConfirmedMtBlocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 0) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_BLOCKED;
        } else if (ordinal == 3) {
            r0 = AnonymousClass063.NO_SIGQUIT_AM_CONFIRMED_MT_UNBLOCKED;
        } else if (ordinal != 4) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            r0 = AnonymousClass063.NO_ANR_DETECTED;
        }
        this.mCurrentState = r0;
    }

    private void setCurrentAnrStateFromNoSigquitAmConfirmedMtUnblocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 0) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_UNBLOCKED;
        } else if (ordinal != 4) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            r0 = AnonymousClass063.NO_ANR_DETECTED;
        }
        this.mCurrentState = r0;
    }

    private void setCurrentAnrStateFromSigquitReceivedAmConfirmedMtBlocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 3) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_UNBLOCKED;
        } else if (ordinal != 4) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            r0 = AnonymousClass063.NO_ANR_DETECTED;
        }
        this.mCurrentState = r0;
    }

    private void setCurrentAnrStateFromSigquitReceivedAmConfirmedMtUnblocked(Event event) {
        if (event.ordinal() != 4) {
            logUnexpectedStateTransition(event);
        } else {
            this.mCurrentState = AnonymousClass063.NO_ANR_DETECTED;
        }
    }

    private void setCurrentAnrStateFromSigquitReceivedAmExpiredMtBlocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 0) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED;
        } else if (ordinal == 1) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_BLOCKED;
        } else if (ordinal != 3) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            r0 = AnonymousClass063.NO_ANR_DETECTED;
        }
        this.mCurrentState = r0;
    }

    private void setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtBlocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal != 0) {
            if (ordinal == 1) {
                r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_BLOCKED;
            } else if (ordinal == 3) {
                r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_UNBLOCKED;
            } else if (ordinal != 2) {
                logUnexpectedStateTransition(event);
                return;
            } else {
                r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_EXPIRED_MT_BLOCKED;
            }
            this.mCurrentState = r0;
        }
    }

    private void setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtUnblocked(Event event) {
        AnonymousClass063 r0;
        int ordinal = event.ordinal();
        if (ordinal == 0) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED;
        } else if (ordinal == 1) {
            r0 = AnonymousClass063.SIGQUIT_RECEIVED_AM_CONFIRMED_MT_UNBLOCKED;
        } else if (ordinal != 2) {
            logUnexpectedStateTransition(event);
            return;
        } else {
            r0 = AnonymousClass063.NO_ANR_DETECTED;
        }
        this.mCurrentState = r0;
    }

    public long getANRReceivedTime() {
        return this.mSigquitReceivedTime;
    }

    public long getANRReceivedUpTime() {
        return this.mSigquitReceivedUptime;
    }

    public void setANRReportProvider(ANRReportProvider aNRReportProvider) {
        this.mANRReportProvider = aNRReportProvider;
    }

    public void setCheckIntervalMs(long j) {
    }

    public void setListener(ANRDetectorListener aNRDetectorListener) {
        this.mAnrDetectorListener = aNRDetectorListener;
    }

    public MultiSignalANRDetector(C011005t r12, SigquitDetector sigquitDetector, HandlerThread handlerThread) {
        this.mAnrDetectorConfig = r12;
        this.mSigquitDetector = sigquitDetector;
        this.mCurrentState = AnonymousClass063.NO_ANR_DETECTED;
        this.mProcessAnrErrorMonitor = new ProcessAnrErrorMonitor(r12.A08, r12.A0D, false, r12.A05, true, 0, 0, r12.A06);
        this.mProcessingThread = handlerThread;
        this.mAnrStagesListener = null;
        handlerThread.start();
        this.mProcessingThreadHandler = new Handler(handlerThread.getLooper());
    }

    public static MultiSignalANRDetector getInstance(C011005t r1) {
        return getInstance(r1, (C14750qJ) null);
    }

    public void setCurrentAnrState(Event event, boolean z, boolean z2) {
        AnonymousClass063 r0;
        C14270pR.A0P(this.mLogTag, "Transitioning from %s event %s inFgV1: %b inFgV2: %b", this.mCurrentState, event, Boolean.valueOf(z), Boolean.valueOf(z2));
        AnonymousClass063 r3 = this.mCurrentState;
        switch (r3.ordinal()) {
            case 0:
                setCurrentAnrStateFromNoAnrDetected(event);
                break;
            case 3:
                setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtBlocked(event);
                break;
            case 4:
                setCurrentAnrStateFromSigquitReceivedAmConfirmedMtBlocked(event);
                break;
            case 5:
                setCurrentAnrStateFromSigquitReceivedAmConfirmedMtUnblocked(event);
                break;
            case 6:
                setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtUnblocked(event);
                break;
            case 7:
                setCurrentAnrStateFromSigquitReceivedAmExpiredMtBlocked(event);
                break;
            case 8:
                setCurrentAnrStateFromNoSigquitAmConfirmedMtBlocked(event);
                break;
            case 9:
                setCurrentAnrStateFromNoSigquitAmConfirmedMtUnblocked(event);
                break;
            default:
                throw AnonymousClass002.A0G(r3, "Unknown state: ", AnonymousClass001.A0m());
        }
        setASLState(event, z, z2);
        maybeStartMainThreadBlockedCheck();
        AnonymousClass063 r2 = this.mCurrentState;
        if (r3 != r2 && r3 != (r0 = AnonymousClass063.NO_ANR_DETECTED) && r2 != r0) {
            C010705q r1 = (C010705q) this.mAnrDetectorConfig.A0A;
            r1.A0D = r2;
            if (r1.A0Q) {
                C010705q.A00(r1);
            }
        }
    }
}
