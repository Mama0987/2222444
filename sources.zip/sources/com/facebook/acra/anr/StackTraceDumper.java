package com.facebook.acra.anr;

import X.AnonymousClass001;
import android.os.Looper;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;

public class StackTraceDumper {
    public static void dumpStackTraces(OutputStream outputStream) {
        dumpStackTraces(outputStream, (String) null, (String) null);
    }

    public static void printThread(PrintWriter printWriter, Thread thread, StackTraceElement[] stackTraceElementArr) {
        printWriter.print(thread);
        printWriter.print(" ");
        printWriter.print(thread.getState());
        printWriter.println(":");
        for (StackTraceElement println : stackTraceElementArr) {
            printWriter.println(println);
        }
        printWriter.println();
    }

    public static void dumpStackTraces(OutputStream outputStream, String str, String str2) {
        PrintWriter printWriter = new PrintWriter(outputStream);
        if (str != null) {
            printWriter.println(str);
            printWriter.println(str2);
        }
        Map<Thread, StackTraceElement[]> allStackTraces = Thread.getAllStackTraces();
        Thread thread = Looper.getMainLooper().getThread();
        Iterator A12 = AnonymousClass001.A12(allStackTraces);
        while (A12.hasNext()) {
            Map.Entry A13 = AnonymousClass001.A13(A12);
            printThread(printWriter, (Thread) A13.getKey(), (StackTraceElement[]) A13.getValue());
        }
        if (!allStackTraces.containsKey(thread)) {
            printThread(printWriter, thread, thread.getStackTrace());
        }
        printWriter.flush();
    }
}
