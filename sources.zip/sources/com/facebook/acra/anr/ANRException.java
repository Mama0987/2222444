package com.facebook.acra.anr;

public class ANRException extends Exception {
    public ANRException(String str) {
        super(str);
    }

    public ANRException() {
    }
}
