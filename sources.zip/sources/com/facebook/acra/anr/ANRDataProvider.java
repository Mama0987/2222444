package com.facebook.acra.anr;

import X.C06300Vs;

public abstract class ANRDataProvider implements ANRReportProvider {
    public abstract int detectionIntervalTimeMs();

    public abstract int detectorToUse();

    public abstract int getForegroundCheckPeriod();

    public abstract int getRecoveryTimeout();

    public abstract void provideDexStatus();

    public abstract void provideLooperMonitorInfo();

    public abstract void provideLooperProfileInfo();

    public abstract void provideStats();

    public abstract void reportSoftError(String str, Throwable th);

    public abstract boolean shouldANRDetectorRun();

    public abstract boolean shouldAvoidMutexOnSignalHandler();

    public abstract boolean shouldCollectAndUploadANRReports();

    public abstract boolean shouldDedupDiskPersistence();

    public abstract boolean shouldLogOnSignalHandler();

    public abstract boolean shouldLogProcessPositionInAnrTraceFile();

    public abstract boolean shouldRecordSignalTime();

    public abstract boolean shouldReportSoftErrors();

    public abstract boolean shouldRunANRDetectorOnBrowserProcess();

    public abstract boolean shouldUploadSystemANRTraces();

    public ANRDataProvider() {
        throw C06300Vs.createAndThrow();
    }
}
