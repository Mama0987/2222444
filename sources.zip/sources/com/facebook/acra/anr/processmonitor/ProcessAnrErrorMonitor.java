package com.facebook.acra.anr.processmonitor;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0LX;
import X.AnonymousClass0WY;
import X.C14270pR;
import X.C14840qS;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Process;
import android.os.SystemClock;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ProcessAnrErrorMonitor {
    public static final int DEFAULT_POLLING_TIME_MS = 500;
    public static final String LOG_TAG = "ProcessAnrErrorMonitor";
    public static final int UNLIMITED_NUMBER_OF_CHECKS = 0;
    public final Context mContext;
    public final boolean mContinuousMonitoring;
    public long mCurrentMonitorThreadId;
    public int mDurationWritePos;
    public MonitorThread mErrorCheckThread;
    public boolean mFullHistoryData;
    public final int mMaxNumberOfChecksAfterError;
    public final int mMaxNumberOfChecksBeforeError;
    public final int mMyUid;
    public final int mPollingTime;
    public final String mProcessName;
    public final long[] mQueryDurationHistory;
    public State mState;

    public class AnrCheckState {
        public boolean mAnrConfirmed;
        public int mCount;
    }

    public class AnrErrorState {
        public String mErrorMsg;
        public String mProcessName;
        public String mTag;
    }

    public class MonitorThread extends Thread {
        public final ActivityManager mAm;
        public final long mDelay;
        public boolean mFirstCheck;
        public final long mId;
        public volatile ProcessErrorStateListener mListener;
        public final Object mMonitorLock;
        public boolean mPauseRequested;
        public final Set mProcessesInAnr;
        public boolean mStopRequested;

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0086  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean checkIteration(com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.AnrCheckState r9) {
            /*
                r8 = this;
                r3 = 1
                r4 = 0
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ RuntimeException -> 0x00f6 }
                long[] r0 = r0.mQueryDurationHistory     // Catch:{ RuntimeException -> 0x00f6 }
                if (r0 == 0) goto L_0x0041
                long r6 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.Api17Utils.getTimeInNanos()     // Catch:{ RuntimeException -> 0x00f6 }
            L_0x000c:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ RuntimeException -> 0x00f6 }
                android.app.ActivityManager r0 = r8.mAm     // Catch:{ RuntimeException -> 0x00f6 }
                java.util.LinkedList r5 = r1.checkProcessError(r0)     // Catch:{ RuntimeException -> 0x00f6 }
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ RuntimeException -> 0x00f6 }
                long[] r0 = r2.mQueryDurationHistory     // Catch:{ RuntimeException -> 0x00f6 }
                if (r0 == 0) goto L_0x0022
                long r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.Api17Utils.getTimeInNanos()     // Catch:{ RuntimeException -> 0x00f6 }
                long r0 = r0 - r6
                r2.logDuration(r0)     // Catch:{ RuntimeException -> 0x00f6 }
            L_0x0022:
                boolean r0 = r8.mFirstCheck     // Catch:{ RuntimeException -> 0x00f6 }
                if (r0 == 0) goto L_0x0044
                java.lang.String r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG     // Catch:{ RuntimeException -> 0x00f6 }
                java.lang.String r1 = "Starting process monitor checks for process '%s'"
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ RuntimeException -> 0x00f6 }
                java.lang.String r0 = r0.mProcessName     // Catch:{ RuntimeException -> 0x00f6 }
                java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ RuntimeException -> 0x00f6 }
                X.C14270pR.A0P(r2, r1, r0)     // Catch:{ RuntimeException -> 0x00f6 }
                r8.mFirstCheck = r4     // Catch:{ RuntimeException -> 0x00f6 }
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ RuntimeException -> 0x00f6 }
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MONITOR_STARTED     // Catch:{ RuntimeException -> 0x00f6 }
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r8.mListener     // Catch:{ RuntimeException -> 0x00f6 }
                r2.updateStateAndMaybeCallListener(r1, r0)     // Catch:{ RuntimeException -> 0x00f6 }
                goto L_0x0044
            L_0x0041:
                r6 = 0
                goto L_0x000c
            L_0x0044:
                boolean r0 = r5.isEmpty()
                if (r0 != 0) goto L_0x0091
                java.lang.Object r7 = r5.getFirst()
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrErrorState r7 = (com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.AnrErrorState) r7
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                java.lang.String r1 = r2.mProcessName
                java.lang.String r0 = r7.mProcessName
                boolean r0 = r1.equals(r0)
                if (r0 == 0) goto L_0x0091
                boolean r0 = r9.mAnrConfirmed
                if (r0 != 0) goto L_0x00d2
                r9.mAnrConfirmed = r3
                r9.mCount = r4
                java.lang.String r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG
                java.lang.String r1 = r7.mErrorMsg
                java.lang.String r0 = r7.mTag
                java.lang.Object[] r1 = new java.lang.Object[]{r1, r0}
                java.lang.String r0 = "ANR detected Short msg: %s Tag: %s"
                X.C14270pR.A0P(r2, r0, r1)
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r6 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r4 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_DETECTED
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r2 = r8.mListener
                java.lang.String r1 = r7.mErrorMsg
                java.lang.String r0 = r7.mTag
                r6.updateStateAndMaybeCallListener(r4, r2, r1, r0)
            L_0x0080:
                boolean r0 = r5.isEmpty()
                if (r0 != 0) goto L_0x008d
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                java.lang.String r0 = r0.mProcessName
                r8.maybeLogAnrStateFromOtherProcesses(r5, r0)
            L_0x008d:
                r8.maybeCallIterationListener()
                return r3
            L_0x0091:
                boolean r0 = r9.mAnrConfirmed
                if (r0 == 0) goto L_0x00b0
                java.lang.String r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG
                java.lang.String r0 = "On error cleared"
                X.C14270pR.A0G(r1, r0)
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_CLEARED
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r8.mListener
                r2.updateStateAndMaybeCallListener(r1, r0)
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                boolean r3 = r0.mContinuousMonitoring
                if (r3 == 0) goto L_0x0080
                r9.mAnrConfirmed = r4
                r9.mCount = r4
                goto L_0x0080
            L_0x00b0:
                int r0 = r9.mCount
                int r1 = r0 + 1
                r9.mCount = r1
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                int r0 = r2.mMaxNumberOfChecksBeforeError
                if (r0 <= 0) goto L_0x0080
                if (r1 < r0) goto L_0x0080
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MAX_NUMBER_BEFORE_ERROR
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r8.mListener
                r2.updateStateAndMaybeCallListener(r1, r0)
                java.lang.String r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                java.lang.String r0 = r0.mProcessName
                java.lang.Object[] r1 = new java.lang.Object[]{r0}
                java.lang.String r0 = "Stopping checks for '%s' because of MAX_NUMBER_BEFORE_ERROR"
                goto L_0x00f1
            L_0x00d2:
                int r0 = r9.mCount
                int r1 = r0 + 1
                r9.mCount = r1
                int r0 = r2.mMaxNumberOfChecksAfterError
                if (r0 <= 0) goto L_0x0080
                if (r1 < r0) goto L_0x0080
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MAX_NUMBER_AFTER_ERROR
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r8.mListener
                r2.updateStateAndMaybeCallListener(r1, r0)
                java.lang.String r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                java.lang.String r0 = r0.mProcessName
                java.lang.Object[] r1 = new java.lang.Object[]{r0}
                java.lang.String r0 = "Stopping checks for '%s' because of MAX_NUMBER_AFTER_ERROR"
            L_0x00f1:
                X.C14270pR.A0P(r2, r0, r1)
                r3 = 0
                goto L_0x0080
            L_0x00f6:
                r3 = move-exception
                boolean r0 = X.AnonymousClass001.A1Z(r3)
                if (r0 != 0) goto L_0x0106
                java.lang.Throwable r0 = r3.getCause()
                boolean r0 = r0 instanceof android.os.RemoteException
                if (r0 != 0) goto L_0x0106
                throw r3
            L_0x0106:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_QUERYING_ACTIVITY_MANAGER
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r8.mListener
                r2.updateStateAndMaybeCallListener(r1, r0)
                java.lang.String r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.LOG_TAG
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                java.lang.String r0 = r0.mProcessName
                java.lang.Object[] r1 = new java.lang.Object[]{r0, r3}
                java.lang.String r0 = "Stopping checks for '%s' because of ERROR_QUERYING_ACTIVITY_MANAGER"
                X.C14270pR.A0O(r2, r0, r1)
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.MonitorThread.checkIteration(com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrCheckState):boolean");
        }

        private void maybeCallIterationListener() {
            if (this.mListener != null) {
                this.mListener.onCheckPerformed();
            }
        }

        private void maybeLogAnrStateFromOtherProcesses(LinkedList linkedList, String str) {
            if (this.mListener != null) {
                Iterator it = linkedList.iterator();
                while (it.hasNext()) {
                    AnrErrorState anrErrorState = (AnrErrorState) it.next();
                    String str2 = anrErrorState.mProcessName;
                    if (!str.equals(str2)) {
                        C14270pR.A0P(ProcessAnrErrorMonitor.LOG_TAG, "Error found in process '%s' different from process being searched '%s'", str2, str);
                        String str3 = anrErrorState.mProcessName;
                        if (str3 != null && !this.mProcessesInAnr.contains(str3) && this.mListener.onErrorDetectOnOtherProcess(anrErrorState.mProcessName, anrErrorState.mErrorMsg, anrErrorState.mTag)) {
                            this.mProcessesInAnr.add(anrErrorState.mProcessName);
                        }
                    }
                }
            }
        }

        /* JADX WARNING: type inference failed for: r5v0, types: [com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrCheckState, java.lang.Object] */
        /* JADX WARNING: CFG modification limit reached, blocks count: 178 */
        /* JADX WARNING: Can't wrap try/catch for region: R(14:54|(1:56)|57|58|59|60|(1:64)|54|(0)|57|58|59|60|64) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x001d, code lost:
            if (r12.mListener == null) goto L_0x001f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x004b, code lost:
            if (r12.mListener == null) goto L_0x004d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:69:0x0098, code lost:
            if (r9 != false) goto L_0x009a;
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:59:0x0081 */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x002a  */
        /* JADX WARNING: Removed duplicated region for block: B:38:0x0054  */
        /* JADX WARNING: Removed duplicated region for block: B:56:0x007a  */
        /* JADX WARNING: Removed duplicated region for block: B:75:0x0039 A[EDGE_INSN: B:75:0x0039->B:21:0x0039 ?: BREAK  , SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void monitorLoop() {
            /*
                r12 = this;
                long r1 = r12.mDelay
                r6 = 0
                r10 = 0
                int r0 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
                if (r0 > 0) goto L_0x000d
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r12.mListener
                if (r0 != 0) goto L_0x005c
            L_0x000d:
                long r1 = r12.mDelay
                java.lang.Object r5 = r12.mMonitorLock
                monitor-enter(r5)
                int r0 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
                if (r0 <= 0) goto L_0x001b
                boolean r0 = r12.mStopRequested     // Catch:{ all -> 0x0059 }
                if (r0 != 0) goto L_0x0021
                goto L_0x001f
            L_0x001b:
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r12.mListener     // Catch:{ all -> 0x0059 }
                if (r0 != 0) goto L_0x0021
            L_0x001f:
                r0 = 1
                goto L_0x0022
            L_0x0021:
                r0 = 0
            L_0x0022:
                boolean r9 = r12.mStopRequested     // Catch:{ all -> 0x0059 }
                long r7 = android.os.SystemClock.uptimeMillis()     // Catch:{ all -> 0x0059 }
                if (r0 == 0) goto L_0x0039
                goto L_0x003b
            L_0x002b:
                long r1 = r12.mDelay     // Catch:{ all -> 0x0059 }
                long r3 = android.os.SystemClock.uptimeMillis()     // Catch:{ all -> 0x0059 }
                long r3 = r3 - r7
                long r1 = r1 - r3
                r3 = 1
                int r0 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
                if (r0 >= 0) goto L_0x003b
            L_0x0039:
                monitor-exit(r5)     // Catch:{ all -> 0x0059 }
                goto L_0x0098
            L_0x003b:
                java.lang.Object r0 = r12.mMonitorLock     // Catch:{ InterruptedException -> 0x0040 }
                r0.wait(r1)     // Catch:{ InterruptedException -> 0x0040 }
            L_0x0040:
                int r0 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
                if (r0 <= 0) goto L_0x0049
                boolean r0 = r12.mStopRequested     // Catch:{ all -> 0x0059 }
                if (r0 != 0) goto L_0x004f
                goto L_0x004d
            L_0x0049:
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r12.mListener     // Catch:{ all -> 0x0059 }
                if (r0 != 0) goto L_0x004f
            L_0x004d:
                r0 = 1
                goto L_0x0050
            L_0x004f:
                r0 = 0
            L_0x0050:
                boolean r9 = r12.mStopRequested     // Catch:{ all -> 0x0059 }
                if (r0 == 0) goto L_0x0039
                int r0 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
                if (r0 <= 0) goto L_0x003b
                goto L_0x002b
            L_0x0059:
                r0 = move-exception
                monitor-exit(r5)     // Catch:{ all -> 0x0059 }
                throw r0
            L_0x005c:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrCheckState r5 = new com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrCheckState
                r5.<init>()
                r5.mAnrConfirmed = r6
                r5.mCount = r6
            L_0x0065:
                boolean r0 = r12.checkIteration(r5)
                if (r0 == 0) goto L_0x009a
                java.lang.Object r4 = r12.mMonitorLock
                monitor-enter(r4)
                boolean r0 = r12.mStopRequested     // Catch:{ all -> 0x009b }
                if (r0 != 0) goto L_0x008b
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this     // Catch:{ all -> 0x009b }
                int r3 = r0.mPollingTime     // Catch:{ all -> 0x009b }
            L_0x0076:
                boolean r0 = r12.mPauseRequested     // Catch:{ all -> 0x009b }
                if (r0 == 0) goto L_0x007b
                r3 = 0
            L_0x007b:
                java.lang.Object r2 = r12.mMonitorLock     // Catch:{ InterruptedException -> 0x0081 }
                long r0 = (long) r3     // Catch:{ InterruptedException -> 0x0081 }
                r2.wait(r0)     // Catch:{ InterruptedException -> 0x0081 }
            L_0x0081:
                boolean r0 = r12.mPauseRequested     // Catch:{ all -> 0x009b }
                if (r0 == 0) goto L_0x0089
                boolean r0 = r12.mStopRequested     // Catch:{ all -> 0x009b }
                if (r0 == 0) goto L_0x0076
            L_0x0089:
                boolean r0 = r12.mStopRequested     // Catch:{ all -> 0x009b }
            L_0x008b:
                monitor-exit(r4)     // Catch:{ all -> 0x009b }
                if (r0 == 0) goto L_0x0065
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor r2 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.this
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r1 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.STOP_REQUESTED
                com.facebook.acra.anr.processmonitor.ProcessErrorStateListener r0 = r12.mListener
                r2.updateStateAndMaybeCallListener(r1, r0)
                return
            L_0x0098:
                if (r9 == 0) goto L_0x005c
            L_0x009a:
                return
            L_0x009b:
                r0 = move-exception
                monitor-exit(r4)     // Catch:{ all -> 0x009b }
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.MonitorThread.monitorLoop():void");
        }

        /* access modifiers changed from: private */
        public void pauseRequested() {
            synchronized (this.mMonitorLock) {
                this.mPauseRequested = true;
                this.mMonitorLock.notifyAll();
            }
        }

        /* access modifiers changed from: private */
        public void resumeRequested() {
            synchronized (this.mMonitorLock) {
                this.mPauseRequested = false;
                this.mMonitorLock.notifyAll();
            }
        }

        /* access modifiers changed from: private */
        public void stopRequested() {
            synchronized (this.mMonitorLock) {
                this.mStopRequested = true;
                this.mMonitorLock.notifyAll();
            }
        }

        public boolean hasListener() {
            if (this.mListener != null) {
                return true;
            }
            return false;
        }

        public void setListener(ProcessErrorStateListener processErrorStateListener) {
            synchronized (this.mMonitorLock) {
                this.mListener = processErrorStateListener;
                this.mMonitorLock.notifyAll();
            }
        }

        public long getMonitorId() {
            return this.mId;
        }

        public void run() {
            monitorLoop();
        }

        public /* synthetic */ MonitorThread(ProcessAnrErrorMonitor processAnrErrorMonitor, ActivityManager activityManager, ProcessErrorStateListener processErrorStateListener, long j, long j2, AnonymousClass1 r8) {
            this(activityManager, processErrorStateListener, j, j2);
        }

        public MonitorThread(ActivityManager activityManager, ProcessErrorStateListener processErrorStateListener, long j, long j2) {
            super(AnonymousClass0WY.A0i("ProcessAnrErrorMonitorThread:", C14840qS.A03()));
            this.mMonitorLock = AnonymousClass001.A0U();
            this.mProcessesInAnr = AnonymousClass001.A0x();
            this.mAm = activityManager;
            this.mListener = processErrorStateListener;
            this.mId = j;
            this.mDelay = j2;
            this.mFirstCheck = true;
        }
    }

    public enum State {
        NOT_MONITORING,
        MONITORING_NO_ERROR_DETECTED,
        MONITORING_ERROR_DETECTED
    }

    public enum StateChangeReason {
        MONITOR_STARTED,
        ERROR_CLEARED,
        ERROR_DETECTED,
        MAX_NUMBER_BEFORE_ERROR,
        MAX_NUMBER_AFTER_ERROR,
        STOP_REQUESTED,
        ERROR_QUERYING_ACTIVITY_MANAGER
    }

    public ProcessAnrErrorMonitor(Context context, String str, int i, int i2) {
        this(context, str, false, 500, false, i, i2, 0);
    }

    public synchronized MonitorThread getErrorCheckThread() {
        return this.mErrorCheckThread;
    }

    public synchronized State getState() {
        return this.mState;
    }

    public void pause() {
        MonitorThread monitorThread;
        synchronized (this) {
            if (!(this.mState == State.NOT_MONITORING || (monitorThread = this.mErrorCheckThread) == null)) {
                monitorThread.pauseRequested();
            }
        }
    }

    public void resume() {
        MonitorThread monitorThread;
        synchronized (this) {
            if (!(this.mState == State.NOT_MONITORING || (monitorThread = this.mErrorCheckThread) == null)) {
                monitorThread.resumeRequested();
            }
        }
    }

    public synchronized void setErrorCheckThread(MonitorThread monitorThread) {
        this.mErrorCheckThread = monitorThread;
    }

    public MonitorThread startMonitoringForTest(ProcessErrorStateListener processErrorStateListener) {
        MonitorThread monitorThread;
        MonitorThread monitorThread2;
        ActivityManager activityManager = (ActivityManager) this.mContext.getSystemService("activity");
        synchronized (this) {
            if (!(this.mState == State.NOT_MONITORING || (monitorThread2 = this.mErrorCheckThread) == null)) {
                monitorThread2.stopRequested();
            }
            long j = this.mCurrentMonitorThreadId + 1;
            this.mCurrentMonitorThreadId = j;
            monitorThread = new MonitorThread(activityManager, processErrorStateListener, j, 0);
            this.mErrorCheckThread = monitorThread;
        }
        return monitorThread;
    }

    public void stopMonitoring() {
        MonitorThread monitorThread;
        synchronized (this) {
            if (!(this.mState == State.NOT_MONITORING || (monitorThread = this.mErrorCheckThread) == null)) {
                monitorThread.stopRequested();
            }
        }
    }

    public void updateStateAndMaybeCallListener(StateChangeReason stateChangeReason, ProcessErrorStateListener processErrorStateListener) {
        updateStateAndMaybeCallListener(stateChangeReason, processErrorStateListener, (String) null, (String) null);
    }

    /* renamed from: com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$1  reason: invalid class name */
    public abstract /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$com$facebook$acra$anr$processmonitor$ProcessAnrErrorMonitor$StateChangeReason;

        /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0036 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x003f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0024 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x002d */
        static {
            /*
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason[] r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.values()
                int r0 = r0.length
                int[] r2 = new int[r0]
                $SwitchMap$com$facebook$acra$anr$processmonitor$ProcessAnrErrorMonitor$StateChangeReason = r2
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MONITOR_STARTED     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0 = 1
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_DETECTED     // Catch:{ NoSuchFieldError -> 0x001b }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x001b }
                r0 = 2
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x001b }
            L_0x001b:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_CLEARED     // Catch:{ NoSuchFieldError -> 0x0024 }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0024 }
                r0 = 3
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0024 }
            L_0x0024:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MAX_NUMBER_AFTER_ERROR     // Catch:{ NoSuchFieldError -> 0x002d }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x002d }
                r0 = 4
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x002d }
            L_0x002d:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.MAX_NUMBER_BEFORE_ERROR     // Catch:{ NoSuchFieldError -> 0x0036 }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0036 }
                r0 = 5
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0036 }
            L_0x0036:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.STOP_REQUESTED     // Catch:{ NoSuchFieldError -> 0x003f }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x003f }
                r0 = 6
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x003f }
            L_0x003f:
                com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$StateChangeReason r0 = com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.StateChangeReason.ERROR_QUERYING_ACTIVITY_MANAGER     // Catch:{ NoSuchFieldError -> 0x0048 }
                int r1 = r0.ordinal()     // Catch:{ NoSuchFieldError -> 0x0048 }
                r0 = 7
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0048 }
            L_0x0048:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor.AnonymousClass1.<clinit>():void");
        }
    }

    public class Api17Utils {
        public static long getTimeInNanos() {
            return SystemClock.elapsedRealtimeNanos();
        }
    }

    /* access modifiers changed from: private */
    public void logDuration(long j) {
        long[] jArr = this.mQueryDurationHistory;
        if (jArr != null) {
            synchronized (jArr) {
                long[] jArr2 = this.mQueryDurationHistory;
                int i = this.mDurationWritePos;
                jArr2[i] = j;
                int i2 = i + 1;
                this.mDurationWritePos = i2;
                if (i2 >= jArr2.length) {
                    this.mFullHistoryData = true;
                    this.mDurationWritePos = 0;
                }
            }
        }
    }

    public AnonymousClass0LX getDurationHistory() {
        AnonymousClass0LX r0;
        long[] jArr = this.mQueryDurationHistory;
        if (jArr == null) {
            return null;
        }
        synchronized (jArr) {
            long[] jArr2 = this.mQueryDurationHistory;
            int length = jArr2.length;
            long[] jArr3 = new long[length];
            System.arraycopy(jArr2, 0, jArr3, 0, length);
            r0 = new AnonymousClass0LX(jArr3, this.mDurationWritePos, this.mFullHistoryData);
        }
        return r0;
    }

    public void startMonitoring(ProcessErrorStateListener processErrorStateListener) {
        startMonitoringAfterDelay(processErrorStateListener, 0);
    }

    public void startMonitoringAfterDelay(ProcessErrorStateListener processErrorStateListener, long j) {
        IllegalArgumentException illegalArgumentException;
        MonitorThread monitorThread;
        long j2 = j;
        C14270pR.A0P(LOG_TAG, "startMonitoring with delay: %d", Long.valueOf(j));
        ActivityManager activityManager = (ActivityManager) this.mContext.getSystemService("activity");
        synchronized (this) {
            ProcessErrorStateListener processErrorStateListener2 = processErrorStateListener;
            if (processErrorStateListener != null || j == 0) {
                MonitorThread monitorThread2 = this.mErrorCheckThread;
                if (monitorThread2 == null || monitorThread2.hasListener()) {
                    State state = this.mState;
                    State state2 = State.NOT_MONITORING;
                    if (!(state == state2 || (monitorThread = this.mErrorCheckThread) == null)) {
                        monitorThread.stopRequested();
                    }
                    long j3 = this.mCurrentMonitorThreadId + 1;
                    this.mCurrentMonitorThreadId = j3;
                    MonitorThread monitorThread3 = new MonitorThread(activityManager, processErrorStateListener2, j3, j2);
                    this.mErrorCheckThread = monitorThread3;
                    if (processErrorStateListener != null) {
                        state2 = State.MONITORING_NO_ERROR_DETECTED;
                    }
                    this.mState = state2;
                    monitorThread3.start();
                } else if (processErrorStateListener != null) {
                    this.mErrorCheckThread.setListener(processErrorStateListener);
                } else {
                    illegalArgumentException = AnonymousClass001.A0L("Listener cannot be null");
                }
            } else {
                illegalArgumentException = AnonymousClass001.A0L("Cannot delay and wait for listener at the same time");
            }
            throw illegalArgumentException;
        }
    }

    public static long getTimeInNanos() {
        return Api17Utils.getTimeInNanos();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [java.lang.Object, com.facebook.acra.anr.processmonitor.ProcessAnrErrorMonitor$AnrErrorState] */
    public LinkedList checkProcessError(ActivityManager activityManager) {
        List<ActivityManager.ProcessErrorStateInfo> processesInErrorState = activityManager.getProcessesInErrorState();
        LinkedList linkedList = new LinkedList();
        if (processesInErrorState != null) {
            for (ActivityManager.ProcessErrorStateInfo next : processesInErrorState) {
                if (next.condition == 2 && next.uid == this.mMyUid) {
                    ? obj = new Object();
                    obj.mErrorMsg = next.shortMsg;
                    obj.mTag = next.tag;
                    String str = next.processName;
                    obj.mProcessName = str;
                    if (this.mProcessName.equals(str)) {
                        linkedList.addFirst(obj);
                    } else {
                        linkedList.addLast(obj);
                    }
                }
            }
        }
        return linkedList;
    }

    public ProcessAnrErrorMonitor(Context context, String str, boolean z, int i, boolean z2, int i2, int i3, int i4) {
        this.mContext = context;
        this.mProcessName = str;
        this.mState = State.NOT_MONITORING;
        this.mPollingTime = i;
        this.mContinuousMonitoring = z2;
        this.mMaxNumberOfChecksBeforeError = i2;
        this.mMaxNumberOfChecksAfterError = i3;
        this.mMyUid = Process.myUid();
        if (i4 > 0) {
            this.mQueryDurationHistory = new long[i4];
        } else {
            this.mQueryDurationHistory = null;
        }
        this.mFullHistoryData = false;
        this.mDurationWritePos = 0;
        if (z) {
            startMonitoringAfterDelay((ProcessErrorStateListener) null, 0);
        }
    }

    public synchronized void updateStateAndMaybeCallListener(StateChangeReason stateChangeReason, ProcessErrorStateListener processErrorStateListener, String str, String str2) {
        MonitorThread monitorThread = this.mErrorCheckThread;
        if (monitorThread == null || monitorThread.mId == this.mCurrentMonitorThreadId) {
            switch (stateChangeReason.ordinal()) {
                case 0:
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onStart();
                        break;
                    }
                    break;
                case 1:
                    if (this.mContinuousMonitoring) {
                        this.mState = State.MONITORING_NO_ERROR_DETECTED;
                    } else {
                        this.mState = State.NOT_MONITORING;
                    }
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onErrorCleared();
                        break;
                    }
                    break;
                case 2:
                    this.mState = State.MONITORING_ERROR_DETECTED;
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onErrorDetected(str, str2);
                        break;
                    }
                    break;
                case 3:
                    this.mState = State.NOT_MONITORING;
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onMaxChecksReachedBeforeError();
                        break;
                    }
                    break;
                case 4:
                    this.mState = State.NOT_MONITORING;
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onMaxChecksReachedAfterError();
                        break;
                    }
                    break;
                case 5:
                    this.mState = State.NOT_MONITORING;
                    break;
                case 6:
                    this.mState = State.NOT_MONITORING;
                    if (processErrorStateListener != null) {
                        processErrorStateListener.onCheckFailed();
                        break;
                    }
                    break;
                default:
                    throw AnonymousClass002.A0E(stateChangeReason, "Unexpected state change reason: ", AnonymousClass001.A0m());
            }
        }
    }

    public ProcessAnrErrorMonitor(Context context, String str, boolean z, int i, int i2) {
        this(context, str, z, 500, false, i, i2, 0);
    }
}
