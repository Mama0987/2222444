package com.facebook.acra.anr.sigquit;

import X.C14270pR;
import android.os.Handler;

public class SigquitDetectorLacrima implements SigquitDetector {
    public static final String TAG = "SigquitDetectorLacrima";
    public static SigquitDetector sInstance;
    public static boolean sIsArt;
    public SigquitDetectorListener mListener;
    public Handler mMainThreadHandler;
    public boolean mNotifyJavaOnSigquit;

    public static native void nativeAddSignalHandler();

    public static native void nativeCleanupAppStateFile();

    public static native boolean nativeHookMethods();

    public static native void nativeInit(Object obj, boolean z, int i, String str, String str2, String str3, String str4, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, String str5, boolean z7, boolean z8, boolean z9, boolean z10);

    public static native void nativeSendNextSigquitTraceUnconditionally();

    public static native void nativeStartDetector();

    public static native void nativeStopDetector();

    public static native void nativeWaitForSignal();

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0017, code lost:
        if (r1.startsWith("0.") != false) goto L_0x0019;
     */
    static {
        /*
            java.lang.String r0 = "java.vm.version"
            java.lang.String r1 = java.lang.System.getProperty(r0)
            if (r1 == 0) goto L_0x0019
            java.lang.String r0 = "1."
            boolean r0 = r1.startsWith(r0)
            if (r0 != 0) goto L_0x0019
            java.lang.String r0 = "0."
            boolean r1 = r1.startsWith(r0)
            r0 = 1
            if (r1 == 0) goto L_0x001a
        L_0x0019:
            r0 = 0
        L_0x001a:
            sIsArt = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.sigquit.SigquitDetectorLacrima.<clinit>():void");
    }

    public static SigquitDetector getInstance(SigquitDetectorListener sigquitDetectorListener) {
        SigquitDetector sigquitDetector = sInstance;
        if (sigquitDetector != null) {
            return sigquitDetector;
        }
        SigquitDetectorLacrima sigquitDetectorLacrima = new SigquitDetectorLacrima(sigquitDetectorListener);
        sInstance = sigquitDetectorLacrima;
        return sigquitDetectorLacrima;
    }

    private void onSigquit() {
        this.mListener.onSigquit();
    }

    private void onSigquitTracesAvailable(String str, String str2, boolean z, boolean z2) {
        C14270pR.A0P(TAG, "sigquitDetected inFgV1: %b inFgV2: %b", Boolean.valueOf(z), Boolean.valueOf(z2));
        this.mListener.onSigquitTracesAvailable(str, str2, z, z2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0030, code lost:
        if (r3.endsWith(":browser") != false) goto L_0x0032;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void init(X.C011005t r22, boolean r23) {
        /*
            r21 = this;
            java.lang.String r1 = TAG
            java.lang.String r0 = "nativeInit"
            X.C14270pR.A0G(r1, r0)
            r0 = r22
            android.os.Handler r1 = r0.A09
            r4 = r21
            r4.mMainThreadHandler = r1
            boolean r2 = r0.A0J
            r4.mNotifyJavaOnSigquit = r2
            boolean r5 = sIsArt
            int r6 = android.os.Build.VERSION.SDK_INT
            java.lang.String r7 = r0.A0B
            java.lang.String r8 = r0.A0C
            java.lang.String r9 = r0.A0F
            java.lang.String r10 = r0.A0E
            java.lang.String r3 = r0.A0D
            java.lang.String r1 = ":"
            boolean r1 = r3.contains(r1)
            if (r1 == 0) goto L_0x0032
            java.lang.String r1 = ":browser"
            boolean r1 = r3.endsWith(r1)
            r11 = 0
            if (r1 == 0) goto L_0x0033
        L_0x0032:
            r11 = 1
        L_0x0033:
            boolean r13 = r0.A0N
            boolean r14 = r0.A0L
            boolean r15 = r0.A0K
            java.lang.String r16 = r0.A00()
            boolean r1 = r0.A0M
            int r3 = r0.A02
            boolean r19 = X.AnonymousClass001.A1R(r3)
            boolean r0 = r0.A01
            r12 = r23
            r18 = r2
            r20 = r0
            r17 = r1
            nativeInit(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.acra.anr.sigquit.SigquitDetectorLacrima.init(X.05t, boolean):void");
    }

    public void installSignalHandler(final Handler handler, final boolean z) {
        final AnonymousClass1 r2 = new Runnable() {
            public void run() {
                boolean nativeHookMethods = SigquitDetectorLacrima.nativeHookMethods();
                SigquitDetectorLacrima.this.mListener.onHookedMethods(nativeHookMethods);
                if (nativeHookMethods && z) {
                    SigquitDetectorLacrima.this.startDetector();
                }
            }
        };
        if (this.mNotifyJavaOnSigquit) {
            new Thread("LacrimaSigquitNotifier") {
                public void run() {
                    SigquitDetectorLacrima.nativeWaitForSignal();
                }
            }.start();
        }
        this.mMainThreadHandler.post(new Runnable() {
            public void run() {
                SigquitDetectorLacrima.nativeAddSignalHandler();
                handler.post(r2);
            }
        });
    }

    public SigquitDetectorLacrima(SigquitDetectorListener sigquitDetectorListener) {
        this.mListener = sigquitDetectorListener;
    }

    public void cleanupAppStateFile() {
        nativeCleanupAppStateFile();
    }

    public void doNotIgnoreNextSiguit() {
        nativeSendNextSigquitTraceUnconditionally();
    }

    public void startDetector() {
        nativeStartDetector();
    }

    public void stopDetector() {
        nativeStopDetector();
    }
}
