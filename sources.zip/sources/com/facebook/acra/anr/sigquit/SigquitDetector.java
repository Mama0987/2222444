package com.facebook.acra.anr.sigquit;

import X.C011005t;
import android.os.Handler;

public interface SigquitDetector {
    void cleanupAppStateFile();

    void doNotIgnoreNextSiguit();

    void init(C011005t r1, boolean z);

    void installSignalHandler(Handler handler, boolean z);

    void startDetector();

    void stopDetector();
}
