package com.facebook.push.fcm.customprovider;

import X.C10640fx;
import X.C11730iz;
import android.os.ConditionVariable;
import java.util.Map;

public final class FirebaseInitCustomProvider extends C10640fx {
    public final boolean A0C() {
        Map map = C11730iz.A01;
        synchronized (map) {
            if (!map.containsKey("firebase_init")) {
                map.put("firebase_init", new ConditionVariable());
            }
        }
        return true;
    }
}
