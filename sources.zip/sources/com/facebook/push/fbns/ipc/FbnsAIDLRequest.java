package com.facebook.push.fbns.ipc;

import X.AnonymousClass16P;
import android.os.Parcel;
import android.os.Parcelable;

public final class FbnsAIDLRequest extends FbnsAIDLResult {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16P(0);
    public int A00;

    public final void A00(Parcel parcel, int i) {
        super.A00(parcel, i);
        parcel.writeInt(this.A00);
    }
}
