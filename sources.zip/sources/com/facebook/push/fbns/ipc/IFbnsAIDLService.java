package com.facebook.push.fbns.ipc;

import android.os.IInterface;

public interface IFbnsAIDLService extends IInterface {
    FbnsAIDLResult Dei(FbnsAIDLRequest fbnsAIDLRequest);

    void ELb(FbnsAIDLRequest fbnsAIDLRequest);
}
