package com.facebook.push.fbns.ipc;

import X.AnonymousClass0BS;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

public final class IFbnsAIDLService$Stub$Proxy implements IFbnsAIDLService {
    public IBinder A00;

    public final FbnsAIDLResult Dei(FbnsAIDLRequest fbnsAIDLRequest) {
        Object obj;
        int A03 = AnonymousClass0BS.A03(1819998277);
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.push.fbns.ipc.IFbnsAIDLService");
            obtain.writeInt(1);
            fbnsAIDLRequest.writeToParcel(obtain, 0);
            this.A00.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            Parcelable.Creator creator = FbnsAIDLResult.CREATOR;
            if (obtain2.readInt() != 0) {
                obj = creator.createFromParcel(obtain2);
            } else {
                obj = null;
            }
            return (FbnsAIDLResult) obj;
        } finally {
            obtain2.recycle();
            obtain.recycle();
            AnonymousClass0BS.A09(-1651473098, A03);
        }
    }

    public final void ELb(FbnsAIDLRequest fbnsAIDLRequest) {
        int A03 = AnonymousClass0BS.A03(1204005627);
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.facebook.push.fbns.ipc.IFbnsAIDLService");
            obtain.writeInt(1);
            fbnsAIDLRequest.writeToParcel(obtain, 0);
            this.A00.transact(2, obtain, (Parcel) null, 1);
        } finally {
            obtain.recycle();
            AnonymousClass0BS.A09(1041951890, A03);
        }
    }

    public final IBinder asBinder() {
        int A03 = AnonymousClass0BS.A03(-335947478);
        IBinder iBinder = this.A00;
        AnonymousClass0BS.A09(-1666669739, A03);
        return iBinder;
    }
}
