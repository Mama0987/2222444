package com.facebook.push.mqtt.ipc;

import X.AnonymousClass0BS;
import android.os.IBinder;
import android.os.IInterface;

public final class MqttPubAckCallback$Stub$Proxy implements IInterface {
    public IBinder A00;

    public final IBinder asBinder() {
        int A03 = AnonymousClass0BS.A03(1452549602);
        IBinder iBinder = this.A00;
        AnonymousClass0BS.A09(-1044785833, A03);
        return iBinder;
    }
}
