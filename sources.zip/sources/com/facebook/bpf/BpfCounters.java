package com.facebook.bpf;

import X.C11830jC;
import X.C14270pR;
import X.C16810u4;
import java.util.HashMap;

public final class BpfCounters {
    public static final boolean A00;

    public static final native void closeBpfMapImpl(int i);

    public static final native void getBpfCountersImpl(HashMap hashMap, int i);

    public static final native int openBpfMapImpl(String str);

    static {
        boolean z;
        Class<BpfCounters> cls = BpfCounters.class;
        if (C11830jC.A00.length() == 0) {
            z = false;
        } else {
            try {
                C16810u4.loadLibrary("bpfcounters");
                z = true;
            } catch (UnsatisfiedLinkError e) {
                C14270pR.A07(cls, "Could not load bpfcounters library", e);
                C14270pR.A04(cls, "Consider adding dependency on bpfcounters-jni");
                z = false;
            }
        }
        A00 = z;
    }
}
