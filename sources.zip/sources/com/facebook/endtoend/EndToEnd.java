package com.facebook.endtoend;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.C10960hP;
import X.C11320iB;
import X.C14600q0;
import android.util.Log;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class EndToEnd {
    public static String A00 = "";
    public static Map A01;
    public static boolean A02;
    public static boolean A03;
    public static boolean A04 = true;
    public static boolean A05;
    public static boolean A06;
    public static boolean A07;
    public static boolean A08;
    public static volatile JSONObject A09 = AnonymousClass001.A19();
    public static volatile boolean A0A;
    public static volatile boolean A0B;
    public static volatile Map A0C;

    public static String A01(String str, boolean z, boolean z2) {
        if (!z2 && !isRunningEndToEndTest()) {
            return null;
        }
        String property = System.getProperty(str);
        if (property == null || property.equals("")) {
            String property2 = System.getProperty(AnonymousClass0WY.A0i("fb.e2e.", str));
            if (property2 != null && !property2.equals("")) {
                return property2;
            }
            if (z) {
                try {
                    property = C10960hP.A02(str);
                    if (property.equals("")) {
                        String A022 = C10960hP.A02(AnonymousClass0WY.A0i("fb.e2e.", str));
                        if (!A022.equals("")) {
                            return A022;
                        }
                    }
                } catch (IllegalArgumentException unused) {
                }
            }
            return null;
        }
        return property;
    }

    public static C14600q0 A00() {
        JSONObject optJSONObject;
        if (!isRunningEndToEndTest() || A09 == null || (optJSONObject = A09.optJSONObject("auth_data")) == null) {
            return null;
        }
        try {
            Log.w("EndToEnd-Test", AnonymousClass002.A0M(optJSONObject, "Using auth data: ", AnonymousClass001.A0m()));
            return new C14600q0(optJSONObject);
        } catch (JSONException e) {
            Log.e("EndToEnd-Test", "Failed to parse auth data", e);
            return null;
        }
    }

    public static Map A02() {
        JSONObject A19;
        if (A0C == null) {
            A0C = AnonymousClass001.A0w();
            try {
                String A012 = A01("sharedprefs", false, false);
                if (A012 != null && A012.length() > 0) {
                    A19 = new JSONObject(A012);
                } else if (A09.has("sharedprefs")) {
                    A19 = A09.getJSONObject("sharedprefs");
                } else {
                    A19 = AnonymousClass001.A19();
                }
                Iterator<String> keys = A19.keys();
                while (keys.hasNext()) {
                    String A0j = AnonymousClass001.A0j(keys);
                    A0C.put(A0j, A19.getJSONObject(A0j));
                }
                if (!A0C.isEmpty()) {
                    StringBuilder A0m = AnonymousClass001.A0m();
                    A0m.append("Use E2E shared preferences overrides: ");
                    Log.w("EndToEnd-Test", AnonymousClass001.A0d(A0C, A0m));
                }
            } catch (JSONException e) {
                throw AnonymousClass001.A0W("Malformed json for shared preferences", e);
            }
        }
        return A0C;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001e, code lost:
        if ("true".equals(java.lang.System.getProperty("fb.running_e2e_locally")) != false) goto L_0x0020;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized boolean A03() {
        /*
            java.lang.Class<com.facebook.endtoend.EndToEnd> r3 = com.facebook.endtoend.EndToEnd.class
            monitor-enter(r3)
            boolean r0 = A05     // Catch:{ all -> 0x0033 }
            if (r0 != 0) goto L_0x002f
            java.lang.String r2 = "fb.running_e2e_locally"
            java.lang.String r0 = X.C10960hP.A02(r2)     // Catch:{ all -> 0x0033 }
            java.lang.String r1 = "true"
            boolean r0 = r1.equals(r0)     // Catch:{ all -> 0x0033 }
            if (r0 != 0) goto L_0x0020
            java.lang.String r0 = java.lang.System.getProperty(r2)     // Catch:{ all -> 0x0033 }
            boolean r1 = r1.equals(r0)     // Catch:{ all -> 0x0033 }
            r0 = 0
            if (r1 == 0) goto L_0x0021
        L_0x0020:
            r0 = 1
        L_0x0021:
            A06 = r0     // Catch:{ all -> 0x0033 }
            if (r0 == 0) goto L_0x002c
            java.lang.String r1 = "EndToEnd-Test"
            java.lang.String r0 = "Is running E2E test locally"
            android.util.Log.w(r1, r0)     // Catch:{ all -> 0x0033 }
        L_0x002c:
            r0 = 1
            A05 = r0     // Catch:{ all -> 0x0033 }
        L_0x002f:
            boolean r0 = A06     // Catch:{ all -> 0x0033 }
            monitor-exit(r3)
            return r0
        L_0x0033:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0033 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.endtoend.EndToEnd.A03():boolean");
    }

    public static synchronized boolean A04() {
        boolean z;
        synchronized (EndToEnd.class) {
            if (!A02) {
                boolean equals = "true".equals(C10960hP.A02("fb.running_mobilelab"));
                A07 = equals;
                if (equals) {
                    Log.w("Mobilelab", "Is running Mobilelab test");
                }
                A02 = true;
            }
            z = A07;
        }
        return z;
    }

    public static synchronized boolean A05() {
        boolean z;
        synchronized (EndToEnd.class) {
            if (!A03) {
                boolean equals = "true".equals(C10960hP.A02("fb.running_sapienz"));
                A08 = equals;
                if (equals) {
                    Log.w("Sapienz", "Is running Sapienz test");
                }
                A03 = true;
            }
            z = A08;
        }
        return z;
    }

    public static boolean A06(String str, boolean z) {
        return "true".equals(A01(str, z, false));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0036, code lost:
        if ("true".equals(java.lang.System.getProperty("persist.fb.running_e2e")) != false) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x001b, code lost:
        if ("true".equals(java.lang.System.getProperty("fb.running_e2e")) != false) goto L_0x001d;
     */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean isRunningEndToEndTest() {
        /*
            boolean r0 = A0A
            if (r0 != 0) goto L_0x0048
            java.lang.String r1 = "fb.running_e2e"
            java.lang.String r0 = X.C10960hP.A02(r1)
            java.lang.String r3 = "true"
            boolean r0 = r3.equals(r0)
            if (r0 != 0) goto L_0x001d
            java.lang.String r0 = java.lang.System.getProperty(r1)
            boolean r1 = r3.equals(r0)
            r0 = 0
            if (r1 == 0) goto L_0x001e
        L_0x001d:
            r0 = 1
        L_0x001e:
            r2 = 1
            if (r0 != 0) goto L_0x0038
            java.lang.String r1 = "persist.fb.running_e2e"
            java.lang.String r0 = X.C10960hP.A02(r1)
            boolean r0 = r3.equals(r0)
            if (r0 != 0) goto L_0x0038
            java.lang.String r0 = java.lang.System.getProperty(r1)
            boolean r1 = r3.equals(r0)
            r0 = 0
            if (r1 == 0) goto L_0x0039
        L_0x0038:
            r0 = 1
        L_0x0039:
            A0B = r0
            boolean r0 = A0B
            if (r0 == 0) goto L_0x0046
            java.lang.String r1 = "EndToEnd-Test"
            java.lang.String r0 = "Is running E2E test"
            android.util.Log.w(r1, r0)
        L_0x0046:
            A0A = r2
        L_0x0048:
            boolean r0 = A0B
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.endtoend.EndToEnd.isRunningEndToEndTest():boolean");
    }

    static {
        try {
            C11320iB.A00();
        } catch (IllegalStateException unused) {
        }
    }
}
