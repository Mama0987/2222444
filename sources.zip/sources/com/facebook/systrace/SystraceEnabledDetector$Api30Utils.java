package com.facebook.systrace;

import android.os.Trace;

public class SystraceEnabledDetector$Api30Utils {
    public static boolean isTracing() {
        return Trace.isEnabled();
    }
}
