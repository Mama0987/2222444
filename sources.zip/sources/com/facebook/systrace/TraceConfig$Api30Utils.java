package com.facebook.systrace;

import X.AnonymousClass001;
import X.C10990hS;
import android.os.Trace;
import java.util.concurrent.atomic.AtomicBoolean;

public class TraceConfig$Api30Utils {
    public static AtomicBoolean isTracing = AnonymousClass001.A17();

    public static void updateTraceConfigIfNeeded() {
        boolean isEnabled = Trace.isEnabled();
        if (isTracing.compareAndSet(!isEnabled, isEnabled)) {
            C10990hS.A03(false, false);
        }
    }
}
