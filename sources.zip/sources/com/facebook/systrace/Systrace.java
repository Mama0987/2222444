package com.facebook.systrace;

import X.AnonymousClass002;
import X.C10760gy;
import X.C10810h5;
import X.C10850hB;
import X.C10980hR;
import X.C10990hS;
import X.C11240hz;
import X.C11500iX;
import X.C11520iZ;
import android.os.Build;
import android.os.Process;
import com.facebook.common.dextricks.OdexSchemeArtXdex;
import java.io.FileOutputStream;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class Systrace {
    public static long A00;
    public static final ThreadLocal A01 = new C11500iX();
    public static final AtomicInteger A02 = new AtomicInteger();
    public static final String[][] A03 = {new String[]{"com.facebook.common.fury.FBSystraceReqContextLifecycleCallbacks.onActivate", "com.facebook.common.fury.FBSystraceReqContextLifecycleCallbacks.onDeactivate"}, new String[]{"com.facebook.common.plugins.fblogging.FbPluginsLogger.pluginMarkerStart", "com.facebook.common.plugins.fblogging.FbPluginsLogger.pluginMarkerEnd"}, new String[]{"com.facebook.common.plugins.fblogging.FbPluginsLogger.onSocketGetPluginsStart", "com.facebook.common.plugins.fblogging.FbPluginsLogger.onSocketGetPluginsEnd"}};

    static {
        C10760gy r0 = C10990hS.A01;
        C10980hR.A00();
        C10990hS.A03(false, false);
        C11240hz r02 = C11240hz.$redex_init_class;
    }

    public static void A00() {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
    }

    public static void A01(long j) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeEndSection();
        } else {
            C10810h5.A00("E");
        }
    }

    public static void A02(long j, String str) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeBeginSection(str);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB r1 = new C10850hB('B');
        r1.A01(Process.myPid());
        r1.A03(str);
        C10810h5.A00(r1.toString());
    }

    public static void A03(long j, String str, int i) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeAsyncTraceBegin(str, i, 0);
        } else {
            C10810h5.A01(str, i, 0);
        }
    }

    public static void A05(long j, String str, int i) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeAsyncTraceEnd(str, i, 0);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 'F');
        AnonymousClass002.A0g(A002, (0 > 0 ? 1 : (0 == 0 ? 0 : -1)), 0);
        A002.A01(i);
        AnonymousClass002.A0h(A002);
    }

    public static void A08(long j, String str, int i, String str2) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (A0H(j)) {
            TraceDirect.asyncTraceStageBegin(str, i, 0, str2);
        }
    }

    public static void A09(long j, String str, int i, String str2) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (A0H(j)) {
            TraceDirect.asyncTraceRename(str, str2, i);
        }
    }

    public static void A0A(String str) {
        A00();
        if (!A0H(OdexSchemeArtXdex.STATE_PGO_ATTEMPTED)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeTraceInstant("", str, 't');
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 'I');
        StringBuilder sb = A002.A00;
        sb.append('|');
        sb.append('t');
        A002.A03("");
        AnonymousClass002.A0h(A002);
    }

    public static void A0B(String str, int i, long j) {
        A00();
        if (A0H(4)) {
            long A002 = C11520iZ.A00(j);
            if (TraceDirect.checkNative()) {
                TraceDirect.nativeAsyncTraceBegin(str, i, A002);
            } else {
                C10810h5.A01(str, i, A002);
            }
        }
    }

    public static void A0D(String str, int i, String str2) {
        A00();
        if (!A0H(64)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeTraceMetadata(str, str2, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 'M');
        A002.A01(i);
        A002.A03(str2);
        AnonymousClass002.A0h(A002);
    }

    public static void A0F(String str, String[] strArr, int i, long j) {
        if (Build.VERSION.SDK_INT >= 30) {
            TraceConfig$Api30Utils.updateTraceConfigIfNeeded();
        }
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeBeginSectionWithArgs(str, strArr, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB r4 = new C10850hB('B');
        r4.A01(Process.myPid());
        r4.A03(str);
        StringBuilder sb = r4.A00;
        sb.append('|');
        for (int i2 = 1; i2 < i; i2 += 2) {
            String str2 = strArr[i2 - 1];
            String str3 = strArr[i2];
            sb.append(str2);
            sb.append('=');
            sb.append(str3);
            if (i2 < i - 1) {
                sb.append(';');
            }
        }
        C10810h5.A00(r4.toString());
    }

    public static boolean A0H(long j) {
        if ((j & C10990hS.A02) == 0 && (A00 & j) == 0) {
            return false;
        }
        return true;
    }

    public static void A04(long j, String str, int i) {
        A00();
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeEndAsyncFlow(str, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 'f');
        A002.A01(i);
        AnonymousClass002.A0h(A002);
    }

    public static void A06(long j, String str, int i) {
        A00();
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeStartAsyncFlow(str, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 's');
        A002.A01(i);
        AnonymousClass002.A0h(A002);
    }

    public static void A07(long j, String str, int i) {
        A00();
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeTraceCounter(str, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A002 = C10850hB.A00(str, 'C');
        A002.A01(i);
        AnonymousClass002.A0h(A002);
    }

    public static void A0C(String str, int i, long j, long j2) {
        A00();
        if (A0H(j)) {
            long A002 = C11520iZ.A00(j2);
            if (TraceDirect.checkNative()) {
                TraceDirect.nativeAsyncTraceEnd(str, i, A002);
                return;
            }
            FileOutputStream fileOutputStream = C10810h5.A00;
            C10850hB A003 = C10850hB.A00(str, 'F');
            AnonymousClass002.A0g(A003, (A002 > 0 ? 1 : (A002 == 0 ? 0 : -1)), A002);
            A003.A01(i);
            AnonymousClass002.A0h(A003);
        }
    }

    public static void A0E(String str, String str2, int i, long j, long j2) {
        A00();
        if (A0H(j)) {
            TraceDirect.asyncTraceStageBegin(str, i, C11520iZ.A00(j2), str2);
        }
    }

    public static void A0G(String[] strArr, int i, long j) {
        A00();
        if (!A0H(j)) {
            return;
        }
        if (TraceDirect.checkNative()) {
            TraceDirect.nativeEndSectionWithArgs(strArr, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB r4 = new C10850hB('E');
        StringBuilder sb = r4.A00;
        sb.append('|');
        sb.append('|');
        sb.append('|');
        for (int i2 = 1; i2 < i; i2 += 2) {
            String str = strArr[i2 - 1];
            String str2 = strArr[i2];
            sb.append(str);
            sb.append('=');
            sb.append(str2);
            if (i2 < i - 1) {
                sb.append(';');
            }
        }
        AnonymousClass002.A0h(r4);
    }
}
