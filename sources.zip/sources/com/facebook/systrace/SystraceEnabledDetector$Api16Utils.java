package com.facebook.systrace;

import X.C10930hK;

public class SystraceEnabledDetector$Api16Utils {
    public static boolean isTracing() {
        if (C10930hK.A00 == null) {
            C10930hK.A00();
        }
        return C10930hK.A00.booleanValue();
    }
}
