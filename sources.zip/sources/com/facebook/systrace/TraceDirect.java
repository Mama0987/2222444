package com.facebook.systrace;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass102;
import X.C10760gy;
import X.C10810h5;
import X.C10850hB;
import X.C10960hP;
import X.C10990hS;
import X.C16810u4;
import android.util.Log;
import com.facebook.common.util.TriState;
import java.io.FileOutputStream;

public class TraceDirect {
    public static final boolean sForceJavaImpl = "true".equals(C10960hP.A02("debug.fbsystrace.force_java"));
    public static volatile TriState sNativeAvailable = TriState.UNSET;
    public static volatile int sPrevSoLoaderSourcesVersion = -1;
    public static final boolean sTraceLoad = "true".equals(C10960hP.A02("debug.fbsystrace.trace_load"));

    public static native void nativeAsyncTraceBegin(String str, int i, long j);

    public static native void nativeAsyncTraceCancel(String str, int i);

    public static native void nativeAsyncTraceEnd(String str, int i, long j);

    public static native void nativeAsyncTraceRename(String str, String str2, int i);

    public static native void nativeAsyncTraceStageBegin(String str, int i, long j, String str2);

    public static native void nativeBeginSection(String str);

    public static native void nativeBeginSectionWithArgs(String str, String[] strArr, int i);

    public static native void nativeEndAsyncFlow(String str, int i);

    public static native void nativeEndSection();

    public static native void nativeEndSectionWithArgs(String[] strArr, int i);

    public static native void nativeSetDefaultTags(long j);

    public static native void nativeSetEnabledTags(long j);

    public static native void nativeStartAsyncFlow(String str, int i);

    public static native void nativeStepAsyncFlow(String str, int i);

    public static native void nativeTraceCounter(String str, int i);

    public static native void nativeTraceInstant(String str, String str2, char c);

    public static native void nativeTraceMetadata(String str, String str2, int i);

    public static boolean checkNative() {
        int i;
        AnonymousClass102 r0;
        if (sNativeAvailable == TriState.UNSET) {
            if (sForceJavaImpl) {
                sNativeAvailable = TriState.NO;
            } else {
                if (C16810u4.A01()) {
                    synchronized (C16810u4.class) {
                        r0 = C16810u4.A00;
                        if (r0 == null) {
                            throw AnonymousClass001.A0P("NativeLoader has not been initialized.  To use standard native library loading, call NativeLoader.init(new SystemDelegate()).");
                        }
                    }
                    i = r0.BkO();
                } else {
                    i = -1;
                }
                if (i != sPrevSoLoaderSourcesVersion) {
                    sPrevSoLoaderSourcesVersion = i;
                    try {
                        C16810u4.loadLibrary("fbsystrace");
                        C10760gy r02 = C10990hS.A01;
                        nativeSetEnabledTags(C10960hP.A00("debug.fbsystrace.tags", 0));
                        nativeBeginSection("fbsystrace.so loaded");
                        nativeEndSection();
                        sNativeAvailable = TriState.YES;
                    } catch (UnsatisfiedLinkError unused) {
                        sNativeAvailable = TriState.NO;
                        Log.w("TraceDirect", "fbsystrace.so could not be loaded - switching to Java implementation.");
                    }
                }
            }
        }
        if (sNativeAvailable != TriState.YES) {
            return false;
        }
        return true;
    }

    public static void asyncTraceRename(String str, String str2, int i) {
        if (checkNative()) {
            nativeAsyncTraceRename(str, str2, i);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A00 = C10850hB.A00(str, 'F');
        A00.A02("<M>");
        A00.A01(i);
        A00.A03(str2);
        AnonymousClass002.A0h(A00);
    }

    public static void asyncTraceStageBegin(String str, int i, long j, String str2) {
        if (checkNative()) {
            nativeAsyncTraceStageBegin(str, i, j, str2);
            return;
        }
        FileOutputStream fileOutputStream = C10810h5.A00;
        C10850hB A00 = C10850hB.A00(str, 'T');
        AnonymousClass002.A0g(A00, (j > 0 ? 1 : (j == 0 ? 0 : -1)), j);
        A00.A01(i);
        A00.A03(str2);
        AnonymousClass002.A0h(A00);
    }
}
