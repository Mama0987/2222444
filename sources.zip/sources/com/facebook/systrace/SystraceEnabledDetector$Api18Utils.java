package com.facebook.systrace;

public class SystraceEnabledDetector$Api18Utils {
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0024, code lost:
        if ((r1 instanceof java.lang.Error) == false) goto L_0x0029;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean isTracing() {
        /*
            long r4 = X.C10980hR.A00
            boolean r0 = X.C10980hR.A03
            r3 = 0
            if (r0 == 0) goto L_0x003a
            java.lang.reflect.Method r1 = X.C10980hR.A01
            if (r1 == 0) goto L_0x0032
            java.lang.Long r0 = java.lang.Long.valueOf(r4)
            java.lang.Object[] r0 = new java.lang.Object[]{r0}
            r2 = 0
            java.lang.Object r2 = r1.invoke(r2, r0)     // Catch:{ IllegalAccessException -> 0x0027, InvocationTargetException -> 0x0019 }
            goto L_0x0029
        L_0x0019:
            r0 = move-exception
            java.lang.Throwable r1 = r0.getTargetException()
            boolean r0 = r1 instanceof java.lang.RuntimeException
            if (r0 != 0) goto L_0x0039
            boolean r0 = r1 instanceof java.lang.Error
            if (r0 != 0) goto L_0x0039
            goto L_0x0029
        L_0x0027:
            X.C10980hR.A03 = r3
        L_0x0029:
            java.lang.Boolean r2 = (java.lang.Boolean) r2
            if (r2 == 0) goto L_0x003a
            boolean r3 = r2.booleanValue()
            return r3
        L_0x0032:
            X.C18610xQ.A00(r1)
            X.0Vs r1 = X.C06300Vs.createAndThrow()
        L_0x0039:
            throw r1
        L_0x003a:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.systrace.SystraceEnabledDetector$Api18Utils.isTracing():boolean");
    }
}
