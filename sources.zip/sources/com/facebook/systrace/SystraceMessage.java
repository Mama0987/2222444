package com.facebook.systrace;

import X.AnonymousClass0OW;
import X.AnonymousClass0QH;
import X.AnonymousClass0QI;
import X.C11290i4;
import X.C11300i8;

public abstract class SystraceMessage {
    public static final AnonymousClass0QH A00 = new Object();
    public static final ThreadLocal A01 = new AnonymousClass0OW();
    public static final AnonymousClass0QI A02 = new Object();
    public static final AnonymousClass0QI A03 = new Object();

    public static AnonymousClass0QH A00(long j) {
        AnonymousClass0QI r2 = A03;
        if (!Systrace.A0H(j)) {
            return A00;
        }
        C11290i4 r5 = (C11290i4) A01.get();
        r5.A00 = j;
        r5.A02 = r2;
        r5.A03 = "";
        C11300i8 r4 = r5.A01;
        for (int i = 0; i < r4.A00; i++) {
            r4.A01[i] = null;
        }
        r4.A00 = 0;
        return r5;
    }

    public static AnonymousClass0QH A01(String str, long j) {
        AnonymousClass0QI r1 = A02;
        if (!Systrace.A0H(j)) {
            return A00;
        }
        C11290i4 r5 = (C11290i4) A01.get();
        r5.A00 = j;
        r5.A02 = r1;
        r5.A03 = str;
        C11300i8 r4 = r5.A01;
        for (int i = 0; i < r4.A00; i++) {
            r4.A01[i] = null;
        }
        r4.A00 = 0;
        return r5;
    }
}
