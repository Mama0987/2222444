package com.facebook.platform.common.provider;

import X.C10640fx;

public final class PlatformProviderBase extends C10640fx {
}
