package com.facebook.androidcompat;

import X.AnonymousClass0ZM;
import X.C15800sA;

public final class AndroidCompat$Api19Utils {
    public static final AndroidCompat$Api19Utils INSTANCE = new AndroidCompat$Api19Utils();

    public static final void addSuppressed(Throwable th, Throwable th2) {
        C15800sA.A0D(th, 0);
        AnonymousClass0ZM.A00(th, th2);
    }
}
