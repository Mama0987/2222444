package com.facebook.analytics.memory;

public final class MemProcWatermarkReader$Api21Utils {
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0023, code lost:
        if (r2 == null) goto L_0x002e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean canRead() {
        /*
            android.os.StrictMode$ThreadPolicy r4 = android.os.StrictMode.allowThreadDiskReads()
            r3 = 0
            r2 = 0
            java.lang.String r1 = "/proc/zoneinfo"
            int r0 = android.system.OsConstants.O_RDONLY     // Catch:{ ErrnoException | NullPointerException -> 0x0023, all -> 0x0013 }
            java.io.FileDescriptor r2 = android.system.Os.open(r1, r0, r3)     // Catch:{ ErrnoException | NullPointerException -> 0x0023, all -> 0x0013 }
            boolean r3 = r2.valid()     // Catch:{ ErrnoException | NullPointerException -> 0x0023, all -> 0x0013 }
            goto L_0x0025
        L_0x0013:
            r1 = move-exception
            if (r2 == 0) goto L_0x001f
            boolean r0 = r2.valid()
            if (r0 == 0) goto L_0x001f
            android.system.Os.close(r2)     // Catch:{ ErrnoException -> 0x001f }
        L_0x001f:
            android.os.StrictMode.setThreadPolicy(r4)
            throw r1
        L_0x0023:
            if (r2 == 0) goto L_0x002e
        L_0x0025:
            boolean r0 = r2.valid()
            if (r0 == 0) goto L_0x002e
            android.system.Os.close(r2)     // Catch:{ ErrnoException -> 0x002e }
        L_0x002e:
            android.os.StrictMode.setThreadPolicy(r4)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.analytics.memory.MemProcWatermarkReader$Api21Utils.canRead():boolean");
    }
}
