package com.facebook.analytics.memory;

import X.C14270pR;
import X.C18440x7;

public final class AddressSpace {
    public static final AddressSpace INSTANCE = new Object();
    public static volatile boolean initialized;

    public static final native int nativeGetLargestAddressSpaceChunkKb();

    public static final int getLargestChunkKb() {
        try {
            if (initialized) {
                return nativeGetLargestAddressSpaceChunkKb();
            }
            if (!C18440x7.A08()) {
                return -1;
            }
            C18440x7.loadLibrary("addressspace");
            initialized = true;
            return nativeGetLargestAddressSpaceChunkKb();
        } catch (UnsatisfiedLinkError e) {
            C14270pR.A0I("AddressSpace", "Error querying address space", e);
            return -1;
        }
    }
}
