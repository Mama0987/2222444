package com.facebook.analytics.appstatelogger.foregroundstate;

public final class EntityAppState$ForegroundInit {
    public boolean A00 = false;

    public final String toString() {
        if (this.A00) {
            return "ForegroundInitPeeked";
        }
        return "ForegroundInit";
    }
}
