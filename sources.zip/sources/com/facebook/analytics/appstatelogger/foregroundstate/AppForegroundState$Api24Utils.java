package com.facebook.analytics.appstatelogger.foregroundstate;

import android.app.Activity;

public class AppForegroundState$Api24Utils {
    public static boolean isInMultiWindowMode(Activity activity) {
        return activity.isInMultiWindowMode();
    }

    public static boolean isInMultiWindowOrPipMode(Activity activity) {
        if (isInMultiWindowMode(activity) || isInPictureInPictureMode(activity)) {
            return true;
        }
        return false;
    }

    public static boolean isInPictureInPictureMode(Activity activity) {
        return activity.isInPictureInPictureMode();
    }
}
