package com.facebook.analytics.appstatelogger;

import android.os.StatFs;

public class DiskSpaceUtil$Api18Utils {
    public static long getAvailableBytes(StatFs statFs) {
        return statFs.getAvailableBytes();
    }

    public static long getTotalBytes(StatFs statFs) {
        return statFs.getTotalBytes();
    }
}
