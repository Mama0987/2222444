package com.facebook.reliability.ourprocsinfo;

public class OurProcsInfo$ProcessInfo {
    public String mName;
    public int mPid;
}
