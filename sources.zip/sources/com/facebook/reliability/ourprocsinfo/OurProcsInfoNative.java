package com.facebook.reliability.ourprocsinfo;

import X.AnonymousClass0T4;
import X.C18440x7;

public final class OurProcsInfoNative {
    public static final AnonymousClass0T4 Companion = new Object();

    public static final native OurProcsInfo$ProcessInfo[] getOurProcessInfo(String str);

    /* JADX WARNING: type inference failed for: r0v0, types: [X.0T4, java.lang.Object] */
    static {
        C18440x7.loadLibrary("ourprocsinfo");
    }
}
