package com.facebook.secure.context;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

public class ScopedIntentLauncher$Api16Utils {
    public static boolean startActivityIfNeeded(Activity activity, Intent intent, int i, Bundle bundle) {
        return activity.startActivityIfNeeded(intent, i, bundle);
    }

    public static void startActivityForResult(Fragment fragment, Intent intent, int i, Bundle bundle) {
        fragment.startActivityForResult(intent, i, bundle);
    }
}
