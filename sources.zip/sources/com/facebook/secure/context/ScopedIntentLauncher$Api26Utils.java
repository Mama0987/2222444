package com.facebook.secure.context;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class ScopedIntentLauncher$Api26Utils {
    public static ComponentName startForegroundService(Context context, Intent intent) {
        return context.startForegroundService(intent);
    }
}
