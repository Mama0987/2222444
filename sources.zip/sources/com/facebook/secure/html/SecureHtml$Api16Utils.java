package com.facebook.secure.html;

import android.text.Html;

public class SecureHtml$Api16Utils {
    public static String escapeHtml(String str) {
        return Html.escapeHtml(str);
    }
}
