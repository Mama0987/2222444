package com.facebook.secure.fileprovider;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass108;
import X.AnonymousClass109;
import X.AnonymousClass11P;
import X.C03110Fq;
import X.C10640fx;
import X.C11870jQ;
import X.C14400pg;
import X.C14540pu;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ConditionVariable;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

public class SecureFileProvider extends C10640fx {
    public C14400pg A00;
    public final ConditionVariable A01 = new ConditionVariable();

    public class Impl extends C03110Fq {
        public static final AnonymousClass11P A01 = new Object();
        public static final String[] A02 = {"_display_name", "_size"};
        public final SecureFileProvider A00;

        public final int A0D(Uri uri, ContentValues contentValues, String str, String[] strArr) {
            throw AnonymousClass001.A0r("No external updates");
        }

        public final Uri A0K(Uri uri, ContentValues contentValues) {
            throw AnonymousClass001.A0r("No external inserts");
        }

        public Impl(C10640fx r1) {
            super(r1);
            this.A00 = (SecureFileProvider) r1;
        }

        public final int A0E(Uri uri, String str, String[] strArr) {
            C14540pu A002 = C14540pu.A00(uri);
            C10640fx r1 = this.A00;
            if (A002.A04(r1.getContext()).booleanValue()) {
                try {
                    File A022 = A002.A02(r1.getContext(), uri);
                    SecureFileProvider secureFileProvider = this.A00;
                    secureFileProvider.A01.block();
                    if (C14400pg.A03(secureFileProvider.A00, A022) == null || !A022.delete()) {
                        return 0;
                    }
                    return 1;
                } catch (IOException unused) {
                }
            } else {
                throw AnonymousClass001.A0Y("Access denied");
            }
        }

        public final Cursor A0J(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
            int i;
            Object A0R;
            C14540pu A002 = C14540pu.A00(uri);
            C10640fx r1 = this.A00;
            if (A002.A04(r1.getContext()).booleanValue()) {
                if (strArr == null) {
                    strArr = A02;
                }
                try {
                    File A022 = A002.A02(r1.getContext(), uri);
                    String[] strArr3 = new String[r8];
                    Object[] objArr = new Object[r8];
                    int i2 = 0;
                    for (String str3 : strArr) {
                        if ("_display_name".equals(str3)) {
                            strArr3[i2] = "_display_name";
                            i = i2 + 1;
                            A0R = A022.getName();
                        } else if ("_size".equals(str3)) {
                            strArr3[i2] = "_size";
                            i = i2 + 1;
                            A0R = AnonymousClass001.A0R(A022);
                        }
                        objArr[i2] = A0R;
                        i2 = i;
                    }
                    Object[] copyOf = Arrays.copyOf(objArr, i2);
                    MatrixCursor matrixCursor = new MatrixCursor((String[]) Arrays.copyOf(strArr3, i2), 0);
                    if (i2 > 0) {
                        matrixCursor.addRow(copyOf);
                    }
                    return matrixCursor;
                } catch (IOException e) {
                    A01.Dm9("SecureFileProvider.Impl", "Query incurred an IOException", e);
                    return new MatrixCursor(new String[strArr.length], 0);
                }
            } else {
                throw AnonymousClass001.A0Y("Access denied");
            }
        }

        public final ParcelFileDescriptor A0M(Uri uri, String str) {
            int i;
            C14540pu A002 = C14540pu.A00(uri);
            C10640fx r1 = this.A00;
            if (A002.A04(r1.getContext()).booleanValue()) {
                try {
                    File A022 = A002.A02(r1.getContext(), uri);
                    if ("r".equals(str)) {
                        i = 268435456;
                    } else if ("w".equals(str) || "wt".equals(str)) {
                        i = 738197504;
                    } else if ("wa".equals(str)) {
                        i = 704643072;
                    } else if ("rw".equals(str)) {
                        i = 939524096;
                    } else if ("rwt".equals(str)) {
                        i = 1006632960;
                    } else {
                        throw AnonymousClass0WY.A04("Invalid mode: ", str);
                    }
                    return ParcelFileDescriptor.open(A022, i);
                } catch (FileNotFoundException e) {
                    throw e;
                } catch (IOException e2) {
                    A01.Dm9("SecureFileProvider.Impl", "IOException during file opening.", e2);
                    throw new FileNotFoundException("Could not open file");
                }
            } else {
                throw AnonymousClass001.A0Y("Access denied");
            }
        }

        public final String A0N(Uri uri) {
            String A0Z;
            String mimeTypeFromExtension;
            C14540pu A002 = C14540pu.A00(uri);
            C10640fx r1 = this.A00;
            if (A002.A04(r1.getContext()).booleanValue()) {
                try {
                    File A022 = A002.A02(r1.getContext(), uri);
                    int lastIndexOf = A022.getName().lastIndexOf(46);
                    if (lastIndexOf == -1) {
                        A0Z = "";
                    } else {
                        A0Z = AnonymousClass001.A0Z(lastIndexOf, A022.getName());
                    }
                    if (A0Z.length() <= 0 || (mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(A0Z)) == null) {
                        return "application/octet-stream";
                    }
                    return mimeTypeFromExtension;
                } catch (IOException e) {
                    A01.Dm9("SecureFileProvider.Impl", "Could not resolve file type.", e);
                    return "";
                }
            } else {
                throw AnonymousClass001.A0Y("Access denied");
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [X.11P, java.lang.Object] */
    @Deprecated(since = "Use SecureFile insteadhttps://www.internalfb.com/intern/wiki/Mobile-secure-framework/sending-files/")
    public static Uri A01(Context context, File file) {
        HashMap hashMap = C14400pg.A06;
        return C14400pg.A01(context, (ProviderInfo) null, new Object(), 0, 0).A05(file);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [X.11P, java.lang.Object] */
    public static boolean A02(Context context, Uri uri) {
        HashMap hashMap = C14400pg.A06;
        C14400pg A012 = C14400pg.A01(context, (ProviderInfo) null, new Object(), 0, 0);
        try {
            if (A012.A02.equals(uri.getAuthority()) && uri.getScheme().equals("content")) {
                A012.A06(uri, false);
                return true;
            }
        } catch (Exception unused) {
        }
        return false;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [X.11P, java.lang.Object] */
    public final void A0G(Context context, ProviderInfo providerInfo) {
        C11870jQ.A00();
        AnonymousClass109 r2 = AnonymousClass108.A00;
        r2.markerStart(115417244);
        if (!providerInfo.exported) {
            HashMap hashMap = C14400pg.A06;
            this.A00 = C14400pg.A01(context, providerInfo, new Object(), 115417244, 0);
            this.A01.open();
            C11870jQ.A00();
            r2.markerEnd(115417244, 2);
            return;
        }
        C11870jQ.A00();
        r2.markerEnd(115417244, 3);
        throw AnonymousClass001.A0Y("Provider must not be exported.");
    }
}
