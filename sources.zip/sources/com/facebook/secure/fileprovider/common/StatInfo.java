package com.facebook.secure.fileprovider.common;

import X.AnonymousClass001;
import X.AnonymousClass002;

public class StatInfo {
    public long device;
    public long inode;
    public int ownerGid;
    public int ownerUid;

    public static StatInfo newInstance(int i, int i2, long j, long j2) {
        return new StatInfo(i, i2, j, j2);
    }

    public StatInfo(int i, int i2, long j, long j2) {
        this.ownerUid = i;
        this.ownerGid = i2;
        this.inode = j;
        this.device = j2;
    }

    public String toString() {
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("Stat{ownerUid=");
        A0m.append(this.ownerUid);
        A0m.append(",ownerGid=");
        A0m.append(this.ownerGid);
        A0m.append(",inode=");
        A0m.append(this.inode);
        A0m.append(",device=");
        A0m.append(this.device);
        return AnonymousClass002.A0Q(A0m);
    }
}
