package com.facebook.secure.fileprovider.common;

import X.C18440x7;
import android.os.ParcelFileDescriptor;

public class FileStatHelper {
    public static native StatInfo statOpenFile(int i);

    static {
        C18440x7.loadLibrary("filestathelper");
    }

    public static int A00(ParcelFileDescriptor parcelFileDescriptor) {
        return parcelFileDescriptor.getFd();
    }

    public FileStatHelper(int i) {
    }

    public FileStatHelper() {
    }
}
