package com.facebook.secure.content.delegate;

import X.AnonymousClass0OO;
import X.C06130Uw;
import X.C10640fx;
import X.C15800sA;

public abstract class FbPermissionContentProviderDelegate extends TrustedCallerContentProviderDelegate {
    public final C06130Uw A00;
    public final C06130Uw A01;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FbPermissionContentProviderDelegate(C10640fx r3) {
        super(r3);
        C15800sA.A0D(r3, 1);
        String A0j = A0j();
        this.A00 = new AnonymousClass0OO(A0j);
        this.A01 = new AnonymousClass0OO(A0j);
    }

    public abstract String A0j();

    public final C06130Uw A0h() {
        return this.A00;
    }

    public final C06130Uw A0i() {
        return this.A01;
    }
}
