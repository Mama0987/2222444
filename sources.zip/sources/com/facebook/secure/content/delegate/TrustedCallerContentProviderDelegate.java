package com.facebook.secure.content.delegate;

import X.C03910Jg;
import X.C06130Uw;
import X.C10640fx;
import X.C15800sA;
import com.facebook.secure.content.base.AbstractContentProviderDelegate;

public abstract class TrustedCallerContentProviderDelegate extends AbstractContentProviderDelegate {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TrustedCallerContentProviderDelegate(C10640fx r2) {
        super(r2);
        C15800sA.A0D(r2, 1);
    }

    public abstract C06130Uw A0h();

    public abstract C06130Uw A0i();

    public final boolean A0f() {
        return C03910Jg.A00(this.A00.getContext(), A0h());
    }

    public final boolean A0g() {
        return C03910Jg.A00(this.A00.getContext(), A0i());
    }
}
