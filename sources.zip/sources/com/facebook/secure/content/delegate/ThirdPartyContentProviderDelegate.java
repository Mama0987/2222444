package com.facebook.secure.content.delegate;

import X.C03880Jd;
import X.C06130Uw;
import X.C10640fx;
import X.C15800sA;

public abstract class ThirdPartyContentProviderDelegate extends TrustedCallerContentProviderDelegate {
    public final C06130Uw A00;
    public final C06130Uw A01;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ThirdPartyContentProviderDelegate(C10640fx r2) {
        super(r2);
        C15800sA.A0D(r2, 1);
        C03880Jd r0 = C03880Jd.A00;
        this.A00 = r0;
        this.A01 = r0;
    }

    public final C06130Uw A0h() {
        return this.A00;
    }

    public final C06130Uw A0i() {
        return this.A01;
    }
}
