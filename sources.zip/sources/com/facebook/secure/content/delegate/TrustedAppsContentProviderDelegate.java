package com.facebook.secure.content.delegate;

import X.C06300Vs;
import X.C10640fx;

public abstract class TrustedAppsContentProviderDelegate extends TrustedCallerContentProviderDelegate {
    public TrustedAppsContentProviderDelegate(C10640fx r2) {
        throw C06300Vs.createAndThrow();
    }
}
