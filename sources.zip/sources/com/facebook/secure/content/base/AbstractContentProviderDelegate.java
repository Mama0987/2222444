package com.facebook.secure.content.base;

import X.AnonymousClass001;
import X.AnonymousClass07m;
import X.AnonymousClass0WY;
import X.C004802v;
import X.C03110Fq;
import X.C03890Je;
import X.C03900Jf;
import X.C03940Jj;
import X.C08310bp;
import X.C10640fx;
import X.C15800sA;
import X.C198111f;
import android.content.ContentProviderResult;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import com.facebook.common.stringformat.StringFormatUtil;
import com.facebook.systrace.Systrace;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class AbstractContentProviderDelegate extends C03110Fq {
    public final AtomicBoolean A00 = new AtomicBoolean();

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AbstractContentProviderDelegate(C10640fx r2) {
        super(r2);
        C15800sA.A0D(r2, 1);
        A03("onCreate");
        A02();
    }

    public final int A0D(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        C15800sA.A0D(uri, 0);
        A03("update");
        A04("update");
        try {
            A01();
            return A0V(uri, contentValues, str, strArr);
        } finally {
            A02();
        }
    }

    public final int A0E(Uri uri, String str, String[] strArr) {
        C15800sA.A0D(uri, 0);
        A03("delete");
        A04("delete");
        try {
            A01();
            return A0W(uri, str, strArr);
        } finally {
            A02();
        }
    }

    public final Cursor A0I(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        C15800sA.A0D(uri, 0);
        A03("query");
        A04("query");
        try {
            A00();
            return A0Z(uri, strArr, str, strArr2, str2);
        } finally {
            A02();
        }
    }

    public final Cursor A0J(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        C15800sA.A0D(uri, 0);
        A03("query");
        A04("query");
        try {
            A00();
            return A0Z(uri, strArr, str, strArr2, str2);
        } finally {
            A02();
        }
    }

    public final Uri A0K(Uri uri, ContentValues contentValues) {
        C15800sA.A0D(uri, 0);
        A03("insert");
        A04("insert");
        try {
            A01();
            return A0a(uri, contentValues);
        } finally {
            A02();
        }
    }

    public final Bundle A0L(String str, String str2, Bundle bundle) {
        C15800sA.A0D(str, 0);
        A03("call");
        A04("call");
        try {
            A01();
            return A0b(bundle, str);
        } finally {
            A02();
        }
    }

    public final String A0N(Uri uri) {
        C15800sA.A0D(uri, 0);
        A03("getType");
        A04("getType");
        try {
            A00();
            return A0c(uri);
        } finally {
            A02();
        }
    }

    public final void A0R(Configuration configuration) {
        C15800sA.A0D(configuration, 0);
        A03("onConfigurationChanged");
        try {
            if (this.A00.get()) {
                super.A0R(configuration);
            }
        } finally {
            A02();
        }
    }

    public final ContentProviderResult[] A0T(ArrayList arrayList) {
        C15800sA.A0D(arrayList, 0);
        A03("applyBatch");
        A04("applyBatch");
        try {
            A01();
            ContentProviderResult[] A0E = this.A00.A0E(arrayList);
            C15800sA.A09(A0E);
            return A0E;
        } finally {
            A02();
        }
    }

    public abstract int A0V(Uri uri, ContentValues contentValues, String str, String[] strArr);

    public abstract int A0W(Uri uri, String str, String[] strArr);

    public abstract Cursor A0Z(Uri uri, String[] strArr, String str, String[] strArr2, String str2);

    public abstract Uri A0a(Uri uri, ContentValues contentValues);

    public abstract String A0c(Uri uri);

    public abstract boolean A0g();

    public static final void A02() {
        C004802v.A01(512, -623279417);
    }

    private final void A03(String str) {
        if (Systrace.A0H(512)) {
            C004802v.A02(512, AnonymousClass0WY.A0l(getClass().getSimpleName(), str, '.'), 1009194527);
        }
    }

    private final void A04(String str) {
        C03900Jf r3 = C03890Je.A00;
        if (!r3.A00.isEmpty()) {
            Context context = this.A00.getContext();
            String formatStrLocaleSafe = StringFormatUtil.formatStrLocaleSafe("%s/%s", context.getPackageName(), AnonymousClass001.A0c(this));
            C03940Jj r0 = null;
            try {
                r0 = C03940Jj.fromUidAllPackageNames(context, C08310bp.A00().A00, (String) null);
            } catch (SecurityException unused) {
            }
            String str2 = str;
            if (r0 != null) {
                String A03 = r0.A03();
                C15800sA.A09(A03);
                r3.A01(context, formatStrLocaleSafe, str2, r0.toString(), A03);
                return;
            }
            r3.A00(context, formatStrLocaleSafe, str);
        }
    }

    public final void A0O() {
        A03("onLowMemory");
        try {
            if (this.A00.get()) {
                super.A0O();
            }
        } finally {
            A02();
        }
    }

    public final void A0P() {
        A03("shutdown");
        A02();
    }

    public final void A0Q(int i) {
        A03("onTrimMemory");
        try {
            if (this.A00.get()) {
                super.A0Q(i);
            }
        } finally {
            A02();
        }
    }

    public final boolean A0S() {
        A03("isTemporary");
        try {
            A00();
            return this.A00.A0D();
        } finally {
            A02();
        }
    }

    public int A0X(Uri uri, ContentValues[] contentValuesArr) {
        return this.A00.A03(uri, contentValuesArr);
    }

    public final void A0e() {
        AtomicBoolean atomicBoolean = this.A00;
        synchronized (atomicBoolean) {
            if (!atomicBoolean.get()) {
                A0d();
                atomicBoolean.set(true);
            }
        }
    }

    private final void A00() {
        A0e();
        if (Binder.getCallingUid() != Process.myUid() || Binder.getCallingPid() != Process.myPid()) {
            Set A002 = AnonymousClass07m.A00().A01.A00();
            if (!(A002 instanceof Collection) || !A002.isEmpty()) {
                Iterator it = A002.iterator();
                while (it.hasNext()) {
                    String A0j = AnonymousClass001.A0j(it);
                    String A0c = AnonymousClass001.A0c(this);
                    C15800sA.A09(A0c);
                    if (C198111f.A0Y(A0c, A0j, false)) {
                        throw AnonymousClass0WY.A0B(this.A00, "Content Provider blocked by kill switch for ", A0c);
                    }
                }
            }
            if (!A0f()) {
                throw AnonymousClass0WY.A0B(this.A00, "Component access not allowed for ", AnonymousClass001.A0c(this));
            }
        }
    }

    private final void A01() {
        A0e();
        if (Binder.getCallingUid() != Process.myUid() || Binder.getCallingPid() != Process.myPid()) {
            Set A002 = AnonymousClass07m.A00().A01.A00();
            if (!(A002 instanceof Collection) || !A002.isEmpty()) {
                Iterator it = A002.iterator();
                while (it.hasNext()) {
                    String A0j = AnonymousClass001.A0j(it);
                    String A0c = AnonymousClass001.A0c(this);
                    C15800sA.A09(A0c);
                    if (C198111f.A0Y(A0c, A0j, false)) {
                        throw AnonymousClass0WY.A0B(this.A00, "Content Provider blocked by kill switch for ", A0c);
                    }
                }
            }
            if (!A0g()) {
                throw AnonymousClass0WY.A0B(this.A00, "Component access not allowed for ", AnonymousClass001.A0c(this));
            }
        }
    }

    public final int A0F(Uri uri, ContentValues[] contentValuesArr) {
        C15800sA.A0F(uri, contentValuesArr);
        A03("bulkInsert");
        A04("bulkInsert");
        try {
            A01();
            return A0X(uri, contentValuesArr);
        } finally {
            A02();
        }
    }

    public final AssetFileDescriptor A0G(Uri uri, String str) {
        C15800sA.A0F(uri, str);
        A03("openAssetFile");
        A04("openAssetFile");
        try {
            if (C198111f.A0Y(str, "w", false)) {
                A01();
            } else {
                A00();
            }
            return this.A00.A04(uri, str);
        } finally {
            A02();
        }
    }

    public final AssetFileDescriptor A0H(Uri uri, String str, Bundle bundle) {
        C15800sA.A0F(uri, str);
        A03("openTypedAssetFile");
        A04("openTypedAssetFile");
        try {
            A00();
            return A0Y(uri, str, bundle);
        } finally {
            A02();
        }
    }

    public final ParcelFileDescriptor A0M(Uri uri, String str) {
        C15800sA.A0F(uri, str);
        A03("openFile");
        A04("openFile");
        try {
            if (C198111f.A0Y(str, "w", false)) {
                A01();
            } else {
                A00();
            }
            return this.A00.A07(uri, str);
        } finally {
            A02();
        }
    }

    public final String[] A0U(Uri uri, String str) {
        C15800sA.A0F(uri, str);
        A03("getStreamTypes");
        A04("getStreamTypes");
        try {
            A00();
            return null;
        } finally {
            A02();
        }
    }

    public AssetFileDescriptor A0Y(Uri uri, String str, Bundle bundle) {
        return super.A0H(uri, str, bundle);
    }

    public void A0d() {
    }

    public boolean A0f() {
        return A0g();
    }

    public Bundle A0b(Bundle bundle, String str) {
        return null;
    }
}
