package com.facebook.secure.intentparser;

import android.content.ClipData;
import android.content.Intent;

public class IntentParser$Api16IUtils {
    public static ClipData getClipData(Intent intent) {
        return intent.getClipData();
    }

    public static void setClipData(Intent intent, ClipData clipData) {
        intent.setClipData(clipData);
    }
}
