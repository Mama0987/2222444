package com.facebook.secure.intent;

public class AccessibleByAnyAppIntentScope$Api23Utils {
    public static int getProtectionFlagPrivileged() {
        return 16;
    }
}
