package com.facebook.secure.intent;

public class FamilyAccessibleByAnyAppIntentScope$Api23Utils {
    public static int getProtectionFlagPrivileged() {
        return 16;
    }
}
