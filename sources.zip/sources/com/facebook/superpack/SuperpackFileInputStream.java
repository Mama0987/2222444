package com.facebook.superpack;

import X.AnonymousClass001;
import X.AnonymousClass0ZM;
import X.C14270pR;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class SuperpackFileInputStream extends InputStream {
    public int A00;
    public int A01;
    public int A02;
    public Boolean A03;
    public byte[] A04;
    public final SuperpackFile A05;

    public final synchronized int available() {
        return this.A00 - this.A02;
    }

    public final synchronized void mark(int i) {
        this.A01 = this.A02;
    }

    public final int read(byte[] bArr) {
        return read(bArr, 0, bArr.length);
    }

    public final synchronized void reset() {
        this.A02 = this.A01;
    }

    public final synchronized long skip(long j) {
        if (j < 0) {
            return 0;
        }
        int i = this.A02;
        long j2 = (long) i;
        int i2 = this.A00;
        if (j2 + j > ((long) i2)) {
            j = (long) (i2 - i);
        }
        this.A02 = (int) (j2 + j);
        return j;
    }

    public static SuperpackFileInputStream createFromSingletonArchiveFile(File file, String str) {
        int i;
        String str2 = SuperpackArchive.TAG;
        if (str.equals("spo")) {
            i = Runtime.getRuntime().availableProcessors();
        } else {
            i = 1;
        }
        return createFromSingletonArchiveFile(file, str, i);
    }

    public static SuperpackFileInputStream createFromSingletonArchiveInputStream(InputStream inputStream, String str) {
        int i;
        String str2 = SuperpackArchive.TAG;
        if (str.equals("spo")) {
            i = Runtime.getRuntime().availableProcessors();
        } else {
            i = 1;
        }
        return createFromSingletonArchiveInputStream(inputStream, str, i);
    }

    public static int getDefaultThreadNum(String str) {
        String str2 = SuperpackArchive.TAG;
        if (str.equals("spo")) {
            return Runtime.getRuntime().availableProcessors();
        }
        return 1;
    }

    public final void close() {
        if (this.A03.booleanValue()) {
            this.A05.close();
        }
    }

    public SuperpackFileInputStream(SuperpackFile superpackFile, Boolean bool) {
        this(superpackFile);
        this.A03 = bool;
    }

    public static SuperpackFileInputStream A00(SuperpackArchive superpackArchive) {
        if (superpackArchive.hasNext()) {
            SuperpackFile next = superpackArchive.next();
            if (!superpackArchive.hasNext()) {
                return new SuperpackFileInputStream(next, AnonymousClass001.A0J());
            }
            throw new IllegalArgumentException();
        }
        throw new IllegalArgumentException();
    }

    public final boolean markSupported() {
        return true;
    }

    public SuperpackFileInputStream(SuperpackFile superpackFile) {
        int i;
        if (superpackFile != null) {
            this.A05 = superpackFile;
            this.A02 = 0;
            synchronized (superpackFile) {
                if (superpackFile.mPtr != 0) {
                    i = superpackFile.mLength;
                } else {
                    throw AnonymousClass001.A0N();
                }
            }
            this.A00 = i;
            this.A01 = 0;
            this.A04 = null;
            this.A03 = false;
            return;
        }
        throw AnonymousClass001.A0S();
    }

    public static SuperpackFileInputStream createFromSingletonArchiveFile(File file, String str, int i) {
        long j;
        SuperpackArchive superpackArchive;
        FileInputStream A0F;
        if (file != null) {
            String str2 = SuperpackArchive.TAG;
            if (!str.matches("spo")) {
                j = 0;
            } else {
                j = SuperpackArchive.getThreadNumOption(i);
            }
            try {
                superpackArchive = new SuperpackArchive(SuperpackArchive.readNative(file.getPath(), str, j), (String[]) null);
                try {
                    SuperpackFileInputStream A002 = A00(superpackArchive);
                    superpackArchive.close();
                    return A002;
                } catch (Throwable th) {
                    AnonymousClass0ZM.A00(th, th);
                    throw th;
                }
            } catch (RuntimeException e) {
                C14270pR.A0I("SuperpackArchive", "Failed to read superpack file, retrying.", e);
                A0F = AnonymousClass001.A0F(file);
                superpackArchive = SuperpackArchive.read(A0F, str);
                A0F.close();
            } catch (Throwable th2) {
                th = th2;
                A0F.close();
                throw th;
            }
        } else {
            throw AnonymousClass001.A0S();
        }
    }

    public static SuperpackFileInputStream createFromSingletonArchiveInputStream(InputStream inputStream, String str, int i) {
        if (inputStream != null) {
            SuperpackArchive read = SuperpackArchive.read(inputStream, str, i);
            try {
                SuperpackFileInputStream A002 = A00(read);
                read.close();
                return A002;
            } catch (Throwable th) {
                AnonymousClass0ZM.A00(th, th);
                throw th;
            }
        } else {
            throw AnonymousClass001.A0S();
        }
    }

    public final synchronized int read(byte[] bArr, int i, int i2) {
        Throwable th;
        Throwable th2;
        int i3 = i2;
        synchronized (this) {
            byte[] bArr2 = bArr;
            if (bArr != null) {
                int i4 = i;
                if (i >= 0 && i2 >= 0) {
                    int i5 = i2 + i;
                    int length = bArr.length;
                    if (i5 <= length) {
                        int i6 = this.A02;
                        int i7 = this.A00;
                        if (i6 == i7) {
                            return -1;
                        }
                        if (i2 + i6 > i7) {
                            i3 = i7 - i6;
                        }
                        SuperpackFile superpackFile = this.A05;
                        synchronized (superpackFile) {
                            try {
                                long j = superpackFile.mPtr;
                                if (j == 0) {
                                    th2 = AnonymousClass001.A0N();
                                } else if (i6 < 0 || i3 < 0) {
                                    th2 = new IndexOutOfBoundsException();
                                } else if (i + i3 > length) {
                                    th2 = new IndexOutOfBoundsException();
                                } else if (i6 + i3 <= superpackFile.mLength) {
                                    SuperpackFile.readBytesNative(j, i6, i3, bArr2, i4);
                                } else {
                                    th2 = new IndexOutOfBoundsException();
                                }
                                throw th2;
                            } catch (Throwable th3) {
                                th = th3;
                            }
                        }
                        this.A02 += i3;
                        return i3;
                    }
                }
                th = new IndexOutOfBoundsException();
            } else {
                th = AnonymousClass001.A0S();
            }
            throw th;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v4, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v11, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v12, resolved type: byte} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized int read() {
        /*
            r3 = this;
            monitor-enter(r3)
            byte[] r0 = r3.A04     // Catch:{ all -> 0x0026 }
            r2 = 1
            if (r0 != 0) goto L_0x000a
            byte[] r0 = new byte[r2]     // Catch:{ all -> 0x0026 }
            r3.A04 = r0     // Catch:{ all -> 0x0026 }
        L_0x000a:
            int r1 = r3.read(r0)     // Catch:{ all -> 0x0026 }
            r0 = -1
            if (r1 == r0) goto L_0x0024
            if (r1 != r2) goto L_0x001b
            byte[] r1 = r3.A04     // Catch:{ all -> 0x0026 }
            r0 = 0
            byte r0 = r1[r0]     // Catch:{ all -> 0x0026 }
            if (r0 >= 0) goto L_0x0024
            goto L_0x0022
        L_0x001b:
            java.lang.String r0 = "Unexpected number of bytes read"
            java.lang.IllegalStateException r0 = X.AnonymousClass001.A0P(r0)     // Catch:{ all -> 0x0026 }
            throw r0     // Catch:{ all -> 0x0026 }
        L_0x0022:
            int r0 = r0 + 256
        L_0x0024:
            monitor-exit(r3)
            return r0
        L_0x0026:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0026 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.superpack.SuperpackFileInputStream.read():int");
    }
}
