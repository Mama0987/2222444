package com.facebook.superpack;

public final class AssetDecompressionException extends Exception {
    public AssetDecompressionException(String str) {
        super(str);
    }
}
