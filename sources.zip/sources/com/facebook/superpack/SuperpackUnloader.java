package com.facebook.superpack;

import X.AnonymousClass001;
import X.AnonymousClass0VD;
import com.facebook.common.dextricks.DalvikInternals;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class SuperpackUnloader implements AnonymousClass0VD {
    public static final List A00 = Collections.synchronizedList(AnonymousClass001.A0t());
    public static final Set A01;
    public static final Set A02;

    public static native long getProcessMappings(String str);

    public static native void releaseProcessMappings(long j);

    public static native void unload(long j, String str);

    static {
        String[] strArr = new String[34];
        boolean A1W = AnonymousClass001.A1W(new String[]{"libbreakpad.so", "libliger.so", DalvikInternals.LIBCOLDSTART_BASE_NAME, "libdexload.so", "libreliabilitymerged.so", "libsigquit.so", "libappstatelogger2.so", "libnative_allocation_hooks_installer_jni.so", "libforker.so", "libgrimsey.so", "libfb_mboost.so", "libplthooks.so", "libfbandroid_native_cppdistract_cppdistract.so", "libbreakpad_extra.so", "libfbandroid_native_sigmuxutils_sigmuxutils.so", "libxplat_pvd_segmentation_model_holder_plc_pytorch_model_holdersAndroid.so", "libdistractutil.so", "libchipsetmerged.so", "libvmasaver.so", "libdalvikdistract.so", "libfbandroid_native_museum_museum.so", "libglog.so", "libpando-core.so", "libpando-engine.so", "libxplat_third-party_jsoncpp_jsoncppAndroid.so", "libxplat_mobilenetwork_fbdomainsAndroid.so", "libfmt.so"}, strArr);
        System.arraycopy(new String[]{"libthird-party_boost_boost_contextAndroid.so", "libthird-party_boost_boostAndroid.so", "liblinkerutils.so", "libmem_alloc_marker.so", "libfbunwindstack.so", "liblive-query-jni.so", "libaospbugfixmerged.so"}, A1W ? 1 : 0, strArr, 27, 7);
        A02 = AnonymousClass001.A0y(strArr);
        String[] strArr2 = new String[35];
        System.arraycopy(new String[]{"libfbandroid_native_cppdistract_cppdistract.so", "libfbandroid_native_museum_museum.so", "libglog.so", "libfbandroid_native_sigmuxutils_sigmuxutils.so", "libbreakpad.so", "libdexload.so", "libxplat_third-party_jsoncpp_jsoncppAndroid.so", "libappstatelogger2.so", "libpreconnector.so", "libxplat_mobilenetwork_fbdomainsAndroid.so", "libfmt.so", "libthird-party_boost_boost_contextAndroid.so", "libthird-party_boost_boostAndroid.so", "liblinkerutils.so", "libplthooks.so", "libmem_alloc_marker.so", "libfbunwindstack.so", "liblive-query-jni.so", DalvikInternals.LIBCOLDSTART_BASE_NAME, "libaospbugfixmerged.so", "libsigquit.so", "libreliabilitymerged.so", "libfb_mboost.so", "libtigonnativeauthedservice.so", "libimagepipeline.so", "libxplat_arfx_versioning_sdk_version_constants_constantsAndroid.so", "libard-upload.so"}, A1W, strArr2, A1W, 27);
        System.arraycopy(new String[]{"libIGL.so", "libimagesmerged.so", "libthreadutils-jni.so", "libclasstracing.so", "libunwindstack_stream.so", "libbreakpad_extra.so", "libfbnightwatch.so", "libreliablemediamonitor.so"}, A1W, strArr2, 27, 8);
        A01 = AnonymousClass001.A0y(strArr2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0055, code lost:
        r2 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0056, code lost:
        r3 = 0;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0063  */
    /* JADX WARNING: Removed duplicated region for block: B:55:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void DSk(java.lang.Integer r9) {
        /*
            r8 = this;
            java.lang.Integer r0 = X.AnonymousClass0X6.A0u
            if (r9 == r0) goto L_0x0085
            java.lang.Integer r0 = X.AnonymousClass0X6.A15
            if (r9 == r0) goto L_0x0085
            java.util.List r1 = A00
            boolean r0 = r1.isEmpty()
            if (r0 != 0) goto L_0x0085
            java.util.ArrayList r7 = X.AnonymousClass001.A0v(r1)
            java.util.ArrayList r3 = X.AnonymousClass001.A0t()
            java.lang.Integer r0 = X.AnonymousClass0X6.A0j
            if (r9 == r0) goto L_0x0030
            int r2 = r7.size()
        L_0x0020:
            int r2 = r2 + -1
            if (r2 < 0) goto L_0x002f
            r7.get(r2)
            r1 = 0
            int r0 = r9.intValue()
            switch(r0) {
                case 0: goto L_0x0033;
                case 1: goto L_0x0070;
                case 2: goto L_0x0077;
                case 3: goto L_0x007e;
                case 4: goto L_0x007e;
                case 5: goto L_0x0033;
                default: goto L_0x002f;
            }
        L_0x002f:
            r7 = r3
        L_0x0030:
            r5 = 0
            goto L_0x0037
        L_0x0033:
            r3.add(r1)
            goto L_0x0020
        L_0x0037:
            java.lang.String r0 = ".spk"
            long r3 = getProcessMappings(r0)     // Catch:{ RuntimeException -> 0x0055, all -> 0x0053 }
            java.util.Iterator r1 = r7.iterator()     // Catch:{ RuntimeException -> 0x0051 }
            boolean r0 = r1.hasNext()     // Catch:{ RuntimeException -> 0x0051 }
            if (r0 == 0) goto L_0x005f
            r1.next()     // Catch:{ RuntimeException -> 0x0051 }
            java.lang.String r0 = "path"
            java.lang.NullPointerException r0 = X.AnonymousClass001.A0T(r0)     // Catch:{ RuntimeException -> 0x0051 }
            throw r0     // Catch:{ RuntimeException -> 0x0051 }
        L_0x0051:
            r2 = move-exception
            goto L_0x0058
        L_0x0053:
            r1 = move-exception
            throw r1
        L_0x0055:
            r2 = move-exception
            r3 = 0
        L_0x0058:
            java.lang.String r1 = "SuperpackUnloader"
            java.lang.String r0 = "Failed to unload in-memory compressed libraries. Ignoring."
            X.C14270pR.A0I(r1, r0, r2)     // Catch:{ all -> 0x0067 }
        L_0x005f:
            int r0 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r0 == 0) goto L_0x0085
            releaseProcessMappings(r3)
            return
        L_0x0067:
            r1 = move-exception
            int r0 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r0 == 0) goto L_0x006f
            releaseProcessMappings(r3)
        L_0x006f:
            throw r1
        L_0x0070:
            java.lang.String r0 = "loadTime"
            java.lang.NullPointerException r0 = X.AnonymousClass001.A0T(r0)
            throw r0
        L_0x0077:
            java.lang.String r0 = "loadTime"
            java.lang.NullPointerException r0 = X.AnonymousClass001.A0T(r0)
            throw r0
        L_0x007e:
            java.lang.String r0 = "name"
            java.lang.NullPointerException r0 = X.AnonymousClass001.A0T(r0)
            throw r0
        L_0x0085:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.superpack.SuperpackUnloader.DSk(java.lang.Integer):void");
    }
}
