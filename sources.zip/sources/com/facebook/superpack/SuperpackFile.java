package com.facebook.superpack;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.C18440x7;
import java.io.Closeable;
import java.io.InputStream;

public final class SuperpackFile implements Closeable {
    public int mFd;
    public int mLength;
    public boolean mOwnsFilePtr;
    public long mPtr;

    public SuperpackFile(long j, int i) {
        if (j != 0) {
            this.mPtr = j;
            this.mOwnsFilePtr = true;
            this.mLength = getLengthNative(j);
            this.mFd = -1;
            return;
        }
        throw AnonymousClass001.A0S();
    }

    public static native void closeMemfdNative(long j);

    public static native void closeNative(long j);

    public static native long createSuperpackFileNative(String str, InputStream inputStream);

    public static native long createSuperpackFileNative(String str, byte[] bArr);

    public static native int getLengthNative(long j);

    public static native String getNameNative(long j);

    public static native void readBytesNative(long j, int i, int i2, byte[] bArr, int i3);

    public synchronized void close() {
        long j = this.mPtr;
        if (j != 0) {
            if (this.mFd >= 0) {
                closeMemfdNative(j);
            } else if (this.mOwnsFilePtr) {
                closeNative(j);
            }
            this.mPtr = 0;
        } else {
            throw AnonymousClass001.A0N();
        }
    }

    public synchronized String getName() {
        long j;
        j = this.mPtr;
        if (j != 0) {
        } else {
            throw AnonymousClass001.A0N();
        }
        return getNameNative(j);
    }

    static {
        C18440x7.loadLibrary("superpack-jni");
    }

    public void finalize() {
        int A03 = AnonymousClass0BS.A03(-2000321027);
        long j = this.mPtr;
        if (j == 0) {
            AnonymousClass0BS.A09(-158776507, A03);
            return;
        }
        if (this.mOwnsFilePtr) {
            closeNative(j);
        }
        this.mPtr = 0;
        IllegalStateException A0N = AnonymousClass001.A0N();
        AnonymousClass0BS.A09(1774343014, A03);
        throw A0N;
    }
}
