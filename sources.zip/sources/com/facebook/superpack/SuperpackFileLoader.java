package com.facebook.superpack;

import X.AnonymousClass001;
import X.AnonymousClass0WY;
import X.AnonymousClass11O;
import X.C17850vu;
import X.C18440x7;
import android.text.TextUtils;
import com.facebook.breakpad.BreakpadManager;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class SuperpackFileLoader implements AnonymousClass11O {
    public static boolean A04;
    public static final Map A05 = AnonymousClass001.A14();
    public static final Set A06 = AnonymousClass001.A0y(new String[]{"libliger.so"});
    public final Runtime A00 = Runtime.getRuntime();
    public final String A01;
    public final String A02;
    public final Method A03;

    public static native boolean canLoadInMemoryNative();

    public static native MappingInfo[] loadBytesNative(String str, byte[] bArr);

    public static native MappingInfo[] loadFdNative(String str, int i, long j, long j2);

    public static native void loadFileNative(String str);

    public class MappingInfo {
        public final long A00;
        public final long A01;
        public final long A02;
        public final String A03;
        public final byte[] A04;

        public MappingInfo(String str, byte[] bArr, long j, long j2, long j3) {
            this.A03 = str;
            this.A04 = bArr;
            this.A02 = j;
            this.A01 = j2;
            this.A00 = j3;
        }
    }

    public final void CHV(String str, int i) {
        String str2;
        String str3;
        String str4;
        FileInputStream A0F;
        Method method = this.A03;
        if (method != null) {
            if ((i & 4) == 4) {
                str2 = this.A01;
            } else {
                str2 = this.A02;
            }
            try {
                Runtime runtime = this.A00;
                synchronized (runtime) {
                    try {
                        str3 = (String) method.invoke(runtime, new Object[]{str, C18440x7.class.getClassLoader(), str2});
                        if (str3 == null) {
                            try {
                            } catch (Throwable th) {
                                th = th;
                                try {
                                    throw th;
                                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                                    e = e;
                                }
                            }
                        } else {
                            throw new UnsatisfiedLinkError(str3);
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        str3 = null;
                        throw th;
                    }
                }
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e2) {
                e = e2;
                str3 = null;
                try {
                    throw AnonymousClass001.A0W(AnonymousClass0WY.A0i("Error: Cannot load ", str), e);
                } catch (Throwable th3) {
                    A0F.close();
                    throw th3;
                }
            } catch (Throwable th4) {
                th = th4;
                throw th;
            }
        } else if (A04) {
            try {
                loadFileNative(str);
            } catch (UnsatisfiedLinkError e3) {
                if (!(!str.endsWith(".so"))) {
                    System.load(str);
                } else {
                    throw e3;
                }
            }
            if (BreakpadManager.initialized) {
                Map map = A05;
                if (!map.isEmpty()) {
                    ArrayList A0u = AnonymousClass001.A0u(map.size());
                    synchronized (map) {
                        Iterator A12 = AnonymousClass001.A12(map);
                        while (A12.hasNext()) {
                            A0u.add((MappingInfo) AnonymousClass001.A13(A12).getValue());
                            A12.remove();
                        }
                    }
                    Iterator it = A0u.iterator();
                    while (it.hasNext()) {
                        MappingInfo mappingInfo = (MappingInfo) it.next();
                        String str5 = mappingInfo.A03;
                        byte[] bArr = mappingInfo.A04;
                        BreakpadManager.addMappingInfo(str5, bArr, bArr.length, mappingInfo.A02, mappingInfo.A01, mappingInfo.A00);
                    }
                }
            }
        } else {
            System.load(str);
            if (str.regionMatches(str.lastIndexOf(File.separatorChar) + 1, "libsuperpack-jni.so", 0, 19)) {
                A04 = true;
            }
        }
    }

    public SuperpackFileLoader() {
        String str;
        String join;
        Method A022 = C17850vu.A02();
        this.A03 = A022;
        if (A022 != null) {
            str = C17850vu.A01();
        } else {
            str = null;
        }
        this.A01 = str;
        if (str == null) {
            join = null;
        } else {
            ArrayList A0u = AnonymousClass001.A0u(r4);
            for (String str2 : str.split(":")) {
                if (!str2.contains("!")) {
                    A0u.add(str2);
                }
            }
            join = TextUtils.join(":", A0u);
        }
        this.A02 = join;
    }
}
