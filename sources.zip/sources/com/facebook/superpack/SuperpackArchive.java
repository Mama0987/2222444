package com.facebook.superpack;

import X.AnonymousClass001;
import X.AnonymousClass0BS;
import X.C18440x7;
import java.io.Closeable;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;

public class SuperpackArchive implements Iterator, Closeable {
    public static final String TAG = "SuperpackArchive";
    public int mDecompressedFiles = 0;
    public long mPtr;

    public static native void appendAnonNative(long j, long j2);

    public static native void appendNative(long j, long j2);

    public static native void closeNative(long j);

    public static native long createNative();

    public static native long extractNextNative(long j, String[] strArr);

    public static native long getThreadNumOption(int i);

    public static native boolean isEmptyNative(long j);

    public static native long[] nextMemfdNative(long j, String str);

    public static native long nextNative(long j);

    public static native long readNative(InputStream inputStream, String str, long j);

    public static native long readNative(String str, String str2, long j);

    public static native void setPackingOptionsNative(long j, boolean z, boolean z2);

    public static native void setStorageNative(long j, String str, int i);

    public static native void writeNative(long j, OutputStream outputStream);

    public synchronized void close() {
        long j = this.mPtr;
        if (j != 0) {
            closeNative(j);
            this.mPtr = 0;
        } else {
            throw AnonymousClass001.A0N();
        }
    }

    public boolean hasNext() {
        boolean isEmptyNative;
        synchronized (this) {
            long j = this.mPtr;
            if (j != 0) {
                isEmptyNative = isEmptyNative(j);
            } else {
                throw AnonymousClass001.A0N();
            }
        }
        return !isEmptyNative;
    }

    public synchronized SuperpackFile next() {
        Throwable th;
        long nextNative;
        long j = this.mPtr;
        if (j != 0) {
            nextNative = nextNative(j);
            if (nextNative != 0) {
                this.mDecompressedFiles++;
            } else {
                th = AnonymousClass001.A15();
            }
        } else {
            th = AnonymousClass001.A0N();
        }
        throw th;
        return new SuperpackFile(nextNative, -1);
    }

    static {
        C18440x7.loadLibrary("superpack-jni");
    }

    public static SuperpackArchive read(InputStream inputStream, String str) {
        if (inputStream != null) {
            return new SuperpackArchive(readNative(inputStream, str, 0), (String[]) null);
        }
        throw AnonymousClass001.A0S();
    }

    public SuperpackArchive(long j, String[] strArr) {
        if (j != 0) {
            this.mPtr = j;
            return;
        }
        throw new IllegalArgumentException();
    }

    public void finalize() {
        int A03 = AnonymousClass0BS.A03(1818645622);
        long j = this.mPtr;
        if (j == 0) {
            AnonymousClass0BS.A09(-1684098993, A03);
            return;
        }
        closeNative(j);
        this.mPtr = 0;
        IllegalStateException A0N = AnonymousClass001.A0N();
        AnonymousClass0BS.A09(1146585758, A03);
        throw A0N;
    }

    public static SuperpackArchive read(InputStream inputStream, String str, int i) {
        long threadNumOption;
        if (!str.matches("spo")) {
            threadNumOption = 0;
        } else {
            threadNumOption = getThreadNumOption(i);
        }
        return new SuperpackArchive(readNative(inputStream, str, threadNumOption), (String[]) null);
    }
}
