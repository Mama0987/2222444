package com.facebook.photos.provider;

import X.C10640fx;

public final class PhotosProvider extends C10640fx {
}
