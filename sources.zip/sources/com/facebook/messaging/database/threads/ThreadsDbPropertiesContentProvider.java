package com.facebook.messaging.database.threads;

import X.C10640fx;

public class ThreadsDbPropertiesContentProvider extends C10640fx {
}
