package com.facebook.messaging.database.threads;

import X.C10640fx;

public class MessagesDbContentProvider extends C10640fx {
}
