package com.facebook.messaging.sharekey.contentprovider;

import X.C10640fx;

public final class SecureMessagingKeyContentProvider extends C10640fx {
}
