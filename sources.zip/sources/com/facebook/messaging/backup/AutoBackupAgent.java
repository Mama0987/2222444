package com.facebook.messaging.backup;

import android.app.backup.BackupAgentHelper;

public final class AutoBackupAgent extends BackupAgentHelper {
}
