package com.facebook.messaging.push.dedup.provider;

import X.C10640fx;

public final class ClientMessagePushDedupInfoProvider extends C10640fx {
}
