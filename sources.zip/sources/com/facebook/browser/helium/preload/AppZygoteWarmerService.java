package com.facebook.browser.helium.preload;

import X.C15800sA;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public final class AppZygoteWarmerService extends Service {
    public final IBinder onBind(Intent intent) {
        C15800sA.A0I(intent, "intent");
        return null;
    }
}
