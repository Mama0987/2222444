package com.facebook.browser.helium.content;

import X.AnonymousClass0SN;
import X.C11840jG;
import X.C15800sA;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import com.facebook.browser.helium.util.voltron.HeliumVoltronHelper;
import dalvik.system.InMemoryDexClassLoader;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import kotlin.jvm.internal.DefaultConstructorMarker;

public class SandboxedProcessService extends Service {
    public static final C11840jG A01 = new C11840jG((DefaultConstructorMarker) null);
    public Object A00;

    public final IBinder onBind(Intent intent) {
        ClassLoader classLoader;
        Class<?> cls;
        C15800sA.A0I(intent, "intent");
        Bundle extras = intent.getExtras();
        if (extras != null) {
            if (extras.getBoolean("use_extracted_child_dex", true)) {
                classLoader = new AnonymousClass0SN(this).A00();
            } else {
                classLoader = A00();
            }
            try {
                Object invoke = classLoader.loadClass("org.chromium.content_public.app.ChildProcessServiceFactory").getMethod("create", new Class[]{Service.class, Context.class}).invoke((Object) null, new Object[]{this, getApplicationContext()});
                this.A00 = invoke;
                if (invoke == null) {
                    throw new IllegalArgumentException("Failed to create ChildProcessService".toString());
                } else if (invoke == null || (cls = invoke.getClass()) == null) {
                    throw new RuntimeException("Service cannot be null");
                } else {
                    cls.getMethod("onCreate", (Class[]) null).invoke(this.A00, (Object[]) null);
                    Object invoke2 = cls.getMethod("onBind", new Class[]{Intent.class}).invoke(this.A00, new Object[]{intent});
                    C15800sA.A0G(invoke2, "null cannot be cast to non-null type android.os.IBinder");
                    return (IBinder) invoke2;
                }
            } catch (ReflectiveOperationException e) {
                throw new RuntimeException(e);
            }
        } else {
            throw new RuntimeException("Helium child processes require a bundle");
        }
    }

    private final ClassLoader A00() {
        try {
            AssetFileDescriptor childDexFd = HeliumVoltronHelper.getChildDexFd(getApplicationContext());
            C15800sA.A0H(childDexFd, "getChildDexFd(...)");
            ParcelFileDescriptor parcelFileDescriptor = childDexFd.getParcelFileDescriptor();
            MappedByteBuffer map = new FileInputStream(parcelFileDescriptor.getFileDescriptor()).getChannel().map(FileChannel.MapMode.READ_ONLY, childDexFd.getStartOffset(), childDexFd.getDeclaredLength());
            if (Build.VERSION.SDK_INT < 29) {
                return new InMemoryDexClassLoader(map, getClassLoader());
            }
            return new InMemoryDexClassLoader((ByteBuffer[]) new MappedByteBuffer[]{map}, getApplicationInfo().nativeLibraryDir, (ClassLoader) null);
        } catch (IOException e) {
            throw new RuntimeException("Failed to bootstrap child process", e);
        }
    }

    public final void onDestroy() {
        super.onDestroy();
        Object obj = this.A00;
        if (obj != null) {
            try {
                obj.getClass().getMethod("onDestroy", (Class[]) null).invoke(obj, (Object[]) null);
                this.A00 = null;
            } catch (ReflectiveOperationException e) {
                throw new RuntimeException(e);
            } catch (Throwable th) {
                this.A00 = null;
                throw th;
            }
        }
    }
}
