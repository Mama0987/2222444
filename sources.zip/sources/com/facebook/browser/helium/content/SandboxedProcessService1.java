package com.facebook.browser.helium.content;

public final class SandboxedProcessService1 extends SandboxedProcessService {
}
