package com.facebook.browser.helium.content;

public final class SandboxedProcessService0 extends SandboxedProcessService {
}
