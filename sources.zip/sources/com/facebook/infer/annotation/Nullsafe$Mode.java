package com.facebook.infer.annotation;

public enum Nullsafe$Mode {
    LOCAL,
    RUNTIME,
    STRICT
}
