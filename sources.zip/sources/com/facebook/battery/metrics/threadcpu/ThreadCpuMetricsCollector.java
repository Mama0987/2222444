package com.facebook.battery.metrics.threadcpu;

import X.AnonymousClass0GM;
import X.AnonymousClass0GN;
import X.AnonymousClass0Sj;

public final class ThreadCpuMetricsCollector extends AnonymousClass0GM {
    public final /* bridge */ /* synthetic */ AnonymousClass0GN A02() {
        return new AnonymousClass0Sj();
    }

    /* JADX WARNING: type inference failed for: r3v1, types: [X.0As, java.lang.Object] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00cf A[SYNTHETIC, Splitter:B:37:0x00cf] */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0013 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* bridge */ /* synthetic */ boolean A03(X.AnonymousClass0GN r15) {
        /*
            r14 = this;
            X.0Sj r15 = (X.AnonymousClass0Sj) r15
            if (r15 == 0) goto L_0x018b
            r13 = 0
            java.util.HashMap r0 = X.C05690Sp.A00()     // Catch:{ Exception -> 0x0181 }
            if (r0 == 0) goto L_0x0189
            java.util.HashMap r5 = X.AnonymousClass001.A0w()     // Catch:{ Exception -> 0x0181 }
            java.util.Iterator r12 = X.AnonymousClass001.A10(r0)     // Catch:{ Exception -> 0x0181 }
        L_0x0013:
            boolean r0 = r12.hasNext()     // Catch:{ Exception -> 0x0181 }
            if (r0 == 0) goto L_0x0101
            java.lang.Object r0 = r12.next()     // Catch:{ Exception -> 0x0181 }
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0     // Catch:{ Exception -> 0x0181 }
            java.lang.Object r9 = r0.getKey()     // Catch:{ Exception -> 0x0181 }
            java.lang.String r9 = (java.lang.String) r9     // Catch:{ Exception -> 0x0181 }
            java.lang.Object r8 = r0.getValue()     // Catch:{ Exception -> 0x0181 }
            java.lang.String r8 = (java.lang.String) r8     // Catch:{ Exception -> 0x0181 }
            java.lang.String r1 = "/proc/%d/task/%s/stat"
            int r0 = android.os.Process.myPid()     // Catch:{ Exception -> 0x0181 }
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch:{ Exception -> 0x0181 }
            java.lang.String r7 = com.facebook.common.stringformat.StringFormatUtil.formatStrLocaleSafe(r1, r0, r9)     // Catch:{ Exception -> 0x0181 }
            java.lang.String r6 = "Error closing procfs file: %s"
            java.io.File r0 = new java.io.File     // Catch:{ Exception -> 0x0181 }
            r0.<init>(r7)     // Catch:{ Exception -> 0x0181 }
            boolean r0 = r0.exists()     // Catch:{ Exception -> 0x0181 }
            if (r0 != 0) goto L_0x0052
            java.lang.String r1 = "CpuInfoUtils"
            java.lang.String r0 = "stat file not found "
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r0, r7)     // Catch:{ Exception -> 0x0181 }
            X.C14270pR.A0G(r1, r0)     // Catch:{ Exception -> 0x0181 }
            goto L_0x0013
        L_0x0052:
            android.os.StrictMode$ThreadPolicy r11 = android.os.StrictMode.allowThreadDiskReads()     // Catch:{ Exception -> 0x0181 }
            r4 = 1
            java.lang.String r0 = "r"
            java.io.RandomAccessFile r10 = new java.io.RandomAccessFile     // Catch:{ Exception -> 0x00ba, all -> 0x00e4 }
            r10.<init>(r7, r0)     // Catch:{ Exception -> 0x00ba, all -> 0x00e4 }
            java.lang.String r3 = r10.readLine()     // Catch:{ Exception -> 0x00b8 }
            r10.close()     // Catch:{ IOException -> 0x0066 }
            goto L_0x0076
        L_0x0066:
            r2 = move-exception
            java.util.Locale r1 = java.util.Locale.US     // Catch:{ Exception -> 0x0181 }
            java.lang.Object[] r0 = new java.lang.Object[]{r7}     // Catch:{ Exception -> 0x0181 }
            java.lang.String r1 = java.lang.String.format(r1, r6, r0)     // Catch:{ Exception -> 0x0181 }
            java.lang.String r0 = "CpuInfoUtils"
            X.C14270pR.A0J(r0, r1, r2)     // Catch:{ Exception -> 0x0181 }
        L_0x0076:
            android.os.StrictMode.setThreadPolicy(r11)     // Catch:{ Exception -> 0x0181 }
            if (r3 == 0) goto L_0x0013
            java.lang.String r0 = " "
            java.lang.String[] r10 = r3.split(r0)     // Catch:{ Exception -> 0x0181 }
            if (r10 == 0) goto L_0x0013
            boolean r0 = X.C05700Sq.A01     // Catch:{ Exception -> 0x0181 }
            if (r0 != 0) goto L_0x0091
            int r0 = android.system.OsConstants._SC_CLK_TCK     // Catch:{ Exception -> 0x0181 }
            long r0 = android.system.Os.sysconf(r0)     // Catch:{ Exception -> 0x0181 }
            X.C05700Sq.A00 = r0     // Catch:{ Exception -> 0x0181 }
            X.C05700Sq.A01 = r4     // Catch:{ Exception -> 0x0181 }
        L_0x0091:
            long r0 = X.C05700Sq.A00     // Catch:{ Exception -> 0x0181 }
            r2 = 13
            double r6 = X.C05700Sq.A00(r10, r2, r0)     // Catch:{ Exception -> 0x0181 }
            r2 = 14
            double r2 = X.C05700Sq.A00(r10, r2, r0)     // Catch:{ Exception -> 0x0181 }
            r4 = 15
            X.C05700Sq.A00(r10, r4, r0)     // Catch:{ Exception -> 0x0181 }
            r4 = 16
            X.C05700Sq.A00(r10, r4, r0)     // Catch:{ Exception -> 0x0181 }
            X.0Sr r1 = new X.0Sr     // Catch:{ Exception -> 0x0181 }
            r1.<init>(r6, r2)     // Catch:{ Exception -> 0x0181 }
            android.util.Pair r0 = new android.util.Pair     // Catch:{ Exception -> 0x0181 }
            r0.<init>(r8, r1)     // Catch:{ Exception -> 0x0181 }
            r5.put(r9, r0)     // Catch:{ Exception -> 0x0181 }
            goto L_0x0013
        L_0x00b8:
            r4 = move-exception
            goto L_0x00bc
        L_0x00ba:
            r4 = move-exception
            r10 = r13
        L_0x00bc:
            java.util.Locale r3 = java.util.Locale.US     // Catch:{ all -> 0x00e6 }
            java.lang.String r1 = "Error reading cpu time from procfs file: %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r7}     // Catch:{ all -> 0x00e6 }
            java.lang.String r0 = java.lang.String.format(r3, r1, r0)     // Catch:{ all -> 0x00e6 }
            java.lang.String r2 = "CpuInfoUtils"
            X.C14270pR.A0J(r2, r0, r4)     // Catch:{ all -> 0x00e6 }
            if (r10 == 0) goto L_0x0013
            r10.close()     // Catch:{ IOException -> 0x00d3 }
            goto L_0x00df
        L_0x00d3:
            r1 = move-exception
            java.lang.Object[] r0 = new java.lang.Object[]{r7}     // Catch:{ Exception -> 0x0181 }
            java.lang.String r0 = java.lang.String.format(r3, r6, r0)     // Catch:{ Exception -> 0x0181 }
            X.C14270pR.A0J(r2, r0, r1)     // Catch:{ Exception -> 0x0181 }
        L_0x00df:
            android.os.StrictMode.setThreadPolicy(r11)     // Catch:{ Exception -> 0x0181 }
            goto L_0x0013
        L_0x00e4:
            r3 = move-exception
            goto L_0x0100
        L_0x00e6:
            r3 = move-exception
            if (r10 == 0) goto L_0x0100
            r10.close()     // Catch:{ IOException -> 0x00ed }
            goto L_0x00fd
        L_0x00ed:
            r2 = move-exception
            java.util.Locale r1 = java.util.Locale.US     // Catch:{ Exception -> 0x0181 }
            java.lang.Object[] r0 = new java.lang.Object[]{r7}     // Catch:{ Exception -> 0x0181 }
            java.lang.String r1 = java.lang.String.format(r1, r6, r0)     // Catch:{ Exception -> 0x0181 }
            java.lang.String r0 = "CpuInfoUtils"
            X.C14270pR.A0J(r0, r1, r2)     // Catch:{ Exception -> 0x0181 }
        L_0x00fd:
            android.os.StrictMode.setThreadPolicy(r11)     // Catch:{ Exception -> 0x0181 }
        L_0x0100:
            throw r3     // Catch:{ Exception -> 0x0181 }
        L_0x0101:
            java.util.HashMap r0 = r15.threadCpuMap
            java.util.Set r1 = r0.keySet()
            java.util.Set r0 = r5.keySet()
            r1.retainAll(r0)
            java.util.Iterator r7 = X.AnonymousClass001.A10(r5)
        L_0x0112:
            boolean r0 = r7.hasNext()
            if (r0 == 0) goto L_0x017f
            java.lang.Object r4 = r7.next()
            java.util.Map$Entry r4 = (java.util.Map.Entry) r4
            java.lang.Object r0 = r4.getKey()     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ NumberFormatException -> 0x016e }
            int r6 = java.lang.Integer.parseInt(r0)     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r0 = r4.getValue()     // Catch:{ NumberFormatException -> 0x016e }
            android.util.Pair r0 = (android.util.Pair) r0     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r5 = r0.first     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r0 = r4.getValue()     // Catch:{ NumberFormatException -> 0x016e }
            android.util.Pair r0 = (android.util.Pair) r0     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r2 = r0.second     // Catch:{ NumberFormatException -> 0x016e }
            X.0Sr r2 = (X.AnonymousClass0Sr) r2     // Catch:{ NumberFormatException -> 0x016e }
            X.0As r3 = new X.0As     // Catch:{ NumberFormatException -> 0x016e }
            r3.<init>()     // Catch:{ NumberFormatException -> 0x016e }
            double r0 = r2.A01     // Catch:{ NumberFormatException -> 0x016e }
            r3.userTimeS = r0     // Catch:{ NumberFormatException -> 0x016e }
            double r0 = r2.A00     // Catch:{ NumberFormatException -> 0x016e }
            r3.systemTimeS = r0     // Catch:{ NumberFormatException -> 0x016e }
            java.util.HashMap r0 = r15.threadCpuMap     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r6)     // Catch:{ NumberFormatException -> 0x016e }
            boolean r0 = r0.containsKey(r2)     // Catch:{ NumberFormatException -> 0x016e }
            if (r0 == 0) goto L_0x0163
            java.util.HashMap r0 = r15.threadCpuMap     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r0 = r0.get(r2)     // Catch:{ NumberFormatException -> 0x016e }
            android.util.Pair r0 = (android.util.Pair) r0     // Catch:{ NumberFormatException -> 0x016e }
            java.lang.Object r0 = r0.second     // Catch:{ NumberFormatException -> 0x016e }
            X.0As r0 = (X.C02150As) r0     // Catch:{ NumberFormatException -> 0x016e }
            r0.A09(r3)     // Catch:{ NumberFormatException -> 0x016e }
            goto L_0x0112
        L_0x0163:
            java.util.HashMap r1 = r15.threadCpuMap     // Catch:{ NumberFormatException -> 0x016e }
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x016e }
            r0.<init>(r5, r3)     // Catch:{ NumberFormatException -> 0x016e }
            r1.put(r2, r0)     // Catch:{ NumberFormatException -> 0x016e }
            goto L_0x0112
        L_0x016e:
            r3 = move-exception
            java.lang.String r2 = "com.facebook.battery.metrics.threadcpu.ThreadCpuMetricsCollector"
            java.lang.String r1 = "Thread Id is not an integer: "
            java.lang.String r0 = X.AnonymousClass001.A0l(r4)
            java.lang.String r0 = X.AnonymousClass0WY.A0i(r1, r0)
            X.AnonymousClass0RB.A00(r2, r0, r3)
            goto L_0x0112
        L_0x017f:
            r0 = 1
            return r0
        L_0x0181:
            r2 = move-exception
            java.lang.Class<X.0Sp> r1 = X.C05690Sp.class
            java.lang.String r0 = "Error getting thread level CPU Usage data"
            X.C14270pR.A06(r1, r0, r2)
        L_0x0189:
            r0 = 0
            return r0
        L_0x018b:
            java.lang.String r0 = "Null value passed to getSnapshot!"
            java.lang.IllegalArgumentException r0 = X.AnonymousClass001.A0L(r0)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.battery.metrics.threadcpu.ThreadCpuMetricsCollector.A03(X.0GN):boolean");
    }
}
