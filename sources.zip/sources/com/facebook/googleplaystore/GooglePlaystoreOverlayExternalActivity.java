package com.facebook.googleplaystore;

import android.app.Activity;
import android.content.Intent;

public final class GooglePlaystoreOverlayExternalActivity extends Activity {
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0) {
            finish();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0048, code lost:
        if (r8.length() == 0) goto L_0x004a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(android.os.Bundle r10) {
        /*
            r9 = this;
            r0 = 1209032570(0x48105f7a, float:147837.9)
            int r4 = X.AnonymousClass0BS.A00(r0)
            super.onCreate(r10)
            r5 = 0
            r9.setVisible(r5)
            android.content.Intent r3 = r9.getIntent()
            X.C15800sA.A09(r3)
            java.lang.String r0 = "IG_GPS_AD_CONTENT"
            java.lang.String r8 = r3.getStringExtra(r0)
            X.03D r2 = new X.03D
            r2.<init>()
            r2.A01()
            X.038 r1 = X.AnonymousClass039.A0t
            java.util.Set r0 = X.AnonymousClass0j6.A04
            r2.A04(r1, r0)
            java.lang.String r0 = "IG_GOOGLE_PLAYSTORE_FRAGMENT"
            r2.A05(r0)
            X.03E r1 = r2.A00()
            r0 = 0
            boolean r1 = r1.A05(r9, r3, r0)
            X.0G2 r0 = X.C015008c.A03()
            boolean r7 = r0.A02(r9, r3, r9)
            r6 = 1
            if (r8 == 0) goto L_0x004a
            int r0 = r8.length()
            r3 = 0
            if (r0 != 0) goto L_0x004b
        L_0x004a:
            r3 = 1
        L_0x004b:
            if (r1 == 0) goto L_0x008e
            if (r7 == 0) goto L_0x008e
            if (r8 == 0) goto L_0x008e
            int r0 = r8.length()
            if (r0 == 0) goto L_0x008e
            java.lang.String r0 = "android.intent.action.VIEW"
            android.content.Intent r3 = X.AnonymousClass001.A07(r0)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            android.net.Uri r0 = X.C014507v.A02(r8)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            r3.setData(r0)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            java.lang.String r0 = "com.android.vending"
            r3.setPackage(r0)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            android.os.Bundle r2 = X.AnonymousClass001.A08()     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            java.lang.String r1 = "callerId"
            java.lang.String r0 = "com.facebook.katana"
            r2.putString(r1, r0)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            java.lang.String r0 = "overlay"
            r2.putBoolean(r0, r6)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            r3.putExtras(r2)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            X.0HU r0 = X.AnonymousClass0HU.A00()     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            X.0Lh r0 = r0.A06()     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            r0.A0B(r9, r3, r5)     // Catch:{ SecurityException -> 0x00c2, NullPointerException -> 0x0088 }
            goto L_0x00d1
        L_0x0088:
            r2 = move-exception
            java.lang.String r1 = "ERROR_ACTIVITY"
            java.lang.String r0 = "Null pointer exception, "
            goto L_0x00c7
        L_0x008e:
            java.lang.String r2 = "ERROR_ACTIVITY"
            java.lang.String r0 = java.lang.String.valueOf(r1)
            java.lang.Object[] r1 = new java.lang.Object[]{r0}
            java.lang.String r0 = "Trusted call: %s"
            X.C14270pR.A0O(r2, r0, r1)
            java.lang.String r0 = java.lang.String.valueOf(r7)
            java.lang.Object[] r1 = new java.lang.Object[]{r0}
            java.lang.String r0 = "Default Switch off: %s"
            X.C14270pR.A0O(r2, r0, r1)
            java.lang.String r0 = java.lang.String.valueOf(r3)
            java.lang.Object[] r1 = new java.lang.Object[]{r0}
            java.lang.String r0 = "External intent string: %s"
            X.C14270pR.A0O(r2, r0, r1)
            r0 = -1
            r9.setResult(r0)
            r9.finish()
            r0 = 2078291497(0x7be03629, float:2.328346E36)
            goto L_0x00d4
        L_0x00c2:
            r2 = move-exception
            java.lang.String r1 = "ERROR_ACTIVITY"
            java.lang.String r0 = "Security: "
        L_0x00c7:
            X.C14270pR.A0I(r1, r0, r2)
            r0 = -1
            r9.setResult(r0)
            r9.finish()
        L_0x00d1:
            r0 = -979510384(0xffffffffc59ddb90, float:-5051.4453)
        L_0x00d4:
            X.AnonymousClass0BS.A07(r0, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.googleplaystore.GooglePlaystoreOverlayExternalActivity.onCreate(android.os.Bundle):void");
    }
}
