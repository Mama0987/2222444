package com.facebook.katana.app;

import X.C15800sA;
import android.app.Application;

public final class FacebookApplicationErrorDelegate {
    public final Application A00;

    public FacebookApplicationErrorDelegate(Application application) {
        C15800sA.A0D(application, 1);
        this.A00 = application;
    }

    public FacebookApplicationErrorDelegate() {
    }
}
