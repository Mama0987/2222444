package com.facebook.katana.app.crashloop;

import X.AnonymousClass001;
import X.AnonymousClass0V1;
import X.C02040Ah;
import X.C12620kw;
import X.C15800sA;
import X.C18730xw;
import X.C19010yk;
import android.content.Context;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public final class FacebookApplicationCrashRemedy extends AnonymousClass0V1 {
    public static String[] A00 = {"UniqueDeviceIdPrefs.xml"};
    public static String[] A01 = {"logged_in_.*", "dbl_local_auth_.*", "authentication", "pw_enc_key", "underlying_account", "account_manager"};

    public final C19010yk A01(Context context, int i, int i2) {
        Object obj;
        File[] fileArr;
        C15800sA.A0D(context, 0);
        C19010yk A012 = super.A01(context, i, i2);
        if (i <= i2 || i != 1) {
            return A012;
        }
        File A0E = AnonymousClass001.A0E(AnonymousClass001.A0a(context));
        File filesDir = context.getFilesDir();
        ArrayList A0u = AnonymousClass001.A0u(3);
        A0u.add(AnonymousClass001.A0D(filesDir, "video-cache"));
        A0u.add(AnonymousClass001.A0D(A0E, "app_webview"));
        C15800sA.A0C(filesDir);
        C15800sA.A0D(filesDir, 2);
        if (C12620kw.A01(context).A3O) {
            ArrayList A0u2 = AnonymousClass001.A0u(3);
            File parentFile = context.getDatabasePath("ignore").getParentFile();
            if (parentFile == null || (fileArr = parentFile.listFiles(C18730xw.A00)) == null) {
                fileArr = new File[0];
            }
            C02040Ah.A00(fileArr, A0u2);
            A0u2.add(AnonymousClass001.A0D(filesDir, "NewsFeed"));
            A0u2.add(AnonymousClass001.A0D(A0E, "app_NewsFeed"));
            obj = A0u2.toArray(new File[A0u2.size()]);
        } else {
            obj = new File[]{AnonymousClass001.A0D(filesDir, "NewsFeed"), AnonymousClass001.A0D(A0E, "app_NewsFeed")};
        }
        C02040Ah.A00(obj, A0u);
        for (File A002 : (File[]) A0u.toArray(new File[A0u.size()])) {
            AnonymousClass0V1.A00(A002, new String[0]);
        }
        return new C19010yk(true, false);
    }

    public final String[] A03(Context context) {
        String[] strArr = AnonymousClass0V1.A00;
        String[] strArr2 = A00;
        String[] strArr3 = (String[]) Arrays.copyOf(strArr, 10);
        System.arraycopy(strArr2, 0, strArr3, 9, 1);
        C15800sA.A09(strArr3);
        if (!C12620kw.A01(context).A60) {
            return strArr3;
        }
        String[] strArr4 = A01;
        int length = strArr3.length;
        String[] strArr5 = (String[]) Arrays.copyOf(strArr3, length + 6);
        System.arraycopy(strArr4, 0, strArr5, length, 6);
        return strArr5;
    }

    public final String A02() {
        return "FacebookApplication.Fb4aCrashRemedy";
    }
}
