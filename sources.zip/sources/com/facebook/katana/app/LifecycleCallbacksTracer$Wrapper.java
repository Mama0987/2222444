package com.facebook.katana.app;

import X.AnonymousClass0WY;
import X.C11460iT;
import X.C15800sA;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import com.facebook.base.lwperf.traceutil.TraceUtil$Api18Utils;

public class LifecycleCallbacksTracer$Wrapper implements Application.ActivityLifecycleCallbacks {
    public final Application.ActivityLifecycleCallbacks callbacks;

    public LifecycleCallbacksTracer$Wrapper(Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        C15800sA.A0D(activityLifecycleCallbacks, 1);
        this.callbacks = activityLifecycleCallbacks;
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityCreated.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityCreated(activity, bundle);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivityDestroyed(Activity activity) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityDestroyed.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityDestroyed(activity);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivityPaused(Activity activity) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityPaused.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityPaused(activity);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivityResumed(Activity activity) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityResumed.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityResumed(activity);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        C15800sA.A0D(bundle, 1);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivitySaveInstanceState.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivitySaveInstanceState(activity, bundle);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivityStarted(Activity activity) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityStarted.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityStarted(activity);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public void onActivityStopped(Activity activity) {
        C15800sA.A0D(activity, 0);
        C11460iT.A00(AnonymousClass0WY.A0i("ActivityLifecycleCallbacks.onActivityStopped.", this.callbacks.getClass().getName()));
        try {
            this.callbacks.onActivityStopped(activity);
        } finally {
            TraceUtil$Api18Utils.endSection();
        }
    }

    public final Application.ActivityLifecycleCallbacks getCallbacks() {
        return this.callbacks;
    }
}
