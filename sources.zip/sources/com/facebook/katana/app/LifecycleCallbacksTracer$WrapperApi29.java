package com.facebook.katana.app;

import X.C15800sA;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public final class LifecycleCallbacksTracer$WrapperApi29 extends LifecycleCallbacksTracer$Wrapper {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LifecycleCallbacksTracer$WrapperApi29(Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        super(activityLifecycleCallbacks);
        C15800sA.A0D(activityLifecycleCallbacks, 1);
    }

    public void onActivityPostCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostCreated(activity, bundle);
    }

    public void onActivityPostDestroyed(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostDestroyed(activity);
    }

    public void onActivityPostPaused(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostPaused(activity);
    }

    public void onActivityPostResumed(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostResumed(activity);
    }

    public void onActivityPostSaveInstanceState(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        C15800sA.A0D(bundle, 1);
        this.callbacks.onActivityPostSaveInstanceState(activity, bundle);
    }

    public void onActivityPostStarted(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostStarted(activity);
    }

    public void onActivityPostStopped(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPostStopped(activity);
    }

    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPreCreated(activity, bundle);
    }

    public void onActivityPreDestroyed(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPreDestroyed(activity);
    }

    public void onActivityPrePaused(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPrePaused(activity);
    }

    public void onActivityPreResumed(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPreResumed(activity);
    }

    public void onActivityPreSaveInstanceState(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        C15800sA.A0D(bundle, 1);
        this.callbacks.onActivityPreSaveInstanceState(activity, bundle);
    }

    public void onActivityPreStarted(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPreStarted(activity);
    }

    public void onActivityPreStopped(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.callbacks.onActivityPreStopped(activity);
    }
}
