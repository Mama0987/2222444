package com.facebook.katana.app.mainactivity;

import X.C15800sA;
import android.app.Activity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.inputmethod.EditorInfoCompat;

public final class FbMainActivitySplashHelper$Api28 {
    public static final FbMainActivitySplashHelper$Api28 INSTANCE = new FbMainActivitySplashHelper$Api28();
    public static final int SYSTEM_UI_LIGHT_BARS = 8208;

    public final void configureUnderlay(Activity activity, boolean z, View view) {
        int systemUiVisibility;
        C15800sA.A0E(activity, 0, view);
        view.setSystemUiVisibility(1792 | view.getSystemUiVisibility());
        if (z) {
            systemUiVisibility = -8209 & view.getSystemUiVisibility();
        } else {
            systemUiVisibility = 8208 | view.getSystemUiVisibility();
        }
        view.setSystemUiVisibility(systemUiVisibility);
        activity.getWindowManager().addView(view, new WindowManager.LayoutParams(-1, -1, 1, -2147417832, -2));
    }

    public final void configureWindowAndSystemBars(Window window, boolean z) {
        int systemUiVisibility;
        C15800sA.A0D(window, 0);
        window.clearFlags(201326592);
        window.addFlags(EditorInfoCompat.IME_FLAG_FORCE_ASCII);
        View decorView = window.getDecorView();
        C15800sA.A09(decorView);
        decorView.setSystemUiVisibility(1792 | decorView.getSystemUiVisibility());
        window.setStatusBarColor(0);
        window.setNavigationBarColor(0);
        View decorView2 = window.getDecorView();
        if (z) {
            C15800sA.A09(decorView2);
            systemUiVisibility = -8209 & decorView2.getSystemUiVisibility();
        } else {
            C15800sA.A09(decorView2);
            systemUiVisibility = 8208 | decorView2.getSystemUiVisibility();
        }
        decorView2.setSystemUiVisibility(systemUiVisibility);
    }
}
