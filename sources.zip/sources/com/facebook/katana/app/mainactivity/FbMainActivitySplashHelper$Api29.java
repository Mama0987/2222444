package com.facebook.katana.app.mainactivity;

import X.C15800sA;
import android.view.Window;

public final class FbMainActivitySplashHelper$Api29 {
    public static final FbMainActivitySplashHelper$Api29 INSTANCE = new FbMainActivitySplashHelper$Api29();

    public final void configureWindowAndSystemBars(Window window, boolean z) {
        C15800sA.A0D(window, 0);
        window.setStatusBarContrastEnforced(false);
        window.setNavigationBarContrastEnforced(false);
        FbMainActivitySplashHelper$Api28.INSTANCE.configureWindowAndSystemBars(window, z);
    }
}
