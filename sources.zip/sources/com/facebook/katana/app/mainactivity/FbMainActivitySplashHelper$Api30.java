package com.facebook.katana.app.mainactivity;

import X.C15800sA;
import android.app.Activity;
import android.view.Window;
import android.view.WindowInsetsController;
import androidx.core.view.inputmethod.EditorInfoCompat;

public final class FbMainActivitySplashHelper$Api30 {
    public static final int APPEARANCE_LIGHT_BARS = 24;
    public static final FbMainActivitySplashHelper$Api30 INSTANCE = new FbMainActivitySplashHelper$Api30();

    public final void configureWindowAndSystemBars(Window window, boolean z) {
        C15800sA.A0D(window, 0);
        window.clearFlags(201326592);
        window.addFlags(EditorInfoCompat.IME_FLAG_FORCE_ASCII);
        int i = 0;
        window.setDecorFitsSystemWindows(false);
        window.setStatusBarColor(0);
        window.setNavigationBarColor(0);
        window.setStatusBarContrastEnforced(false);
        window.setNavigationBarContrastEnforced(false);
        WindowInsetsController windowInsetsController = window.getDecorView().getWindowInsetsController();
        if (windowInsetsController != null) {
            if (!z) {
                i = 24;
            }
            windowInsetsController.setSystemBarsAppearance(i, 24);
        }
    }

    public final void resetSystemBars(Activity activity) {
        C15800sA.A0D(activity, 0);
        Window window = activity.getWindow();
        WindowInsetsController windowInsetsController = window.getDecorView().getWindowInsetsController();
        if (windowInsetsController != null) {
            windowInsetsController.setSystemBarsAppearance(0, 24);
        }
        window.setDecorFitsSystemWindows(true);
    }
}
