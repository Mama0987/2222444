package com.facebook.katana.app.mainactivity;

import X.C03820Iv;
import X.C15800sA;
import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;

public final class FbMainActivitySplashHelper$ActivityRecreateLifecycleListener implements Application.ActivityLifecycleCallbacks {
    public final /* synthetic */ C03820Iv A00;

    public final void onActivityCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        boolean isFinishing = activity.isFinishing();
        int i = Build.VERSION.SDK_INT;
        if (!isFinishing) {
            if (i >= 30) {
                FbMainActivitySplashHelper$Api30.INSTANCE.resetSystemBars(activity);
            }
            activity.getApplication().unregisterActivityLifecycleCallbacks(this);
        } else if (i >= 31) {
            C03820Iv.A01(activity, this.A00, false);
        } else {
            FbMainActivitySplashHelper$Api28 fbMainActivitySplashHelper$Api28 = FbMainActivitySplashHelper$Api28.INSTANCE;
            C03820Iv r0 = this.A00;
            fbMainActivitySplashHelper$Api28.configureUnderlay(activity, r0.A07, C03820Iv.A00(r0, false));
        }
    }

    public FbMainActivitySplashHelper$ActivityRecreateLifecycleListener(C03820Iv r1) {
        this.A00 = r1;
    }

    public final void onActivityDestroyed(Activity activity) {
    }

    public final void onActivityPaused(Activity activity) {
    }

    public final void onActivityResumed(Activity activity) {
    }

    public final void onActivityStarted(Activity activity) {
    }

    public final void onActivityStopped(Activity activity) {
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
