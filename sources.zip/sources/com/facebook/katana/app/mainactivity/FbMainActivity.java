package com.facebook.katana.app.mainactivity;

import X.AnonymousClass036;
import X.AnonymousClass080;
import X.AnonymousClass0BS;
import X.AnonymousClass0HQ;
import X.AnonymousClass0S2;
import X.C011306f;
import X.C03810It;
import X.C03820Iv;
import X.C06300Vs;
import X.C11250i0;
import X.C12620kw;
import X.C15800sA;
import X.C18800y4;
import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import com.facebook.perf.background.BackgroundStartupDetector;
import java.lang.ref.WeakReference;

public final class FbMainActivity extends Activity implements AnonymousClass0HQ {
    public C03820Iv A00;
    public Intent A01;
    public Bundle A02;

    public final void onSaveInstanceState(Bundle bundle) {
        C15800sA.A0D(bundle, 0);
        if (this.A02 != null) {
            bundle.clear();
            bundle.putAll(this.A02);
        }
    }

    static {
        AnonymousClass036.A00 = new C03810It();
    }

    /* JADX INFO: finally extract failed */
    public final void finish() {
        AnonymousClass0S2.A01(this);
        if (C011306f.A04) {
            Intent intent = getIntent();
            try {
                setIntent(new Intent(intent));
                super.finish();
                setIntent(intent);
            } catch (Throwable th) {
                setIntent(intent);
                throw th;
            }
        } else {
            super.finish();
        }
    }

    /* JADX INFO: finally extract failed */
    public final void onBackPressed() {
        AnonymousClass0S2.A00(this);
        if (C011306f.A04) {
            Intent intent = getIntent();
            try {
                setIntent(new Intent(intent));
                super.onBackPressed();
                setIntent(intent);
            } catch (Throwable th) {
                setIntent(intent);
                throw th;
            }
        } else {
            super.onBackPressed();
        }
    }

    public final void onCreate(Bundle bundle) {
        C03820Iv r0;
        int A002 = AnonymousClass0BS.A00(60648454);
        Application application = getApplication();
        if (application == null) {
            C15800sA.A0J("null cannot be cast to non-null type com.facebook.base.app.NonBlockingApplication");
            throw C06300Vs.createAndThrow();
        }
        this.A00 = new C03820Iv(this, (C11250i0) application, (Integer) null);
        if (C12620kw.A01(this).A3p && (r0 = this.A00) != null) {
            r0.A05.setRequestedOrientation(1);
        }
        this.A01 = getIntent();
        if (bundle != null) {
            this.A02 = bundle;
        }
        AnonymousClass036.A04 = true;
        AnonymousClass080.A00.add(new WeakReference(this));
        if (Build.VERSION.SDK_INT > 35 && getApplicationInfo().targetSdkVersion > 35) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, new C18800y4(this));
        }
        super.onCreate((Bundle) null);
        C03820Iv r02 = this.A00;
        if (r02 != null) {
            r02.A03();
        }
        BackgroundStartupDetector backgroundStartupDetector = BackgroundStartupDetector.backgroundStartupDetector;
        if (backgroundStartupDetector != null) {
            backgroundStartupDetector.activityLifecycleCallbacks.onActivityCreated(this, (Bundle) null);
        }
        AnonymousClass0BS.A07(634873428, A002);
    }

    public final void onRestart() {
        int A002 = AnonymousClass0BS.A00(-1201230994);
        AnonymousClass0S2.A02(this);
        super.onRestart();
        AnonymousClass0BS.A07(-870339960, A002);
    }

    public final void onStart() {
        int A002 = AnonymousClass0BS.A00(1964188591);
        super.onStart();
        AnonymousClass080.A01.incrementAndGet();
        AnonymousClass0BS.A07(-1681412058, A002);
    }

    /* JADX INFO: finally extract failed */
    public final void onStop() {
        int A002 = AnonymousClass0BS.A00(1973764619);
        if (C011306f.A04) {
            Intent intent = getIntent();
            try {
                setIntent(new Intent(intent));
                super.onStop();
                setIntent(intent);
            } catch (Throwable th) {
                setIntent(intent);
                throw th;
            }
        } else {
            super.onStop();
        }
        AnonymousClass080.A01.decrementAndGet();
        AnonymousClass0BS.A07(-1920910454, A002);
    }

    public final void onUserLeaveHint() {
        AnonymousClass0S2.A03(this);
        super.onUserLeaveHint();
    }

    public final void onRestoreInstanceState(Bundle bundle) {
    }
}
