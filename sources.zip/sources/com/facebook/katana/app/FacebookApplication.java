package com.facebook.katana.app;

import X.AnonymousClass001;
import X.AnonymousClass108;
import X.AnonymousClass109;
import X.C11250i0;
import X.C11450iR;
import X.C12550kk;
import X.C15800sA;
import X.C18690xs;
import android.app.Application;
import java.io.File;
import java.util.ArrayList;

public final class FacebookApplication extends C11250i0 {
    public final C11450iR A00;
    public final Object A01 = AnonymousClass001.A0U();
    public final C18690xs A02 = new C18690xs();

    public final File getDir(String str, int i) {
        C15800sA.A0D(str, 0);
        File dir = super.getDir(str, i);
        C15800sA.A09(dir);
        return dir;
    }

    public final void registerActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        C15800sA.A0D(activityLifecycleCallbacks, 0);
        this.A02.A00(activityLifecycleCallbacks, this);
    }

    public final void unregisterActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        C15800sA.A0D(activityLifecycleCallbacks, 0);
        ArrayList arrayList = this.A02.A00;
        synchronized (arrayList) {
            int size = arrayList.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    break;
                }
                Object obj = arrayList.get(i);
                C15800sA.A09(obj);
                if (((LifecycleCallbacksTracer$Wrapper) obj).callbacks == activityLifecycleCallbacks) {
                    super.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks) arrayList.remove(i));
                    break;
                }
                i++;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x002a, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0026, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0027, code lost:
        X.C06520Wo.A00(r2, r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A0A() {
        /*
            r3 = this;
            X.0iR r1 = r3.A00
            java.lang.String r0 = "FacebookApplication.callOnSplashScreenDismissed"
            X.0iQ r2 = r1.A00(r0)
            com.facebook.errorreporting.field.ReportFieldString r1 = X.C14990qj.A9q     // Catch:{ all -> 0x0024 }
            java.lang.String r0 = "true"
            X.C14840qS.A08(r1, r0)     // Catch:{ all -> 0x0024 }
            super.A0A()     // Catch:{ all -> 0x0024 }
            android.os.Looper r0 = r3.getMainLooper()     // Catch:{ all -> 0x0024 }
            android.os.Handler r1 = new android.os.Handler     // Catch:{ all -> 0x0024 }
            r1.<init>(r0)     // Catch:{ all -> 0x0024 }
            X.06h r0 = X.AnonymousClass06h.A00     // Catch:{ all -> 0x0024 }
            r1.post(r0)     // Catch:{ all -> 0x0024 }
            r2.close()
            return
        L_0x0024:
            r1 = move-exception
            throw r1     // Catch:{ all -> 0x0026 }
        L_0x0026:
            r0 = move-exception
            X.C06520Wo.A00(r2, r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.katana.app.FacebookApplication.A0A():void");
    }

    public FacebookApplication() {
        AnonymousClass109 r2 = AnonymousClass108.A00;
        C15800sA.A0D(r2, 0);
        C11450iR r0 = new C11450iR(r2, 4003988);
        C12550kk.A01 = r0;
        this.A00 = r0;
    }

    public final void A0E(Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        super.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
    }
}
