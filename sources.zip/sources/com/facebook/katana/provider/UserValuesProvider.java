package com.facebook.katana.provider;

import X.C10640fx;

public class UserValuesProvider extends C10640fx {
}
