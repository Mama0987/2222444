package com.facebook.katana.provider;

import X.C10640fx;

public class FirstPartyUserValuesProvider extends C10640fx {
}
