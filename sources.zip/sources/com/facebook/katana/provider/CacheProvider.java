package com.facebook.katana.provider;

import X.C10640fx;

public class CacheProvider extends C10640fx {
}
