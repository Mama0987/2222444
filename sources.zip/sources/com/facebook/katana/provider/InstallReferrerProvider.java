package com.facebook.katana.provider;

import X.C10640fx;

public class InstallReferrerProvider extends C10640fx {
}
