package com.facebook.katana.liteprovider;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0OO;
import X.AnonymousClass0WY;
import X.C06130Uw;
import X.C06740Xs;
import X.C14390pf;
import X.C15800sA;
import X.C18280wf;
import X.C18830yF;
import android.content.Context;
import android.content.UriMatcher;
import android.database.MatrixCursor;
import android.net.Uri;

public final class FirstPartyUserValuesLiteProvider extends C18280wf {
    public static final String A01 = AnonymousClass0WY.A0i("com.facebook.katana", ".liteprovider.FirstPartyUserValuesLiteProvider");
    public final UriMatcher A00;

    public final MatrixCursor A05(Uri uri, String str) {
        MatrixCursor matrixCursor;
        String[] strArr;
        String[] strArr2;
        if (this.A00.match(uri) == 1) {
            MatrixCursor matrixCursor2 = new MatrixCursor(new String[]{C14390pf.ATTR_NAME, "value"});
            if (str == null) {
                return matrixCursor2;
            }
            int hashCode = str.hashCode();
            if (hashCode != 217257341) {
                if (hashCode != 730983340) {
                    if (hashCode != 1063606563 || !str.equals("name='saved_session_info'")) {
                        return matrixCursor2;
                    }
                    matrixCursor = new MatrixCursor(new String[]{C14390pf.ATTR_NAME, "value"});
                    String name = C18830yF.class.getName();
                    C15800sA.A09(name);
                    Context context = getContext();
                    if (context != null) {
                        strArr2 = C18830yF.A00(context, name, "account_switcher_data");
                    } else {
                        strArr2 = new String[0];
                    }
                    for (String str2 : strArr2) {
                        matrixCursor.addRow(new String[]{"name='saved_session_info'", str2});
                    }
                } else if (!str.equals("name='active_session_info'")) {
                    return matrixCursor2;
                } else {
                    matrixCursor = new MatrixCursor(new String[]{C14390pf.ATTR_NAME, "value"});
                    String name2 = C18830yF.class.getName();
                    C15800sA.A09(name2);
                    Context context2 = getContext();
                    if (context2 != null) {
                        strArr = C18830yF.A00(context2, name2, "sso_data");
                    } else {
                        strArr = new String[0];
                    }
                    for (String str3 : strArr) {
                        matrixCursor.addRow(new String[]{"name='active_session_info'", str3});
                    }
                }
                return matrixCursor;
            } else if (str.equals("name='all_session_info'")) {
                return A00();
            } else {
                return matrixCursor2;
            }
        } else {
            throw AnonymousClass002.A0G(uri, "Unsupported uri: ", AnonymousClass001.A0m());
        }
    }

    private final MatrixCursor A00() {
        String[] strArr;
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{C14390pf.ATTR_NAME, "value"});
        String name = C18830yF.class.getName();
        C15800sA.A09(name);
        Context context = getContext();
        if (context != null) {
            strArr = (String[]) C06740Xs.A0W(C18830yF.A00(context, name, "sso_data"), C18830yF.A00(context, name, "account_switcher_data"));
        } else {
            strArr = new String[0];
        }
        for (String str : strArr) {
            matrixCursor.addRow(new String[]{"name='all_session_info'", str});
        }
        return matrixCursor;
    }

    public final void A06() {
        this.A00.addURI(A01, "user_values", 1);
    }

    public final C06130Uw A07() {
        return new AnonymousClass0OO("com.facebook.katana.fbpermission.LITE_PROVIDER_ACCESS");
    }

    public final C06130Uw A08() {
        return new AnonymousClass0OO("com.facebook.katana.fbpermission.LITE_PROVIDER_ACCESS");
    }

    public FirstPartyUserValuesLiteProvider(int i) {
    }

    public FirstPartyUserValuesLiteProvider() {
        this.A00 = new UriMatcher(-1);
    }
}
