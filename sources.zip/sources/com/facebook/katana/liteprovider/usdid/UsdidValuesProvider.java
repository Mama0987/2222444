package com.facebook.katana.liteprovider.usdid;

import X.C10640fx;

public final class UsdidValuesProvider extends C10640fx {
}
