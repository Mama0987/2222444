package com.facebook.perf.background;

import X.AnonymousClass001;
import X.AnonymousClass0Ft;
import X.AnonymousClass0GG;
import X.C14270pR;
import X.C14730qH;
import X.C15800sA;
import X.C18650xk;
import X.C19060yq;
import X.C210215z;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class BackgroundStartupDetector {
    public static final int ACTIVITY_CREATE_QUEUE_DRAINED = 49182;
    public static final int ACTIVITY_REDIRECT_LAUNCH_TIMEOUT_MS = 200;
    public static final int COLDSTART_QUEUE_DRAINED = 49181;
    public static final C19060yq Companion = new Object();
    public static volatile int _coldStartMode = 0;
    public static volatile AnonymousClass0GG abandonedActivityStartListener = null;
    public static volatile BackgroundStartupDetector backgroundStartupDetector = null;
    public static volatile int backgroundedCount = 0;
    public static ArrayList getColdStartModeCallbacks = AnonymousClass001.A0t();
    public static boolean isActivityStackStart = false;
    public static AnonymousClass0Ft isBackgroundListener = null;
    public static volatile Boolean isBackgroundState = null;
    public static volatile boolean isBackgroundedNotYetResumed = true;
    public static final CopyOnWriteArraySet listeners = new CopyOnWriteArraySet();
    public static C14730qH reliabilityListener;
    public static String tag;
    public int activitiesStartedSinceLastColdStartQueueDrain;
    public boolean activityIsRecreating;
    public final BackgroundStartupDetector$activityLifecycleCallbacks$1 activityLifecycleCallbacks;
    public boolean activityQueueAlreadyDrained;
    public int activityResumeCount;
    public int activityStartCount;
    public boolean anyActivityCreated;
    public final int coldStartQueueDrainMessageCount;
    public final C210215z handler;
    public boolean isColdStartQueueDrained;
    public int sentMessageCount;
    public boolean wasInconclusiveColdStart;

    public static final BackgroundStartupDetector installFromApplicationOnCreate(Application application, boolean z) {
        C15800sA.A0D(application, 0);
        return C19060yq.A00(application, z, false);
    }

    public static final void onActivityCreated(Activity activity) {
        C15800sA.A0D(activity, 0);
        BackgroundStartupDetector backgroundStartupDetector2 = backgroundStartupDetector;
        if (backgroundStartupDetector2 != null) {
            backgroundStartupDetector2.activityLifecycleCallbacks.onActivityCreated(activity, (Bundle) null);
        }
    }

    public static final void onBeforeActivityInstantiated(String str) {
        C15800sA.A0D(str, 0);
        BackgroundStartupDetector backgroundStartupDetector2 = backgroundStartupDetector;
        if (backgroundStartupDetector2 != null) {
            backgroundStartupDetector2.activityCreateInternal(str);
        }
    }

    public static final void removeListener(C14730qH r1) {
        C15800sA.A0D(r1, 0);
        listeners.remove(r1);
    }

    public static final void resetReliabilityListener() {
        reliabilityListener = null;
    }

    /* access modifiers changed from: private */
    public final void activityCreateInternal(String str) {
        boolean z = this.anyActivityCreated;
        this.activityIsRecreating = false;
        if (!z) {
            this.anyActivityCreated = true;
            if (!this.isColdStartQueueDrained) {
                Companion.setColdStartMode(4);
            }
        }
        if (this.activityStartCount == 0) {
            C19060yq.A01(false);
            this.activityQueueAlreadyDrained = false;
            this.handler.removeMessages(ACTIVITY_CREATE_QUEUE_DRAINED);
            this.handler.sendEmptyMessage(ACTIVITY_CREATE_QUEUE_DRAINED);
        }
    }

    public static final void addListener(C14730qH r2) {
        C19060yq r1 = Companion;
        C15800sA.A0D(r2, 0);
        listeners.add(r2);
        r2.CeF();
        r2.CvO(Boolean.valueOf(r1.A03()));
    }

    public static final void getColdStartMode(C18650xk r1) {
        Companion.A02(r1);
    }

    /* access modifiers changed from: private */
    public final void handleActivityCreateQueueDrained() {
        if (!this.activityQueueAlreadyDrained) {
            this.activityQueueAlreadyDrained = true;
            C210215z r3 = this.handler;
            r3.sendMessageDelayed(Message.obtain(r3, ACTIVITY_CREATE_QUEUE_DRAINED), 200);
        } else if (this.activityStartCount == 0 && this.activityResumeCount == 0 && !this.activityIsRecreating) {
            C14270pR.A0G(tag, "ActivityCreateQueue drained. Activity likely self-finished or redirected to another process.");
            C19060yq.A01(true);
            backgroundedCount++;
            AnonymousClass0GG r0 = abandonedActivityStartListener;
            if (r0 != null) {
                r0.CTx();
            }
        }
    }

    /* access modifiers changed from: private */
    public final void handleColdStartQueueDrained() {
        if (this.sentMessageCount >= this.coldStartQueueDrainMessageCount || this.anyActivityCreated) {
            if (!this.isColdStartQueueDrained) {
                this.isColdStartQueueDrained = true;
                boolean z = false;
                if (this.activitiesStartedSinceLastColdStartQueueDrain > 1) {
                    z = true;
                }
                isActivityStackStart = z;
                this.activitiesStartedSinceLastColdStartQueueDrain = 0;
            }
            if (!this.anyActivityCreated) {
                C19060yq r2 = Companion;
                int i = 1;
                if (this.wasInconclusiveColdStart) {
                    i = 2;
                }
                r2.setColdStartMode(i);
                C19060yq.A01(true);
            } else if (this.activityResumeCount > 0) {
                C19060yq r22 = Companion;
                int i2 = 3;
                if (this.wasInconclusiveColdStart) {
                    i2 = 4;
                }
                r22.setColdStartMode(i2);
            } else {
                this.anyActivityCreated = false;
                this.wasInconclusiveColdStart = true;
                C210215z r3 = this.handler;
                r3.sendMessageDelayed(Message.obtain(r3, COLDSTART_QUEUE_DRAINED), 200);
            }
        } else {
            this.handler.sendEmptyMessage(COLDSTART_QUEUE_DRAINED);
            this.sentMessageCount++;
        }
    }

    public static final void initializeForTest(BackgroundStartupDetector backgroundStartupDetector2) {
        Companion.initializeForTest(backgroundStartupDetector2);
    }

    public static final boolean isBackground() {
        return Companion.A03();
    }

    public static final boolean isInstalled() {
        if (backgroundStartupDetector != null) {
            return true;
        }
        return false;
    }

    public static final void setActivityIsRecreating() {
        BackgroundStartupDetector backgroundStartupDetector2 = backgroundStartupDetector;
        if (backgroundStartupDetector2 != null) {
            backgroundStartupDetector2.activityIsRecreating = true;
        }
    }

    public static final void setIsBackgroundListener(AnonymousClass0Ft r2) {
        C19060yq r1 = Companion;
        C15800sA.A0D(r2, 0);
        if (isBackgroundListener == null) {
            isBackgroundListener = r2;
            r2.CvP(r1.A03());
            return;
        }
        throw AnonymousClass001.A0r("Only one listener is supported at this time.");
    }

    public static final synchronized void setReliabilityListener(C14730qH r3) {
        synchronized (BackgroundStartupDetector.class) {
            synchronized (Companion) {
                C15800sA.A0D(r3, 0);
                if (reliabilityListener == null) {
                    reliabilityListener = r3;
                    r3.CeF();
                    r3.CvO(isBackgroundState);
                } else {
                    throw AnonymousClass001.A0r("Only one reliability listener is supported at this time.");
                }
            }
        }
    }

    public static final boolean wasForegroundColdStart() {
        int i = _coldStartMode;
        if (i == 3 || i == 4) {
            return true;
        }
        return false;
    }

    public BackgroundStartupDetector(Looper looper, int i) {
        this.coldStartQueueDrainMessageCount = i;
        this.sentMessageCount = 1;
        this.handler = new C210215z(looper, this, 0);
        this.activityLifecycleCallbacks = new BackgroundStartupDetector$activityLifecycleCallbacks$1(this);
    }

    public static final int getBackgroundedCount() {
        return backgroundedCount;
    }

    public static final boolean isActivityStackStart() {
        return isActivityStackStart;
    }

    public static final Boolean isBackgroundState() {
        return isBackgroundState;
    }

    public static final boolean isBackgroundedNotYetResumed() {
        return isBackgroundedNotYetResumed;
    }

    public static final void setAbandonedActivityStartListener(AnonymousClass0GG r0) {
        abandonedActivityStartListener = r0;
    }

    public /* synthetic */ BackgroundStartupDetector(Looper looper, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(looper, i);
    }

    public static final int getColdStartMode() {
        return _coldStartMode;
    }

    public static final BackgroundStartupDetector installFromApplicationOnCreate(Application application, boolean z, boolean z2) {
        return C19060yq.A00(application, z, z2);
    }

    public static final BackgroundStartupDetector installFromApplicationOnCreate(Application application) {
        C15800sA.A0D(application, 0);
        return C19060yq.A00(application, false, false);
    }
}
