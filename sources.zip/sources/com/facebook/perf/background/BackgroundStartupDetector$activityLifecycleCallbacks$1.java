package com.facebook.perf.background;

import X.AnonymousClass001;
import X.C15800sA;
import X.C19060yq;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public final class BackgroundStartupDetector$activityLifecycleCallbacks$1 implements Application.ActivityLifecycleCallbacks {
    public final /* synthetic */ BackgroundStartupDetector A00;

    public final void onActivityCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        BackgroundStartupDetector backgroundStartupDetector = this.A00;
        String A0b = AnonymousClass001.A0b(activity);
        C15800sA.A09(A0b);
        backgroundStartupDetector.activityCreateInternal(A0b);
    }

    public final void onActivityPaused(Activity activity) {
        C15800sA.A0D(activity, 0);
        BackgroundStartupDetector backgroundStartupDetector = this.A00;
        backgroundStartupDetector.activityResumeCount--;
    }

    public final void onActivityResumed(Activity activity) {
        C15800sA.A0D(activity, 0);
        this.A00.activityResumeCount++;
        BackgroundStartupDetector.isBackgroundedNotYetResumed = false;
    }

    public final void onActivityStarted(Activity activity) {
        C15800sA.A0D(activity, 0);
        BackgroundStartupDetector backgroundStartupDetector = this.A00;
        backgroundStartupDetector.activityStartCount++;
        backgroundStartupDetector.activitiesStartedSinceLastColdStartQueueDrain++;
        C19060yq.A01(false);
        backgroundStartupDetector.handler.removeMessages(BackgroundStartupDetector.ACTIVITY_CREATE_QUEUE_DRAINED);
    }

    public final void onActivityStopped(Activity activity) {
        C15800sA.A0D(activity, 0);
        BackgroundStartupDetector backgroundStartupDetector = this.A00;
        int i = backgroundStartupDetector.activityStartCount - 1;
        backgroundStartupDetector.activityStartCount = i;
        if (i == 0 && backgroundStartupDetector.activityResumeCount == 0 && !backgroundStartupDetector.activityIsRecreating) {
            BackgroundStartupDetector.backgroundedCount++;
            BackgroundStartupDetector.isBackgroundedNotYetResumed = true;
            C19060yq.A01(true);
        }
    }

    public BackgroundStartupDetector$activityLifecycleCallbacks$1(BackgroundStartupDetector backgroundStartupDetector) {
        this.A00 = backgroundStartupDetector;
    }

    public final void onActivityDestroyed(Activity activity) {
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
