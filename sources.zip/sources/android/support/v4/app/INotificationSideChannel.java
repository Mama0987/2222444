package android.support.v4.app;

import android.os.IInterface;

public interface INotificationSideChannel extends IInterface {
    public static final String A00 = "android$support$v4$app$INotificationSideChannel".replace('$', '.');
}
