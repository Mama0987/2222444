package android.support.v4.app;

import X.AnonymousClass0BS;
import android.os.IBinder;

public final class INotificationSideChannel$Stub$Proxy implements INotificationSideChannel {
    public IBinder A00;

    public final IBinder asBinder() {
        int A03 = AnonymousClass0BS.A03(-606491721);
        IBinder iBinder = this.A00;
        AnonymousClass0BS.A09(538711793, A03);
        return iBinder;
    }
}
