package kotlin.enums;

import X.AnonymousClass0XX;
import java.lang.Enum;
import java.util.List;

public interface EnumEntries<E extends Enum<E>> extends List<E>, AnonymousClass0XX {
}
