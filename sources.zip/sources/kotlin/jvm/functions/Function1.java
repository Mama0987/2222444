package kotlin.jvm.functions;

import X.C06420We;

public interface Function1 extends C06420We {
    Object invoke(Object obj);
}
