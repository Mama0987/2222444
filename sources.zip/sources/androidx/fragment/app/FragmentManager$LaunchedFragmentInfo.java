package androidx.fragment.app;

import X.AnonymousClass16O;
import android.os.Parcel;
import android.os.Parcelable;

public final class FragmentManager$LaunchedFragmentInfo implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16O(2);
    public int A00;
    public String A01;

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.A01);
        parcel.writeInt(this.A00);
    }

    public final int describeContents() {
        return 0;
    }
}
