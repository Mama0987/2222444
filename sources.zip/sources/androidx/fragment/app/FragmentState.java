package androidx.fragment.app;

import X.AnonymousClass001;
import X.AnonymousClass0D6;
import X.AnonymousClass16O;
import X.C09740eO;
import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.common.dextricks.DalvikInternals;

public final class FragmentState implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16O(4);
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final String A04;
    public final String A05;
    public final boolean A06;
    public final boolean A07;
    public final boolean A08;
    public final boolean A09;
    public final boolean A0A;
    public final boolean A0B;
    public final boolean A0C;
    public final String mClassName;
    public final String mWho;

    public final Fragment A00(AnonymousClass0D6 r4) {
        Fragment A002 = r4.A00(this.mClassName);
        A002.mWho = this.mWho;
        A002.mFromLayout = this.A07;
        A002.mInDynamicContainer = this.A09;
        A002.mRestored = true;
        A002.mFragmentId = this.A01;
        A002.mContainerId = this.A00;
        A002.mTag = this.A04;
        A002.mRetainInstance = this.A0B;
        A002.mRemoving = this.A0A;
        A002.mDetached = this.A06;
        A002.mHidden = this.A08;
        A002.mMaxState = C09740eO.values()[this.A02];
        A002.mTargetWho = this.A05;
        A002.mTargetRequestCode = this.A03;
        A002.mUserVisibleHint = this.A0C;
        return A002;
    }

    public final String toString() {
        StringBuilder A0n = AnonymousClass001.A0n(DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS);
        A0n.append("FragmentState{");
        A0n.append(this.mClassName);
        A0n.append(" (");
        A0n.append(this.mWho);
        A0n.append(")}:");
        if (this.A07) {
            A0n.append(" fromLayout");
        }
        if (this.A09) {
            A0n.append(" dynamicContainer");
        }
        int i = this.A00;
        if (i != 0) {
            A0n.append(" id=0x");
            A0n.append(Integer.toHexString(i));
        }
        String str = this.A04;
        if (str != null && !str.isEmpty()) {
            A0n.append(" tag=");
            A0n.append(str);
        }
        if (this.A0B) {
            A0n.append(" retainInstance");
        }
        if (this.A0A) {
            A0n.append(" removing");
        }
        if (this.A06) {
            A0n.append(" detached");
        }
        if (this.A08) {
            A0n.append(" hidden");
        }
        String str2 = this.A05;
        if (str2 != null) {
            A0n.append(" targetWho=");
            A0n.append(str2);
            A0n.append(" targetRequestCode=");
            A0n.append(this.A03);
        }
        if (this.A0C) {
            A0n.append(" userVisibleHint");
        }
        return A0n.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mClassName);
        parcel.writeString(this.mWho);
        parcel.writeInt(this.A07 ? 1 : 0);
        parcel.writeInt(this.A09 ? 1 : 0);
        parcel.writeInt(this.A01);
        parcel.writeInt(this.A00);
        parcel.writeString(this.A04);
        parcel.writeInt(this.A0B ? 1 : 0);
        parcel.writeInt(this.A0A ? 1 : 0);
        parcel.writeInt(this.A06 ? 1 : 0);
        parcel.writeInt(this.A08 ? 1 : 0);
        parcel.writeInt(this.A02);
        parcel.writeString(this.A05);
        parcel.writeInt(this.A03);
        parcel.writeInt(this.A0C ? 1 : 0);
    }

    public FragmentState(Parcel parcel) {
        this.mClassName = parcel.readString();
        this.mWho = parcel.readString();
        boolean z = true;
        this.A07 = AnonymousClass001.A1R(parcel.readInt());
        this.A09 = AnonymousClass001.A1R(parcel.readInt());
        this.A01 = parcel.readInt();
        this.A00 = parcel.readInt();
        this.A04 = parcel.readString();
        this.A0B = AnonymousClass001.A1R(parcel.readInt());
        this.A0A = AnonymousClass001.A1R(parcel.readInt());
        this.A06 = AnonymousClass001.A1R(parcel.readInt());
        this.A08 = AnonymousClass001.A1R(parcel.readInt());
        this.A02 = parcel.readInt();
        this.A05 = parcel.readString();
        this.A03 = parcel.readInt();
        this.A0C = parcel.readInt() == 0 ? false : z;
    }

    public final int describeContents() {
        return 0;
    }

    public FragmentState(Fragment fragment) {
        this.mClassName = fragment.getClass().getName();
        this.mWho = fragment.mWho;
        this.A07 = fragment.mFromLayout;
        this.A09 = fragment.mInDynamicContainer;
        this.A01 = fragment.mFragmentId;
        this.A00 = fragment.mContainerId;
        this.A04 = fragment.mTag;
        this.A0B = fragment.mRetainInstance;
        this.A0A = fragment.mRemoving;
        this.A06 = fragment.mDetached;
        this.A08 = fragment.mHidden;
        this.A02 = fragment.mMaxState.ordinal();
        this.A05 = fragment.mTargetWho;
        this.A03 = fragment.mTargetRequestCode;
        this.A0C = fragment.mUserVisibleHint;
    }
}
