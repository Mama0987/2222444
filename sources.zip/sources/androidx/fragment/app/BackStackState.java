package androidx.fragment.app;

import X.AnonymousClass16O;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

public final class BackStackState implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16O(1);
    public final List A00;
    public final List A01;

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.A00);
        parcel.writeTypedList(this.A01);
    }

    public BackStackState(List list, List list2) {
        this.A00 = list;
        this.A01 = list2;
    }

    public final int describeContents() {
        return 0;
    }

    public BackStackState(Parcel parcel) {
        this.A00 = parcel.createStringArrayList();
        this.A01 = parcel.createTypedArrayList(BackStackRecordState.CREATOR);
    }
}
