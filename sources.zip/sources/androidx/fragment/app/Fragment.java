package androidx.fragment.app;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass084;
import X.AnonymousClass085;
import X.AnonymousClass086;
import X.AnonymousClass087;
import X.AnonymousClass089;
import X.AnonymousClass08C;
import X.AnonymousClass08K;
import X.AnonymousClass08M;
import X.AnonymousClass08N;
import X.AnonymousClass08Q;
import X.AnonymousClass0BS;
import X.AnonymousClass0BZ;
import X.AnonymousClass0D1;
import X.AnonymousClass0D6;
import X.AnonymousClass0E0;
import X.AnonymousClass0GJ;
import X.AnonymousClass0HT;
import X.AnonymousClass0Hh;
import X.AnonymousClass0LO;
import X.AnonymousClass0Ou;
import X.AnonymousClass0P2;
import X.AnonymousClass0PP;
import X.AnonymousClass0PT;
import X.AnonymousClass0PU;
import X.AnonymousClass0PV;
import X.AnonymousClass0PW;
import X.AnonymousClass0WJ;
import X.AnonymousClass0WK;
import X.AnonymousClass0WM;
import X.AnonymousClass0WY;
import X.AnonymousClass0XY;
import X.C013307i;
import X.C02230Ba;
import X.C02530Ci;
import X.C02560Cl;
import X.C02570Cm;
import X.C02820Dz;
import X.C03390Gt;
import X.C03490Hd;
import X.C03510Hf;
import X.C04310Ld;
import X.C05030Os;
import X.C05040Ot;
import X.C05100Pf;
import X.C06460Wi;
import X.C09240dV;
import X.C09250dW;
import X.C09260dX;
import X.C09460dr;
import X.C09590e4;
import X.C09730eN;
import X.C09740eO;
import X.C09750eP;
import X.C09780eT;
import X.C10100f1;
import X.C15800sA;
import X.C212616x;
import X.C212716y;
import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.result.IntentSenderRequest;
import com.facebook.common.dextricks.DalvikInternals;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class Fragment implements C06460Wi, C05030Os, C05040Ot, AnonymousClass0Ou, AnonymousClass0P2, ComponentCallbacks, View.OnCreateContextMenuListener {
    public static final int ACTIVITY_CREATED = 4;
    public static final int ATTACHED = 0;
    public static final int AWAITING_ENTER_EFFECTS = 6;
    public static final int AWAITING_EXIT_EFFECTS = 3;
    public static final int CREATED = 1;
    public static final int INITIALIZING = -1;
    public static final int RESUMED = 7;
    public static final int STARTED = 5;
    public static final Object USE_DEFAULT_TRANSITION = AnonymousClass001.A0U();
    public static final int VIEW_CREATED = 2;
    public boolean mAdded;
    public AnonymousClass08K mAnimationInfo;
    public Bundle mArguments;
    public int mBackStackNesting;
    public boolean mBeingSaved;
    public boolean mCalled;
    public AnonymousClass0PW mChildFragmentManager;
    public ViewGroup mContainer;
    public int mContainerId;
    public int mContentLayoutId;
    public C03490Hd mDefaultFactory;
    public boolean mDeferStart;
    public boolean mDetached;
    public int mFragmentId;
    public AnonymousClass0PW mFragmentManager;
    public boolean mFromLayout;
    public boolean mHasMenu;
    public boolean mHidden;
    public boolean mHiddenChanged;
    public AnonymousClass0PT mHost;
    public boolean mInDynamicContainer;
    public boolean mInLayout;
    public boolean mIsCreated;
    public Boolean mIsPrimaryNavigationFragment;
    public LayoutInflater mLayoutInflater;
    public C09780eT mLifecycleRegistry;
    public C09740eO mMaxState;
    public boolean mMenuVisible;
    public final AtomicInteger mNextLocalRequestCode;
    public final ArrayList mOnPreAttachedListeners;
    public Fragment mParentFragment;
    public boolean mPerformedCreateView;
    public Runnable mPostponedDurationRunnable;
    public Handler mPostponedHandler;
    public String mPreviousWho;
    public boolean mRemoving;
    public boolean mRestored;
    public boolean mRetainInstance;
    public boolean mRetainInstanceChangedWhileDetached;
    public Bundle mSavedFragmentState;
    public final AnonymousClass0GJ mSavedStateAttachListener;
    public C02560Cl mSavedStateRegistryController;
    public Boolean mSavedUserVisibleHint;
    public Bundle mSavedViewRegistryState;
    public SparseArray mSavedViewState;
    public int mState;
    public String mTag;
    public Fragment mTarget;
    public int mTargetRequestCode;
    public String mTargetWho;
    public boolean mTransitioning;
    public boolean mUserVisibleHint;
    public View mView;
    public AnonymousClass08N mViewLifecycleOwner;
    public AnonymousClass0E0 mViewLifecycleOwnerLiveData;
    public String mWho;

    public final class SavedState implements Parcelable {
        public static final Parcelable.Creator CREATOR = new C212716y(1);
        public final Bundle A00;

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeBundle(this.A00);
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            Bundle readBundle = parcel.readBundle();
            this.A00 = readBundle;
            if (classLoader != null && readBundle != null) {
                readBundle.setClassLoader(classLoader);
            }
        }

        public final int describeContents() {
            return 0;
        }

        public SavedState(Bundle bundle) {
            this.A00 = bundle;
        }
    }

    private void initLifecycle() {
        this.mLifecycleRegistry = new C09780eT(this, true);
        this.mSavedStateRegistryController = C02530Ci.A00(this);
        this.mDefaultFactory = null;
        if (!this.mOnPreAttachedListeners.contains(this.mSavedStateAttachListener)) {
            registerOnPreAttachListener(this.mSavedStateAttachListener);
        }
    }

    @Deprecated
    public static Fragment instantiate(Context context, String str) {
        return instantiate(context, str, (Bundle) null);
    }

    private AnonymousClass0Hh prepareCallInternal(C03390Gt r7, C05100Pf r8, C03510Hf r9) {
        if (this.mState <= 1) {
            AtomicReference atomicReference = new AtomicReference();
            registerOnPreAttachListener(new AnonymousClass0WK(r9, r7, r8, this, atomicReference));
            return new AnonymousClass0WM(r7, this, atomicReference);
        }
        throw AnonymousClass002.A0I(" is attempting to registerForActivityResult after being created. Fragments must call registerForActivityResult() before they are created (i.e. initialization, onAttach(), or onCreate()).", AnonymousClass002.A0T(this));
    }

    public void onAttach(Context context) {
        Activity activity;
        this.mCalled = true;
        AnonymousClass0PT r0 = this.mHost;
        if (r0 != null && (activity = r0.A00) != null) {
            this.mCalled = false;
            onAttach(activity);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.mCalled = true;
    }

    public void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.mCalled = true;
        AnonymousClass0PT r0 = this.mHost;
        if (r0 != null && r0.A00 != null) {
            this.mCalled = false;
            this.mCalled = true;
        }
    }

    public void onLowMemory() {
        this.mCalled = true;
    }

    public void performDetach() {
        this.mState = -1;
        this.mCalled = false;
        onDetach();
        this.mLayoutInflater = null;
        if (this.mCalled) {
            AnonymousClass0PW r1 = this.mChildFragmentManager;
            if (!r1.A0F) {
                r1.A0Y();
                this.mChildFragmentManager = new AnonymousClass0PW();
                return;
            }
            return;
        }
        throw A00(" did not call through to super.onDetach()", AnonymousClass002.A0T(this));
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i) {
        startActivityForResult(intent, i, (Bundle) null);
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [androidx.fragment.app.FragmentManager$LaunchedFragmentInfo, java.lang.Object] */
    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        Intent intent2 = intent;
        if (this.mHost != null) {
            AnonymousClass0PW parentFragmentManager = getParentFragmentManager();
            IntentSender intentSender2 = intentSender;
            int i5 = i2;
            int i6 = i3;
            Bundle bundle2 = bundle;
            if (parentFragmentManager.A04 != null) {
                if (bundle != null) {
                    if (intent == null) {
                        intent2 = new Intent();
                        intent2.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
                    }
                    intent2.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle2);
                }
                C15800sA.A0D(intentSender, 1);
                IntentSenderRequest intentSenderRequest = new IntentSenderRequest(intent2, intentSender, i2, i6);
                String str = this.mWho;
                ? obj = new Object();
                obj.A01 = str;
                obj.A00 = i;
                parentFragmentManager.A0C.addLast(obj);
                parentFragmentManager.A04.A02(intentSenderRequest);
                return;
            }
            AnonymousClass0PT r1 = parentFragmentManager.A09;
            C15800sA.A0D(intentSender, 1);
            if (i == -1) {
                Activity activity = r1.A00;
                if (activity != null) {
                    activity.startIntentSenderForResult(intentSender2, -1, intent2, i5, i6, i4, bundle2);
                    return;
                }
                throw AnonymousClass001.A0P("Starting intent sender with a requestCode requires a FragmentActivity host");
            }
            throw AnonymousClass001.A0P("Starting intent sender with a requestCode requires a FragmentActivity host");
        }
        StringBuilder A0o = AnonymousClass001.A0o("Fragment ");
        A0o.append(this);
        throw AnonymousClass002.A0I(" not attached to Activity", A0o);
    }

    public void unregisterForContextMenu(View view) {
        view.setOnCreateContextMenuListener((View.OnCreateContextMenuListener) null);
    }

    private AnonymousClass08K ensureAnimationInfo() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 != null) {
            return r0;
        }
        AnonymousClass08K r02 = new AnonymousClass08K();
        this.mAnimationInfo = r02;
        return r02;
    }

    private int getMinimumMaxLifecycleState() {
        Fragment fragment;
        C09740eO r1 = this.mMaxState;
        if (r1 == C09740eO.INITIALIZED || (fragment = this.mParentFragment) == null) {
            return r1.ordinal();
        }
        return Math.min(r1.ordinal(), fragment.getMinimumMaxLifecycleState());
    }

    private Fragment getTargetFragment(boolean z) {
        String str;
        if (z) {
            AnonymousClass086 r0 = AnonymousClass086.A01;
            AnonymousClass0HT r3 = new AnonymousClass0HT(AnonymousClass002.A0M(this, "Attempting to get target fragment from fragment ", AnonymousClass001.A0m()), this);
            AnonymousClass087 A00 = AnonymousClass086.A00(this);
            if (A00.A01.contains(AnonymousClass089.DETECT_TARGET_FRAGMENT_USAGE)) {
                AnonymousClass002.A0a(A00, r3, this);
            }
        }
        Fragment fragment = this.mTarget;
        if (fragment != null) {
            return fragment;
        }
        AnonymousClass0PW r02 = this.mFragmentManager;
        if (r02 == null || (str = this.mTargetWho) == null) {
            return null;
        }
        return r02.A0U.A01(str);
    }

    private void registerOnPreAttachListener(AnonymousClass0GJ r2) {
        if (this.mState >= 0) {
            r2.A00();
        } else {
            this.mOnPreAttachedListeners.add(r2);
        }
    }

    public void callStartTransitionListener(boolean z) {
        ViewGroup viewGroup;
        AnonymousClass0PW r0;
        AnonymousClass08K r1 = this.mAnimationInfo;
        if (r1 != null) {
            r1.A0J = false;
        }
        if (this.mView != null && (viewGroup = this.mContainer) != null && (r0 = this.mFragmentManager) != null) {
            AnonymousClass08Q A00 = AnonymousClass08Q.A00(viewGroup, r0);
            A00.A08();
            if (z) {
                this.mHost.A02.post(new C09250dW(this, A00));
            } else {
                A00.A06();
            }
            Handler handler = this.mPostponedHandler;
            if (handler != null) {
                handler.removeCallbacks(this.mPostponedDurationRunnable);
                this.mPostponedHandler = null;
            }
        }
    }

    public AnonymousClass0PU createFragmentContainer() {
        return new AnonymousClass08C(this);
    }

    public Fragment findFragmentByWho(String str) {
        if (str.equals(this.mWho)) {
            return this;
        }
        return this.mChildFragmentManager.A0U.A02(str);
    }

    public String generateActivityResultKey() {
        return AnonymousClass0WY.A0N(this.mNextLocalRequestCode.getAndIncrement(), "fragment_", this.mWho, "_rq#");
    }

    public final FragmentActivity getActivity() {
        AnonymousClass0PT r0 = this.mHost;
        if (r0 == null) {
            return null;
        }
        return (FragmentActivity) r0.A00;
    }

    public boolean getAllowEnterTransitionOverlap() {
        Boolean bool;
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null || (bool = r0.A09) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public boolean getAllowReturnTransitionOverlap() {
        Boolean bool;
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null || (bool = r0.A0A) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public final AnonymousClass0PW getChildFragmentManager() {
        if (this.mHost != null) {
            return this.mChildFragmentManager;
        }
        throw AnonymousClass002.A0I(" has not been attached yet.", AnonymousClass002.A0T(this));
    }

    public Context getContext() {
        AnonymousClass0PT r0 = this.mHost;
        if (r0 == null) {
            return null;
        }
        return r0.A01;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x001a, code lost:
        if (r2 == null) goto L_0x001c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0021, code lost:
        if (X.AnonymousClass0PW.A0H(3) == false) goto L_0x002a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0023, code lost:
        requireContext().getApplicationContext();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public X.C03490Hd getDefaultViewModelProviderFactory() {
        /*
            r3 = this;
            X.0PW r0 = r3.mFragmentManager
            if (r0 == 0) goto L_0x003d
            X.0Hd r0 = r3.mDefaultFactory
            if (r0 != 0) goto L_0x0033
            android.content.Context r0 = r3.requireContext()
            android.content.Context r2 = r0.getApplicationContext()
        L_0x0010:
            boolean r0 = r2 instanceof android.content.ContextWrapper
            if (r0 == 0) goto L_0x003b
            boolean r0 = r2 instanceof android.app.Application
            if (r0 == 0) goto L_0x0034
            android.app.Application r2 = (android.app.Application) r2
            if (r2 != 0) goto L_0x002a
        L_0x001c:
            r0 = 3
            boolean r0 = X.AnonymousClass0PW.A0H(r0)
            if (r0 == 0) goto L_0x002a
            android.content.Context r0 = r3.requireContext()
            r0.getApplicationContext()
        L_0x002a:
            android.os.Bundle r1 = r3.mArguments
            X.0V4 r0 = new X.0V4
            r0.<init>(r2, r1, r3)
            r3.mDefaultFactory = r0
        L_0x0033:
            return r0
        L_0x0034:
            android.content.ContextWrapper r2 = (android.content.ContextWrapper) r2
            android.content.Context r2 = r2.getBaseContext()
            goto L_0x0010
        L_0x003b:
            r2 = 0
            goto L_0x001c
        L_0x003d:
            java.lang.String r0 = "Can't access ViewModels from detached fragment"
            java.lang.IllegalStateException r0 = X.AnonymousClass001.A0P(r0)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.getDefaultViewModelProviderFactory():X.0Hd");
    }

    public int getEnterAnim() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 0;
        }
        return r0.A01;
    }

    public Object getEnterTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        return r0.A0B;
    }

    public int getExitAnim() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 0;
        }
        return r0.A02;
    }

    public Object getExitTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        return r0.A0C;
    }

    public View getFocusedView() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        return r0.A06;
    }

    public final Object getHost() {
        AnonymousClass0PT r0 = this.mHost;
        if (r0 == null) {
            return null;
        }
        return r0.A03();
    }

    @Deprecated
    public LayoutInflater getLayoutInflater(Bundle bundle) {
        AnonymousClass0PT r0 = this.mHost;
        if (r0 != null) {
            LayoutInflater A02 = r0.A02();
            A02.setFactory2(this.mChildFragmentManager.A0S);
            return A02;
        }
        throw AnonymousClass001.A0P("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public int getNextTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 0;
        }
        return r0.A03;
    }

    public final AnonymousClass0PW getParentFragmentManager() {
        AnonymousClass0PW r0 = this.mFragmentManager;
        if (r0 != null) {
            return r0;
        }
        throw AnonymousClass002.A0I(" not associated with a fragment manager.", AnonymousClass002.A0T(this));
    }

    public boolean getPopDirection() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return false;
        }
        return r0.A0K;
    }

    public int getPopEnterAnim() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 0;
        }
        return r0.A04;
    }

    public int getPopExitAnim() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 0;
        }
        return r0.A05;
    }

    public float getPostOnViewCreatedAlpha() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return 1.0f;
        }
        return r0.A00;
    }

    public Object getReenterTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        Object obj = r0.A0D;
        if (obj == USE_DEFAULT_TRANSITION) {
            return getExitTransition();
        }
        return obj;
    }

    public Object getReturnTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        Object obj = r0.A0E;
        if (obj == USE_DEFAULT_TRANSITION) {
            return getEnterTransition();
        }
        return obj;
    }

    public final C02570Cm getSavedStateRegistry() {
        return this.mSavedStateRegistryController.A00;
    }

    public Object getSharedElementEnterTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        return r0.A0F;
    }

    public Object getSharedElementReturnTransition() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return null;
        }
        Object obj = r0.A0G;
        if (obj == USE_DEFAULT_TRANSITION) {
            return getSharedElementEnterTransition();
        }
        return obj;
    }

    public ArrayList getSharedElementSourceNames() {
        ArrayList arrayList;
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null || (arrayList = r0.A0H) == null) {
            return AnonymousClass001.A0t();
        }
        return arrayList;
    }

    public ArrayList getSharedElementTargetNames() {
        ArrayList arrayList;
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null || (arrayList = r0.A0I) == null) {
            return AnonymousClass001.A0t();
        }
        return arrayList;
    }

    public C06460Wi getViewLifecycleOwner() {
        AnonymousClass08N r0 = this.mViewLifecycleOwner;
        if (r0 != null) {
            return r0;
        }
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("Can't access the Fragment View's LifecycleOwner for ");
        A0m.append(this);
        throw AnonymousClass002.A0I(" when getView() is null i.e., before onCreateView() or after onDestroyView()", A0m);
    }

    public AnonymousClass0BZ getViewModelStore() {
        AnonymousClass0PW r2 = this.mFragmentManager;
        if (r2 == null) {
            throw AnonymousClass001.A0P("Can't access ViewModels from detached fragment");
        } else if (getMinimumMaxLifecycleState() != 1) {
            HashMap hashMap = r2.A0A.A04;
            AnonymousClass0BZ r0 = (AnonymousClass0BZ) hashMap.get(this.mWho);
            if (r0 != null) {
                return r0;
            }
            AnonymousClass0BZ r1 = new AnonymousClass0BZ();
            hashMap.put(this.mWho, r1);
            return r1;
        } else {
            throw AnonymousClass001.A0P("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
    }

    public final boolean isAdded() {
        if (this.mHost == null || !this.mAdded) {
            return false;
        }
        return true;
    }

    public final boolean isHidden() {
        Fragment fragment;
        if (this.mHidden) {
            return true;
        }
        if (this.mFragmentManager == null || (fragment = this.mParentFragment) == null || !fragment.isHidden()) {
            return false;
        }
        return true;
    }

    public final boolean isInBackStack() {
        if (this.mBackStackNesting > 0) {
            return true;
        }
        return false;
    }

    public final boolean isMenuVisible() {
        Fragment fragment;
        if (!this.mMenuVisible) {
            return false;
        }
        if (this.mFragmentManager == null || (fragment = this.mParentFragment) == null || fragment.isMenuVisible()) {
            return true;
        }
        return false;
    }

    public boolean isPostponed() {
        AnonymousClass08K r0 = this.mAnimationInfo;
        if (r0 == null) {
            return false;
        }
        return r0.A0J;
    }

    public final boolean isResumed() {
        if (this.mState >= 7) {
            return true;
        }
        return false;
    }

    public final boolean isStateSaved() {
        AnonymousClass0PW r0 = this.mFragmentManager;
        if (r0 == null) {
            return false;
        }
        return r0.A0w();
    }

    /* renamed from: lambda$performCreateView$0$androidx-fragment-app-Fragment  reason: not valid java name */
    public /* synthetic */ void m3lambda$performCreateView$0$androidxfragmentappFragment() {
        AnonymousClass08N r0 = this.mViewLifecycleOwner;
        r0.A01.A00(this.mSavedViewRegistryState);
        this.mSavedViewRegistryState = null;
    }

    public void noteStateNotSaved() {
        this.mChildFragmentManager.A0b();
    }

    public void performActivityCreated(Bundle bundle) {
        this.mChildFragmentManager.A0b();
        this.mState = 3;
        this.mCalled = false;
        onActivityCreated(bundle);
        if (this.mCalled) {
            restoreViewState();
            AnonymousClass0PW r1 = this.mChildFragmentManager;
            r1.A0I = false;
            r1.A0J = false;
            r1.A0A.A01 = false;
            AnonymousClass0PW.A0B(r1, 4);
            return;
        }
        throw A00(" did not call through to super.onActivityCreated()", AnonymousClass002.A0T(this));
    }

    public void performAttach() {
        Iterator it = this.mOnPreAttachedListeners.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0GJ) it.next()).A00();
        }
        this.mOnPreAttachedListeners.clear();
        this.mChildFragmentManager.A0j(this, createFragmentContainer(), this.mHost);
        this.mState = 0;
        this.mCalled = false;
        onAttach(this.mHost.A01);
        if (this.mCalled) {
            Iterator it2 = this.mFragmentManager.A0Z.iterator();
            while (it2.hasNext()) {
                ((AnonymousClass0PV) it2.next()).CWy(this);
            }
            AnonymousClass0PW r1 = this.mChildFragmentManager;
            r1.A0I = false;
            r1.A0J = false;
            r1.A0A.A01 = false;
            AnonymousClass0PW.A0B(r1, 0);
            return;
        }
        throw A00(" did not call through to super.onAttach()", AnonymousClass002.A0T(this));
    }

    public boolean performContextItemSelected(MenuItem menuItem) {
        if (this.mHidden) {
            return false;
        }
        AnonymousClass0PW r1 = this.mChildFragmentManager;
        if (r1.A00 < 1) {
            return false;
        }
        Iterator A00 = AnonymousClass0D1.A00(r1);
        while (A00.hasNext()) {
            Fragment fragment = (Fragment) A00.next();
            if (fragment != null && fragment.performContextItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public void performCreate(Bundle bundle) {
        this.mChildFragmentManager.A0b();
        this.mState = 1;
        this.mCalled = false;
        this.mLifecycleRegistry.A05(new C212616x(this, 0));
        onCreate(bundle);
        this.mIsCreated = true;
        if (this.mCalled) {
            this.mLifecycleRegistry.A07(C09730eN.ON_CREATE);
            return;
        }
        throw A00(" did not call through to super.onCreate()", AnonymousClass002.A0T(this));
    }

    public boolean performCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.mHidden) {
            return false;
        }
        if (this.mHasMenu && this.mMenuVisible) {
            z = true;
        }
        return z | this.mChildFragmentManager.A0z(menu, menuInflater);
    }

    public void performCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.mChildFragmentManager.A0b();
        this.mPerformedCreateView = true;
        this.mViewLifecycleOwner = new AnonymousClass08N(this, getViewModelStore(), new AnonymousClass08M(this));
        View onCreateView = onCreateView(layoutInflater, viewGroup, bundle);
        this.mView = onCreateView;
        AnonymousClass08N r0 = this.mViewLifecycleOwner;
        if (onCreateView != null) {
            r0.A00();
            View view = this.mView;
            AnonymousClass08N r1 = this.mViewLifecycleOwner;
            C15800sA.A0D(view, 0);
            view.setTag(2131370787, r1);
            View view2 = this.mView;
            AnonymousClass08N r12 = this.mViewLifecycleOwner;
            C15800sA.A0D(view2, 0);
            view2.setTag(2131370790, r12);
            View view3 = this.mView;
            AnonymousClass08N r13 = this.mViewLifecycleOwner;
            C15800sA.A0D(view3, 0);
            view3.setTag(2131370789, r13);
            this.mViewLifecycleOwnerLiveData.A09(this.mViewLifecycleOwner);
        } else if (r0.A00 != null) {
            throw AnonymousClass001.A0P("Called getViewLifecycleOwner() but onCreateView() returned null");
        } else {
            this.mViewLifecycleOwner = null;
        }
    }

    public void performDestroy() {
        this.mChildFragmentManager.A0Y();
        this.mLifecycleRegistry.A07(C09730eN.ON_DESTROY);
        this.mState = 0;
        this.mCalled = false;
        this.mIsCreated = false;
        onDestroy();
        if (!this.mCalled) {
            throw A00(" did not call through to super.onDestroy()", AnonymousClass002.A0T(this));
        }
    }

    public void performDestroyView() {
        AnonymousClass0PW.A0B(this.mChildFragmentManager, 1);
        if (this.mView != null) {
            AnonymousClass08N r0 = this.mViewLifecycleOwner;
            r0.A00();
            if (r0.A00.A04().A00(C09740eO.CREATED)) {
                AnonymousClass08N r02 = this.mViewLifecycleOwner;
                r02.A00.A07(C09730eN.ON_DESTROY);
            }
        }
        this.mState = 1;
        this.mCalled = false;
        onDestroyView();
        if (this.mCalled) {
            C013307i r3 = AnonymousClass0LO.A00(this).A01.A00;
            int A00 = r3.A00();
            for (int i = 0; i < A00; i++) {
                ((C10100f1) r3.A05(i)).A0D();
            }
            this.mPerformedCreateView = false;
            return;
        }
        throw A00(" did not call through to super.onDestroyView()", AnonymousClass002.A0T(this));
    }

    public boolean performOptionsItemSelected(MenuItem menuItem) {
        if (this.mHidden) {
            return false;
        }
        if (!this.mHasMenu || !this.mMenuVisible || !onOptionsItemSelected(menuItem)) {
            return this.mChildFragmentManager.A10(menuItem);
        }
        return true;
    }

    public void performOptionsMenuClosed(Menu menu) {
        if (!this.mHidden) {
            this.mChildFragmentManager.A0f(menu);
        }
    }

    public void performPause() {
        AnonymousClass0PW.A0B(this.mChildFragmentManager, 5);
        if (this.mView != null) {
            AnonymousClass08N r0 = this.mViewLifecycleOwner;
            r0.A00.A07(C09730eN.ON_PAUSE);
        }
        this.mLifecycleRegistry.A07(C09730eN.ON_PAUSE);
        this.mState = 6;
        this.mCalled = false;
        onPause();
        if (!this.mCalled) {
            throw A00(" did not call through to super.onPause()", AnonymousClass002.A0T(this));
        }
    }

    public boolean performPrepareOptionsMenu(Menu menu) {
        boolean z = false;
        if (this.mHidden) {
            return false;
        }
        if (this.mHasMenu && this.mMenuVisible) {
            onPrepareOptionsMenu(menu);
            z = true;
        }
        return z | this.mChildFragmentManager.A0y(menu);
    }

    public void performPrimaryNavigationFragmentChanged() {
        boolean A11 = this.mFragmentManager.A11(this);
        Boolean bool = this.mIsPrimaryNavigationFragment;
        if (bool == null || bool.booleanValue() != A11) {
            this.mIsPrimaryNavigationFragment = Boolean.valueOf(A11);
            AnonymousClass0PW r1 = this.mChildFragmentManager;
            AnonymousClass0PW.A0A(r1);
            AnonymousClass0PW.A07(r1.A07, r1);
        }
    }

    public void performResume() {
        this.mChildFragmentManager.A0b();
        this.mChildFragmentManager.A0v(true);
        this.mState = 7;
        this.mCalled = false;
        onResume();
        if (this.mCalled) {
            C09780eT r0 = this.mLifecycleRegistry;
            C09730eN r1 = C09730eN.ON_RESUME;
            r0.A07(r1);
            if (this.mView != null) {
                this.mViewLifecycleOwner.A00.A07(r1);
            }
            AnonymousClass0PW r12 = this.mChildFragmentManager;
            r12.A0I = false;
            r12.A0J = false;
            r12.A0A.A01 = false;
            AnonymousClass0PW.A0B(r12, 7);
            return;
        }
        throw A00(" did not call through to super.onResume()", AnonymousClass002.A0T(this));
    }

    public void performStart() {
        this.mChildFragmentManager.A0b();
        this.mChildFragmentManager.A0v(true);
        this.mState = 5;
        this.mCalled = false;
        onStart();
        if (this.mCalled) {
            C09780eT r0 = this.mLifecycleRegistry;
            C09730eN r1 = C09730eN.ON_START;
            r0.A07(r1);
            if (this.mView != null) {
                this.mViewLifecycleOwner.A00.A07(r1);
            }
            AnonymousClass0PW r12 = this.mChildFragmentManager;
            r12.A0I = false;
            r12.A0J = false;
            r12.A0A.A01 = false;
            AnonymousClass0PW.A0B(r12, 5);
            return;
        }
        throw A00(" did not call through to super.onStart()", AnonymousClass002.A0T(this));
    }

    public void performStop() {
        AnonymousClass0PW r3 = this.mChildFragmentManager;
        r3.A0J = true;
        r3.A0A.A01 = true;
        AnonymousClass0PW.A0B(r3, 4);
        if (this.mView != null) {
            AnonymousClass08N r0 = this.mViewLifecycleOwner;
            r0.A00.A07(C09730eN.ON_STOP);
        }
        this.mLifecycleRegistry.A07(C09730eN.ON_STOP);
        this.mState = 4;
        this.mCalled = false;
        onStop();
        if (!this.mCalled) {
            throw A00(" did not call through to super.onStop()", AnonymousClass002.A0T(this));
        }
    }

    public void performViewCreated() {
        Bundle bundle;
        Bundle bundle2 = this.mSavedFragmentState;
        if (bundle2 != null) {
            bundle = bundle2.getBundle("savedInstanceState");
        } else {
            bundle = null;
        }
        onViewCreated(this.mView, bundle);
        AnonymousClass0PW.A0B(this.mChildFragmentManager, 2);
    }

    public final AnonymousClass0Hh registerForActivityResult(C03390Gt r2, C03510Hf r3) {
        return prepareCallInternal(r2, new AnonymousClass0WJ(this), r3);
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [androidx.fragment.app.FragmentManager$LaunchedFragmentInfo, java.lang.Object] */
    @Deprecated
    public final void requestPermissions(String[] strArr, int i) {
        if (this.mHost != null) {
            AnonymousClass0PW parentFragmentManager = getParentFragmentManager();
            if (parentFragmentManager.A02 != null) {
                String str = this.mWho;
                ? obj = new Object();
                obj.A01 = str;
                obj.A00 = i;
                parentFragmentManager.A0C.addLast(obj);
                parentFragmentManager.A02.A02(strArr);
                return;
            }
            return;
        }
        throw AnonymousClass002.A0I(" not attached to Activity", AnonymousClass002.A0T(this));
    }

    public final Bundle requireArguments() {
        Bundle bundle = this.mArguments;
        if (bundle != null) {
            return bundle;
        }
        throw AnonymousClass002.A0I(" does not have any arguments.", AnonymousClass002.A0T(this));
    }

    public final Fragment requireParentFragment() {
        Fragment fragment = this.mParentFragment;
        if (fragment != null) {
            return fragment;
        }
        Context context = getContext();
        StringBuilder A0o = AnonymousClass001.A0o("Fragment ");
        if (context == null) {
            A0o.append(this);
            throw AnonymousClass002.A0I(" is not attached to any Fragment or host", A0o);
        }
        A0o.append(this);
        A0o.append(" is not a child Fragment, it is directly attached to ");
        throw AnonymousClass002.A0H(getContext(), A0o);
    }

    public final View requireView() {
        View view = this.mView;
        if (view != null) {
            return view;
        }
        throw AnonymousClass002.A0I(" did not return a View from onCreateView() or this was called before onCreateView().", AnonymousClass002.A0T(this));
    }

    public void restoreChildFragmentState() {
        Bundle bundle;
        Bundle bundle2 = this.mSavedFragmentState;
        if (bundle2 != null && (bundle = bundle2.getBundle("childFragmentManager")) != null) {
            this.mChildFragmentManager.A0e(bundle);
            AnonymousClass0PW r2 = this.mChildFragmentManager;
            r2.A0I = false;
            r2.A0J = false;
            r2.A0A.A01 = false;
            AnonymousClass0PW.A0B(r2, 1);
        }
    }

    public final void restoreViewState(Bundle bundle) {
        SparseArray sparseArray = this.mSavedViewState;
        if (sparseArray != null) {
            this.mView.restoreHierarchyState(sparseArray);
            this.mSavedViewState = null;
        }
        this.mCalled = false;
        onViewStateRestored(bundle);
        if (!this.mCalled) {
            throw A00(" did not call through to super.onViewStateRestored()", AnonymousClass002.A0T(this));
        } else if (this.mView != null) {
            AnonymousClass08N r0 = this.mViewLifecycleOwner;
            r0.A00.A07(C09730eN.ON_CREATE);
        }
    }

    public void setAnimations(int i, int i2, int i3, int i4) {
        if (this.mAnimationInfo != null || i != 0 || i2 != 0 || i3 != 0 || i4 != 0) {
            ensureAnimationInfo().A01 = i;
            ensureAnimationInfo().A02 = i2;
            ensureAnimationInfo().A04 = i3;
            ensureAnimationInfo().A05 = i4;
        }
    }

    public void setArguments(Bundle bundle) {
        if (this.mFragmentManager == null || !isStateSaved()) {
            this.mArguments = bundle;
            return;
        }
        throw AnonymousClass001.A0P("Fragment already added and state has been saved");
    }

    @Deprecated
    public void setHasOptionsMenu(boolean z) {
        if (this.mHasMenu != z) {
            this.mHasMenu = z;
            if (isAdded() && !isHidden()) {
                this.mHost.A04();
            }
        }
    }

    public void setInitialSavedState(SavedState savedState) {
        Bundle bundle;
        if (this.mFragmentManager == null) {
            if (savedState == null || (bundle = savedState.A00) == null) {
                bundle = null;
            }
            this.mSavedFragmentState = bundle;
            return;
        }
        throw AnonymousClass001.A0P("Fragment already added");
    }

    public void setMenuVisibility(boolean z) {
        if (this.mMenuVisible != z) {
            this.mMenuVisible = z;
            if (this.mHasMenu && isAdded() && !isHidden()) {
                this.mHost.A04();
            }
        }
    }

    public void setNextTransition(int i) {
        if (this.mAnimationInfo != null || i != 0) {
            ensureAnimationInfo();
            this.mAnimationInfo.A03 = i;
        }
    }

    public void setPopDirection(boolean z) {
        if (this.mAnimationInfo != null) {
            ensureAnimationInfo().A0K = z;
        }
    }

    @Deprecated
    public void setRetainInstance(boolean z) {
        AnonymousClass086 r0 = AnonymousClass086.A01;
        AnonymousClass0HT r3 = new AnonymousClass0HT(AnonymousClass002.A0M(this, "Attempting to set retain instance for fragment ", AnonymousClass001.A0m()), this);
        AnonymousClass087 A00 = AnonymousClass086.A00(this);
        if (A00.A01.contains(AnonymousClass089.DETECT_RETAIN_INSTANCE_USAGE)) {
            AnonymousClass002.A0a(A00, r3, this);
        }
        this.mRetainInstance = z;
        AnonymousClass0PW r02 = this.mFragmentManager;
        if (r02 != null) {
            C02230Ba r1 = r02.A0A;
            boolean z2 = r1.A01;
            if (z) {
                if (!z2) {
                    HashMap hashMap = r1.A03;
                    if (!hashMap.containsKey(this.mWho)) {
                        hashMap.put(this.mWho, this);
                    }
                }
            } else if (!z2) {
                r1.A03.remove(this.mWho);
            }
        } else {
            this.mRetainInstanceChangedWhileDetached = true;
        }
    }

    @Deprecated
    public void setTargetFragment(Fragment fragment, int i) {
        AnonymousClass0PW r0;
        if (fragment != null) {
            AnonymousClass086 r02 = AnonymousClass086.A01;
            C09590e4 r3 = new C09590e4(this, fragment, i);
            AnonymousClass087 A00 = AnonymousClass086.A00(this);
            if (A00.A01.contains(AnonymousClass089.DETECT_TARGET_FRAGMENT_USAGE)) {
                AnonymousClass002.A0a(A00, r3, this);
            }
        }
        AnonymousClass0PW r1 = this.mFragmentManager;
        if (fragment != null) {
            r0 = fragment.mFragmentManager;
        } else {
            r0 = null;
        }
        if (r1 == null || r0 == null || r1 == r0) {
            Fragment fragment2 = fragment;
            while (fragment2 != null) {
                if (!fragment2.equals(this)) {
                    fragment2 = fragment2.getTargetFragment(false);
                } else {
                    StringBuilder A0m = AnonymousClass001.A0m();
                    A0m.append("Setting ");
                    A0m.append(fragment);
                    A0m.append(" as the target of ");
                    A0m.append(this);
                    throw AnonymousClass002.A0F(" would create a target cycle", A0m);
                }
            }
            if (fragment == null) {
                this.mTargetWho = null;
                this.mTarget = null;
            } else if (this.mFragmentManager == null || fragment.mFragmentManager == null) {
                this.mTargetWho = null;
                this.mTarget = fragment;
            } else {
                this.mTargetWho = fragment.mWho;
                this.mTarget = null;
            }
            this.mTargetRequestCode = i;
            return;
        }
        throw AnonymousClass002.A0F(" must share the same FragmentManager to be set as a target fragment", AnonymousClass002.A0T(fragment));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x003f, code lost:
        if (r5 != false) goto L_0x0041;
     */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setUserVisibleHint(boolean r5) {
        /*
            r4 = this;
            X.086 r0 = X.AnonymousClass086.A01
            X.088 r3 = new X.088
            r3.<init>(r4, r5)
            X.087 r2 = X.AnonymousClass086.A00(r4)
            java.util.Set r1 = r2.A01
            X.089 r0 = X.AnonymousClass089.DETECT_SET_USER_VISIBLE_HINT
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x0018
            X.AnonymousClass002.A0a(r2, r3, r4)
        L_0x0018:
            boolean r0 = r4.mUserVisibleHint
            r2 = 5
            if (r0 != 0) goto L_0x0038
            if (r5 == 0) goto L_0x0038
            int r0 = r4.mState
            if (r0 >= r2) goto L_0x0038
            X.0PW r1 = r4.mFragmentManager
            if (r1 == 0) goto L_0x0038
            boolean r0 = r4.isAdded()
            if (r0 == 0) goto L_0x0038
            boolean r0 = r4.mIsCreated
            if (r0 == 0) goto L_0x0038
            X.08B r0 = r1.A0U(r4)
            r1.A0r(r0)
        L_0x0038:
            r4.mUserVisibleHint = r5
            int r0 = r4.mState
            if (r0 >= r2) goto L_0x0041
            r0 = 1
            if (r5 == 0) goto L_0x0042
        L_0x0041:
            r0 = 0
        L_0x0042:
            r4.mDeferStart = r0
            android.os.Bundle r0 = r4.mSavedFragmentState
            if (r0 == 0) goto L_0x004e
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r5)
            r4.mSavedUserVisibleHint = r0
        L_0x004e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.setUserVisibleHint(boolean):void");
    }

    public boolean shouldShowRequestPermissionRationale(String str) {
        AnonymousClass0PT r0 = this.mHost;
        if (r0 != null) {
            return r0.A07(str);
        }
        return false;
    }

    public void startActivity(Intent intent, Bundle bundle) {
        AnonymousClass0PT r1 = this.mHost;
        if (r1 != null) {
            r1.A05(intent, -1, bundle);
            return;
        }
        throw AnonymousClass002.A0I(" not attached to Activity", AnonymousClass002.A0T(this));
    }

    public void startPostponedEnterTransition() {
        if (this.mAnimationInfo != null && ensureAnimationInfo().A0J) {
            if (this.mHost == null) {
                ensureAnimationInfo().A0J = false;
            } else if (Looper.myLooper() != this.mHost.A02.getLooper()) {
                this.mHost.A02.postAtFrontOfQueue(new C09240dV(this));
            } else {
                callStartTransitionListener(true);
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.mWho);
        int i = this.mFragmentId;
        if (i != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i));
        }
        String str = this.mTag;
        if (str != null) {
            sb.append(" tag=");
            sb.append(str);
        }
        sb.append(")");
        return sb.toString();
    }

    public Fragment(int i) {
        this();
        this.mContentLayoutId = i;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.util.AndroidRuntimeException, X.0dr] */
    public static C09460dr A00(String str, StringBuilder sb) {
        sb.append(str);
        return new AndroidRuntimeException(sb.toString());
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        AnonymousClass001.A1D(printWriter, this.mFragmentId);
        printWriter.print(" mContainerId=#");
        AnonymousClass001.A1D(printWriter, this.mContainerId);
        printWriter.print(" mTag=");
        printWriter.println(this.mTag);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.mState);
        printWriter.print(" mWho=");
        printWriter.print(this.mWho);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.mBackStackNesting);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.mAdded);
        printWriter.print(" mRemoving=");
        printWriter.print(this.mRemoving);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.mFromLayout);
        printWriter.print(" mInLayout=");
        printWriter.println(this.mInLayout);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.mHidden);
        printWriter.print(" mDetached=");
        printWriter.print(this.mDetached);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.mMenuVisible);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.mHasMenu);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.mRetainInstance);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.mUserVisibleHint);
        if (this.mFragmentManager != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.mFragmentManager);
        }
        if (this.mHost != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.mHost);
        }
        if (this.mParentFragment != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.mParentFragment);
        }
        if (this.mArguments != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.mArguments);
        }
        if (this.mSavedFragmentState != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.mSavedFragmentState);
        }
        if (this.mSavedViewState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.mSavedViewState);
        }
        if (this.mSavedViewRegistryState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.mSavedViewRegistryState);
        }
        Fragment targetFragment = getTargetFragment(false);
        if (targetFragment != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(targetFragment);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.mTargetRequestCode);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(getPopDirection());
        if (getEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(getEnterAnim());
        }
        if (getExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(getExitAnim());
        }
        if (getPopEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(getPopEnterAnim());
        }
        if (getPopExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(getPopExitAnim());
        }
        if (this.mContainer != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.mContainer);
        }
        if (this.mView != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.mView);
        }
        if (getContext() != null) {
            AnonymousClass0LO.A00(this).A03(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("Child ");
        A0m.append(this.mChildFragmentManager);
        printWriter.println(AnonymousClass001.A0g(":", A0m));
        this.mChildFragmentManager.A0u(AnonymousClass0WY.A0i(str, "  "), fileDescriptor, printWriter, strArr);
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public View getAnimatingAway() {
        return null;
    }

    public final Bundle getArguments() {
        return this.mArguments;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0010, code lost:
        if (r1 == null) goto L_0x0012;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0017, code lost:
        if (X.AnonymousClass0PW.A0H(3) == false) goto L_0x0020;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0019, code lost:
        requireContext().getApplicationContext();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public X.C03500He getDefaultViewModelCreationExtras() {
        /*
            r3 = this;
            android.content.Context r0 = r3.requireContext()
            android.content.Context r1 = r0.getApplicationContext()
        L_0x0008:
            boolean r0 = r1 instanceof android.content.ContextWrapper
            if (r0 == 0) goto L_0x0047
            boolean r0 = r1 instanceof android.app.Application
            if (r0 == 0) goto L_0x0040
            if (r1 != 0) goto L_0x0020
        L_0x0012:
            r0 = 3
            boolean r0 = X.AnonymousClass0PW.A0H(r0)
            if (r0 == 0) goto L_0x0020
            android.content.Context r0 = r3.requireContext()
            r0.getApplicationContext()
        L_0x0020:
            X.0C4 r2 = new X.0C4
            r2.<init>()
            if (r1 == 0) goto L_0x002c
            X.0PQ r0 = X.AnonymousClass02B.A02
            r2.A01(r0, r1)
        L_0x002c:
            X.0PQ r0 = X.C02600Ct.A01
            r2.A01(r0, r3)
            X.0PQ r0 = X.C02600Ct.A02
            r2.A01(r0, r3)
            android.os.Bundle r1 = r3.mArguments
            if (r1 == 0) goto L_0x003f
            X.0PQ r0 = X.C02600Ct.A00
            r2.A01(r0, r1)
        L_0x003f:
            return r2
        L_0x0040:
            android.content.ContextWrapper r1 = (android.content.ContextWrapper) r1
            android.content.Context r1 = r1.getBaseContext()
            goto L_0x0008
        L_0x0047:
            r1 = 0
            goto L_0x0012
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.getDefaultViewModelCreationExtras():X.0He");
    }

    public C04310Ld getEnterTransitionCallback() {
        return null;
    }

    public C04310Ld getExitTransitionCallback() {
        return null;
    }

    @Deprecated
    public final AnonymousClass0PW getFragmentManager() {
        return this.mFragmentManager;
    }

    public final int getId() {
        return this.mFragmentId;
    }

    public C09750eP getLifecycle() {
        return this.mLifecycleRegistry;
    }

    @Deprecated
    public AnonymousClass0LO getLoaderManager() {
        return AnonymousClass0LO.A00(this);
    }

    public final Fragment getParentFragment() {
        return this.mParentFragment;
    }

    public final Resources getResources() {
        return requireContext().getResources();
    }

    @Deprecated
    public final boolean getRetainInstance() {
        AnonymousClass086.A01(this);
        return this.mRetainInstance;
    }

    public final String getString(int i, Object... objArr) {
        return requireContext().getResources().getString(i, objArr);
    }

    public final String getTag() {
        return this.mTag;
    }

    @Deprecated
    public final int getTargetRequestCode() {
        AnonymousClass086.A02(this);
        return this.mTargetRequestCode;
    }

    public final CharSequence getText(int i) {
        return requireContext().getResources().getText(i);
    }

    @Deprecated
    public boolean getUserVisibleHint() {
        return this.mUserVisibleHint;
    }

    public View getView() {
        return this.mView;
    }

    public C02820Dz getViewLifecycleOwnerLiveData() {
        return this.mViewLifecycleOwnerLiveData;
    }

    public final boolean hasOptionsMenu() {
        return this.mHasMenu;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public void initState() {
        initLifecycle();
        this.mPreviousWho = this.mWho;
        this.mWho = UUID.randomUUID().toString();
        this.mAdded = false;
        this.mRemoving = false;
        this.mFromLayout = false;
        this.mInLayout = false;
        this.mRestored = false;
        this.mBackStackNesting = 0;
        this.mFragmentManager = null;
        this.mChildFragmentManager = new AnonymousClass0PW();
        this.mHost = null;
        this.mFragmentId = 0;
        this.mContainerId = 0;
        this.mTag = null;
        this.mHidden = false;
        this.mDetached = false;
    }

    public final boolean isDetached() {
        return this.mDetached;
    }

    public final boolean isInLayout() {
        return this.mInLayout;
    }

    public final boolean isRemoving() {
        return this.mRemoving;
    }

    public final boolean isVisible() {
        View view;
        if (!isAdded() || isHidden() || (view = this.mView) == null || view.getWindowToken() == null || this.mView.getVisibility() != 0) {
            return false;
        }
        return true;
    }

    @Deprecated
    public void onActivityCreated(Bundle bundle) {
        int A02 = AnonymousClass0BS.A02(-1986149221);
        this.mCalled = true;
        AnonymousClass0BS.A08(1469501862, A02);
    }

    public void onCreate(Bundle bundle) {
        int A02 = AnonymousClass0BS.A02(412399288);
        this.mCalled = true;
        restoreChildFragmentState();
        AnonymousClass0PW r2 = this.mChildFragmentManager;
        if (r2.A00 < 1) {
            r2.A0I = false;
            r2.A0J = false;
            r2.A0A.A01 = false;
            AnonymousClass0PW.A0B(r2, 1);
        }
        AnonymousClass0BS.A08(1111400336, A02);
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        requireActivity().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int A02 = AnonymousClass0BS.A02(-1027310901);
        int i = this.mContentLayoutId;
        if (i != 0) {
            View inflate = layoutInflater.inflate(i, viewGroup, false);
            AnonymousClass0BS.A08(1445078932, A02);
            return inflate;
        }
        AnonymousClass0BS.A08(1196706451, A02);
        return null;
    }

    public void onDestroy() {
        int A02 = AnonymousClass0BS.A02(1429640738);
        this.mCalled = true;
        AnonymousClass0BS.A08(55621516, A02);
    }

    @Deprecated
    public void onDestroyOptionsMenu() {
    }

    public void onDestroyView() {
        int A02 = AnonymousClass0BS.A02(-961299403);
        this.mCalled = true;
        AnonymousClass0BS.A08(223467279, A02);
    }

    public void onDetach() {
        int A02 = AnonymousClass0BS.A02(1887423784);
        this.mCalled = true;
        AnonymousClass0BS.A08(1766004772, A02);
    }

    public LayoutInflater onGetLayoutInflater(Bundle bundle) {
        return getLayoutInflater(bundle);
    }

    public void onPause() {
        int A02 = AnonymousClass0BS.A02(-741365511);
        this.mCalled = true;
        AnonymousClass0BS.A08(257018534, A02);
    }

    public void onResume() {
        int A02 = AnonymousClass0BS.A02(339993235);
        this.mCalled = true;
        AnonymousClass0BS.A08(-70928354, A02);
    }

    public void onStart() {
        int A02 = AnonymousClass0BS.A02(-179177744);
        this.mCalled = true;
        AnonymousClass0BS.A08(84446793, A02);
    }

    public void onStop() {
        int A02 = AnonymousClass0BS.A02(1602857852);
        this.mCalled = true;
        AnonymousClass0BS.A08(1867857833, A02);
    }

    public void onViewStateRestored(Bundle bundle) {
        int A02 = AnonymousClass0BS.A02(865006028);
        this.mCalled = true;
        AnonymousClass0BS.A08(881477546, A02);
    }

    public LayoutInflater performGetLayoutInflater(Bundle bundle) {
        LayoutInflater onGetLayoutInflater = onGetLayoutInflater(bundle);
        this.mLayoutInflater = onGetLayoutInflater;
        return onGetLayoutInflater;
    }

    public void performLowMemory() {
        onLowMemory();
    }

    public final void postponeEnterTransition(long j, TimeUnit timeUnit) {
        Handler A09;
        ensureAnimationInfo().A0J = true;
        Handler handler = this.mPostponedHandler;
        if (handler != null) {
            handler.removeCallbacks(this.mPostponedDurationRunnable);
        }
        AnonymousClass0PW r0 = this.mFragmentManager;
        if (r0 != null) {
            A09 = r0.A09.A02;
        } else {
            A09 = AnonymousClass001.A09();
        }
        this.mPostponedHandler = A09;
        A09.removeCallbacks(this.mPostponedDurationRunnable);
        this.mPostponedHandler.postDelayed(this.mPostponedDurationRunnable, timeUnit.toMillis(j));
    }

    public final FragmentActivity requireActivity() {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            return activity;
        }
        throw AnonymousClass002.A0I(" not attached to an activity.", AnonymousClass002.A0T(this));
    }

    public final Context requireContext() {
        Context context = getContext();
        if (context != null) {
            return context;
        }
        throw AnonymousClass002.A0I(" not attached to a context.", AnonymousClass002.A0T(this));
    }

    @Deprecated
    public final AnonymousClass0PW requireFragmentManager() {
        return getParentFragmentManager();
    }

    public final Object requireHost() {
        Object host = getHost();
        if (host != null) {
            return host;
        }
        throw AnonymousClass002.A0I(" not attached to a host.", AnonymousClass002.A0T(this));
    }

    public void setAllowEnterTransitionOverlap(boolean z) {
        ensureAnimationInfo().A09 = Boolean.valueOf(z);
    }

    public void setAllowReturnTransitionOverlap(boolean z) {
        ensureAnimationInfo().A0A = Boolean.valueOf(z);
    }

    public void setEnterSharedElementCallback(C04310Ld r2) {
        ensureAnimationInfo().A07 = r2;
    }

    public void setEnterTransition(Object obj) {
        ensureAnimationInfo().A0B = obj;
    }

    public void setExitSharedElementCallback(C04310Ld r2) {
        ensureAnimationInfo().A08 = r2;
    }

    public void setExitTransition(Object obj) {
        ensureAnimationInfo().A0C = obj;
    }

    public void setFocusedView(View view) {
        ensureAnimationInfo().A06 = view;
    }

    public void setPostOnViewCreatedAlpha(float f) {
        ensureAnimationInfo().A00 = f;
    }

    public void setReenterTransition(Object obj) {
        ensureAnimationInfo().A0D = obj;
    }

    public void setReturnTransition(Object obj) {
        ensureAnimationInfo().A0E = obj;
    }

    public void setSharedElementEnterTransition(Object obj) {
        ensureAnimationInfo().A0F = obj;
    }

    public void setSharedElementNames(ArrayList arrayList, ArrayList arrayList2) {
        ensureAnimationInfo();
        AnonymousClass08K r0 = this.mAnimationInfo;
        r0.A0H = arrayList;
        r0.A0I = arrayList2;
    }

    public void setSharedElementReturnTransition(Object obj) {
        ensureAnimationInfo().A0G = obj;
    }

    @Deprecated
    public void onAttachFragment(Fragment fragment) {
    }

    public boolean onContextItemSelected(MenuItem menuItem) {
        return false;
    }

    public void onHiddenChanged(boolean z) {
    }

    public void onMultiWindowModeChanged(boolean z) {
    }

    @Deprecated
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return false;
    }

    @Deprecated
    public void onOptionsMenuClosed(Menu menu) {
    }

    public void onPictureInPictureModeChanged(boolean z) {
    }

    @Deprecated
    public void onPrepareOptionsMenu(Menu menu) {
    }

    public void onPrimaryNavigationFragmentChanged(boolean z) {
    }

    public void onSaveInstanceState(Bundle bundle) {
    }

    public void performConfigurationChanged(Configuration configuration) {
        onConfigurationChanged(configuration);
    }

    public void performMultiWindowModeChanged(boolean z) {
        onMultiWindowModeChanged(z);
    }

    public void performPictureInPictureModeChanged(boolean z) {
        onPictureInPictureModeChanged(z);
    }

    public void performSaveInstanceState(Bundle bundle) {
        onSaveInstanceState(bundle);
    }

    public void registerForContextMenu(View view) {
        view.setOnCreateContextMenuListener(this);
    }

    @Deprecated
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    public void onViewCreated(View view, Bundle bundle) {
    }

    @Deprecated
    public void onActivityResult(int i, int i2, Intent intent) {
    }

    public Animation onCreateAnimation(int i, boolean z, int i2) {
        return null;
    }

    public Animator onCreateAnimator(int i, boolean z, int i2) {
        return null;
    }

    @Deprecated
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
    }

    /* JADX WARNING: type inference failed for: r0v8, types: [X.0E0, X.0Dz] */
    public Fragment() {
        this.mState = -1;
        this.mWho = UUID.randomUUID().toString();
        this.mTargetWho = null;
        this.mIsPrimaryNavigationFragment = null;
        this.mChildFragmentManager = new AnonymousClass0PW();
        this.mMenuVisible = true;
        this.mUserVisibleHint = true;
        this.mPostponedDurationRunnable = new AnonymousClass084(this);
        this.mMaxState = C09740eO.RESUMED;
        this.mViewLifecycleOwnerLiveData = new C02820Dz();
        this.mNextLocalRequestCode = new AtomicInteger();
        this.mOnPreAttachedListeners = new ArrayList();
        this.mSavedStateAttachListener = new AnonymousClass085(this);
        initLifecycle();
    }

    @Deprecated
    public static Fragment instantiate(Context context, String str, Bundle bundle) {
        RuntimeException runtimeException;
        try {
            ClassLoader classLoader = context.getClassLoader();
            try {
                AnonymousClass0XY r0 = AnonymousClass0D6.A01;
                AnonymousClass0XY r1 = (AnonymousClass0XY) r0.get(classLoader);
                if (r1 == null) {
                    r1 = AnonymousClass0XY.A02();
                    r0.put(classLoader, r1);
                }
                Class<?> cls = (Class) r1.get(str);
                if (cls == null) {
                    cls = Class.forName(str, false, classLoader);
                    r1.put(str, cls);
                }
                Fragment fragment = (Fragment) cls.getConstructor((Class[]) null).newInstance((Object[]) null);
                if (bundle != null) {
                    bundle.setClassLoader(fragment.getClass().getClassLoader());
                    fragment.setArguments(bundle);
                }
                return fragment;
            } catch (ClassNotFoundException e) {
                runtimeException = new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": make sure class name exists"), e);
                throw runtimeException;
            } catch (ClassCastException e2) {
                runtimeException = new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e2);
                throw runtimeException;
            }
        } catch (InstantiationException e3) {
            throw new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e3);
        } catch (IllegalAccessException e4) {
            throw new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e4);
        } catch (NoSuchMethodException e5) {
            throw new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e5);
        } catch (InvocationTargetException e6) {
            throw new RuntimeException(AnonymousClass0WY.A0w("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e6);
        }
    }

    private void restoreViewState() {
        Bundle bundle;
        if (this.mView != null) {
            Bundle bundle2 = this.mSavedFragmentState;
            if (bundle2 != null) {
                bundle = bundle2.getBundle("savedInstanceState");
            } else {
                bundle = null;
            }
            restoreViewState(bundle);
        }
        this.mSavedFragmentState = null;
    }

    public final LayoutInflater getLayoutInflater() {
        LayoutInflater layoutInflater = this.mLayoutInflater;
        if (layoutInflater != null) {
            return layoutInflater;
        }
        LayoutInflater onGetLayoutInflater = onGetLayoutInflater((Bundle) null);
        this.mLayoutInflater = onGetLayoutInflater;
        return onGetLayoutInflater;
    }

    public final String getString(int i) {
        return requireContext().getResources().getString(i);
    }

    @Deprecated
    public final Fragment getTargetFragment() {
        return getTargetFragment(true);
    }

    @Deprecated
    public void onAttach(Activity activity) {
        int A02 = AnonymousClass0BS.A02(894618012);
        this.mCalled = true;
        AnonymousClass0BS.A08(-1276121473, A02);
    }

    @Deprecated
    public void onInflate(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.mCalled = true;
    }

    public void postponeEnterTransition() {
        ensureAnimationInfo().A0J = true;
    }

    public final AnonymousClass0Hh registerForActivityResult(C03390Gt r2, AnonymousClass0PP r3, C03510Hf r4) {
        return prepareCallInternal(r2, new C09260dX(r3, this), r4);
    }

    public void startActivity(Intent intent) {
        startActivity(intent, (Bundle) null);
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [androidx.fragment.app.FragmentManager$LaunchedFragmentInfo, java.lang.Object] */
    @Deprecated
    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        if (this.mHost != null) {
            AnonymousClass0PW r2 = this.mFragmentManager;
            if (r2 == null) {
                r2 = getParentFragmentManager();
            }
            if (r2.A03 != null) {
                String str = this.mWho;
                ? obj = new Object();
                obj.A01 = str;
                obj.A00 = i;
                r2.A0C.addLast(obj);
                if (bundle != null) {
                    intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
                }
                r2.A03.A02(intent);
                return;
            }
            r2.A09.A05(intent, i, bundle);
            return;
        }
        throw AnonymousClass002.A0I(" not attached to Activity", AnonymousClass002.A0T(this));
    }
}
