package androidx.fragment.app;

import X.AnonymousClass001;
import X.AnonymousClass083;
import X.AnonymousClass08A;
import X.AnonymousClass16O;
import X.C09740eO;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

public final class BackStackRecordState implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16O(0);
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final CharSequence A04;
    public final CharSequence A05;
    public final String A06;
    public final ArrayList A07;
    public final ArrayList A08;
    public final ArrayList A09;
    public final boolean A0A;
    public final int[] A0B;
    public final int[] A0C;
    public final int[] A0D;

    /* JADX WARNING: type inference failed for: r5v0, types: [java.lang.Object, X.08A] */
    public static void A00(AnonymousClass083 r8, BackStackRecordState backStackRecordState) {
        int i = 0;
        int i2 = 0;
        while (true) {
            int[] iArr = backStackRecordState.A0D;
            boolean z = true;
            if (i < iArr.length) {
                ? obj = new Object();
                int i3 = i + 1;
                obj.A00 = iArr[i];
                obj.A07 = C09740eO.values()[backStackRecordState.A0C[i2]];
                obj.A06 = C09740eO.values()[backStackRecordState.A0B[i2]];
                int i4 = i3 + 1;
                if (iArr[i3] == 0) {
                    z = false;
                }
                obj.A08 = z;
                int i5 = i4 + 1;
                int i6 = iArr[i4];
                obj.A01 = i6;
                int i7 = i5 + 1;
                int i8 = iArr[i5];
                obj.A02 = i8;
                int i9 = i7 + 1;
                int i10 = iArr[i7];
                obj.A03 = i10;
                i = i9 + 1;
                int i11 = iArr[i9];
                obj.A04 = i11;
                r8.A02 = i6;
                r8.A03 = i8;
                r8.A04 = i10;
                r8.A05 = i11;
                r8.A0N(obj);
                i2++;
            } else {
                r8.A06 = backStackRecordState.A03;
                r8.A0A = backStackRecordState.A06;
                r8.A0F = true;
                r8.A01 = backStackRecordState.A01;
                r8.A09 = backStackRecordState.A05;
                r8.A00 = backStackRecordState.A00;
                r8.A08 = backStackRecordState.A04;
                r8.A0D = backStackRecordState.A08;
                r8.A0E = backStackRecordState.A09;
                r8.A0G = backStackRecordState.A0A;
                return;
            }
        }
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.A0D);
        parcel.writeStringList(this.A07);
        parcel.writeIntArray(this.A0C);
        parcel.writeIntArray(this.A0B);
        parcel.writeInt(this.A03);
        parcel.writeString(this.A06);
        parcel.writeInt(this.A02);
        parcel.writeInt(this.A01);
        TextUtils.writeToParcel(this.A05, parcel, 0);
        parcel.writeInt(this.A00);
        TextUtils.writeToParcel(this.A04, parcel, 0);
        parcel.writeStringList(this.A08);
        parcel.writeStringList(this.A09);
        parcel.writeInt(this.A0A ? 1 : 0);
    }

    public BackStackRecordState(AnonymousClass083 r12) {
        String str;
        ArrayList arrayList = r12.A0C;
        int size = arrayList.size();
        int[] iArr = new int[(size * 6)];
        this.A0D = iArr;
        if (r12.A0F) {
            ArrayList A0u = AnonymousClass001.A0u(size);
            this.A07 = A0u;
            int[] iArr2 = new int[size];
            this.A0C = iArr2;
            int[] iArr3 = new int[size];
            this.A0B = iArr3;
            int i = 0;
            for (int i2 = 0; i2 < size; i2++) {
                AnonymousClass08A r10 = (AnonymousClass08A) arrayList.get(i2);
                int i3 = i + 1;
                iArr[i] = r10.A00;
                Fragment fragment = r10.A05;
                if (fragment != null) {
                    str = fragment.mWho;
                } else {
                    str = null;
                }
                A0u.add(str);
                int i4 = i3 + 1;
                iArr[i3] = r10.A08;
                int i5 = i4 + 1;
                iArr[i4] = r10.A01;
                int i6 = i5 + 1;
                iArr[i5] = r10.A02;
                int i7 = i6 + 1;
                iArr[i6] = r10.A03;
                i = i7 + 1;
                iArr[i7] = r10.A04;
                iArr2[i2] = r10.A07.ordinal();
                iArr3[i2] = r10.A06.ordinal();
            }
            this.A03 = r12.A06;
            this.A06 = r12.A0A;
            this.A02 = r12.A07;
            this.A01 = r12.A01;
            this.A05 = r12.A09;
            this.A00 = r12.A00;
            this.A04 = r12.A08;
            this.A08 = r12.A0D;
            this.A09 = r12.A0E;
            this.A0A = r12.A0G;
            return;
        }
        throw AnonymousClass001.A0P("Not on back stack");
    }

    public final int describeContents() {
        return 0;
    }

    public BackStackRecordState(Parcel parcel) {
        this.A0D = parcel.createIntArray();
        this.A07 = parcel.createStringArrayList();
        this.A0C = parcel.createIntArray();
        this.A0B = parcel.createIntArray();
        this.A03 = parcel.readInt();
        this.A06 = parcel.readString();
        this.A02 = parcel.readInt();
        this.A01 = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.A05 = (CharSequence) creator.createFromParcel(parcel);
        this.A00 = parcel.readInt();
        this.A04 = (CharSequence) creator.createFromParcel(parcel);
        this.A08 = parcel.createStringArrayList();
        this.A09 = parcel.createStringArrayList();
        this.A0A = AnonymousClass001.A1R(parcel.readInt());
    }
}
