package androidx.fragment.app;

import X.AnonymousClass001;
import X.AnonymousClass08N;
import X.AnonymousClass0BS;
import X.AnonymousClass0D1;
import X.AnonymousClass0D9;
import X.AnonymousClass0DA;
import X.AnonymousClass0LO;
import X.AnonymousClass0PT;
import X.AnonymousClass0PW;
import X.AnonymousClass0WY;
import X.AnonymousClass0Y8;
import X.AnonymousClass16M;
import X.AnonymousClass17D;
import X.C02650Cz;
import X.C04310Ld;
import X.C09730eN;
import X.C09740eO;
import X.C09780eT;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import androidx.activity.ComponentActivity;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class FragmentActivity extends ComponentActivity {
    public static final String LIFECYCLE_TAG = "android:support:lifecycle";
    public boolean mCreated;
    public final C09780eT mFragmentLifecycleRegistry = new C09780eT(this, true);
    public final AnonymousClass0D9 mFragments = new AnonymousClass0D9(new C02650Cz(this));
    public boolean mResumed;
    public boolean mStopped = true;

    public void startActivityFromFragment(Fragment fragment, Intent intent, int i, Bundle bundle) {
        if (i == -1) {
            startActivityForResult(intent, -1, bundle);
        } else {
            fragment.startActivityForResult(intent, i, bundle);
        }
    }

    @Deprecated
    public void startIntentSenderFromFragment(Fragment fragment, IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        IntentSender intentSender2 = intentSender;
        int i5 = i;
        Intent intent2 = intent;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        Bundle bundle2 = bundle;
        if (i5 == -1) {
            startIntentSenderForResult(intentSender2, -1, intent2, i6, i7, i8, bundle2);
        } else {
            fragment.startIntentSenderForResult(intentSender2, i5, intent2, i6, i7, i8, bundle2);
        }
    }

    public static void A00(FragmentActivity fragmentActivity) {
        fragmentActivity.mFragments.A00.A03.A0b();
    }

    private void init() {
        this.savedStateRegistryController.A00.A03(new AnonymousClass17D(this, 1), LIFECYCLE_TAG);
        addOnConfigurationChangedListener(new AnonymousClass16M(this, 1));
        addOnNewIntentListener(new AnonymousClass16M(this, 2));
        addOnContextAvailableListener(new AnonymousClass0DA(this));
    }

    public static boolean markState(AnonymousClass0PW r4, C09740eO r5) {
        AnonymousClass0PW childFragmentManager;
        boolean z = false;
        for (Fragment fragment : r4.A0U.A05()) {
            if (fragment != null) {
                if (fragment.getHost() != null) {
                    if (fragment.mHost != null) {
                        childFragmentManager = fragment.mChildFragmentManager;
                    } else {
                        childFragmentManager = fragment.getChildFragmentManager();
                    }
                    z |= markState(childFragmentManager, r5);
                }
                AnonymousClass08N r0 = fragment.mViewLifecycleOwner;
                if (r0 != null) {
                    r0.A00();
                    if (r0.A00.A04().A00(C09740eO.STARTED)) {
                        fragment.mViewLifecycleOwner.A00.A08(r5);
                        z = true;
                    }
                }
                if (fragment.mLifecycleRegistry.A01.A00(C09740eO.STARTED)) {
                    fragment.mLifecycleRegistry.A08(r5);
                    z = true;
                }
            }
        }
        return z;
    }

    public final View dispatchFragmentsOnCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return this.mFragments.A00.A03.A0S.onCreateView(view, str, context, attributeSet);
    }

    public AnonymousClass0PW getSupportFragmentManager() {
        return this.mFragments.A00.A03;
    }

    /* renamed from: lambda$init$3$androidx-fragment-app-FragmentActivity  reason: not valid java name */
    public /* synthetic */ void m7lambda$init$3$androidxfragmentappFragmentActivity(Context context) {
        AnonymousClass0PT r1 = this.mFragments.A00;
        r1.A03.A0j((Fragment) null, r1, r1);
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View onCreateView = this.mFragments.A00.A03.A0S.onCreateView(view, str, context, attributeSet);
        if (onCreateView == null) {
            return super.onCreateView(view, str, context, attributeSet);
        }
        return onCreateView;
    }

    public void onResumeFragments() {
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_RESUME);
        AnonymousClass0PW r2 = this.mFragments.A00.A03;
        r2.A0I = false;
        r2.A0J = false;
        r2.A0A.A01 = false;
        AnonymousClass0PW.A0B(r2, 7);
    }

    public void setEnterSharedElementCallback(C04310Ld r2) {
        AnonymousClass0Y8 r0;
        if (r2 != null) {
            r0 = new AnonymousClass0Y8(r2);
        } else {
            r0 = null;
        }
        setEnterSharedElementCallback(r0);
    }

    public void setExitSharedElementCallback(C04310Ld r2) {
        AnonymousClass0Y8 r0;
        if (r2 != null) {
            r0 = new AnonymousClass0Y8(r2);
        } else {
            r0 = null;
        }
        setExitSharedElementCallback(r0);
    }

    public FragmentActivity(int i) {
        super(i);
        init();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (shouldDumpInternalState(strArr)) {
            printWriter.print(str);
            printWriter.print("Local FragmentActivity ");
            AnonymousClass001.A1D(printWriter, System.identityHashCode(this));
            printWriter.println(" State:");
            String A0i = AnonymousClass0WY.A0i(str, "  ");
            printWriter.print(A0i);
            printWriter.print("mCreated=");
            printWriter.print(this.mCreated);
            printWriter.print(" mResumed=");
            printWriter.print(this.mResumed);
            printWriter.print(" mStopped=");
            printWriter.print(this.mStopped);
            if (getApplication() != null) {
                AnonymousClass0LO.A00(this).A03(A0i, fileDescriptor, printWriter, strArr);
            }
            this.mFragments.A00.A03.A0u(str, fileDescriptor, printWriter, strArr);
        }
    }

    @Deprecated
    public AnonymousClass0LO getSupportLoaderManager() {
        return AnonymousClass0LO.A00(this);
    }

    /* renamed from: lambda$init$0$androidx-fragment-app-FragmentActivity  reason: not valid java name */
    public /* synthetic */ Bundle m4lambda$init$0$androidxfragmentappFragmentActivity() {
        markFragmentsCreated();
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_STOP);
        return AnonymousClass001.A08();
    }

    public void markFragmentsCreated() {
        do {
        } while (markState(getSupportFragmentManager(), C09740eO.CREATED));
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        A00(this);
        super.onActivityResult(i, i2, intent);
    }

    public void onCreate(Bundle bundle) {
        int A00 = AnonymousClass0BS.A00(-1607969077);
        super.onCreate(bundle);
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_CREATE);
        AnonymousClass0PW r2 = this.mFragments.A00.A03;
        r2.A0I = false;
        r2.A0J = false;
        r2.A0A.A01 = false;
        AnonymousClass0PW.A0B(r2, 1);
        AnonymousClass0BS.A07(-31364971, A00);
    }

    public void onDestroy() {
        int A00 = AnonymousClass0BS.A00(-657998352);
        super.onDestroy();
        this.mFragments.A00.A03.A0Y();
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_DESTROY);
        AnonymousClass0BS.A07(878966625, A00);
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i != 6) {
            return false;
        }
        AnonymousClass0PW r2 = this.mFragments.A00.A03;
        if (r2.A00 < 1) {
            return false;
        }
        Iterator A00 = AnonymousClass0D1.A00(r2);
        while (A00.hasNext()) {
            Fragment fragment = (Fragment) A00.next();
            if (fragment != null && fragment.performContextItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public void onPause() {
        int A00 = AnonymousClass0BS.A00(1017292864);
        super.onPause();
        this.mResumed = false;
        AnonymousClass0PW.A0B(this.mFragments.A00.A03, 5);
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_PAUSE);
        AnonymousClass0BS.A07(1576098307, A00);
    }

    public void onPostResume() {
        super.onPostResume();
        onResumeFragments();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        A00(this);
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    public void onResume() {
        int A00 = AnonymousClass0BS.A00(561736250);
        A00(this);
        super.onResume();
        this.mResumed = true;
        this.mFragments.A00.A03.A0v(true);
        AnonymousClass0BS.A07(-1018825767, A00);
    }

    public void onStart() {
        int A00 = AnonymousClass0BS.A00(1455024966);
        A00(this);
        super.onStart();
        this.mStopped = false;
        if (!this.mCreated) {
            this.mCreated = true;
            AnonymousClass0PW r1 = this.mFragments.A00.A03;
            r1.A0I = false;
            r1.A0J = false;
            r1.A0A.A01 = false;
            AnonymousClass0PW.A0B(r1, 4);
        }
        this.mFragments.A00.A03.A0v(true);
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_START);
        AnonymousClass0PW r12 = this.mFragments.A00.A03;
        r12.A0I = false;
        r12.A0J = false;
        r12.A0A.A01 = false;
        AnonymousClass0PW.A0B(r12, 5);
        AnonymousClass0BS.A07(-2036869785, A00);
    }

    public void onStateNotSaved() {
        A00(this);
    }

    public void onStop() {
        int A00 = AnonymousClass0BS.A00(1355157239);
        super.onStop();
        this.mStopped = true;
        markFragmentsCreated();
        AnonymousClass0PW r1 = this.mFragments.A00.A03;
        r1.A0J = true;
        r1.A0A.A01 = true;
        AnonymousClass0PW.A0B(r1, 4);
        this.mFragmentLifecycleRegistry.A07(C09730eN.ON_STOP);
        AnonymousClass0BS.A07(853652186, A00);
    }

    public void supportFinishAfterTransition() {
        finishAfterTransition();
    }

    @Deprecated
    public void supportInvalidateOptionsMenu() {
        invalidateOptionsMenu();
    }

    public void supportPostponeEnterTransition() {
        postponeEnterTransition();
    }

    public void supportStartPostponedEnterTransition() {
        startPostponedEnterTransition();
    }

    /* renamed from: lambda$init$1$androidx-fragment-app-FragmentActivity  reason: not valid java name */
    public /* synthetic */ void m5lambda$init$1$androidxfragmentappFragmentActivity(Configuration configuration) {
        A00(this);
    }

    /* renamed from: lambda$init$2$androidx-fragment-app-FragmentActivity  reason: not valid java name */
    public /* synthetic */ void m6lambda$init$2$androidxfragmentappFragmentActivity(Intent intent) {
        A00(this);
    }

    @Deprecated
    public void onAttachFragment(Fragment fragment) {
    }

    @Deprecated
    public final void validateRequestPermissionsRequestCode(int i) {
    }

    public FragmentActivity() {
        init();
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View onCreateView = this.mFragments.A00.A03.A0S.onCreateView((View) null, str, context, attributeSet);
        if (onCreateView == null) {
            return super.onCreateView(str, context, attributeSet);
        }
        return onCreateView;
    }

    public void startActivityFromFragment(Fragment fragment, Intent intent, int i) {
        startActivityFromFragment(fragment, intent, i, (Bundle) null);
    }
}
