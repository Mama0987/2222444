package androidx.fragment.app;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass077;
import X.AnonymousClass07U;
import X.AnonymousClass083;
import X.AnonymousClass08B;
import X.AnonymousClass0D6;
import X.AnonymousClass0PW;
import X.AnonymousClass0Rm;
import X.AnonymousClass0WY;
import X.C15800sA;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class FragmentContainerView extends FrameLayout {
    public boolean A00;
    public View.OnApplyWindowInsetsListener A01;
    public final List A02;
    public final List A03;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
        C15800sA.A0D(context, 1);
    }

    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        C15800sA.A0D(view, 0);
        Object tag = view.getTag(2131365060);
        if (!(tag instanceof Fragment) || tag == null) {
            StringBuilder A0m = AnonymousClass001.A0m();
            A0m.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
            A0m.append(view);
            throw AnonymousClass002.A0I(" is not associated with a Fragment.", A0m);
        }
        super.addView(view, i, layoutParams);
    }

    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        AnonymousClass077 A05;
        C15800sA.A0D(windowInsets, 0);
        AnonymousClass077 r1 = new AnonymousClass077(windowInsets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.A01;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets onApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            C15800sA.A09(onApplyWindowInsets);
            A05 = new AnonymousClass077(onApplyWindowInsets);
        } else {
            A05 = AnonymousClass07U.A05(this, r1);
        }
        if (!A05.A00.A0A()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                AnonymousClass07U.A04(getChildAt(i), A05);
            }
        }
        return windowInsets;
    }

    public final void dispatchDraw(Canvas canvas) {
        C15800sA.A0D(canvas, 0);
        if (this.A00) {
            for (View drawChild : this.A02) {
                super.drawChild(canvas, drawChild, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    public final void endViewTransition(View view) {
        C15800sA.A0D(view, 0);
        this.A03.remove(view);
        if (this.A02.remove(view)) {
            this.A00 = true;
        }
        super.endViewTransition(view);
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        C15800sA.A0D(windowInsets, 0);
        return windowInsets;
    }

    public final void removeView(View view) {
        C15800sA.A0D(view, 0);
        A00(view);
        super.removeView(view);
    }

    public final void removeViewInLayout(View view) {
        C15800sA.A0D(view, 0);
        A00(view);
        super.removeViewInLayout(view);
    }

    public final void startViewTransition(View view) {
        C15800sA.A0D(view, 0);
        if (view.getParent() == this) {
            this.A03.add(view);
        }
        super.startViewTransition(view);
    }

    private final void A00(View view) {
        if (this.A03.contains(view)) {
            this.A02.add(view);
        }
    }

    public final void removeViews(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            C15800sA.A09(childAt);
            A00(childAt);
        }
        super.removeViews(i, i2);
    }

    public final void removeViewsInLayout(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            C15800sA.A09(childAt);
            A00(childAt);
        }
        super.removeViewsInLayout(i, i2);
    }

    public final void setLayoutTransition(LayoutTransition layoutTransition) {
        throw AnonymousClass001.A0r("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    public final boolean drawChild(Canvas canvas, View view, long j) {
        boolean A0Q = C15800sA.A0Q(canvas, view);
        if (this.A00) {
            List list = this.A02;
            if (!list.isEmpty() && list.contains(view)) {
                return A0Q;
            }
        }
        return super.drawChild(canvas, view, j);
    }

    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 < childCount) {
                View childAt = getChildAt(childCount);
                C15800sA.A09(childAt);
                A00(childAt);
            } else {
                super.removeAllViewsInLayout();
                return;
            }
        }
    }

    public final void removeViewAt(int i) {
        View childAt = getChildAt(i);
        C15800sA.A09(childAt);
        A00(childAt);
        super.removeViewAt(i);
    }

    public final void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        this.A01 = onApplyWindowInsetsListener;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        String str;
        C15800sA.A0D(context, 1);
        this.A02 = AnonymousClass001.A0t();
        this.A03 = AnonymousClass001.A0t();
        this.A00 = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            int[] iArr = AnonymousClass0Rm.A01;
            C15800sA.A0A(iArr);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
            if (classAttribute == null) {
                classAttribute = obtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            obtainStyledAttributes.recycle();
            if (classAttribute != null && !isInEditMode()) {
                throw AnonymousClass001.A0r(AnonymousClass0WY.A19("FragmentContainerView must be within a FragmentActivity to use ", str, "=\"", classAttribute, '\"'));
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, AnonymousClass0PW r8) {
        super(context, attributeSet);
        View view;
        String str;
        C15800sA.A0E(context, 1, attributeSet);
        C15800sA.A0D(r8, 3);
        this.A02 = AnonymousClass001.A0t();
        this.A03 = AnonymousClass001.A0t();
        this.A00 = true;
        String classAttribute = attributeSet.getClassAttribute();
        int[] iArr = AnonymousClass0Rm.A01;
        C15800sA.A0A(iArr);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(0) : classAttribute;
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        Fragment A0O = r8.A0O(id);
        if (classAttribute != null && A0O == null) {
            if (id == -1) {
                if (string != null) {
                    str = AnonymousClass0WY.A0i(" with tag ", string);
                } else {
                    str = "";
                }
                throw AnonymousClass0WY.A09("FragmentContainerView must have an android:id to add Fragment ", classAttribute, str);
            }
            AnonymousClass0D6 A0R = r8.A0R();
            context.getClassLoader();
            Fragment A002 = A0R.A00(classAttribute);
            C15800sA.A09(A002);
            A002.mFragmentId = id;
            A002.mContainerId = id;
            A002.mTag = string;
            A002.mFragmentManager = r8;
            A002.mHost = r8.A09;
            A002.onInflate(context, attributeSet, (Bundle) null);
            AnonymousClass083 r1 = new AnonymousClass083(r8);
            r1.A0G = true;
            A002.mContainer = this;
            A002.mInDynamicContainer = true;
            r1.A0M(A002, string, getId(), 1);
            r1.A06();
        }
        Iterator it = r8.A0U.A03().iterator();
        while (it.hasNext()) {
            AnonymousClass08B r3 = (AnonymousClass08B) it.next();
            Fragment fragment = r3.A02;
            if (fragment.mContainerId == getId() && (view = fragment.mView) != null && view.getParent() == null) {
                fragment.mContainer = this;
                r3.A02();
                r3.A04();
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ FragmentContainerView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context) {
        super(context);
        C15800sA.A0D(context, 1);
        this.A02 = AnonymousClass001.A0t();
        this.A03 = AnonymousClass001.A0t();
        this.A00 = true;
    }
}
