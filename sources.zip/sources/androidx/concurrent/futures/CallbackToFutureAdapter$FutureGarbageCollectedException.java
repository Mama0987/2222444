package androidx.concurrent.futures;

public final class CallbackToFutureAdapter$FutureGarbageCollectedException extends Throwable {
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
