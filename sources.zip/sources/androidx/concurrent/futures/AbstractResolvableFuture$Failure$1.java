package androidx.concurrent.futures;

public class AbstractResolvableFuture$Failure$1 extends Throwable {
    public synchronized Throwable fillInStackTrace() {
        return this;
    }

    public AbstractResolvableFuture$Failure$1(String str) {
        super("Failure occurred while trying to finish a future.");
    }
}
