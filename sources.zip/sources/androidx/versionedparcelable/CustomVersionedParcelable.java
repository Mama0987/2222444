package androidx.versionedparcelable;

import X.AnonymousClass0Qz;

public abstract class CustomVersionedParcelable implements AnonymousClass0Qz {
}
