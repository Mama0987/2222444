package androidx.startup;

import X.AnonymousClass001;
import X.C10530fl;
import X.C10560fp;
import X.C10570fq;
import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import com.facebook.common.dextricks.DalvikInternals;

public class InitializationProvider extends ContentProvider {
    public final int delete(Uri uri, String str, String[] strArr) {
        throw AnonymousClass001.A0P("Not allowed.");
    }

    public final String getType(Uri uri) {
        throw AnonymousClass001.A0P("Not allowed.");
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        throw AnonymousClass001.A0P("Not allowed.");
    }

    public final Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        throw AnonymousClass001.A0P("Not allowed.");
    }

    public final int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw AnonymousClass001.A0P("Not allowed.");
    }

    public final boolean onCreate() {
        Context context = getContext();
        if (context == null) {
            throw new RuntimeException("Context cannot be null");
        } else if (context.getApplicationContext() == null) {
            return true;
        } else {
            C10530fl A00 = C10530fl.A00(context);
            Class<?> cls = getClass();
            try {
                C10560fp.A01("Startup");
                Context context2 = A00.A00;
                A00.discoverAndInitialize(context2.getPackageManager().getProviderInfo(new ComponentName(context2, cls), DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS).metaData);
                C10570fq.A00();
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                throw new RuntimeException(e);
            } catch (Throwable th) {
                C10570fq.A00();
                throw th;
            }
        }
    }
}
