package androidx.activity.result;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass16N;
import X.C15800sA;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

public final class ActivityResult implements Parcelable {
    public static final Parcelable.Creator CREATOR = new AnonymousClass16N(0);
    public final int A00;
    public final Intent A01;

    public final void writeToParcel(Parcel parcel, int i) {
        C15800sA.A0D(parcel, 0);
        parcel.writeInt(this.A00);
        Intent intent = this.A01;
        int i2 = 1;
        if (intent == null) {
            i2 = 0;
        }
        parcel.writeInt(i2);
        if (intent != null) {
            intent.writeToParcel(parcel, i);
        }
    }

    public ActivityResult(int i, Intent intent) {
        this.A00 = i;
        this.A01 = intent;
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        String str;
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append("ActivityResult{resultCode=");
        int i = this.A00;
        if (i == -1) {
            str = "RESULT_OK";
        } else if (i != 0) {
            str = String.valueOf(i);
        } else {
            str = "RESULT_CANCELED";
        }
        A0m.append(str);
        A0m.append(", data=");
        A0m.append(this.A01);
        return AnonymousClass002.A0P(A0m);
    }
}
