package androidx.activity;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass00Q;
import X.AnonymousClass02B;
import X.AnonymousClass02D;
import X.AnonymousClass08p;
import X.AnonymousClass0BS;
import X.AnonymousClass0BV;
import X.AnonymousClass0BY;
import X.AnonymousClass0BZ;
import X.AnonymousClass0C4;
import X.AnonymousClass0Cp;
import X.AnonymousClass0D5;
import X.AnonymousClass0Hh;
import X.AnonymousClass0Ou;
import X.AnonymousClass0P0;
import X.AnonymousClass0P1;
import X.AnonymousClass0P2;
import X.AnonymousClass0PG;
import X.AnonymousClass0PO;
import X.AnonymousClass0PP;
import X.AnonymousClass0PQ;
import X.AnonymousClass0PS;
import X.AnonymousClass0PX;
import X.AnonymousClass0PY;
import X.AnonymousClass0R7;
import X.AnonymousClass0S2;
import X.AnonymousClass0WY;
import X.AnonymousClass0YR;
import X.AnonymousClass0ZS;
import X.AnonymousClass170;
import X.AnonymousClass172;
import X.AnonymousClass17D;
import X.C02240Bb;
import X.C02490Ce;
import X.C02500Cf;
import X.C02510Cg;
import X.C02520Ch;
import X.C02530Ci;
import X.C02560Cl;
import X.C02570Cm;
import X.C02580Cn;
import X.C02590Co;
import X.C02600Ct;
import X.C02620Cw;
import X.C02630Cx;
import X.C02640Cy;
import X.C03390Gt;
import X.C03490Hd;
import X.C03500He;
import X.C03510Hf;
import X.C03680Ib;
import X.C05030Os;
import X.C05040Ot;
import X.C05050Ov;
import X.C05060Ow;
import X.C05070Ox;
import X.C05080Oy;
import X.C05090Oz;
import X.C05770Tb;
import X.C06300Vs;
import X.C06460Wi;
import X.C08370bv;
import X.C09730eN;
import X.C09740eO;
import X.C09750eP;
import X.C09780eT;
import X.C10560fp;
import X.C10570fq;
import X.C15800sA;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Deprecated;

public class ComponentActivity extends androidx.core.app.ComponentActivity implements C06460Wi, C05030Os, C05040Ot, AnonymousClass0Ou, C05050Ov, C05060Ow, C05070Ox, C05080Oy, C05090Oz, AnonymousClass0P0, AnonymousClass0P1, AnonymousClass0P2 {
    public static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
    public static final C02490Ce Companion = new Object();
    public AnonymousClass0BZ _viewModelStore;
    public final AnonymousClass0PP activityResultRegistry;
    public int contentLayoutId;
    public final C02500Cf contextAwareHelper;
    public final AnonymousClass0PG defaultViewModelProviderFactory$delegate;
    public boolean dispatchingOnMultiWindowModeChanged;
    public boolean dispatchingOnPictureInPictureModeChanged;
    public final AnonymousClass0PG fullyDrawnReporter$delegate;
    public final C02520Ch menuHostHelper;
    public final AtomicInteger nextLocalRequestCode;
    public final AnonymousClass0PG onBackPressedDispatcher$delegate;
    public final CopyOnWriteArrayList onConfigurationChangedListeners;
    public final CopyOnWriteArrayList onMultiWindowModeChangedListeners;
    public final CopyOnWriteArrayList onNewIntentListeners;
    public final CopyOnWriteArrayList onPictureInPictureModeChangedListeners;
    public final CopyOnWriteArrayList onTrimMemoryListeners;
    public final CopyOnWriteArrayList onUserLeaveHintListeners;
    public final AnonymousClass0PO reportFullyDrawnExecutor;
    public final C02560Cl savedStateRegistryController;

    public static final void _init_$lambda$2(ComponentActivity componentActivity, C06460Wi r2, C09730eN r3) {
        Window window;
        View peekDecorView;
        C15800sA.A0D(r3, 2);
        if (r3 == C09730eN.ON_STOP && (window = componentActivity.getWindow()) != null && (peekDecorView = window.peekDecorView()) != null) {
            peekDecorView.cancelPendingInputEvents();
        }
    }

    public static final void _init_$lambda$3(ComponentActivity componentActivity, C06460Wi r3, C09730eN r4) {
        C15800sA.A0D(r4, 2);
        if (r4 == C09730eN.ON_DESTROY) {
            componentActivity.contextAwareHelper.A01 = null;
            if (!componentActivity.isChangingConfigurations()) {
                componentActivity.getViewModelStore().A00();
            }
            C02580Cn r2 = (C02580Cn) componentActivity.reportFullyDrawnExecutor;
            ComponentActivity componentActivity2 = r2.A03;
            componentActivity2.getWindow().getDecorView().removeCallbacks(r2);
            componentActivity2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(r2);
        }
    }

    public static final void addObserverForBackInvoker$lambda$7(AnonymousClass0BV r1, ComponentActivity componentActivity, C06460Wi r3, C09730eN r4) {
        C15800sA.A0D(r4, 3);
        if (r4 == C09730eN.ON_CREATE) {
            r1.A06(AnonymousClass02D.A00(componentActivity));
        }
    }

    public final void addOnConfigurationChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onConfigurationChangedListeners.add(r2);
    }

    public final void addOnContextAvailableListener(AnonymousClass0PS r3) {
        C15800sA.A0D(r3, 0);
        C02500Cf r1 = this.contextAwareHelper;
        Context context = r1.A01;
        if (context != null) {
            r3.Cg9(context);
        }
        r1.A00.add(r3);
    }

    public final void addOnMultiWindowModeChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onMultiWindowModeChangedListeners.add(r2);
    }

    public final void addOnNewIntentListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onNewIntentListeners.add(r2);
    }

    public final void addOnPictureInPictureModeChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onPictureInPictureModeChangedListeners.add(r2);
    }

    public final void addOnTrimMemoryListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onTrimMemoryListeners.add(r2);
    }

    public final void addOnUserLeaveHintListener(Runnable runnable) {
        C15800sA.A0D(runnable, 0);
        this.onUserLeaveHintListeners.add(runnable);
    }

    public void onConfigurationChanged(Configuration configuration) {
        C15800sA.A0D(configuration, 0);
        super.onConfigurationChanged(configuration);
        Iterator it = this.onConfigurationChangedListeners.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0PX) it.next()).accept(configuration);
        }
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        C15800sA.A0D(menu, 1);
        if (i == 0) {
            super.onCreatePanelMenu(i, menu);
            C02520Ch r0 = this.menuHostHelper;
            MenuInflater menuInflater = getMenuInflater();
            Iterator it = r0.A02.iterator();
            while (it.hasNext()) {
                ((AnonymousClass0D5) ((AnonymousClass0PY) it.next())).A00.A0z(menu, menuInflater);
            }
        }
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        C15800sA.A0D(menuItem, 1);
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i != 0) {
            return false;
        }
        Iterator it = this.menuHostHelper.A02.iterator();
        while (it.hasNext()) {
            if (((AnonymousClass0D5) ((AnonymousClass0PY) it.next())).A00.A10(menuItem)) {
            }
        }
        return false;
        return true;
    }

    /* JADX INFO: finally extract failed */
    public void onMultiWindowModeChanged(boolean z, Configuration configuration) {
        C15800sA.A0D(configuration, 1);
        this.dispatchingOnMultiWindowModeChanged = true;
        try {
            super.onMultiWindowModeChanged(z, configuration);
            this.dispatchingOnMultiWindowModeChanged = false;
            Iterator it = this.onMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                AnonymousClass0YR r0 = new AnonymousClass0YR(z);
                r0.A00 = configuration;
                ((AnonymousClass0PX) it.next()).accept(r0);
            }
        } catch (Throwable th) {
            this.dispatchingOnMultiWindowModeChanged = false;
            throw th;
        }
    }

    public void onNewIntent(Intent intent) {
        C15800sA.A0D(intent, 0);
        super.onNewIntent(intent);
        Iterator it = this.onNewIntentListeners.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0PX) it.next()).accept(intent);
        }
    }

    public void onPanelClosed(int i, Menu menu) {
        C15800sA.A0D(menu, 1);
        Iterator it = this.menuHostHelper.A02.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0D5) ((AnonymousClass0PY) it.next())).A00.A0f(menu);
        }
        super.onPanelClosed(i, menu);
    }

    /* JADX INFO: finally extract failed */
    public void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        C15800sA.A0D(configuration, 1);
        this.dispatchingOnPictureInPictureModeChanged = true;
        try {
            super.onPictureInPictureModeChanged(z, configuration);
            this.dispatchingOnPictureInPictureModeChanged = false;
            Iterator it = this.onPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                AnonymousClass0ZS r0 = new AnonymousClass0ZS(z);
                r0.A00 = configuration;
                ((AnonymousClass0PX) it.next()).accept(r0);
            }
        } catch (Throwable th) {
            this.dispatchingOnPictureInPictureModeChanged = false;
            throw th;
        }
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        C15800sA.A0D(menu, 2);
        if (i != 0) {
            return true;
        }
        super.onPreparePanel(i, view, menu);
        Iterator it = this.menuHostHelper.A02.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0D5) ((AnonymousClass0PY) it.next())).A00.A0y(menu);
        }
        return true;
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)} passing\n      in a {@link RequestMultiplePermissions} object for the {@link ActivityResultContract} and\n      handling the result in the {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        C15800sA.A0E(strArr, 1, iArr);
        if (!this.activityResultRegistry.A05(new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr), i, -1)) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, X.0BY] */
    public final Object onRetainNonConfigurationInstance() {
        AnonymousClass0BY r0;
        AnonymousClass0BZ r02 = this._viewModelStore;
        if (r02 == null && ((r0 = (AnonymousClass0BY) getLastNonConfigurationInstance()) == null || (r02 = r0.A00) == null)) {
            return null;
        }
        ? obj = new Object();
        obj.A00 = r02;
        return obj;
    }

    public void onSaveInstanceState(Bundle bundle) {
        C15800sA.A0D(bundle, 0);
        C09780eT r1 = this.lifecycleRegistry;
        if (r1 != null) {
            r1.A08(C09740eO.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.savedStateRegistryController.A01(bundle);
    }

    public void removeMenuProvider(AnonymousClass0PY r2) {
        C15800sA.A0D(r2, 0);
        this.menuHostHelper.A00(r2);
    }

    public final void removeOnConfigurationChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onConfigurationChangedListeners.remove(r2);
    }

    public final void removeOnContextAvailableListener(AnonymousClass0PS r2) {
        C15800sA.A0D(r2, 0);
        this.contextAwareHelper.A00.remove(r2);
    }

    public final void removeOnMultiWindowModeChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onMultiWindowModeChangedListeners.remove(r2);
    }

    public final void removeOnNewIntentListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onNewIntentListeners.remove(r2);
    }

    public final void removeOnPictureInPictureModeChangedListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onPictureInPictureModeChangedListeners.remove(r2);
    }

    public final void removeOnTrimMemoryListener(AnonymousClass0PX r2) {
        C15800sA.A0D(r2, 0);
        this.onTrimMemoryListeners.remove(r2);
    }

    public final void removeOnUserLeaveHintListener(Runnable runnable) {
        C15800sA.A0D(runnable, 0);
        this.onUserLeaveHintListeners.remove(runnable);
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      passing in a {@link StartActivityForResult} object for the {@link ActivityResultContract}.")
    public void startActivityForResult(Intent intent, int i) {
        C15800sA.A0D(intent, 0);
        super.startActivityForResult(intent, i);
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      passing in a {@link StartIntentSenderForResult} object for the\n      {@link ActivityResultContract}.")
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        C15800sA.A0D(intentSender, 0);
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }

    public static final void _init_$lambda$5(ComponentActivity componentActivity, Context context) {
        Bundle A00 = componentActivity.savedStateRegistryController.A00.A00(ACTIVITY_RESULT_TAG);
        if (A00 != null) {
            AnonymousClass0PP r8 = componentActivity.activityResultRegistry;
            ArrayList<Integer> integerArrayList = A00.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = A00.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                ArrayList<String> stringArrayList2 = A00.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                if (stringArrayList2 != null) {
                    r8.A01.addAll(stringArrayList2);
                }
                Bundle bundle = A00.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                if (bundle != null) {
                    r8.A00.putAll(bundle);
                }
                int size = stringArrayList.size();
                for (int i = 0; i < size; i++) {
                    String str = stringArrayList.get(i);
                    Map map = r8.A02;
                    if (map.containsKey(str)) {
                        Object remove = map.remove(str);
                        if (!r8.A00.containsKey(str)) {
                            AnonymousClass08p.A03(r8.A04).remove(remove);
                        }
                    }
                    Integer num = integerArrayList.get(i);
                    C15800sA.A09(num);
                    int intValue = num.intValue();
                    String str2 = stringArrayList.get(i);
                    C15800sA.A09(str2);
                    Integer valueOf = Integer.valueOf(intValue);
                    r8.A04.put(valueOf, str2);
                    map.put(str2, valueOf);
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public final void addObserverForBackInvoker(AnonymousClass0BV r4) {
        this.lifecycleRegistry.A05(new AnonymousClass172(0, this, r4));
    }

    private final AnonymousClass0PO createFullyDrawnExecutor() {
        return new C02580Cn(this);
    }

    /* access modifiers changed from: private */
    public final void ensureViewModelStore() {
        if (this._viewModelStore == null) {
            AnonymousClass0BY r0 = (AnonymousClass0BY) getLastNonConfigurationInstance();
            if (r0 != null) {
                this._viewModelStore = r0.A00;
            }
            if (this._viewModelStore == null) {
                this._viewModelStore = new AnonymousClass0BZ();
            }
        }
    }

    public C03500He getDefaultViewModelCreationExtras() {
        Bundle extras;
        AnonymousClass0C4 r2 = new AnonymousClass0C4(C02240Bb.A00);
        if (getApplication() != null) {
            AnonymousClass0PQ r1 = AnonymousClass02B.A02;
            Application application = getApplication();
            C15800sA.A09(application);
            r2.A01(r1, application);
        }
        r2.A01(C02600Ct.A01, this);
        r2.A01(C02600Ct.A02, this);
        Intent intent = getIntent();
        if (!(intent == null || (extras = intent.getExtras()) == null)) {
            r2.A01(C02600Ct.A00, extras);
        }
        return r2;
    }

    public C03490Hd getDefaultViewModelProviderFactory() {
        return (C03490Hd) this.defaultViewModelProviderFactory$delegate.getValue();
    }

    public AnonymousClass0R7 getFullyDrawnReporter() {
        return (AnonymousClass0R7) this.fullyDrawnReporter$delegate.getValue();
    }

    public final AnonymousClass0BV getOnBackPressedDispatcher() {
        return (AnonymousClass0BV) this.onBackPressedDispatcher$delegate.getValue();
    }

    public final C02570Cm getSavedStateRegistry() {
        return this.savedStateRegistryController.A00;
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      with the appropriate {@link ActivityResultContract} and handling the result in the\n      {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    public void onActivityResult(int i, int i2, Intent intent) {
        if (!this.activityResultRegistry.A05(intent, i, i2)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public Context peekAvailableContext() {
        return this.contextAwareHelper.A01;
    }

    public ComponentActivity(int i) {
        this();
        this.contentLayoutId = i;
    }

    public static void A01(ComponentActivity componentActivity) {
        componentActivity.initializeViewTreeOwners();
        AnonymousClass0PO r2 = componentActivity.reportFullyDrawnExecutor;
        View decorView = componentActivity.getWindow().getDecorView();
        C15800sA.A09(decorView);
        C02580Cn r22 = (C02580Cn) r2;
        if (!r22.A01) {
            r22.A01 = true;
            decorView.getViewTreeObserver().addOnDrawListener(r22);
        }
    }

    public static final Bundle _init_$lambda$4(ComponentActivity componentActivity) {
        Bundle A08 = AnonymousClass001.A08();
        AnonymousClass0PP r3 = componentActivity.activityResultRegistry;
        Map map = r3.A02;
        A08.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", AnonymousClass001.A0v(map.values()));
        A08.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", AnonymousClass001.A0v(map.keySet()));
        A08.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", AnonymousClass001.A0v(r3.A01));
        A08.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(r3.A00));
        return A08;
    }

    public static /* synthetic */ void getOnBackPressedDispatcher$annotations() {
    }

    public static /* synthetic */ void getSavedStateRegistryController$annotations() {
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        A01(this);
        super.addContentView(view, layoutParams);
    }

    public void addMenuProvider(AnonymousClass0PY r7, C06460Wi r8) {
        boolean A0R = C15800sA.A0R(r7, r8);
        C02520Ch r4 = this.menuHostHelper;
        r4.A02.add(r7);
        r4.A00.run();
        C09750eP lifecycle = r8.getLifecycle();
        Map map = r4.A01;
        AnonymousClass002.A0n(map, r7);
        map.put(r7, new C05770Tb(lifecycle, new AnonymousClass172(A0R ? 1 : 0, r7, r4)));
    }

    public final AnonymousClass0PP getActivityResultRegistry() {
        return this.activityResultRegistry;
    }

    @Deprecated(message = "Use a {@link androidx.lifecycle.ViewModel} to store non config state.")
    public Object getLastCustomNonConfigurationInstance() {
        getLastNonConfigurationInstance();
        return null;
    }

    public C09750eP getLifecycle() {
        return this.lifecycleRegistry;
    }

    public AnonymousClass0BZ getViewModelStore() {
        if (getApplication() != null) {
            ensureViewModelStore();
            AnonymousClass0BZ r0 = this._viewModelStore;
            if (r0 != null) {
                return r0;
            }
            C15800sA.A0C(r0);
            throw C06300Vs.createAndThrow();
        }
        throw AnonymousClass001.A0P("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public void initializeViewTreeOwners() {
        C15800sA.A02(this).setTag(2131370787, this);
        C15800sA.A02(this).setTag(2131370790, this);
        C15800sA.A02(this).setTag(2131370789, this);
        C15800sA.A02(this).setTag(2131370788, this);
        C15800sA.A02(this).setTag(2131368666, this);
    }

    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    @Deprecated(message = "This method has been deprecated in favor of using the\n      {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n      The OnBackPressedDispatcher controls how back button events are dispatched\n      to one or more {@link OnBackPressedCallback} objects.")
    public void onBackPressed() {
        AnonymousClass0S2.A00(this);
        getOnBackPressedDispatcher().A05();
    }

    public void onCreate(Bundle bundle) {
        int A00 = AnonymousClass0BS.A00(950917542);
        this.savedStateRegistryController.A00(bundle);
        C02500Cf r0 = this.contextAwareHelper;
        r0.A01 = this;
        for (AnonymousClass0PS Cg9 : r0.A00) {
            Cg9.Cg9(this);
        }
        super.onCreate(bundle);
        AnonymousClass00Q.A00(this);
        int i = this.contentLayoutId;
        if (i != 0) {
            setContentView(i);
        }
        AnonymousClass0BS.A07(-1508650169, A00);
    }

    @Deprecated(message = "Use a {@link androidx.lifecycle.ViewModel} to store non config state.")
    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    public void onTrimMemory(int i) {
        super.onTrimMemory(i);
        Iterator it = this.onTrimMemoryListeners.iterator();
        while (it.hasNext()) {
            ((AnonymousClass0PX) it.next()).accept(Integer.valueOf(i));
        }
    }

    public void onUserLeaveHint() {
        AnonymousClass0S2.A03(this);
        super.onUserLeaveHint();
        Iterator it = this.onUserLeaveHintListeners.iterator();
        while (it.hasNext()) {
            ((Runnable) it.next()).run();
        }
    }

    public final AnonymousClass0Hh registerForActivityResult(C03390Gt r2, C03510Hf r3) {
        C15800sA.A0F(r2, r3);
        return registerForActivityResult(r2, this.activityResultRegistry, r3);
    }

    public void reportFullyDrawn() {
        try {
            if (C10560fp.A05()) {
                C10560fp.A01("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            getFullyDrawnReporter().A00();
        } finally {
            C10570fq.A00();
        }
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        A01(this);
        super.setContentView(view, layoutParams);
    }

    public static final void menuHostHelper$lambda$0(ComponentActivity componentActivity) {
        componentActivity.invalidateOptionsMenu();
    }

    public void addMenuProvider(AnonymousClass0PY r5, C06460Wi r6, C09740eO r7) {
        C15800sA.A0F(r5, r6);
        C15800sA.A0D(r7, 2);
        C02520Ch r0 = this.menuHostHelper;
        C09750eP lifecycle = r6.getLifecycle();
        Map map = r0.A01;
        AnonymousClass002.A0n(map, r5);
        map.put(r5, new C05770Tb(lifecycle, new C08370bv(r0, r5, r7)));
    }

    @Deprecated(message = "Deprecated in android.app.Activity")
    public void onMultiWindowModeChanged(boolean z) {
        if (!this.dispatchingOnMultiWindowModeChanged) {
            Iterator it = this.onMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                ((AnonymousClass0PX) it.next()).accept(new AnonymousClass0YR(z));
            }
        }
    }

    @Deprecated(message = "Deprecated in android.app.Activity")
    public void onPictureInPictureModeChanged(boolean z) {
        if (!this.dispatchingOnPictureInPictureModeChanged) {
            Iterator it = this.onPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                ((AnonymousClass0PX) it.next()).accept(new AnonymousClass0ZS(z));
            }
        }
    }

    public final AnonymousClass0Hh registerForActivityResult(C03390Gt r3, AnonymousClass0PP r4, C03510Hf r5) {
        C15800sA.A0F(r3, r4);
        C15800sA.A0D(r5, 2);
        return r4.A01(r5, r3, this, AnonymousClass0WY.A0d("activity_rq#", this.nextLocalRequestCode.getAndIncrement()));
    }

    public void setContentView(int i) {
        A01(this);
        super.setContentView(i);
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      passing in a {@link StartActivityForResult} object for the {@link ActivityResultContract}.")
    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        C15800sA.A0D(intent, 0);
        super.startActivityForResult(intent, i, bundle);
    }

    @Deprecated(message = "This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      passing in a {@link StartIntentSenderForResult} object for the\n      {@link ActivityResultContract}.")
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        C15800sA.A0D(intentSender, 0);
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public ComponentActivity() {
        this.contextAwareHelper = new C02500Cf();
        this.menuHostHelper = new C02520Ch(new C02510Cg(this));
        C02560Cl A00 = C02530Ci.A00(this);
        this.savedStateRegistryController = A00;
        this.reportFullyDrawnExecutor = new C02580Cn(this);
        this.fullyDrawnReporter$delegate = C03680Ib.A01(new C02590Co(this));
        this.nextLocalRequestCode = new AtomicInteger();
        this.activityResultRegistry = new AnonymousClass0Cp(this);
        this.onConfigurationChangedListeners = new CopyOnWriteArrayList();
        this.onTrimMemoryListeners = new CopyOnWriteArrayList();
        this.onNewIntentListeners = new CopyOnWriteArrayList();
        this.onMultiWindowModeChangedListeners = new CopyOnWriteArrayList();
        this.onPictureInPictureModeChangedListeners = new CopyOnWriteArrayList();
        this.onUserLeaveHintListeners = new CopyOnWriteArrayList();
        C09780eT r1 = this.lifecycleRegistry;
        if (r1 != null) {
            r1.A05(new AnonymousClass170(this, 0));
            this.lifecycleRegistry.A05(new AnonymousClass170(this, 1));
            this.lifecycleRegistry.A05(new AnonymousClass170(this, 2));
            A00.A01.A00();
            C02600Ct.A02(this);
            this.savedStateRegistryController.A00.A03(new AnonymousClass17D(this, 0), ACTIVITY_RESULT_TAG);
            addOnContextAvailableListener(new C02620Cw(this));
            this.defaultViewModelProviderFactory$delegate = C03680Ib.A01(new C02630Cx(this));
            this.onBackPressedDispatcher$delegate = C03680Ib.A01(new C02640Cy(this));
            return;
        }
        throw AnonymousClass001.A0P("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    public void addMenuProvider(AnonymousClass0PY r3) {
        C15800sA.A0D(r3, 0);
        C02520Ch r1 = this.menuHostHelper;
        r1.A02.add(r3);
        r1.A00.run();
    }

    public void setContentView(View view) {
        A01(this);
        super.setContentView(view);
    }
}
