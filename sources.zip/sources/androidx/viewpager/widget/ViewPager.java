package androidx.viewpager.widget;

import X.AnonymousClass001;
import X.AnonymousClass07O;
import X.AnonymousClass07P;
import X.AnonymousClass07Q;
import X.AnonymousClass07R;
import X.AnonymousClass07S;
import X.AnonymousClass07U;
import X.AnonymousClass07X;
import X.AnonymousClass07Y;
import X.AnonymousClass08O;
import X.AnonymousClass0BS;
import X.AnonymousClass0BT;
import X.AnonymousClass0GB;
import X.AnonymousClass0GC;
import X.AnonymousClass0IA;
import X.AnonymousClass0WY;
import X.AnonymousClass16H;
import X.C013607l;
import X.C10610fu;
import X.C10620fv;
import X.C10630fw;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import androidx.customview.view.AbsSavedState;
import com.facebook.common.dextricks.Constants;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
    public static final int[] A0m = {16842931};
    public static final Interpolator A0n = new AnonymousClass07O();
    public static final AnonymousClass07P A0o = new Object();
    public static final Comparator A0p = new AnonymousClass16H(0);
    public float A00;
    public float A01;
    public float A02;
    public int A03;
    public int A04;
    public int A05;
    public int A06;
    public int A07;
    public int A08;
    public int A09;
    public int A0A;
    public int A0B;
    public int A0C;
    public Parcelable A0D;
    public VelocityTracker A0E;
    public Scroller A0F;
    public AnonymousClass0GB A0G;
    public AnonymousClass0GC A0H;
    public AnonymousClass0GC A0I;
    public C10620fv A0J;
    public ClassLoader A0K;
    public List A0L;
    public List A0M;
    public boolean A0N;
    public boolean A0O;
    public boolean A0P;
    public boolean A0Q;
    public boolean A0R;
    public boolean A0S;
    public float A0T;
    public float A0U;
    public float A0V;
    public int A0W;
    public int A0X;
    public int A0Y;
    public int A0Z;
    public int A0a;
    public int A0b = 0;
    public int A0c;
    public C013607l A0d;
    public ArrayList A0e;
    public boolean A0f;
    public boolean A0g;
    public boolean A0h;
    public final ArrayList A0i = AnonymousClass001.A0t();
    public final Rect A0j = new Rect();
    public final AnonymousClass07Q A0k = new Object();
    public final Runnable A0l = AnonymousClass07R.A00(this);
    public EdgeEffect mLeftEdge;
    public EdgeEffect mRightEdge;

    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface DecorView {
    }

    public final class SavedState extends AbsSavedState {
        public static final Parcelable.Creator CREATOR = new C10630fw();
        public int A00;
        public Parcelable A01;
        public ClassLoader A02;

        public final String toString() {
            return AnonymousClass0WY.A0P(this.A00, "FragmentPager.SavedState{", Integer.toHexString(System.identityHashCode(this)), " position=", "}");
        }

        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.A00);
            parcel.writeParcelable(this.A01, i);
        }
    }

    private final AnonymousClass07Q A04(View view) {
        int i = 0;
        while (true) {
            ArrayList arrayList = this.A0i;
            if (i >= arrayList.size()) {
                return null;
            }
            AnonymousClass07Q r2 = (AnonymousClass07Q) arrayList.get(i);
            if (this.A0G.A0G(view, r2.A03)) {
                return r2;
            }
            i++;
        }
    }

    private final void A08(Context context) {
        setWillNotDraw(false);
        setDescendantFocusability(Constants.LOAD_RESULT_DEX2OAT_TRY_PERIODIC_PGO_COMP_ATTEMPTED);
        setFocusable(true);
        this.A0F = new Scroller(context, A0n);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f = context.getResources().getDisplayMetrics().density;
        this.A0c = viewConfiguration.getScaledPagingTouchSlop();
        this.A08 = (int) (400.0f * f);
        this.A0a = viewConfiguration.getScaledMaximumFlingVelocity();
        this.mLeftEdge = new EdgeEffect(context);
        this.mRightEdge = new EdgeEffect(context);
        this.A06 = (int) (25.0f * f);
        this.A0W = (int) (2.0f * f);
        this.A0Y = (int) (f * 16.0f);
        AnonymousClass07U.A09(this, new AnonymousClass07S(this));
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        AnonymousClass07Y.A00(this, new AnonymousClass07X(this));
    }

    private boolean A0C() {
        this.A03 = -1;
        this.A0P = false;
        this.A0R = false;
        VelocityTracker velocityTracker = this.A0E;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.A0E = null;
        }
        this.mLeftEdge.onRelease();
        this.mRightEdge.onRelease();
        if (!this.mLeftEdge.isFinished() || !this.mRightEdge.isFinished()) {
            return true;
        }
        return false;
    }

    public final AnonymousClass07Q A0G(int i) {
        int i2 = 0;
        while (true) {
            ArrayList arrayList = this.A0i;
            if (i2 >= arrayList.size()) {
                return null;
            }
            AnonymousClass07Q r1 = (AnonymousClass07Q) arrayList.get(i2);
            if (r1.A02 == i) {
                return r1;
            }
            i2++;
        }
    }

    public final void A0I(int i) {
        this.A0h = false;
        A0M(i, 0, !this.A0O, false);
    }

    public final void A0J(int i) {
        if (i < 1) {
            Log.w("ViewPager", AnonymousClass0WY.A0I(i, 1, "Requested offscreen page limit ", " too small; defaulting to "));
            i = 1;
        }
        if (i != this.A09) {
            this.A09 = i;
            A09(this, this.A04);
        }
    }

    public final void A0N(int i, boolean z) {
        this.A0h = false;
        A0M(i, 0, z, false);
    }

    public final void A0S(C10620fv r7, boolean z) {
        int i = 1;
        boolean A1U = AnonymousClass001.A1U(r7);
        boolean z2 = false;
        if (A1U != AnonymousClass001.A1U(this.A0J)) {
            z2 = true;
        }
        this.A0J = r7;
        setChildrenDrawingOrderEnabled(A1U);
        if (A1U) {
            if (z) {
                i = 2;
            }
            this.A05 = i;
            this.A0B = 2;
        } else {
            this.A05 = 0;
        }
        if (z2) {
            A09(this, this.A04);
        }
    }

    public final void addTouchables(ArrayList arrayList) {
        AnonymousClass07Q A042;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (A042 = A04(childAt)) != null && A042.A02 == this.A04) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    public final void computeScroll() {
        this.A0Q = true;
        if (this.A0F.isFinished() || !this.A0F.computeScrollOffset()) {
            A0B(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.A0F.getCurrX();
        int currY = this.A0F.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!A0F(currX)) {
                this.A0F.abortAnimation();
                scrollTo(0, currY);
            }
        }
        postInvalidateOnAnimation();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0068, code lost:
        if (r10 == 80) goto L_0x006a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00bb, code lost:
        if (r11 == false) goto L_0x0079;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r18, int r19) {
        /*
            r17 = this;
            r2 = 0
            r0 = r18
            int r1 = android.view.View.getDefaultSize(r2, r0)
            r0 = r19
            int r0 = android.view.View.getDefaultSize(r2, r0)
            r8 = r17
            r8.setMeasuredDimension(r1, r0)
            int r7 = r8.getMeasuredWidth()
            int r1 = r7 / 10
            int r0 = r8.A0Y
            int r0 = java.lang.Math.min(r1, r0)
            r8.A07 = r0
            int r0 = r8.getPaddingLeft()
            int r7 = r7 - r0
            int r0 = r8.getPaddingRight()
            int r7 = r7 - r0
            int r5 = r8.getMeasuredHeight()
            int r0 = r8.getPaddingTop()
            int r5 = r5 - r0
            int r0 = r8.getPaddingBottom()
            int r5 = r5 - r0
            int r4 = r8.getChildCount()
            r3 = 0
        L_0x003d:
            r10 = 8
            r11 = 1
            r9 = 1073741824(0x40000000, float:2.0)
            if (r3 >= r4) goto L_0x00be
            android.view.View r6 = r8.getChildAt(r3)
            int r0 = r6.getVisibility()
            if (r0 == r10) goto L_0x00a5
            android.view.ViewGroup$LayoutParams r13 = r6.getLayoutParams()
            X.08O r13 = (X.AnonymousClass08O) r13
            if (r13 == 0) goto L_0x00a5
            boolean r0 = r13.A04
            if (r0 == 0) goto L_0x00a5
            int r0 = r13.A02
            r1 = r0 & 7
            r10 = r0 & 112(0x70, float:1.57E-43)
            r0 = 48
            if (r10 == r0) goto L_0x006a
            r0 = 80
            r16 = 0
            if (r10 != r0) goto L_0x006c
        L_0x006a:
            r16 = 1
        L_0x006c:
            r0 = 3
            if (r1 == r0) goto L_0x0073
            r0 = 5
            if (r1 == r0) goto L_0x0073
            r11 = 0
        L_0x0073:
            r12 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r16 == 0) goto L_0x00b9
            r12 = 1073741824(0x40000000, float:2.0)
        L_0x0079:
            r15 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x007b:
            int r0 = r13.width
            r10 = -1
            r14 = -2
            if (r0 == r14) goto L_0x00b7
            int r0 = r13.width
            if (r0 == r10) goto L_0x00b5
            int r1 = r13.width
        L_0x0087:
            r12 = 1073741824(0x40000000, float:2.0)
        L_0x0089:
            int r0 = r13.height
            if (r0 == r14) goto L_0x00b2
            int r0 = r13.height
            if (r0 == r10) goto L_0x00b0
            int r0 = r13.height
        L_0x0093:
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r12)
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r9)
            r6.measure(r1, r0)
            if (r16 == 0) goto L_0x00a8
            int r0 = r6.getMeasuredHeight()
            int r5 = r5 - r0
        L_0x00a5:
            int r3 = r3 + 1
            goto L_0x003d
        L_0x00a8:
            if (r11 == 0) goto L_0x00a5
            int r0 = r6.getMeasuredWidth()
            int r7 = r7 - r0
            goto L_0x00a5
        L_0x00b0:
            r0 = r5
            goto L_0x0093
        L_0x00b2:
            r0 = r5
            r9 = r15
            goto L_0x0093
        L_0x00b5:
            r1 = r7
            goto L_0x0087
        L_0x00b7:
            r1 = r7
            goto L_0x0089
        L_0x00b9:
            r15 = 1073741824(0x40000000, float:2.0)
            if (r11 != 0) goto L_0x007b
            goto L_0x0079
        L_0x00be:
            android.view.View.MeasureSpec.makeMeasureSpec(r7, r9)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r9)
            r8.A0g = r11
            int r0 = r8.A04
            A09(r8, r0)
            r5 = 0
            r8.A0g = r2
            int r4 = r8.getChildCount()
        L_0x00d3:
            if (r5 >= r4) goto L_0x00fa
            android.view.View r3 = r8.getChildAt(r5)
            int r0 = r3.getVisibility()
            if (r0 == r10) goto L_0x00f7
            android.view.ViewGroup$LayoutParams r2 = r3.getLayoutParams()
            X.08O r2 = (X.AnonymousClass08O) r2
            if (r2 == 0) goto L_0x00eb
            boolean r0 = r2.A04
            if (r0 != 0) goto L_0x00f7
        L_0x00eb:
            float r1 = (float) r7
            float r0 = r2.A00
            float r1 = r1 * r0
            int r0 = (int) r1
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r9)
            r3.measure(r0, r6)
        L_0x00f7:
            int r5 = r5 + 1
            goto L_0x00d3
        L_0x00fa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onMeasure(int, int):void");
    }

    private Rect A01(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view != null) {
            rect.left = view.getLeft();
            rect.right = view.getRight();
            rect.top = view.getTop();
            int bottom = view.getBottom();
            while (true) {
                rect.bottom = bottom;
                ViewParent parent = view.getParent();
                if (!(parent instanceof ViewGroup) || parent == this) {
                    break;
                }
                view = (View) parent;
                rect.left += view.getLeft();
                rect.right += view.getRight();
                rect.top += view.getTop();
                bottom = rect.bottom + view.getBottom();
            }
        } else {
            rect.set(0, 0, 0, 0);
        }
        return rect;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [X.07Q, java.lang.Object] */
    private final AnonymousClass07Q A03(int i, int i2) {
        ? obj = new Object();
        obj.A02 = i;
        obj.A03 = this.A0G.A0A(this, i);
        obj.A01 = this.A0G.A04();
        if (i2 >= 0) {
            ArrayList arrayList = this.A0i;
            if (i2 < arrayList.size()) {
                arrayList.add(i2, obj);
                return obj;
            }
        }
        this.A0i.add(obj);
        return obj;
    }

    private void A05() {
        if (this.A05 != 0) {
            ArrayList arrayList = this.A0e;
            if (arrayList == null) {
                this.A0e = new ArrayList();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.A0e.add(getChildAt(i));
            }
            Collections.sort(this.A0e, A0o);
        }
    }

    private void A06(int i) {
        AnonymousClass0GC r0 = this.A0I;
        if (r0 != null) {
            r0.D5j(i);
        }
        List list = this.A0M;
        if (list != null) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                AnonymousClass0GC r02 = (AnonymousClass0GC) this.A0M.get(i2);
                if (r02 != null) {
                    r02.D5j(i);
                }
            }
        }
        AnonymousClass0GC r03 = this.A0H;
        if (r03 != null) {
            r03.D5j(i);
        }
    }

    /* JADX WARNING: type inference failed for: r1v7, types: [android.view.ViewParent] */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0052, code lost:
        if (r0 == r1) goto L_0x0054;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void A09(androidx.viewpager.widget.ViewPager r16, int r17) {
        /*
            r3 = r16
            int r0 = r3.A04
            r1 = r17
            if (r0 == r1) goto L_0x00d0
            X.07Q r12 = r3.A0G(r0)
            r3.A04 = r1
        L_0x000e:
            X.0GB r0 = r3.A0G
            if (r0 == 0) goto L_0x0319
            boolean r0 = r3.A0h
            if (r0 != 0) goto L_0x0319
            android.os.IBinder r0 = r3.getWindowToken()
            if (r0 == 0) goto L_0x031c
            X.0GB r0 = r3.A0G
            r0.A05(r3)
            int r4 = r3.A09
            int r1 = r3.A04
            int r1 = r1 - r4
            r0 = 0
            int r9 = java.lang.Math.max(r0, r1)
            X.0GB r0 = r3.A0G
            int r5 = r0.A07()
            int r2 = r5 + -1
            int r1 = r3.A04
            int r0 = r1 + r4
            int r11 = java.lang.Math.min(r2, r0)
            int r0 = r3.A0Z
            if (r5 != r0) goto L_0x02d1
            r4 = 0
        L_0x0040:
            java.util.ArrayList r10 = r3.A0i
            int r0 = r10.size()
            if (r4 >= r0) goto L_0x00c8
            java.lang.Object r8 = r10.get(r4)
            X.07Q r8 = (X.AnonymousClass07Q) r8
            int r0 = r8.A02
            if (r0 < r1) goto L_0x00c4
            if (r0 != r1) goto L_0x00c8
        L_0x0054:
            r17 = 0
            if (r8 == 0) goto L_0x0253
            int r7 = r4 + -1
            if (r7 < 0) goto L_0x00c2
            java.lang.Object r13 = r10.get(r7)
            X.07Q r13 = (X.AnonymousClass07Q) r13
        L_0x0062:
            int r6 = r3.A00()
            r16 = 1073741824(0x40000000, float:2.0)
            if (r6 > 0) goto L_0x00b5
            r2 = 0
        L_0x006b:
            int r0 = r3.A04
            int r1 = r0 + -1
            r15 = 0
        L_0x0070:
            if (r1 < 0) goto L_0x00d3
            int r0 = (r15 > r2 ? 1 : (r15 == r2 ? 0 : -1))
            if (r0 < 0) goto L_0x009d
            if (r1 >= r9) goto L_0x009d
            if (r13 == 0) goto L_0x00d3
            int r0 = r13.A02
            if (r1 != r0) goto L_0x0098
            boolean r0 = r13.A04
            if (r0 != 0) goto L_0x0098
            r10.remove(r7)
            X.0GB r14 = r3.A0G
            java.lang.Object r0 = r13.A03
            r14.A0F(r3, r0, r1)
            int r7 = r7 + -1
            int r4 = r4 + -1
        L_0x0090:
            if (r7 < 0) goto L_0x009b
            java.lang.Object r13 = r10.get(r7)
            X.07Q r13 = (X.AnonymousClass07Q) r13
        L_0x0098:
            int r1 = r1 + -1
            goto L_0x0070
        L_0x009b:
            r13 = 0
            goto L_0x0098
        L_0x009d:
            if (r13 == 0) goto L_0x00a9
            int r0 = r13.A02
            if (r1 != r0) goto L_0x00a9
            float r0 = r13.A01
            float r15 = r15 + r0
            int r7 = r7 + -1
            goto L_0x0090
        L_0x00a9:
            int r0 = r7 + 1
            X.07Q r0 = r3.A03(r1, r0)
            float r0 = r0.A01
            float r15 = r15 + r0
            int r4 = r4 + 1
            goto L_0x0090
        L_0x00b5:
            float r0 = r8.A01
            float r2 = r16 - r0
            int r0 = r3.getPaddingLeft()
            float r1 = (float) r0
            float r0 = (float) r6
            float r1 = r1 / r0
            float r2 = r2 + r1
            goto L_0x006b
        L_0x00c2:
            r13 = 0
            goto L_0x0062
        L_0x00c4:
            int r4 = r4 + 1
            goto L_0x0040
        L_0x00c8:
            r8 = 0
            if (r5 <= 0) goto L_0x0054
            X.07Q r8 = r3.A03(r1, r4)
            goto L_0x0054
        L_0x00d0:
            r12 = 0
            goto L_0x000e
        L_0x00d3:
            float r7 = r8.A01
            int r2 = r4 + 1
            r9 = r2
            int r0 = (r7 > r16 ? 1 : (r7 == r16 ? 0 : -1))
            if (r0 >= 0) goto L_0x013c
            int r0 = r10.size()
            if (r2 >= r0) goto L_0x013a
            java.lang.Object r13 = r10.get(r2)
            X.07Q r13 = (X.AnonymousClass07Q) r13
        L_0x00e8:
            if (r6 > 0) goto L_0x0130
            r1 = 0
        L_0x00eb:
            int r14 = r3.A04
        L_0x00ed:
            int r14 = r14 + 1
            if (r14 >= r5) goto L_0x013c
            int r0 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r0 < 0) goto L_0x011a
            if (r14 <= r11) goto L_0x011a
            if (r13 == 0) goto L_0x013c
            int r0 = r13.A02
            if (r14 != r0) goto L_0x00ed
            boolean r0 = r13.A04
            if (r0 != 0) goto L_0x00ed
            r10.remove(r2)
            X.0GB r6 = r3.A0G
            java.lang.Object r0 = r13.A03
            r6.A0F(r3, r0, r14)
        L_0x010b:
            int r0 = r10.size()
            if (r2 >= r0) goto L_0x0118
            java.lang.Object r13 = r10.get(r2)
            X.07Q r13 = (X.AnonymousClass07Q) r13
            goto L_0x00ed
        L_0x0118:
            r13 = 0
            goto L_0x00ed
        L_0x011a:
            if (r13 == 0) goto L_0x0126
            int r0 = r13.A02
            if (r14 != r0) goto L_0x0126
            float r0 = r13.A01
            float r7 = r7 + r0
            int r2 = r2 + 1
            goto L_0x010b
        L_0x0126:
            X.07Q r0 = r3.A03(r14, r2)
            int r2 = r2 + 1
            float r0 = r0.A01
            float r7 = r7 + r0
            goto L_0x010b
        L_0x0130:
            int r0 = r3.getPaddingRight()
            float r1 = (float) r0
            float r0 = (float) r6
            float r1 = r1 / r0
            float r1 = r1 + r16
            goto L_0x00eb
        L_0x013a:
            r13 = 0
            goto L_0x00e8
        L_0x013c:
            X.0GB r0 = r3.A0G
            int r13 = r0.A07()
            int r1 = r3.A00()
            if (r1 <= 0) goto L_0x0193
            int r0 = r3.A0A
            float r7 = (float) r0
            float r0 = (float) r1
            float r7 = r7 / r0
        L_0x014d:
            if (r12 == 0) goto L_0x01ca
            int r11 = r12.A02
            int r6 = r8.A02
            if (r11 >= r6) goto L_0x0195
            float r1 = r12.A00
            float r0 = r12.A01
            float r1 = r1 + r0
            float r1 = r1 + r7
            int r5 = r11 + 1
            r2 = 0
        L_0x015e:
            if (r5 > r6) goto L_0x01ca
            int r0 = r10.size()
            if (r2 >= r0) goto L_0x01ca
        L_0x0166:
            java.lang.Object r11 = r10.get(r2)
            X.07Q r11 = (X.AnonymousClass07Q) r11
            int r0 = r11.A02
            if (r5 <= r0) goto L_0x017b
            int r0 = r10.size()
            int r0 = r0 + -1
            if (r2 >= r0) goto L_0x017b
            int r2 = r2 + 1
            goto L_0x0166
        L_0x017b:
            int r0 = r11.A02
            if (r5 >= r0) goto L_0x018a
            X.0GB r0 = r3.A0G
            float r0 = r0.A04()
            float r0 = r0 + r7
            float r1 = r1 + r0
            int r5 = r5 + 1
            goto L_0x017b
        L_0x018a:
            r11.A00 = r1
            float r0 = r11.A01
            float r0 = r0 + r7
            float r1 = r1 + r0
            int r5 = r5 + 1
            goto L_0x015e
        L_0x0193:
            r7 = 0
            goto L_0x014d
        L_0x0195:
            if (r11 <= r6) goto L_0x01ca
            int r0 = r10.size()
            int r5 = r0 + -1
            float r2 = r12.A00
        L_0x019f:
            int r11 = r11 + -1
            if (r11 < r6) goto L_0x01ca
            if (r5 < 0) goto L_0x01ca
        L_0x01a5:
            java.lang.Object r1 = r10.get(r5)
            X.07Q r1 = (X.AnonymousClass07Q) r1
            int r0 = r1.A02
            if (r11 >= r0) goto L_0x01b4
            if (r5 <= 0) goto L_0x01b4
            int r5 = r5 + -1
            goto L_0x01a5
        L_0x01b4:
            int r0 = r1.A02
            if (r11 <= r0) goto L_0x01c3
            X.0GB r0 = r3.A0G
            float r0 = r0.A04()
            float r0 = r0 + r7
            float r2 = r2 - r0
            int r11 = r11 + -1
            goto L_0x01b4
        L_0x01c3:
            float r0 = r1.A01
            float r0 = r0 + r7
            float r2 = r2 - r0
            r1.A00 = r2
            goto L_0x019f
        L_0x01ca:
            int r6 = r10.size()
            float r11 = r8.A00
            int r2 = r8.A02
            int r1 = r2 + -1
            r0 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
            if (r2 != 0) goto L_0x01da
            r0 = r11
        L_0x01da:
            r3.A00 = r0
            int r5 = r13 + -1
            r13 = 1065353216(0x3f800000, float:1.0)
            if (r2 != r5) goto L_0x0212
            float r0 = r8.A01
            float r0 = r0 + r11
            float r0 = r0 - r13
        L_0x01e6:
            r3.A02 = r0
            int r4 = r4 + -1
        L_0x01ea:
            if (r4 < 0) goto L_0x0216
            java.lang.Object r12 = r10.get(r4)
            X.07Q r12 = (X.AnonymousClass07Q) r12
        L_0x01f2:
            int r0 = r12.A02
            if (r1 <= r0) goto L_0x0201
            X.0GB r0 = r3.A0G
            int r1 = r1 + -1
            float r0 = r0.A04()
            float r0 = r0 + r7
            float r11 = r11 - r0
            goto L_0x01f2
        L_0x0201:
            float r0 = r12.A01
            float r0 = r0 + r7
            float r11 = r11 - r0
            r12.A00 = r11
            int r0 = r12.A02
            if (r0 != 0) goto L_0x020d
            r3.A00 = r11
        L_0x020d:
            int r4 = r4 + -1
            int r1 = r1 + -1
            goto L_0x01ea
        L_0x0212:
            r0 = 2139095039(0x7f7fffff, float:3.4028235E38)
            goto L_0x01e6
        L_0x0216:
            float r4 = r8.A00
            float r0 = r8.A01
            float r4 = r4 + r0
            float r4 = r4 + r7
            int r1 = r2 + 1
        L_0x021e:
            if (r9 >= r6) goto L_0x024a
            java.lang.Object r2 = r10.get(r9)
            X.07Q r2 = (X.AnonymousClass07Q) r2
        L_0x0226:
            int r0 = r2.A02
            if (r1 >= r0) goto L_0x0235
            X.0GB r0 = r3.A0G
            int r1 = r1 + 1
            float r0 = r0.A04()
            float r0 = r0 + r7
            float r4 = r4 + r0
            goto L_0x0226
        L_0x0235:
            int r0 = r2.A02
            if (r0 != r5) goto L_0x023f
            float r0 = r2.A01
            float r0 = r0 + r4
            float r0 = r0 - r13
            r3.A02 = r0
        L_0x023f:
            r2.A00 = r4
            float r0 = r2.A01
            float r0 = r0 + r7
            float r4 = r4 + r0
            int r9 = r9 + 1
            int r1 = r1 + 1
            goto L_0x021e
        L_0x024a:
            X.0GB r2 = r3.A0G
            int r1 = r3.A04
            java.lang.Object r0 = r8.A03
            r2.A0E(r3, r0, r1)
        L_0x0253:
            X.0GB r0 = r3.A0G
            r0.A0D(r3)
            int r5 = r3.getChildCount()
            r4 = 0
        L_0x025d:
            if (r4 >= r5) goto L_0x0286
            android.view.View r1 = r3.getChildAt(r4)
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            X.08O r2 = (X.AnonymousClass08O) r2
            r2.A01 = r4
            boolean r0 = r2.A04
            if (r0 != 0) goto L_0x0283
            float r0 = r2.A00
            int r0 = (r0 > r17 ? 1 : (r0 == r17 ? 0 : -1))
            if (r0 != 0) goto L_0x0283
            X.07Q r1 = r3.A04(r1)
            if (r1 == 0) goto L_0x0283
            float r0 = r1.A01
            r2.A00 = r0
            int r0 = r1.A02
            r2.A03 = r0
        L_0x0283:
            int r4 = r4 + 1
            goto L_0x025d
        L_0x0286:
            r3.A05()
            boolean r0 = r3.hasFocus()
            if (r0 == 0) goto L_0x031c
            android.view.View r0 = r3.findFocus()
            if (r0 == 0) goto L_0x02af
        L_0x0295:
            android.view.ViewParent r1 = r0.getParent()
            if (r1 == r3) goto L_0x02a3
            boolean r0 = r1 instanceof android.view.View
            if (r0 == 0) goto L_0x02af
            r0 = r1
            android.view.View r0 = (android.view.View) r0
            goto L_0x0295
        L_0x02a3:
            X.07Q r0 = r3.A04(r0)
            if (r0 == 0) goto L_0x02af
            int r1 = r0.A02
            int r0 = r3.A04
            if (r1 == r0) goto L_0x031c
        L_0x02af:
            r4 = 0
        L_0x02b0:
            int r0 = r3.getChildCount()
            if (r4 >= r0) goto L_0x031c
            android.view.View r2 = r3.getChildAt(r4)
            X.07Q r0 = r3.A04(r2)
            if (r0 == 0) goto L_0x02ce
            int r1 = r0.A02
            int r0 = r3.A04
            if (r1 != r0) goto L_0x02ce
            r0 = 2
            boolean r0 = r2.requestFocus(r0)
            if (r0 == 0) goto L_0x02ce
            return
        L_0x02ce:
            int r4 = r4 + 1
            goto L_0x02b0
        L_0x02d1:
            android.content.res.Resources r1 = r3.getResources()     // Catch:{ NotFoundException -> 0x02de }
            int r0 = r3.getId()     // Catch:{ NotFoundException -> 0x02de }
            java.lang.String r2 = r1.getResourceName(r0)     // Catch:{ NotFoundException -> 0x02de }
            goto L_0x02e6
        L_0x02de:
            int r0 = r3.getId()
            java.lang.String r2 = java.lang.Integer.toHexString(r0)
        L_0x02e6:
            java.lang.StringBuilder r1 = X.AnonymousClass001.A0m()
            java.lang.String r0 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: "
            r1.append(r0)
            int r0 = r3.A0Z
            r1.append(r0)
            java.lang.String r0 = ", found: "
            r1.append(r0)
            r1.append(r5)
            java.lang.String r0 = " Pager id: "
            r1.append(r0)
            r1.append(r2)
            java.lang.String r0 = " Pager class: "
            X.AnonymousClass002.A0i(r3, r0, r1)
            java.lang.String r0 = " Problematic adapter: "
            r1.append(r0)
            X.0GB r0 = r3.A0G
            java.lang.Class r0 = r0.getClass()
            java.lang.IllegalStateException r0 = X.AnonymousClass002.A0H(r0, r1)
            throw r0
        L_0x0319:
            r3.A05()
        L_0x031c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.A09(androidx.viewpager.widget.ViewPager, int):void");
    }

    public static void A0A(ViewPager viewPager, int i, int i2, int i3, int i4) {
        int i5;
        float f;
        if (i2 <= 0 || viewPager.A0i.isEmpty()) {
            AnonymousClass07Q A0G2 = viewPager.A0G(viewPager.A04);
            if (A0G2 != null) {
                f = Math.min(A0G2.A00, viewPager.A02);
            } else {
                f = 0.0f;
            }
            i5 = (int) (f * ((float) ((i - viewPager.getPaddingLeft()) - viewPager.getPaddingRight())));
            if (i5 != viewPager.getScrollX()) {
                viewPager.A0B(false);
            } else {
                return;
            }
        } else if (!viewPager.A0F.isFinished()) {
            viewPager.A0F.setFinalX(viewPager.A04 * viewPager.A00());
            return;
        } else {
            i5 = (int) ((((float) viewPager.getScrollX()) / ((float) (((i2 - viewPager.getPaddingLeft()) - viewPager.getPaddingRight()) + i4))) * ((float) (((i - viewPager.getPaddingLeft()) - viewPager.getPaddingRight()) + i3)));
        }
        viewPager.scrollTo(i5, viewPager.getScrollY());
    }

    private void A0B(boolean z) {
        boolean z2 = false;
        if (this.A0b == 2) {
            z2 = true;
            if (this.A0S) {
                this.A0S = false;
            }
            if (!this.A0F.isFinished()) {
                this.A0F.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.A0F.getCurrX();
                int currY = this.A0F.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        A0F(currX);
                    }
                }
            }
        }
        this.A0h = false;
        int i = 0;
        while (true) {
            ArrayList arrayList = this.A0i;
            if (i >= arrayList.size()) {
                break;
            }
            AnonymousClass07Q r1 = (AnonymousClass07Q) arrayList.get(i);
            if (r1.A04) {
                r1.A04 = false;
                z2 = true;
            }
            i++;
        }
        if (z2) {
            Runnable runnable = this.A0l;
            if (z) {
                postOnAnimation(runnable);
            } else {
                runnable.run();
            }
        }
    }

    private final boolean A0D() {
        AnonymousClass0GB r0 = this.A0G;
        if (r0 == null || this.A04 >= r0.A07() - 1) {
            return false;
        }
        A0N(this.A04 + 1, true);
        return true;
    }

    private boolean A0E(float f, float f2) {
        boolean z;
        float f3 = this.A01 - f;
        this.A01 = f;
        float height = f2 / ((float) getHeight());
        float width = f3 / ((float) getWidth());
        float f4 = 0.0f;
        if (AnonymousClass0IA.A00(this.mLeftEdge) != 0.0f) {
            f4 = -AnonymousClass0IA.A01(this.mLeftEdge, -width, 1.0f - height);
        } else if (AnonymousClass0IA.A00(this.mRightEdge) != 0.0f) {
            f4 = AnonymousClass0IA.A01(this.mRightEdge, width, height);
        }
        float width2 = f4 * ((float) getWidth());
        float f5 = f3 - width2;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = false;
        if (width2 != 0.0f) {
            z4 = true;
        }
        if (Math.abs(f5) >= 1.0E-4f) {
            float scrollX = ((float) getScrollX()) + f5;
            float A002 = (float) A00();
            float f6 = A002 * this.A00;
            float f7 = A002 * this.A02;
            ArrayList arrayList = this.A0i;
            AnonymousClass07Q r1 = (AnonymousClass07Q) arrayList.get(0);
            AnonymousClass07Q r7 = (AnonymousClass07Q) arrayList.get(arrayList.size() - 1);
            if (r1.A02 != 0) {
                f6 = r1.A00 * A002;
                z = false;
            } else {
                z = true;
            }
            if (r7.A02 != this.A0G.A07() - 1) {
                f7 = r7.A00 * A002;
            } else {
                z3 = true;
            }
            if (scrollX < f6) {
                if (z) {
                    AnonymousClass0IA.A01(this.mLeftEdge, (f6 - scrollX) / A002, 1.0f - (f2 / ((float) getHeight())));
                } else {
                    z2 = z4;
                }
                z4 = z2;
                scrollX = f6;
            } else if (scrollX > f7) {
                if (z3) {
                    AnonymousClass0IA.A01(this.mRightEdge, (scrollX - f7) / A002, f2 / ((float) getHeight()));
                } else {
                    z2 = z4;
                }
                z4 = z2;
                scrollX = f7;
            }
            int i = (int) scrollX;
            this.A01 += scrollX - ((float) i);
            scrollTo(i, getScrollY());
            A0F(i);
        }
        return z4;
    }

    private boolean A0F(int i) {
        if (this.A0i.size() == 0) {
            if (!this.A0O) {
                this.A0f = false;
                A0L(0, 0.0f, 0);
                if (!this.A0f) {
                    throw AnonymousClass001.A0P("onPageScrolled did not call superclass implementation");
                }
            }
            return false;
        }
        AnonymousClass07Q A022 = A02();
        int A002 = A00();
        int i2 = this.A0A;
        int i3 = A002 + i2;
        float f = (float) i2;
        float f2 = (float) A002;
        int i4 = A022.A02;
        float f3 = ((((float) i) / f2) - A022.A00) / (A022.A01 + (f / f2));
        this.A0f = false;
        A0L(i4, f3, (int) (((float) i3) * f3));
        if (this.A0f) {
            return true;
        }
        throw AnonymousClass001.A0P("onPageScrolled did not call superclass implementation");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x001c, code lost:
        if (r3.size() >= r7) goto L_0x001e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A0H() {
        /*
            r11 = this;
            X.0GB r0 = r11.A0G
            int r7 = r0.A07()
            r11.A0Z = r7
            java.util.ArrayList r3 = r11.A0i
            int r1 = r3.size()
            int r0 = r11.A09
            int r0 = r0 * 2
            int r0 = r0 + 1
            r5 = 0
            if (r1 >= r0) goto L_0x001e
            int r0 = r3.size()
            r10 = 1
            if (r0 < r7) goto L_0x001f
        L_0x001e:
            r10 = 0
        L_0x001f:
            int r4 = r11.A04
            r6 = 0
            r9 = 0
        L_0x0023:
            int r0 = r3.size()
            if (r6 >= r0) goto L_0x0075
            java.lang.Object r8 = r3.get(r6)
            X.07Q r8 = (X.AnonymousClass07Q) r8
            X.0GB r1 = r11.A0G
            java.lang.Object r0 = r8.A03
            int r2 = r1.A06(r0)
            r0 = -1
            if (r2 == r0) goto L_0x0064
            r0 = -2
            if (r2 != r0) goto L_0x0067
            r3.remove(r6)
            int r6 = r6 + -1
            if (r9 != 0) goto L_0x004a
            X.0GB r0 = r11.A0G
            r0.A05(r11)
            r9 = 1
        L_0x004a:
            X.0GB r2 = r11.A0G
            int r1 = r8.A02
            java.lang.Object r0 = r8.A03
            r2.A0F(r11, r0, r1)
            int r1 = r11.A04
            int r0 = r8.A02
            if (r1 != r0) goto L_0x0063
            int r0 = r7 + -1
            int r0 = java.lang.Math.min(r1, r0)
            int r4 = java.lang.Math.max(r5, r0)
        L_0x0063:
            r10 = 1
        L_0x0064:
            int r6 = r6 + 1
            goto L_0x0023
        L_0x0067:
            int r0 = r8.A02
            if (r0 == r2) goto L_0x0064
            int r1 = r8.A02
            int r0 = r11.A04
            if (r1 != r0) goto L_0x0072
            r4 = r2
        L_0x0072:
            r8.A02 = r2
            goto L_0x0063
        L_0x0075:
            if (r9 == 0) goto L_0x007c
            X.0GB r0 = r11.A0G
            r0.A0D(r11)
        L_0x007c:
            java.util.Comparator r0 = A0p
            java.util.Collections.sort(r3, r0)
            if (r10 == 0) goto L_0x00a5
            int r3 = r11.getChildCount()
            r2 = 0
        L_0x0088:
            if (r2 >= r3) goto L_0x009e
            android.view.View r0 = r11.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            X.08O r1 = (X.AnonymousClass08O) r1
            boolean r0 = r1.A04
            if (r0 != 0) goto L_0x009b
            r0 = 0
            r1.A00 = r0
        L_0x009b:
            int r2 = r2 + 1
            goto L_0x0088
        L_0x009e:
            r0 = 1
            r11.A0M(r4, r5, r5, r0)
            r11.requestLayout()
        L_0x00a5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.A0H():void");
    }

    public final void A0K(int i) {
        int i2;
        if (this.A0b != i) {
            this.A0b = i;
            if (this.A0J != null) {
                boolean z = false;
                if (i != 0) {
                    z = true;
                }
                int childCount = getChildCount();
                for (int i3 = 0; i3 < childCount; i3++) {
                    if (z) {
                        i2 = this.A0B;
                    } else {
                        i2 = 0;
                    }
                    getChildAt(i3).setLayerType(i2, (Paint) null);
                }
            }
            AnonymousClass0GC r0 = this.A0I;
            if (r0 != null) {
                r0.D5g(i);
            }
            List list = this.A0M;
            if (list != null) {
                int size = list.size();
                for (int i4 = 0; i4 < size; i4++) {
                    AnonymousClass0GC r02 = (AnonymousClass0GC) this.A0M.get(i4);
                    if (r02 != null) {
                        r02.D5g(i);
                    }
                }
            }
            AnonymousClass0GC r03 = this.A0H;
            if (r03 != null) {
                r03.D5g(i);
            }
        }
    }

    public void A0L(int i, float f, int i2) {
        int i3;
        int i4;
        if (this.A0X > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                View childAt = getChildAt(i5);
                AnonymousClass08O r7 = (AnonymousClass08O) childAt.getLayoutParams();
                if (r7.A04) {
                    int i6 = r7.A02 & 7;
                    if (i6 == 1) {
                        i3 = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                        i4 = paddingLeft;
                        paddingLeft = i3;
                    } else if (i6 == 3) {
                        i4 = childAt.getWidth() + paddingLeft;
                    } else if (i6 != 5) {
                        i4 = paddingLeft;
                    } else {
                        i3 = (width - paddingRight) - childAt.getMeasuredWidth();
                        paddingRight += childAt.getMeasuredWidth();
                        i4 = paddingLeft;
                        paddingLeft = i3;
                    }
                    int left = (paddingLeft + scrollX) - childAt.getLeft();
                    if (left != 0) {
                        childAt.offsetLeftAndRight(left);
                    }
                    paddingLeft = i4;
                }
            }
        }
        AnonymousClass0GC r0 = this.A0I;
        if (r0 != null) {
            r0.D5h(i, f, i2);
        }
        List list = this.A0M;
        if (list != null) {
            int size = list.size();
            for (int i7 = 0; i7 < size; i7++) {
                AnonymousClass0GC r02 = (AnonymousClass0GC) this.A0M.get(i7);
                if (r02 != null) {
                    r02.D5h(i, f, i2);
                }
            }
        }
        AnonymousClass0GC r03 = this.A0H;
        if (r03 != null) {
            r03.D5h(i, f, i2);
        }
        if (this.A0J != null) {
            int scrollX2 = getScrollX();
            int childCount2 = getChildCount();
            for (int i8 = 0; i8 < childCount2; i8++) {
                View childAt2 = getChildAt(i8);
                if (!((AnonymousClass08O) childAt2.getLayoutParams()).A04) {
                    this.A0J.EJO(childAt2, ((float) (childAt2.getLeft() - scrollX2)) / ((float) A00()));
                }
            }
        }
        this.A0f = true;
    }

    public void A0M(int i, int i2, boolean z, boolean z2) {
        AnonymousClass0GB r0 = this.A0G;
        boolean z3 = false;
        if (r0 != null && r0.A07() > 0 && (z2 || this.A04 != i || this.A0i.size() == 0)) {
            if (i < 0) {
                i = 0;
            } else if (i >= this.A0G.A07()) {
                i = this.A0G.A07() - 1;
            }
            int i3 = this.A09;
            int i4 = this.A04;
            if (i > i4 + i3 || i < i4 - i3) {
                int i5 = 0;
                while (true) {
                    ArrayList arrayList = this.A0i;
                    if (i5 >= arrayList.size()) {
                        break;
                    }
                    ((AnonymousClass07Q) arrayList.get(i5)).A04 = true;
                    i5++;
                }
            }
            if (i4 != i) {
                z3 = true;
            }
            if (this.A0O) {
                this.A04 = i;
                if (z3) {
                    A06(i);
                }
                requestLayout();
                return;
            }
            A09(this, i);
            A07(i, i2, z, z3);
        } else if (this.A0S) {
            this.A0S = false;
        }
    }

    public void A0O(AnonymousClass0GB r8) {
        ArrayList arrayList;
        AnonymousClass0GB r0 = this.A0G;
        if (r0 != null) {
            synchronized (r0) {
                r0.A00 = null;
            }
            this.A0G.A05(this);
            int i = 0;
            while (true) {
                arrayList = this.A0i;
                if (i >= arrayList.size()) {
                    break;
                }
                AnonymousClass07Q r02 = (AnonymousClass07Q) arrayList.get(i);
                this.A0G.A0F(this, r02.A03, r02.A02);
                i++;
            }
            this.A0G.A0D(this);
            arrayList.clear();
            int i2 = 0;
            while (i2 < getChildCount()) {
                if (!((AnonymousClass08O) getChildAt(i2).getLayoutParams()).A04) {
                    removeViewAt(i2);
                    i2--;
                }
                i2++;
            }
            this.A04 = 0;
            scrollTo(0, 0);
        }
        AnonymousClass0GB r3 = this.A0G;
        this.A0G = r8;
        this.A0Z = 0;
        if (r8 != null) {
            C013607l r1 = this.A0d;
            if (r1 == null) {
                r1 = new C013607l(this);
                this.A0d = r1;
            }
            AnonymousClass0GB r03 = this.A0G;
            synchronized (r03) {
                r03.A00 = r1;
            }
            this.A0h = false;
            boolean z = this.A0O;
            this.A0O = true;
            this.A0Z = this.A0G.A07();
            if (this.A0C >= 0) {
                this.A0G.A0C(this.A0D, this.A0K);
                A0M(this.A0C, 0, false, true);
                this.A0C = -1;
                this.A0D = null;
                this.A0K = null;
            } else if (!z) {
                A09(this, this.A04);
            } else {
                requestLayout();
            }
        }
        List list = this.A0L;
        if (list != null && !list.isEmpty()) {
            int size = this.A0L.size();
            for (int i3 = 0; i3 < size; i3++) {
                ((C10610fu) this.A0L.get(i3)).CV6(r3, r8, this);
            }
        }
    }

    public final void A0Q(AnonymousClass0GC r2) {
        List list = this.A0M;
        if (list == null) {
            list = new ArrayList();
            this.A0M = list;
        }
        list.add(r2);
    }

    public final void A0R(AnonymousClass0GC r2) {
        List list = this.A0M;
        if (list != null) {
            list.remove(r2);
        }
    }

    public boolean A0V(View view, int i, int i2, int i3, boolean z) {
        int i4;
        int i5 = i;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i2 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i4 = i3 + scrollY) >= childAt.getTop() && i4 < childAt.getBottom()) {
                    if (A0V(childAt, i5, i6 - childAt.getLeft(), i4 - childAt.getTop(), true)) {
                        return true;
                    }
                }
            }
        }
        if (!z || !view.canScrollHorizontally(-i)) {
            return false;
        }
        return true;
    }

    public final boolean canScrollHorizontally(int i) {
        if (this.A0G == null) {
            return false;
        }
        int A002 = A00();
        int scrollX = getScrollX();
        if (i < 0) {
            if (scrollX > ((int) (((float) A002) * this.A00))) {
                return true;
            }
            return false;
        } else if (i <= 0 || scrollX >= ((int) (((float) A002) * this.A02))) {
            return false;
        }
        return true;
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (!(layoutParams instanceof AnonymousClass08O) || !super.checkLayoutParams(layoutParams)) {
            return false;
        }
        return true;
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new AnonymousClass08O();
    }

    public final int getChildDrawingOrder(int i, int i2) {
        if (this.A05 == 2) {
            i2 = (i - 1) - i2;
        }
        return ((AnonymousClass08O) ((View) this.A0e.get(i2)).getLayoutParams()).A01;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        float f;
        MotionEvent motionEvent2 = motionEvent;
        int action = motionEvent2.getAction() & 255;
        if (action == 3 || action == 1) {
            A0C();
            return false;
        }
        if (action != 0) {
            if (this.A0P) {
                return true;
            }
            if (this.A0R) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent2.getX();
            this.A0T = x;
            this.A01 = x;
            float y = motionEvent2.getY();
            this.A0U = y;
            this.A0V = y;
            this.A03 = motionEvent2.getPointerId(0);
            this.A0R = false;
            this.A0Q = true;
            this.A0F.computeScrollOffset();
            if (this.A0b == 2 && Math.abs(this.A0F.getFinalX() - this.A0F.getCurrX()) > this.A0W) {
                this.A0F.abortAnimation();
                this.A0h = false;
                A09(this, this.A04);
                this.A0P = true;
                ViewParent parent = getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                A0K(1);
            } else if (AnonymousClass0IA.A00(this.mLeftEdge) == 0.0f && AnonymousClass0IA.A00(this.mRightEdge) == 0.0f) {
                A0B(false);
                this.A0P = false;
            } else {
                this.A0P = true;
                A0K(1);
                if (AnonymousClass0IA.A00(this.mLeftEdge) != 0.0f) {
                    AnonymousClass0IA.A01(this.mLeftEdge, 0.0f, 1.0f - (this.A0V / ((float) getHeight())));
                }
                if (AnonymousClass0IA.A00(this.mRightEdge) != 0.0f) {
                    AnonymousClass0IA.A01(this.mRightEdge, 0.0f, this.A0V / ((float) getHeight()));
                }
            }
        } else if (action == 2) {
            int i = this.A03;
            if (i != -1) {
                int findPointerIndex = motionEvent2.findPointerIndex(i);
                float x2 = motionEvent2.getX(findPointerIndex);
                float f2 = x2 - this.A01;
                float abs = Math.abs(f2);
                float y2 = motionEvent2.getY(findPointerIndex);
                float abs2 = Math.abs(y2 - this.A0U);
                if (f2 != 0.0f) {
                    float f3 = this.A01;
                    if (this.A0N || ((f3 >= ((float) this.A07) || f2 <= 0.0f) && (f3 <= ((float) (getWidth() - this.A07)) || f2 >= 0.0f))) {
                        if (A0V(this, (int) f2, (int) x2, (int) y2, false)) {
                            this.A01 = x2;
                            this.A0V = y2;
                            this.A0R = true;
                            return false;
                        }
                    }
                }
                float f4 = (float) this.A0c;
                if (abs > f4 && abs * 0.5f > abs2) {
                    this.A0P = true;
                    ViewParent parent2 = getParent();
                    if (parent2 != null) {
                        parent2.requestDisallowInterceptTouchEvent(true);
                    }
                    A0K(1);
                    int i2 = (f2 > 0.0f ? 1 : (f2 == 0.0f ? 0 : -1));
                    float f5 = this.A0T;
                    float f6 = (float) this.A0c;
                    if (i2 > 0) {
                        f = f5 + f6;
                    } else {
                        f = f5 - f6;
                    }
                    this.A01 = f;
                    this.A0V = y2;
                    if (!this.A0S) {
                        this.A0S = true;
                    }
                } else if (abs2 > f4) {
                    this.A0R = true;
                }
                if (this.A0P && A0E(x2, y2)) {
                    postInvalidateOnAnimation();
                }
            }
        } else if (action == 6) {
            int actionIndex = motionEvent2.getActionIndex();
            if (motionEvent2.getPointerId(actionIndex) == this.A03) {
                int i3 = 0;
                if (actionIndex == 0) {
                    i3 = 1;
                }
                this.A01 = motionEvent2.getX(i3);
                this.A03 = motionEvent2.getPointerId(i3);
                VelocityTracker velocityTracker = this.A0E;
                if (velocityTracker != null) {
                    velocityTracker.clear();
                }
            }
        }
        VelocityTracker velocityTracker2 = this.A0E;
        if (velocityTracker2 == null) {
            velocityTracker2 = VelocityTracker.obtain();
            this.A0E = velocityTracker2;
        }
        velocityTracker2.addMovement(motionEvent2);
        return this.A0P;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.A00);
        AnonymousClass0GB r2 = this.A0G;
        if (r2 != null) {
            r2.A0C(savedState.A01, savedState.A02);
            A0M(savedState.A00, 0, false, true);
            return;
        }
        this.A0C = savedState.A00;
        this.A0D = savedState.A01;
        this.A0K = savedState.A02;
    }

    public final void removeView(View view) {
        if (this.A0g) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [X.07Q, java.lang.Object] */
    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        A08(context);
    }

    private int A00() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private AnonymousClass07Q A02() {
        float f;
        float f2;
        int A002 = A00();
        float f3 = 0.0f;
        if (A002 > 0) {
            float f4 = (float) A002;
            f = ((float) getScrollX()) / f4;
            f2 = ((float) this.A0A) / f4;
        } else {
            f = 0.0f;
            f2 = 0.0f;
        }
        AnonymousClass07Q r11 = null;
        float f5 = 0.0f;
        int i = -1;
        int i2 = 0;
        boolean z = true;
        while (true) {
            ArrayList arrayList = this.A0i;
            if (i2 >= arrayList.size()) {
                break;
            }
            AnonymousClass07Q r4 = (AnonymousClass07Q) arrayList.get(i2);
            if (!z && r4.A02 != i + 1) {
                r4 = this.A0k;
                r4.A00 = f3 + f5 + f2;
                r4.A02 = i + 1;
                r4.A01 = this.A0G.A04();
                i2--;
            }
            f3 = r4.A00;
            f5 = r4.A01;
            float f6 = f5 + f3 + f2;
            if (!z && f < f3) {
                break;
            } else if (f < f6 || i2 == arrayList.size() - 1) {
                return r4;
            } else {
                i = r4.A02;
                i2++;
                z = false;
                r11 = r4;
            }
        }
        return r11;
    }

    private void A07(int i, int i2, boolean z, boolean z2) {
        int i3;
        int scrollX;
        int A042;
        AnonymousClass07Q A0G2 = A0G(i);
        if (A0G2 != null) {
            i3 = (int) (((float) A00()) * Math.max(this.A00, Math.min(A0G2.A00, this.A02)));
        } else {
            i3 = 0;
        }
        if (z) {
            if (getChildCount() != 0) {
                Scroller scroller = this.A0F;
                if (scroller == null || scroller.isFinished()) {
                    scrollX = getScrollX();
                } else {
                    boolean z3 = this.A0Q;
                    Scroller scroller2 = this.A0F;
                    if (z3) {
                        scrollX = scroller2.getCurrX();
                    } else {
                        scrollX = scroller2.getStartX();
                    }
                    this.A0F.abortAnimation();
                    if (this.A0S) {
                        this.A0S = false;
                    }
                }
                int scrollY = getScrollY();
                int i4 = i3 - scrollX;
                int i5 = -scrollY;
                if (i4 == 0 && i5 == 0) {
                    A0B(false);
                    A09(this, this.A04);
                    A0K(0);
                } else {
                    if (!this.A0S) {
                        this.A0S = true;
                    }
                    A0K(2);
                    int A002 = A00();
                    float abs = (float) Math.abs(i4);
                    float f = (float) A002;
                    float f2 = (float) (A002 / 2);
                    float sin = f2 + (f2 * ((float) Math.sin((double) ((Math.min(1.0f, (abs * 1.0f) / f) - 0.5f) * 0.47123894f))));
                    int abs2 = Math.abs(i2);
                    if (abs2 > 0) {
                        A042 = Math.round(Math.abs(sin / ((float) abs2)) * 1000.0f) * 4;
                    } else {
                        A042 = (int) (((abs / ((f * this.A0G.A04()) + ((float) this.A0A))) + 1.0f) * 100.0f);
                    }
                    int min = Math.min(A042, 600);
                    this.A0Q = false;
                    this.A0F.startScroll(scrollX, scrollY, i4, i5, min);
                    postInvalidateOnAnimation();
                }
            } else if (this.A0S) {
                this.A0S = false;
            }
            if (z2) {
                A06(i);
                return;
            }
            return;
        }
        if (z2) {
            A06(i);
        }
        A0B(false);
        scrollTo(i3, 0);
        A0F(i3);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x006e, code lost:
        if (r1 >= r0) goto L_0x0070;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0096, code lost:
        if (r1 <= r0) goto L_0x00a8;
     */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x007c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean A0T(int r6) {
        /*
            r5 = this;
            android.view.View r3 = r5.findFocus()
            r4 = 0
            if (r3 == r5) goto L_0x004b
            if (r3 == 0) goto L_0x004c
            android.view.ViewParent r1 = r3.getParent()
        L_0x000d:
            boolean r0 = r1 instanceof android.view.ViewGroup
            if (r0 == 0) goto L_0x0018
            if (r1 == r5) goto L_0x004c
            android.view.ViewParent r1 = r1.getParent()
            goto L_0x000d
        L_0x0018:
            java.lang.StringBuilder r2 = X.AnonymousClass001.A0m()
            java.lang.String r0 = X.AnonymousClass001.A0b(r3)
            r2.append(r0)
            android.view.ViewParent r1 = r3.getParent()
        L_0x0027:
            boolean r0 = r1 instanceof android.view.ViewGroup
            if (r0 == 0) goto L_0x003c
            java.lang.String r0 = " => "
            r2.append(r0)
            java.lang.String r0 = X.AnonymousClass001.A0b(r1)
            r2.append(r0)
            android.view.ViewParent r1 = r1.getParent()
            goto L_0x0027
        L_0x003c:
            java.lang.String r1 = "arrowScroll tried to find focus based on non-child current focused view "
            java.lang.String r0 = r2.toString()
            java.lang.String r1 = X.AnonymousClass0WY.A0i(r1, r0)
            java.lang.String r0 = "ViewPager"
            android.util.Log.e(r0, r1)
        L_0x004b:
            r3 = r4
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r4 = r0.findNextFocus(r5, r3, r6)
            r1 = 66
            r0 = 17
            if (r4 == 0) goto L_0x009e
            if (r4 == r3) goto L_0x009e
            if (r6 != r0) goto L_0x0084
            android.graphics.Rect r2 = r5.A0j
            android.graphics.Rect r0 = r5.A01(r2, r4)
            int r1 = r0.left
            android.graphics.Rect r0 = r5.A01(r2, r3)
            int r0 = r0.left
            if (r3 == 0) goto L_0x0099
            if (r1 < r0) goto L_0x0099
        L_0x0070:
            int r0 = r5.A04
            r1 = 0
            if (r0 <= 0) goto L_0x007a
            r1 = 1
            int r0 = r0 - r1
            r5.A0N(r0, r1)
        L_0x007a:
            if (r1 == 0) goto L_0x0083
            int r0 = android.view.SoundEffectConstants.getContantForFocusDirection(r6)
            r5.playSoundEffect(r0)
        L_0x0083:
            return r1
        L_0x0084:
            if (r6 != r1) goto L_0x00ad
            android.graphics.Rect r2 = r5.A0j
            android.graphics.Rect r0 = r5.A01(r2, r4)
            int r1 = r0.left
            android.graphics.Rect r0 = r5.A01(r2, r3)
            int r0 = r0.left
            if (r3 == 0) goto L_0x0099
            if (r1 > r0) goto L_0x0099
            goto L_0x00a8
        L_0x0099:
            boolean r1 = r4.requestFocus()
            goto L_0x007a
        L_0x009e:
            if (r6 == r0) goto L_0x0070
            r0 = 1
            if (r6 == r0) goto L_0x0070
            if (r6 == r1) goto L_0x00a8
            r0 = 2
            if (r6 != r0) goto L_0x00ad
        L_0x00a8:
            boolean r1 = r5.A0D()
            goto L_0x007a
        L_0x00ad:
            r1 = 0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.A0T(int):boolean");
    }

    public boolean A0U(KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0) {
            return false;
        }
        int keyCode = keyEvent.getKeyCode();
        int i = 2;
        if (keyCode != 21) {
            if (keyCode != 22) {
                if (keyCode != 61) {
                    return false;
                }
                if (!keyEvent.hasNoModifiers()) {
                    i = 1;
                    if (!keyEvent.hasModifiers(1)) {
                        return false;
                    }
                }
            } else if (keyEvent.hasModifiers(2)) {
                return A0D();
            } else {
                i = 66;
            }
        } else if (keyEvent.hasModifiers(2)) {
            int i2 = this.A04;
            if (i2 <= 0) {
                return false;
            }
            A0N(i2 - 1, true);
            return true;
        } else {
            i = 17;
        }
        return A0T(i);
    }

    public final void addFocusables(ArrayList arrayList, int i, int i2) {
        AnonymousClass07Q A042;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0 && (A042 = A04(childAt)) != null && A042.A02 == this.A04) {
                    childAt.addFocusables(arrayList, i, i2);
                }
            }
            if (descendantFocusability == 262144 && size != arrayList.size()) {
                return;
            }
        }
        if (!isFocusable()) {
            return;
        }
        if ((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) {
            arrayList.add(this);
        }
    }

    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = new AnonymousClass08O();
        }
        AnonymousClass08O r3 = (AnonymousClass08O) layoutParams;
        boolean A1U = r3.A04 | AnonymousClass001.A1U(view.getClass().getAnnotation(DecorView.class));
        r3.A04 = A1U;
        if (!this.A0g) {
            super.addView(view, i, layoutParams);
        } else if (!A1U) {
            r3.A05 = true;
            addViewInLayout(view, i, layoutParams);
        } else {
            throw AnonymousClass001.A0P("Cannot add pager decor view during layout");
        }
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (super.dispatchKeyEvent(keyEvent) || A0U(keyEvent)) {
            return true;
        }
        return false;
    }

    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        AnonymousClass07Q A042;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (A042 = A04(childAt)) != null && A042.A02 == this.A04 && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    public final void draw(Canvas canvas) {
        AnonymousClass0GB r0;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean z = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (r0 = this.A0G) != null && r0.A07() > 1)) {
            if (!this.mLeftEdge.isFinished()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-height) + getPaddingTop()), this.A00 * ((float) width));
                this.mLeftEdge.setSize(height, width);
                z = false | this.mLeftEdge.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.mRightEdge.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.A02 + 1.0f)) * ((float) width2));
                this.mRightEdge.setSize(height2, width2);
                z |= this.mRightEdge.draw(canvas);
                canvas.restoreToCount(save2);
            }
            if (z) {
                postInvalidateOnAnimation();
                return;
            }
            return;
        }
        this.mLeftEdge.finish();
        this.mRightEdge.finish();
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.view.ViewGroup$LayoutParams, X.08O] */
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ? layoutParams = new ViewGroup.LayoutParams(context, attributeSet);
        layoutParams.A00 = 0.0f;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, A0m);
        layoutParams.A02 = obtainStyledAttributes.getInteger(0, 48);
        obtainStyledAttributes.recycle();
        return layoutParams;
    }

    public void onAttachedToWindow() {
        int A062 = AnonymousClass0BS.A06(-782663130);
        super.onAttachedToWindow();
        this.A0O = true;
        AnonymousClass0BS.A0C(-1814596170, A062);
    }

    public void onDetachedFromWindow() {
        int A062 = AnonymousClass0BS.A06(1408290646);
        removeCallbacks(this.A0l);
        Scroller scroller = this.A0F;
        if (scroller != null && !scroller.isFinished()) {
            this.A0F.abortAnimation();
        }
        super.onDetachedFromWindow();
        AnonymousClass0BS.A0C(753494652, A062);
    }

    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        AnonymousClass07Q A042;
        int i5;
        int i6;
        int i7;
        int i8;
        int internalBeginTrack = AnonymousClass0BT.A01.internalBeginTrack(-1689590319);
        int childCount = getChildCount();
        int i9 = i3 - i;
        int i10 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i11 = 0;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                AnonymousClass08O r3 = (AnonymousClass08O) childAt.getLayoutParams();
                if (r3.A04) {
                    int i13 = r3.A02;
                    int i14 = i13 & 7;
                    int i15 = i13 & 112;
                    if (i14 == 1) {
                        i5 = Math.max((i9 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                        i6 = paddingLeft;
                        paddingLeft = i5;
                    } else if (i14 == 3) {
                        i6 = childAt.getMeasuredWidth() + paddingLeft;
                    } else if (i14 != 5) {
                        i6 = paddingLeft;
                    } else {
                        i5 = (i9 - paddingRight) - childAt.getMeasuredWidth();
                        paddingRight += childAt.getMeasuredWidth();
                        i6 = paddingLeft;
                        paddingLeft = i5;
                    }
                    if (i15 == 16) {
                        i7 = Math.max((i10 - childAt.getMeasuredHeight()) / 2, paddingTop);
                        i8 = paddingTop;
                        paddingTop = i7;
                    } else if (i15 == 48) {
                        i8 = childAt.getMeasuredHeight() + paddingTop;
                    } else if (i15 != 80) {
                        i8 = paddingTop;
                    } else {
                        i7 = (i10 - paddingBottom) - childAt.getMeasuredHeight();
                        paddingBottom += childAt.getMeasuredHeight();
                        i8 = paddingTop;
                        paddingTop = i7;
                    }
                    int i16 = paddingLeft + scrollX;
                    childAt.layout(i16, paddingTop, childAt.getMeasuredWidth() + i16, childAt.getMeasuredHeight() + paddingTop);
                    i11++;
                    paddingLeft = i6;
                    paddingTop = i8;
                }
            }
        }
        int i17 = (i9 - paddingLeft) - paddingRight;
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt2 = getChildAt(i18);
            if (childAt2.getVisibility() != 8) {
                AnonymousClass08O r11 = (AnonymousClass08O) childAt2.getLayoutParams();
                if (!r11.A04 && (A042 = A04(childAt2)) != null) {
                    float f = (float) i17;
                    int i19 = ((int) (A042.A00 * f)) + paddingLeft;
                    if (r11.A05) {
                        r11.A05 = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f * r11.A00), 1073741824), View.MeasureSpec.makeMeasureSpec((i10 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i19, paddingTop, childAt2.getMeasuredWidth() + i19, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.A0X = i11;
        if (this.A0O) {
            z2 = false;
            A07(this.A04, 0, false, false);
        } else {
            z2 = false;
        }
        this.A0O = z2;
        AnonymousClass0BT.A01(internalBeginTrack);
    }

    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        AnonymousClass07Q A042;
        int childCount = getChildCount();
        int i2 = childCount - 1;
        int i3 = -1;
        int i4 = -1;
        if ((i & 2) != 0) {
            i3 = childCount;
            i2 = 0;
            i4 = 1;
        }
        while (i2 != i3) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (A042 = A04(childAt)) != null && A042.A02 == this.A04 && childAt.requestFocus(i, rect)) {
                return true;
            }
            i2 += i4;
        }
        return false;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [androidx.viewpager.widget.ViewPager$SavedState, android.os.Parcelable, androidx.customview.view.AbsSavedState] */
    public Parcelable onSaveInstanceState() {
        ? absSavedState = new AbsSavedState(super.onSaveInstanceState());
        absSavedState.A00 = this.A04;
        AnonymousClass0GB r0 = this.A0G;
        if (r0 != null) {
            absSavedState.A01 = r0.A09();
        }
        return absSavedState;
    }

    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        int A062 = AnonymousClass0BS.A06(-2075028882);
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            int i5 = this.A0A;
            A0A(this, i, i3, i5, i5);
        }
        AnonymousClass0BS.A0C(-1549034334, A062);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:86:0x01ba, code lost:
        if (r0 != false) goto L_0x0136;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r11) {
        /*
            r10 = this;
            r0 = -649692108(0xffffffffd9467c34, float:-3.49178801E15)
            int r3 = X.AnonymousClass0BS.A05(r0)
            r2 = 1
            int r0 = r11.getAction()
            r5 = 0
            if (r0 != 0) goto L_0x001c
            int r0 = r11.getEdgeFlags()
            if (r0 == 0) goto L_0x001c
            r0 = -961796525(0xffffffffc6ac2653, float:-22035.162)
        L_0x0018:
            X.AnonymousClass0BS.A0B(r0, r3)
            return r5
        L_0x001c:
            X.0GB r0 = r10.A0G
            if (r0 == 0) goto L_0x0202
            int r0 = r0.A07()
            if (r0 == 0) goto L_0x0202
            android.view.VelocityTracker r0 = r10.A0E
            if (r0 != 0) goto L_0x0030
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r10.A0E = r0
        L_0x0030:
            r0.addMovement(r11)
            int r0 = r11.getAction()
            r1 = r0 & 255(0xff, float:3.57E-43)
            if (r1 == 0) goto L_0x01de
            r9 = 0
            if (r1 == r2) goto L_0x008b
            r0 = 2
            if (r1 == r0) goto L_0x0148
            r0 = 3
            if (r1 == r0) goto L_0x01c0
            r0 = 5
            if (r1 == r0) goto L_0x007f
            r0 = 6
            if (r1 != r0) goto L_0x0078
            int r4 = r11.getActionIndex()
            int r1 = r11.getPointerId(r4)
            int r0 = r10.A03
            if (r1 != r0) goto L_0x006c
            if (r4 != 0) goto L_0x0059
            r5 = 1
        L_0x0059:
            float r0 = r11.getX(r5)
            r10.A01 = r0
            int r0 = r11.getPointerId(r5)
            r10.A03 = r0
            android.view.VelocityTracker r0 = r10.A0E
            if (r0 == 0) goto L_0x006c
            r0.clear()
        L_0x006c:
            int r0 = r10.A03
            int r0 = r11.findPointerIndex(r0)
            float r0 = r11.getX(r0)
            r10.A01 = r0
        L_0x0078:
            r0 = -878972735(0xffffffffcb9bf0c1, float:-2.0439426E7)
            X.AnonymousClass0BS.A0B(r0, r3)
            return r2
        L_0x007f:
            int r5 = r11.getActionIndex()
            float r0 = r11.getX(r5)
            r10.A01 = r0
            goto L_0x01fa
        L_0x008b:
            boolean r0 = r10.A0P
            if (r0 == 0) goto L_0x0078
            android.view.VelocityTracker r4 = r10.A0E
            int r0 = r10.A0a
            float r1 = (float) r0
            r0 = 1000(0x3e8, float:1.401E-42)
            r4.computeCurrentVelocity(r0, r1)
            int r0 = r10.A03
            float r0 = r4.getXVelocity(r0)
            int r4 = (int) r0
            r10.A0h = r2
            int r6 = r10.A00()
            int r7 = r10.getScrollX()
            X.07Q r8 = r10.A02()
            int r0 = r10.A0A
            float r1 = (float) r0
            float r0 = (float) r6
            float r1 = r1 / r0
            int r6 = r8.A02
            float r7 = (float) r7
            float r7 = r7 / r0
            float r0 = r8.A00
            float r7 = r7 - r0
            float r0 = r8.A01
            float r0 = r0 + r1
            float r7 = r7 / r0
            int r0 = r10.A03
            int r0 = r11.findPointerIndex(r0)
            float r1 = r11.getX(r0)
            float r0 = r10.A0T
            float r1 = r1 - r0
            int r0 = (int) r1
            r8 = r6
            int r1 = java.lang.Math.abs(r0)
            int r0 = r10.A06
            if (r1 <= r0) goto L_0x01ce
            int r1 = java.lang.Math.abs(r4)
            int r0 = r10.A08
            if (r1 <= r0) goto L_0x01ce
            android.widget.EdgeEffect r0 = r10.mLeftEdge
            float r0 = X.AnonymousClass0IA.A00(r0)
            int r0 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r0 != 0) goto L_0x01ce
            android.widget.EdgeEffect r0 = r10.mRightEdge
            float r0 = X.AnonymousClass0IA.A00(r0)
            int r0 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r0 != 0) goto L_0x01ce
            if (r4 > 0) goto L_0x00f5
            int r8 = r6 + 1
        L_0x00f5:
            java.util.ArrayList r7 = r10.A0i
            int r0 = r7.size()
            if (r0 <= 0) goto L_0x011b
            java.lang.Object r1 = r7.get(r5)
            X.07Q r1 = (X.AnonymousClass07Q) r1
            int r0 = r7.size()
            int r0 = r0 + -1
            java.lang.Object r0 = r7.get(r0)
            X.07Q r0 = (X.AnonymousClass07Q) r0
            int r1 = r1.A02
            int r0 = r0.A02
            int r0 = java.lang.Math.min(r8, r0)
            int r8 = java.lang.Math.max(r1, r0)
        L_0x011b:
            r10.A0M(r8, r4, r2, r2)
            boolean r0 = r10.A0C()
            if (r8 != r6) goto L_0x01ba
            if (r0 == 0) goto L_0x0078
            android.widget.EdgeEffect r0 = r10.mRightEdge
            float r0 = X.AnonymousClass0IA.A00(r0)
            int r0 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r0 == 0) goto L_0x013b
            android.widget.EdgeEffect r0 = r10.mRightEdge
            int r4 = -r4
        L_0x0133:
            r0.onAbsorb(r4)
        L_0x0136:
            r10.postInvalidateOnAnimation()
            goto L_0x0078
        L_0x013b:
            android.widget.EdgeEffect r0 = r10.mLeftEdge
            float r0 = X.AnonymousClass0IA.A00(r0)
            int r0 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r0 == 0) goto L_0x0136
            android.widget.EdgeEffect r0 = r10.mLeftEdge
            goto L_0x0133
        L_0x0148:
            boolean r0 = r10.A0P
            if (r0 != 0) goto L_0x01a4
            int r0 = r10.A03
            int r1 = r11.findPointerIndex(r0)
            r0 = -1
            if (r1 == r0) goto L_0x01c9
            float r6 = r11.getX(r1)
            float r0 = r10.A01
            float r0 = r6 - r0
            float r4 = java.lang.Math.abs(r0)
            float r5 = r11.getY(r1)
            float r0 = r10.A0V
            float r0 = r5 - r0
            float r1 = java.lang.Math.abs(r0)
            int r0 = r10.A0c
            float r0 = (float) r0
            int r0 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r0 <= 0) goto L_0x01a4
            int r0 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x01a4
            r10.A0P = r2
            android.view.ViewParent r0 = r10.getParent()
            if (r0 == 0) goto L_0x0183
            r0.requestDisallowInterceptTouchEvent(r2)
        L_0x0183:
            float r4 = r10.A0T
            float r6 = r6 - r4
            int r1 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            int r0 = r10.A0c
            float r0 = (float) r0
            if (r1 <= 0) goto L_0x01be
            float r4 = r4 + r0
        L_0x018e:
            r10.A01 = r4
            r10.A0V = r5
            r10.A0K(r2)
            boolean r0 = r10.A0S
            if (r0 == r2) goto L_0x019b
            r10.A0S = r2
        L_0x019b:
            android.view.ViewParent r0 = r10.getParent()
            if (r0 == 0) goto L_0x01a4
            r0.requestDisallowInterceptTouchEvent(r2)
        L_0x01a4:
            boolean r0 = r10.A0P
            if (r0 == 0) goto L_0x0078
            int r0 = r10.A03
            int r0 = r11.findPointerIndex(r0)
            float r1 = r11.getX(r0)
            float r0 = r11.getY(r0)
            boolean r0 = r10.A0E(r1, r0)
        L_0x01ba:
            if (r0 == 0) goto L_0x0078
            goto L_0x0136
        L_0x01be:
            float r4 = r4 - r0
            goto L_0x018e
        L_0x01c0:
            boolean r0 = r10.A0P
            if (r0 == 0) goto L_0x0078
            int r0 = r10.A04
            r10.A07(r0, r5, r2, r5)
        L_0x01c9:
            boolean r0 = r10.A0C()
            goto L_0x01ba
        L_0x01ce:
            int r1 = r10.A04
            r0 = 1058642330(0x3f19999a, float:0.6)
            if (r6 < r1) goto L_0x01d8
            r0 = 1053609165(0x3ecccccd, float:0.4)
        L_0x01d8:
            float r7 = r7 + r0
            int r0 = (int) r7
            int r8 = r6 + r0
            goto L_0x00f5
        L_0x01de:
            android.widget.Scroller r0 = r10.A0F
            r0.abortAnimation()
            r10.A0h = r5
            int r0 = r10.A04
            A09(r10, r0)
            float r0 = r11.getX()
            r10.A0T = r0
            r10.A01 = r0
            float r0 = r11.getY()
            r10.A0U = r0
            r10.A0V = r0
        L_0x01fa:
            int r0 = r11.getPointerId(r5)
            r10.A03 = r0
            goto L_0x0078
        L_0x0202:
            r0 = -576202369(0xffffffffdda7d97f, float:-1.51185474E18)
            goto L_0x0018
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final boolean verifyDrawable(Drawable drawable) {
        if (super.verifyDrawable(drawable) || drawable == null) {
            return true;
        }
        return false;
    }

    @Deprecated
    public void A0P(AnonymousClass0GC r1) {
        this.A0I = r1;
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [X.07Q, java.lang.Object] */
    public ViewPager(Context context) {
        super(context);
        A08(context);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new AnonymousClass08O();
    }
}
