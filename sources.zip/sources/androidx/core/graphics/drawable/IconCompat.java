package androidx.core.graphics.drawable;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class IconCompat extends CustomVersionedParcelable {
    public static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
    public static final String EXTRA_INT1 = "int1";
    public static final String EXTRA_INT2 = "int2";
    public static final String EXTRA_OBJ = "obj";
    public static final String EXTRA_STRING1 = "string1";
    public static final String EXTRA_TINT_LIST = "tint_list";
    public static final String EXTRA_TINT_MODE = "tint_mode";
    public static final String EXTRA_TYPE = "type";
    public byte[] mData;
    public int mInt1;
    public int mInt2;
    public Object mObj1;
    public Parcelable mParcelable;
    public String mString1;
    public ColorStateList mTintList;
    public PorterDuff.Mode mTintMode;
    public String mTintModeStr;
    public int mType;

    public static IconCompat createFromBundle(Bundle bundle) {
        Object obj;
        int i = bundle.getInt(EXTRA_TYPE);
        IconCompat iconCompat = new IconCompat(i);
        iconCompat.mInt1 = bundle.getInt(EXTRA_INT1);
        iconCompat.mInt2 = bundle.getInt(EXTRA_INT2);
        iconCompat.mString1 = bundle.getString(EXTRA_STRING1);
        if (bundle.containsKey(EXTRA_TINT_LIST)) {
            iconCompat.mTintList = (ColorStateList) bundle.getParcelable(EXTRA_TINT_LIST);
        }
        if (bundle.containsKey(EXTRA_TINT_MODE)) {
            iconCompat.mTintMode = PorterDuff.Mode.valueOf(bundle.getString(EXTRA_TINT_MODE));
        }
        switch (i) {
            case -1:
            case 1:
            case 5:
                obj = bundle.getParcelable(EXTRA_OBJ);
                break;
            case 2:
            case 4:
            case 6:
                obj = bundle.getString(EXTRA_OBJ);
                break;
            case 3:
                obj = bundle.getByteArray(EXTRA_OBJ);
                break;
            default:
                Log.w("IconCompat", AnonymousClass0WY.A0d("Unknown type ", i));
                return null;
        }
        iconCompat.mObj1 = obj;
        return iconCompat;
    }

    public static IconCompat createWithBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            IconCompat iconCompat = new IconCompat(1);
            iconCompat.mObj1 = bitmap;
            return iconCompat;
        }
        throw AnonymousClass001.A0S();
    }

    public static IconCompat createWithResource(Resources resources, String str, int i) {
        if (str == null) {
            throw AnonymousClass001.A0S();
        } else if (i != 0) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.mInt1 = i;
            if (resources != null) {
                try {
                    iconCompat.mObj1 = resources.getResourceName(i);
                } catch (Resources.NotFoundException unused) {
                    throw AnonymousClass001.A0L("Icon resource cannot be found");
                }
            } else {
                iconCompat.mObj1 = str;
            }
            iconCompat.mString1 = str;
            return iconCompat;
        } else {
            throw AnonymousClass001.A0L("Drawable resource ID must not be 0");
        }
    }

    public Bitmap getBitmap() {
        Object obj;
        int i = this.mType;
        if (i == -1) {
            obj = this.mObj1;
            if (!(obj instanceof Bitmap)) {
                return null;
            }
        } else if (i == 1) {
            obj = this.mObj1;
        } else if (i == 5) {
            return createLegacyIconFromAdaptiveIcon((Bitmap) this.mObj1, true);
        } else {
            throw AnonymousClass002.A0G(this, "called getBitmap() on ", AnonymousClass001.A0m());
        }
        return (Bitmap) obj;
    }

    public int getResId() {
        int i = this.mType;
        if (i == -1) {
            return ((Icon) this.mObj1).getResId();
        }
        if (i == 2) {
            return this.mInt1;
        }
        throw AnonymousClass002.A0G(this, "called getResId() on ", AnonymousClass001.A0m());
    }

    public Uri getUri() {
        int i = this.mType;
        if (i == -1) {
            return ((Icon) this.mObj1).getUri();
        }
        if (i == 4 || i == 6) {
            return Uri.parse((String) this.mObj1);
        }
        throw AnonymousClass002.A0G(this, "called getUri() on ", AnonymousClass001.A0m());
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r3 = this;
            int r1 = r3.mType
            r0 = -1
            if (r1 != r0) goto L_0x000c
            java.lang.Object r0 = r3.mObj1
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.String r0 = "Icon(typ="
            java.lang.StringBuilder r2 = X.AnonymousClass001.A0p(r0)
            switch(r1) {
                case 1: goto L_0x00b4;
                case 2: goto L_0x00b0;
                case 3: goto L_0x00ac;
                case 4: goto L_0x00a8;
                case 5: goto L_0x00a4;
                case 6: goto L_0x00a0;
                default: goto L_0x0015;
            }
        L_0x0015:
            java.lang.String r0 = "UNKNOWN"
        L_0x0017:
            r2.append(r0)
            switch(r1) {
                case 1: goto L_0x003e;
                case 2: goto L_0x005c;
                case 3: goto L_0x007d;
                case 4: goto L_0x0094;
                case 5: goto L_0x003e;
                case 6: goto L_0x0094;
                default: goto L_0x001d;
            }
        L_0x001d:
            android.content.res.ColorStateList r1 = r3.mTintList
            if (r1 == 0) goto L_0x0029
            java.lang.String r0 = " tint="
            r2.append(r0)
            r2.append(r1)
        L_0x0029:
            android.graphics.PorterDuff$Mode r1 = r3.mTintMode
            android.graphics.PorterDuff$Mode r0 = DEFAULT_TINT_MODE
            if (r1 == r0) goto L_0x0037
            java.lang.String r0 = " mode="
            r2.append(r0)
            r2.append(r1)
        L_0x0037:
            java.lang.String r0 = ")"
            java.lang.String r0 = X.AnonymousClass001.A0g(r0, r2)
            return r0
        L_0x003e:
            java.lang.String r0 = " size="
            r2.append(r0)
            java.lang.Object r0 = r3.mObj1
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
            int r0 = r0.getWidth()
            r2.append(r0)
            java.lang.String r0 = "x"
            r2.append(r0)
            java.lang.Object r0 = r3.mObj1
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
            int r1 = r0.getHeight()
            goto L_0x0090
        L_0x005c:
            java.lang.String r0 = " pkg="
            r2.append(r0)
            java.lang.String r0 = r3.mString1
            r2.append(r0)
            java.lang.String r0 = " id="
            r2.append(r0)
            int r0 = r3.getResId()
            java.lang.Object[] r1 = X.AnonymousClass001.A1a(r0)
            java.lang.String r0 = "0x%08x"
            java.lang.String r0 = java.lang.String.format(r0, r1)
            r2.append(r0)
            goto L_0x001d
        L_0x007d:
            java.lang.String r0 = " len="
            r2.append(r0)
            int r0 = r3.mInt1
            r2.append(r0)
            int r1 = r3.mInt2
            if (r1 == 0) goto L_0x001d
            java.lang.String r0 = " off="
            r2.append(r0)
        L_0x0090:
            r2.append(r1)
            goto L_0x001d
        L_0x0094:
            java.lang.String r0 = " uri="
            r2.append(r0)
            java.lang.Object r0 = r3.mObj1
            r2.append(r0)
            goto L_0x001d
        L_0x00a0:
            java.lang.String r0 = "URI_MASKABLE"
            goto L_0x0017
        L_0x00a4:
            java.lang.String r0 = "BITMAP_MASKABLE"
            goto L_0x0017
        L_0x00a8:
            java.lang.String r0 = "URI"
            goto L_0x0017
        L_0x00ac:
            java.lang.String r0 = "DATA"
            goto L_0x0017
        L_0x00b0:
            java.lang.String r0 = "RESOURCE"
            goto L_0x0017
        L_0x00b4:
            java.lang.String r0 = "BITMAP"
            goto L_0x0017
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }

    public IconCompat(int i) {
        this.mData = null;
        this.mParcelable = null;
        this.mInt1 = 0;
        this.mInt2 = 0;
        this.mTintList = null;
        this.mTintMode = DEFAULT_TINT_MODE;
        this.mTintModeStr = null;
        this.mType = i;
    }

    public static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap bitmap, boolean z) {
        int min = (int) (((float) Math.min(bitmap.getWidth(), bitmap.getHeight())) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f = (float) min;
        float f2 = f * 0.5f;
        float f3 = 0.9166667f * f2;
        if (z) {
            float f4 = f * 0.010416667f;
            paint.setColor(0);
            paint.setShadowLayer(f4, 0.0f, f * 0.020833334f, 1023410176);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.setShadowLayer(f4, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate(((float) (-(bitmap.getWidth() - min))) / 2.0f, ((float) (-(bitmap.getHeight() - min))) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f2, f2, f3, paint);
        canvas.setBitmap((Bitmap) null);
        return createBitmap;
    }

    public InputStream getUriInputStream(Context context) {
        StringBuilder sb;
        String str;
        Uri uri = getUri();
        String scheme = uri.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(uri);
            } catch (Exception e) {
                e = e;
                sb = AnonymousClass001.A0m();
                str = "Unable to load image from URI: ";
                Log.w("IconCompat", AnonymousClass002.A0M(uri, str, sb), e);
                return null;
            }
        } else {
            try {
                return AnonymousClass001.A0F(AnonymousClass001.A0E((String) this.mObj1));
            } catch (FileNotFoundException e2) {
                e = e2;
                sb = AnonymousClass001.A0m();
                str = "Unable to load image from path: ";
                Log.w("IconCompat", AnonymousClass002.A0M(uri, str, sb), e);
                return null;
            }
        }
    }

    public IconCompat() {
        this.mType = -1;
        this.mData = null;
        this.mParcelable = null;
        this.mInt1 = 0;
        this.mInt2 = 0;
        this.mTintList = null;
        this.mTintMode = DEFAULT_TINT_MODE;
        this.mTintModeStr = null;
    }
}
