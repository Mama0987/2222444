package androidx.core.view.accessibility;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0TU;
import X.AnonymousClass0WY;
import X.C05570Sa;
import X.C08900cm;
import X.C08960cs;
import X.C08970ct;
import X.C08980cu;
import X.C09040d0;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.core.view.inputmethod.EditorInfoCompat;
import com.facebook.common.dextricks.Constants;
import com.facebook.common.dextricks.DalvikConstants;
import com.facebook.common.dextricks.DalvikInternals;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AccessibilityNodeInfoCompat {
    public final AccessibilityNodeInfo mInfo;
    public int mParentVirtualDescendantId = -1;
    public int mVirtualDescendantId = -1;

    public static String getActionSymbolicName(int i) {
        if (i == 1) {
            return "ACTION_FOCUS";
        }
        if (i == 2) {
            return "ACTION_CLEAR_FOCUS";
        }
        switch (i) {
            case 4:
                return "ACTION_SELECT";
            case 8:
                return "ACTION_CLEAR_SELECTION";
            case 16:
                return "ACTION_CLICK";
            case 32:
                return "ACTION_LONG_CLICK";
            case 64:
                return "ACTION_ACCESSIBILITY_FOCUS";
            case DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS /*128*/:
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            case DalvikInternals.ART_HACK_DEX_PC_LINENUM /*256*/:
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            case 512:
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            case 1024:
                return "ACTION_NEXT_HTML_ELEMENT";
            case EditorInfoCompat.MEMORY_EFFICIENT_TEXT_LENGTH /*2048*/:
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            case 4096:
                return "ACTION_SCROLL_FORWARD";
            case Constants.LOAD_RESULT_MIXED_MODE_ATTEMPTED /*8192*/:
                return "ACTION_SCROLL_BACKWARD";
            case Constants.LOAD_RESULT_DEX2OAT_CLASSPATH_SET /*16384*/:
                return "ACTION_COPY";
            case Constants.LOAD_RESULT_PGO /*32768*/:
                return "ACTION_PASTE";
            case Constants.LOAD_RESULT_PGO_ATTEMPTED /*65536*/:
                return "ACTION_CUT";
            case Constants.LOAD_RESULT_DEX2OAT_TRY_PERIODIC_PGO_COMP /*131072*/:
                return "ACTION_SET_SELECTION";
            case Constants.LOAD_RESULT_DEX2OAT_TRY_PERIODIC_PGO_COMP_ATTEMPTED /*262144*/:
                return "ACTION_EXPAND";
            case Constants.LOAD_RESULT_WITH_VDEX_ODEX /*524288*/:
                return "ACTION_COLLAPSE";
            case 2097152:
                return "ACTION_SET_TEXT";
            case 16908354:
                return "ACTION_MOVE_WINDOW";
            case 16908382:
                return "ACTION_SCROLL_IN_DIRECTION";
            default:
                switch (i) {
                    case 16908342:
                        return "ACTION_SHOW_ON_SCREEN";
                    case 16908343:
                        return "ACTION_SCROLL_TO_POSITION";
                    case 16908344:
                        return "ACTION_SCROLL_UP";
                    case 16908345:
                        return "ACTION_SCROLL_LEFT";
                    case 16908346:
                        return "ACTION_SCROLL_DOWN";
                    case 16908347:
                        return "ACTION_SCROLL_RIGHT";
                    case 16908348:
                        return "ACTION_CONTEXT_CLICK";
                    case 16908349:
                        return "ACTION_SET_PROGRESS";
                    default:
                        switch (i) {
                            case 16908356:
                                return "ACTION_SHOW_TOOLTIP";
                            case 16908357:
                                return "ACTION_HIDE_TOOLTIP";
                            case 16908358:
                                return "ACTION_PAGE_UP";
                            case 16908359:
                                return "ACTION_PAGE_DOWN";
                            case 16908360:
                                return "ACTION_PAGE_LEFT";
                            case 16908361:
                                return "ACTION_PAGE_RIGHT";
                            case 16908362:
                                return "ACTION_PRESS_AND_HOLD";
                            default:
                                switch (i) {
                                    case 16908372:
                                        return "ACTION_IME_ENTER";
                                    case 16908373:
                                        return "ACTION_DRAG_START";
                                    case 16908374:
                                        return "ACTION_DRAG_DROP";
                                    case 16908375:
                                        return "ACTION_DRAG_CANCEL";
                                    default:
                                        return "ACTION_UNKNOWN";
                                }
                        }
                }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0012, code lost:
        if (r0 != null) goto L_0x0014;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r5) {
        /*
            r4 = this;
            r3 = 1
            if (r4 == r5) goto L_0x0029
            r2 = 0
            if (r5 == 0) goto L_0x0014
            boolean r0 = r5 instanceof androidx.core.view.accessibility.AccessibilityNodeInfoCompat
            if (r0 == 0) goto L_0x0014
            androidx.core.view.accessibility.AccessibilityNodeInfoCompat r5 = (androidx.core.view.accessibility.AccessibilityNodeInfoCompat) r5
            android.view.accessibility.AccessibilityNodeInfo r1 = r4.mInfo
            android.view.accessibility.AccessibilityNodeInfo r0 = r5.mInfo
            if (r1 != 0) goto L_0x0015
            if (r0 == 0) goto L_0x001c
        L_0x0014:
            return r2
        L_0x0015:
            boolean r0 = r1.equals(r0)
            if (r0 != 0) goto L_0x001c
            return r2
        L_0x001c:
            int r1 = r4.mVirtualDescendantId
            int r0 = r5.mVirtualDescendantId
            if (r1 != r0) goto L_0x0014
            int r1 = r4.mParentVirtualDescendantId
            int r0 = r5.mParentVirtualDescendantId
            if (r1 == r0) goto L_0x0029
            return r2
        L_0x0029:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.view.accessibility.AccessibilityNodeInfoCompat.equals(java.lang.Object):boolean");
    }

    private List extrasIntList(String str) {
        ArrayList<Integer> integerArrayList = this.mInfo.getExtras().getIntegerArrayList(str);
        if (integerArrayList != null) {
            return integerArrayList;
        }
        ArrayList A0t = AnonymousClass001.A0t();
        this.mInfo.getExtras().putIntegerArrayList(str, A0t);
        return A0t;
    }

    private boolean getBooleanProperty(int i) {
        Bundle extras = this.mInfo.getExtras();
        if (extras == null || (extras.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0) & i) != i) {
            return false;
        }
        return true;
    }

    public void addAction(C05570Sa r3) {
        this.mInfo.addAction((AccessibilityNodeInfo.AccessibilityAction) r3.A02);
    }

    public List getActionList() {
        List<AccessibilityNodeInfo.AccessibilityAction> actionList = this.mInfo.getActionList();
        if (actionList == null) {
            return Collections.emptyList();
        }
        ArrayList A0t = AnonymousClass001.A0t();
        int size = actionList.size();
        for (int i = 0; i < size; i++) {
            A0t.add(new C05570Sa((C09040d0) null, (CharSequence) null, (Class) null, actionList.get(i), 0));
        }
        return A0t;
    }

    public C08980cu getCollectionInfo() {
        AccessibilityNodeInfo.CollectionInfo collectionInfo = this.mInfo.getCollectionInfo();
        if (collectionInfo != null) {
            return new C08980cu(collectionInfo);
        }
        return null;
    }

    public CharSequence getContainerTitle() {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 34) {
            return AnonymousClass0TU.A01(accessibilityNodeInfo);
        }
        return accessibilityNodeInfo.getExtras().getCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.CONTAINER_TITLE_KEY");
    }

    public CharSequence getStateDescription() {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 30) {
            return C08960cs.A00(accessibilityNodeInfo);
        }
        return accessibilityNodeInfo.getExtras().getCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY");
    }

    public CharSequence getText() {
        if (!(!extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").isEmpty())) {
            return this.mInfo.getText();
        }
        List extrasIntList = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
        List extrasIntList2 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
        List extrasIntList3 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
        List extrasIntList4 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
        SpannableString spannableString = new SpannableString(TextUtils.substring(this.mInfo.getText(), 0, this.mInfo.getText().length()));
        for (int i = 0; i < extrasIntList.size(); i++) {
            spannableString.setSpan(new C08900cm(this, AnonymousClass001.A02(extrasIntList4.get(i)), this.mInfo.getExtras().getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY")), AnonymousClass001.A02(extrasIntList.get(i)), AnonymousClass001.A02(extrasIntList2.get(i)), AnonymousClass001.A02(extrasIntList3.get(i)));
        }
        return spannableString;
    }

    public boolean hasRequestInitialAccessibilityFocus() {
        if (Build.VERSION.SDK_INT >= 34) {
            return AnonymousClass0TU.A06(this.mInfo);
        }
        return getBooleanProperty(32);
    }

    public int hashCode() {
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (accessibilityNodeInfo == null) {
            return 0;
        }
        return accessibilityNodeInfo.hashCode();
    }

    public boolean removeAction(C05570Sa r3) {
        return this.mInfo.removeAction((AccessibilityNodeInfo.AccessibilityAction) r3.A02);
    }

    public void setCheckable(boolean z) {
        this.mInfo.setCheckable(z);
    }

    public void setChecked(boolean z) {
        this.mInfo.setChecked(z);
    }

    public void setClassName(CharSequence charSequence) {
        this.mInfo.setClassName(charSequence);
    }

    public void setClickable(boolean z) {
        this.mInfo.setClickable(z);
    }

    public void setCollectionInfo(Object obj) {
        AccessibilityNodeInfo.CollectionInfo collectionInfo;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (obj == null) {
            collectionInfo = null;
        } else {
            collectionInfo = (AccessibilityNodeInfo.CollectionInfo) ((C08980cu) obj).A00;
        }
        accessibilityNodeInfo.setCollectionInfo(collectionInfo);
    }

    public void setContainerTitle(CharSequence charSequence) {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 34) {
            AnonymousClass0TU.A04(accessibilityNodeInfo, charSequence);
        } else {
            accessibilityNodeInfo.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.CONTAINER_TITLE_KEY", charSequence);
        }
    }

    public void setContentDescription(CharSequence charSequence) {
        this.mInfo.setContentDescription(charSequence);
    }

    public void setMinDurationBetweenContentChangesMillis(long j) {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 34) {
            AnonymousClass0TU.A03(accessibilityNodeInfo, j);
        } else {
            accessibilityNodeInfo.getExtras().putLong("androidx.view.accessibility.AccessibilityNodeInfoCompat.MIN_DURATION_BETWEEN_CONTENT_CHANGES_KEY", j);
        }
    }

    public void setRequestInitialAccessibilityFocus(boolean z) {
        if (Build.VERSION.SDK_INT >= 34) {
            AnonymousClass0TU.A05(this.mInfo, z);
            return;
        }
        int i = 32;
        Bundle extras = this.mInfo.getExtras();
        if (extras != null) {
            int i2 = extras.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0) & -33;
            if (!z) {
                i = 0;
            }
            extras.putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", i | i2);
        }
    }

    public void setRoleDescription(CharSequence charSequence) {
        this.mInfo.getExtras().putCharSequence("AccessibilityNodeInfo.roleDescription", charSequence);
    }

    public void setStateDescription(CharSequence charSequence) {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 30) {
            C08960cs.A01(accessibilityNodeInfo, charSequence);
        } else {
            accessibilityNodeInfo.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY", charSequence);
        }
    }

    public void setUniqueId(String str) {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 33) {
            C08970ct.A01(accessibilityNodeInfo, str);
        } else {
            accessibilityNodeInfo.getExtras().putString("androidx.view.accessibility.AccessibilityNodeInfoCompat.UNIQUE_ID_KEY", str);
        }
    }

    @Deprecated
    public AccessibilityNodeInfoCompat(Object obj) {
        this.mInfo = (AccessibilityNodeInfo) obj;
    }

    public String toString() {
        String string;
        boolean booleanProperty;
        boolean booleanProperty2;
        StringBuilder A0m = AnonymousClass001.A0m();
        A0m.append(super.toString());
        Rect rect = new Rect();
        this.mInfo.getBoundsInParent(rect);
        A0m.append(AnonymousClass002.A0M(rect, "; boundsInParent: ", AnonymousClass001.A0m()));
        this.mInfo.getBoundsInScreen(rect);
        A0m.append(AnonymousClass002.A0M(rect, "; boundsInScreen: ", AnonymousClass001.A0m()));
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        if (i >= 34) {
            AnonymousClass0TU.A02(rect, accessibilityNodeInfo);
        } else {
            Rect rect2 = (Rect) accessibilityNodeInfo.getExtras().getParcelable("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOUNDS_IN_WINDOW_KEY");
            if (rect2 != null) {
                rect.set(rect2.left, rect2.top, rect2.right, rect2.bottom);
            }
        }
        A0m.append(AnonymousClass002.A0M(rect, "; boundsInWindow: ", AnonymousClass001.A0m()));
        A0m.append("; packageName: ");
        A0m.append(this.mInfo.getPackageName());
        A0m.append("; className: ");
        A0m.append(this.mInfo.getClassName());
        A0m.append("; text: ");
        A0m.append(getText());
        A0m.append("; error: ");
        A0m.append(this.mInfo.getError());
        A0m.append("; maxTextLength: ");
        A0m.append(this.mInfo.getMaxTextLength());
        A0m.append("; stateDescription: ");
        A0m.append(getStateDescription());
        A0m.append("; contentDescription: ");
        A0m.append(this.mInfo.getContentDescription());
        A0m.append("; tooltipText: ");
        A0m.append(this.mInfo.getTooltipText());
        A0m.append("; viewIdResName: ");
        A0m.append(this.mInfo.getViewIdResourceName());
        A0m.append("; uniqueId: ");
        AccessibilityNodeInfo accessibilityNodeInfo2 = this.mInfo;
        if (i >= 33) {
            string = C08970ct.A00(accessibilityNodeInfo2);
        } else {
            string = accessibilityNodeInfo2.getExtras().getString("androidx.view.accessibility.AccessibilityNodeInfoCompat.UNIQUE_ID_KEY");
        }
        A0m.append(string);
        A0m.append("; checkable: ");
        A0m.append(this.mInfo.isCheckable());
        A0m.append("; checked: ");
        A0m.append(this.mInfo.isChecked());
        A0m.append("; focusable: ");
        A0m.append(this.mInfo.isFocusable());
        A0m.append("; focused: ");
        A0m.append(this.mInfo.isFocused());
        A0m.append("; selected: ");
        A0m.append(this.mInfo.isSelected());
        A0m.append("; clickable: ");
        A0m.append(this.mInfo.isClickable());
        A0m.append("; longClickable: ");
        A0m.append(this.mInfo.isLongClickable());
        A0m.append("; contextClickable: ");
        A0m.append(this.mInfo.isContextClickable());
        A0m.append("; enabled: ");
        A0m.append(this.mInfo.isEnabled());
        A0m.append("; password: ");
        A0m.append(this.mInfo.isPassword());
        A0m.append(AnonymousClass0WY.A1R("; scrollable: ", this.mInfo.isScrollable()));
        A0m.append("; containerTitle: ");
        A0m.append(getContainerTitle());
        A0m.append("; granularScrollingSupported: ");
        A0m.append(getBooleanProperty(67108864));
        A0m.append("; importantForAccessibility: ");
        A0m.append(this.mInfo.isImportantForAccessibility());
        A0m.append("; visible: ");
        A0m.append(this.mInfo.isVisibleToUser());
        A0m.append("; isTextSelectable: ");
        if (i >= 33) {
            booleanProperty = C08970ct.A02(this.mInfo);
        } else {
            booleanProperty = getBooleanProperty(DalvikConstants.FB4A_LINEAR_ALLOC_BUFFER_SIZE);
        }
        A0m.append(booleanProperty);
        A0m.append("; accessibilityDataSensitive: ");
        if (i >= 34) {
            booleanProperty2 = AnonymousClass0TU.A07(this.mInfo);
        } else {
            booleanProperty2 = getBooleanProperty(64);
        }
        A0m.append(booleanProperty2);
        A0m.append("; [");
        List actionList = getActionList();
        for (int i2 = 0; i2 < actionList.size(); i2++) {
            C05570Sa r2 = (C05570Sa) actionList.get(i2);
            String actionSymbolicName = getActionSymbolicName(r2.A00());
            if (actionSymbolicName.equals("ACTION_UNKNOWN") && ((AccessibilityNodeInfo.AccessibilityAction) r2.A02).getLabel() != null) {
                actionSymbolicName = ((AccessibilityNodeInfo.AccessibilityAction) r2.A02).getLabel().toString();
            }
            A0m.append(actionSymbolicName);
            if (i2 != actionList.size() - 1) {
                A0m.append(", ");
            }
        }
        return AnonymousClass001.A0g("]", A0m);
    }

    public AccessibilityNodeInfoCompat(AccessibilityNodeInfo accessibilityNodeInfo) {
        this.mInfo = accessibilityNodeInfo;
    }

    public void addAction(int i) {
        this.mInfo.addAction(i);
    }
}
