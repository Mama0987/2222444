package androidx.core.content;

import X.AnonymousClass001;
import X.AnonymousClass002;
import X.AnonymousClass0WY;
import X.C07150Zq;
import X.C07160Zr;
import X.C14390pf;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import com.facebook.common.dextricks.DalvikInternals;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider {
    public static final File A04 = AnonymousClass001.A0E("/");
    public static final HashMap A05 = AnonymousClass001.A0w();
    public static final String[] A06 = {"_display_name", "_size"};
    public C07150Zq A00;
    public String A01;
    public final int A02;
    public final Object A03;

    private C07150Zq A00() {
        C07150Zq r0;
        synchronized (this.A03) {
            if (this.A01 != null) {
                r0 = this.A00;
                if (r0 == null) {
                    r0 = A01(getContext(), this.A01, this.A02);
                    this.A00 = r0;
                }
            } else {
                throw AnonymousClass001.A0T("mAuthority is null. Did you override attachInfo and did not call super.attachInfo()?");
            }
        }
        return r0;
    }

    public static C07150Zq A01(Context context, String str, int i) {
        C07160Zr r4;
        IllegalArgumentException illegalArgumentException;
        File file;
        IllegalArgumentException A0L;
        File[] externalMediaDirs;
        HashMap hashMap = A05;
        synchronized (hashMap) {
            C07150Zq r42 = (C07150Zq) hashMap.get(str);
            r4 = r42;
            if (r42 == null) {
                try {
                    C07160Zr r43 = new C07160Zr(str);
                    XmlResourceParser fileProviderPathsMetaData = getFileProviderPathsMetaData(context, str, context.getPackageManager().resolveContentProvider(str, DalvikInternals.ART_HACK_DISABLE_MONITOR_VISITLOCKS), i);
                    while (true) {
                        int next = fileProviderPathsMetaData.next();
                        if (next == 1) {
                            hashMap.put(str, r43);
                            r4 = r43;
                            break;
                        } else if (next == 2) {
                            String name = fileProviderPathsMetaData.getName();
                            String attributeValue = fileProviderPathsMetaData.getAttributeValue((String) null, C14390pf.ATTR_NAME);
                            String attributeValue2 = fileProviderPathsMetaData.getAttributeValue((String) null, C14390pf.ATTR_PATH);
                            if ("root-path".equals(name)) {
                                file = A04;
                            } else if ("files-path".equals(name)) {
                                file = context.getFilesDir();
                            } else if ("cache-path".equals(name)) {
                                file = context.getCacheDir();
                            } else if ("external-path".equals(name)) {
                                file = Environment.getExternalStorageDirectory();
                            } else {
                                if ("external-files-path".equals(name)) {
                                    externalMediaDirs = context.getExternalFilesDirs((String) null);
                                } else if ("external-cache-path".equals(name)) {
                                    externalMediaDirs = context.getExternalCacheDirs();
                                } else if ("external-media-path".equals(name)) {
                                    externalMediaDirs = context.getExternalMediaDirs();
                                } else {
                                    continue;
                                }
                                if (externalMediaDirs.length > 0) {
                                    file = externalMediaDirs[0];
                                } else {
                                    continue;
                                }
                            }
                            if (file != null) {
                                String str2 = new String[]{attributeValue2}[0];
                                if (str2 != null) {
                                    file = AnonymousClass001.A0D(file, str2);
                                }
                                if (TextUtils.isEmpty(attributeValue)) {
                                    A0L = AnonymousClass001.A0L("Name must not be empty");
                                    break;
                                }
                                try {
                                    r43.A01.put(attributeValue, file.getCanonicalFile());
                                } catch (IOException e) {
                                    A0L = new IllegalArgumentException(AnonymousClass002.A0M(file, "Failed to resolve canonical path for ", AnonymousClass001.A0m()), e);
                                }
                            } else {
                                continue;
                            }
                        }
                    }
                    throw A0L;
                } catch (IOException e2) {
                    illegalArgumentException = new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e2);
                    throw illegalArgumentException;
                } catch (XmlPullParserException e3) {
                    illegalArgumentException = new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e3);
                    throw illegalArgumentException;
                }
            }
        }
        return r4;
    }

    public static XmlResourceParser getFileProviderPathsMetaData(Context context, String str, ProviderInfo providerInfo, int i) {
        if (providerInfo != null) {
            if (providerInfo.metaData == null && i != 0) {
                Bundle bundle = new Bundle(1);
                providerInfo.metaData = bundle;
                bundle.putInt("android.support.FILE_PROVIDER_PATHS", i);
            }
            XmlResourceParser loadXmlMetaData = providerInfo.loadXmlMetaData(context.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
            if (loadXmlMetaData != null) {
                return loadXmlMetaData;
            }
            throw AnonymousClass001.A0L("Missing android.support.FILE_PROVIDER_PATHS meta-data");
        }
        throw AnonymousClass0WY.A04("Couldn't find meta-data for provider with authority ", str);
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        throw AnonymousClass001.A0r("No external inserts");
    }

    public final int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw AnonymousClass001.A0r("No external updates");
    }

    public FileProvider(int i) {
        this.A03 = AnonymousClass001.A0U();
        this.A02 = i;
    }

    public final void attachInfo(Context context, ProviderInfo providerInfo) {
        super.attachInfo(context, providerInfo);
        if (providerInfo.exported) {
            throw AnonymousClass001.A0Y("Provider must not be exported");
        } else if (providerInfo.grantUriPermissions) {
            String str = providerInfo.authority.split(";")[0];
            synchronized (this.A03) {
                this.A01 = str;
            }
            HashMap hashMap = A05;
            synchronized (hashMap) {
                hashMap.remove(str);
            }
        } else {
            throw AnonymousClass001.A0Y("Provider must grant uri permissions");
        }
    }

    public final int delete(Uri uri, String str, String[] strArr) {
        return A00().BCt(uri).delete() ? 1 : 0;
    }

    public final String getType(Uri uri) {
        String mimeTypeFromExtension;
        File BCt = A00().BCt(uri);
        int lastIndexOf = BCt.getName().lastIndexOf(46);
        if (lastIndexOf < 0 || (mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(AnonymousClass001.A0Z(lastIndexOf, BCt.getName()))) == null) {
            return "application/octet-stream";
        }
        return mimeTypeFromExtension;
    }

    public final boolean onCreate() {
        return true;
    }

    public final ParcelFileDescriptor openFile(Uri uri, String str) {
        int i;
        File BCt = A00().BCt(uri);
        if ("r".equals(str)) {
            i = 268435456;
        } else if ("w".equals(str) || "wt".equals(str)) {
            i = 738197504;
        } else if ("wa".equals(str)) {
            i = 704643072;
        } else if ("rw".equals(str)) {
            i = 939524096;
        } else if ("rwt".equals(str)) {
            i = 1006632960;
        } else {
            throw AnonymousClass0WY.A04("Invalid mode: ", str);
        }
        return ParcelFileDescriptor.open(BCt, i);
    }

    public final Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        int i;
        Object A0R;
        File BCt = A00().BCt(uri);
        String queryParameter = uri.getQueryParameter("displayName");
        if (strArr == null) {
            strArr = A06;
        }
        String[] strArr3 = new String[r7];
        Object[] objArr = new Object[r7];
        int i2 = 0;
        for (String str3 : strArr) {
            if ("_display_name".equals(str3)) {
                strArr3[i2] = "_display_name";
                i = i2 + 1;
                if (queryParameter == null) {
                    A0R = BCt.getName();
                } else {
                    A0R = queryParameter;
                }
            } else if ("_size".equals(str3)) {
                strArr3[i2] = "_size";
                i = i2 + 1;
                A0R = AnonymousClass001.A0R(BCt);
            }
            objArr[i2] = A0R;
            i2 = i;
        }
        String[] strArr4 = new String[i2];
        System.arraycopy(strArr3, 0, strArr4, 0, i2);
        Object[] objArr2 = new Object[i2];
        System.arraycopy(objArr, 0, objArr2, 0, i2);
        MatrixCursor matrixCursor = new MatrixCursor(strArr4, 1);
        matrixCursor.addRow(objArr2);
        return matrixCursor;
    }

    public final String getTypeAnonymous(Uri uri) {
        return "application/octet-stream";
    }

    public FileProvider() {
        this(0);
    }
}
