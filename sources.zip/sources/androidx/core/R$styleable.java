package androidx.core;

public class R$styleable {
    public static final int[] Capability = {2130971864, 2130972162};
    public static final int[] ColorStateListItem = {16843173, 16843551, 16844359, 2130968699, 2130971066};
    public static final int[] FontFamily = {2130970313, 2130970314, 2130970315, 2130970316, 2130970317, 2130970318, 2130970319};
    public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, 2130970311, 2130970320, 2130970321, 2130970322, 2130972666};
    public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
    public static final int[] GradientColorItem = {16843173, 16844052};
}
