package androidx.core.app;

import X.AnonymousClass0YT;
import X.AnonymousClass0Yg;
import X.AnonymousClass0ZB;
import X.C06930Yp;
import android.app.Notification;
import android.os.Bundle;

public final class NotificationCompat$BigTextStyle extends AnonymousClass0Yg {
    public CharSequence A00;

    public final void A07(AnonymousClass0YT r3) {
        Notification.BigTextStyle bigText = new Notification.BigTextStyle(((AnonymousClass0ZB) r3).A04).setBigContentTitle(this.A01).bigText(this.A00);
        if (this.A03) {
            bigText.setSummaryText(this.A02);
        }
    }

    public final void A02(Bundle bundle) {
        super.A02(bundle);
        bundle.remove("android.bigText");
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$BigTextStyle";
    }

    public final void A06(Bundle bundle) {
        super.A06(bundle);
        this.A00 = bundle.getCharSequence("android.bigText");
    }

    public final void A08(CharSequence charSequence) {
        this.A00 = C06930Yp.A00(charSequence);
    }
}
