package androidx.core.app;

import X.AnonymousClass0Qz;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements AnonymousClass0Qz {
    public PendingIntent mActionIntent;
    public CharSequence mContentDescription;
    public boolean mEnabled;
    public IconCompat mIcon;
    public boolean mShouldShowIcon;
    public CharSequence mTitle;
}
