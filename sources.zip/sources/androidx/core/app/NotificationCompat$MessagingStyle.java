package androidx.core.app;

import X.AnonymousClass001;
import X.AnonymousClass0YT;
import X.AnonymousClass0Yg;
import X.AnonymousClass0Z0;
import X.AnonymousClass0ZB;
import X.AnonymousClass0ZP;
import X.AnonymousClass0ZR;
import X.C06930Yp;
import android.app.Notification;
import android.app.Person;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import java.util.List;

public final class NotificationCompat$MessagingStyle extends AnonymousClass0Yg {
    public AnonymousClass0ZR A00;
    public Boolean A01;
    public CharSequence A02;
    public final List A03 = AnonymousClass001.A0t();
    public final List A04 = AnonymousClass001.A0t();

    public final void A07(AnonymousClass0YT r9) {
        C06930Yp r0 = this.A00;
        boolean z = false;
        if (r0 == null || r0.A0E.getApplicationInfo().targetSdkVersion >= 28 || this.A01 != null) {
            Boolean bool = this.A01;
            if (bool != null) {
                z = bool.booleanValue();
            }
        } else if (this.A02 != null) {
            z = true;
        }
        this.A01 = Boolean.valueOf(z);
        Notification.MessagingStyle messagingStyle = new Notification.MessagingStyle(AnonymousClass0ZP.A00(this.A00));
        for (AnonymousClass0Z0 r5 : this.A03) {
            AnonymousClass0ZR r2 = r5.A04;
            Person person = null;
            CharSequence charSequence = r5.A05;
            long j = r5.A03;
            if (r2 != null) {
                person = AnonymousClass0ZP.A00(r2);
            }
            Notification.MessagingStyle.Message message = new Notification.MessagingStyle.Message(charSequence, j, person);
            String str = r5.A02;
            if (str != null) {
                message.setData(str, r5.A00);
            }
            messagingStyle.addMessage(message);
        }
        for (AnonymousClass0Z0 r52 : this.A04) {
            AnonymousClass0ZR r22 = r52.A04;
            Person person2 = null;
            CharSequence charSequence2 = r52.A05;
            long j2 = r52.A03;
            if (r22 != null) {
                person2 = AnonymousClass0ZP.A00(r22);
            }
            Notification.MessagingStyle.Message message2 = new Notification.MessagingStyle.Message(charSequence2, j2, person2);
            String str2 = r52.A02;
            if (str2 != null) {
                message2.setData(str2, r52.A00);
            }
            messagingStyle.addHistoricMessage(message2);
        }
        messagingStyle.setConversationTitle(this.A02);
        messagingStyle.setGroupConversation(this.A01.booleanValue());
        messagingStyle.setBuilder(((AnonymousClass0ZB) r9).A04);
    }

    public final void A08(AnonymousClass0Z0 r4) {
        if (r4 != null) {
            List list = this.A03;
            list.add(r4);
            if (list.size() > 25) {
                list.remove(0);
            }
        }
    }

    public NotificationCompat$MessagingStyle(AnonymousClass0ZR r2) {
        if (!TextUtils.isEmpty(r2.A01)) {
            this.A00 = r2;
            return;
        }
        throw AnonymousClass001.A0L("User's name must not be empty.");
    }

    public final void A02(Bundle bundle) {
        super.A02(bundle);
        bundle.remove("android.messagingStyleUser");
        bundle.remove("android.selfDisplayName");
        bundle.remove("android.conversationTitle");
        bundle.remove("android.hiddenConversationTitle");
        bundle.remove("android.messages");
        bundle.remove("android.messages.historic");
        bundle.remove("android.isGroupConversation");
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$MessagingStyle";
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004d, code lost:
        r5.putInt(androidx.core.graphics.drawable.IconCompat.EXTRA_TYPE, r3.mType);
        r5.putInt(androidx.core.graphics.drawable.IconCompat.EXTRA_INT1, r3.mInt1);
        r5.putInt(androidx.core.graphics.drawable.IconCompat.EXTRA_INT2, r3.mInt2);
        r5.putString(androidx.core.graphics.drawable.IconCompat.EXTRA_STRING1, r3.mString1);
        r1 = r3.mTintList;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x006b, code lost:
        if (r1 == null) goto L_0x0072;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x006d, code lost:
        r5.putParcelable(androidx.core.graphics.drawable.IconCompat.EXTRA_TINT_LIST, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0072, code lost:
        r3 = r3.mTintMode;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0076, code lost:
        if (r3 == androidx.core.graphics.drawable.IconCompat.DEFAULT_TINT_MODE) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0078, code lost:
        r5.putString(androidx.core.graphics.drawable.IconCompat.EXTRA_TINT_MODE, r3.name());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0040, code lost:
        r5.putParcelable(androidx.core.graphics.drawable.IconCompat.EXTRA_OBJ, r0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A05(android.os.Bundle r7) {
        /*
            r6 = this;
            super.A05(r7)
            X.0ZR r0 = r6.A00
            java.lang.CharSequence r1 = r0.A01
            java.lang.String r0 = "android.selfDisplayName"
            r7.putCharSequence(r0, r1)
            X.0ZR r4 = r6.A00
            android.os.Bundle r2 = X.AnonymousClass001.A08()
            java.lang.String r1 = "name"
            java.lang.CharSequence r0 = r4.A01
            r2.putCharSequence(r1, r0)
            androidx.core.graphics.drawable.IconCompat r3 = r4.A00
            if (r3 == 0) goto L_0x0044
            android.os.Bundle r5 = X.AnonymousClass001.A08()
            int r0 = r3.mType
            java.lang.String r1 = "obj"
            switch(r0) {
                case -1: goto L_0x0037;
                case 0: goto L_0x0028;
                case 1: goto L_0x003c;
                case 2: goto L_0x002f;
                case 3: goto L_0x0046;
                case 4: goto L_0x002f;
                case 5: goto L_0x003c;
                case 6: goto L_0x002f;
                default: goto L_0x0028;
            }
        L_0x0028:
            java.lang.String r0 = "Invalid icon"
            java.lang.IllegalArgumentException r0 = X.AnonymousClass001.A0L(r0)
            throw r0
        L_0x002f:
            java.lang.Object r0 = r3.mObj1
            java.lang.String r0 = (java.lang.String) r0
            r5.putString(r1, r0)
            goto L_0x004d
        L_0x0037:
            java.lang.Object r0 = r3.mObj1
            android.os.Parcelable r0 = (android.os.Parcelable) r0
            goto L_0x0040
        L_0x003c:
            java.lang.Object r0 = r3.mObj1
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
        L_0x0040:
            r5.putParcelable(r1, r0)
            goto L_0x004d
        L_0x0044:
            r5 = 0
            goto L_0x0081
        L_0x0046:
            java.lang.Object r0 = r3.mObj1
            byte[] r0 = (byte[]) r0
            r5.putByteArray(r1, r0)
        L_0x004d:
            java.lang.String r1 = "type"
            int r0 = r3.mType
            r5.putInt(r1, r0)
            java.lang.String r1 = "int1"
            int r0 = r3.mInt1
            r5.putInt(r1, r0)
            java.lang.String r1 = "int2"
            int r0 = r3.mInt2
            r5.putInt(r1, r0)
            java.lang.String r1 = "string1"
            java.lang.String r0 = r3.mString1
            r5.putString(r1, r0)
            android.content.res.ColorStateList r1 = r3.mTintList
            if (r1 == 0) goto L_0x0072
            java.lang.String r0 = "tint_list"
            r5.putParcelable(r0, r1)
        L_0x0072:
            android.graphics.PorterDuff$Mode r3 = r3.mTintMode
            android.graphics.PorterDuff$Mode r0 = androidx.core.graphics.drawable.IconCompat.DEFAULT_TINT_MODE
            if (r3 == r0) goto L_0x0081
            java.lang.String r1 = "tint_mode"
            java.lang.String r0 = r3.name()
            r5.putString(r1, r0)
        L_0x0081:
            java.lang.String r0 = "icon"
            r2.putBundle(r0, r5)
            java.lang.String r1 = "uri"
            java.lang.String r0 = r4.A03
            r2.putString(r1, r0)
            java.lang.String r1 = "key"
            java.lang.String r0 = r4.A02
            r2.putString(r1, r0)
            java.lang.String r1 = "isBot"
            boolean r0 = r4.A04
            r2.putBoolean(r1, r0)
            java.lang.String r1 = "isImportant"
            boolean r0 = r4.A05
            r2.putBoolean(r1, r0)
            java.lang.String r0 = "android.messagingStyleUser"
            r7.putBundle(r0, r2)
            java.lang.String r1 = "android.hiddenConversationTitle"
            java.lang.CharSequence r0 = r6.A02
            r7.putCharSequence(r1, r0)
            java.lang.CharSequence r1 = r6.A02
            if (r1 == 0) goto L_0x00bf
            java.lang.Boolean r0 = r6.A01
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x00bf
            java.lang.String r0 = "android.conversationTitle"
            r7.putCharSequence(r0, r1)
        L_0x00bf:
            java.util.List r1 = r6.A03
            boolean r0 = r1.isEmpty()
            if (r0 != 0) goto L_0x00d0
            android.os.Bundle[] r1 = X.AnonymousClass0Z0.A01(r1)
            java.lang.String r0 = "android.messages"
            r7.putParcelableArray(r0, r1)
        L_0x00d0:
            java.util.List r1 = r6.A04
            boolean r0 = r1.isEmpty()
            if (r0 != 0) goto L_0x00e1
            android.os.Bundle[] r1 = X.AnonymousClass0Z0.A01(r1)
            java.lang.String r0 = "android.messages.historic"
            r7.putParcelableArray(r0, r1)
        L_0x00e1:
            java.lang.Boolean r0 = r6.A01
            if (r0 == 0) goto L_0x00ee
            java.lang.String r1 = "android.isGroupConversation"
            boolean r0 = r0.booleanValue()
            r7.putBoolean(r1, r0)
        L_0x00ee:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.NotificationCompat$MessagingStyle.A05(android.os.Bundle):void");
    }

    public final void A06(Bundle bundle) {
        AnonymousClass0ZR r2;
        super.A06(bundle);
        List list = this.A03;
        list.clear();
        if (bundle.containsKey("android.messagingStyleUser")) {
            r2 = AnonymousClass0ZR.A00(bundle.getBundle("android.messagingStyleUser"));
        } else {
            r2 = new AnonymousClass0ZR((IconCompat) null, bundle.getString("android.selfDisplayName"), (String) null, (String) null, false, false);
        }
        this.A00 = r2;
        CharSequence charSequence = bundle.getCharSequence("android.conversationTitle");
        this.A02 = charSequence;
        if (charSequence == null) {
            this.A02 = bundle.getCharSequence("android.hiddenConversationTitle");
        }
        Parcelable[] parcelableArray = bundle.getParcelableArray("android.messages");
        if (parcelableArray != null) {
            list.addAll(AnonymousClass0Z0.A00(parcelableArray));
        }
        Parcelable[] parcelableArray2 = bundle.getParcelableArray("android.messages.historic");
        if (parcelableArray2 != null) {
            this.A04.addAll(AnonymousClass0Z0.A00(parcelableArray2));
        }
        if (bundle.containsKey("android.isGroupConversation")) {
            this.A01 = Boolean.valueOf(bundle.getBoolean("android.isGroupConversation"));
        }
    }

    public NotificationCompat$MessagingStyle() {
    }
}
