package androidx.core.app;

import X.AnonymousClass001;
import X.AnonymousClass0YT;
import X.AnonymousClass0Yg;
import X.AnonymousClass0ZB;
import android.app.Notification;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public final class NotificationCompat$InboxStyle extends AnonymousClass0Yg {
    public ArrayList A00 = AnonymousClass001.A0t();

    public final void A07(AnonymousClass0YT r4) {
        Notification.InboxStyle bigContentTitle = new Notification.InboxStyle(((AnonymousClass0ZB) r4).A04).setBigContentTitle(this.A01);
        if (this.A03) {
            bigContentTitle.setSummaryText(this.A02);
        }
        Iterator it = this.A00.iterator();
        while (it.hasNext()) {
            bigContentTitle.addLine((CharSequence) it.next());
        }
    }

    public final void A02(Bundle bundle) {
        super.A02(bundle);
        bundle.remove("android.textLines");
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$InboxStyle";
    }

    public final void A06(Bundle bundle) {
        super.A06(bundle);
        ArrayList arrayList = this.A00;
        arrayList.clear();
        if (bundle.containsKey("android.textLines")) {
            Collections.addAll(arrayList, bundle.getCharSequenceArray("android.textLines"));
        }
    }
}
