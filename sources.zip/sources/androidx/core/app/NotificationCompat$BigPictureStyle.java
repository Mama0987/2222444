package androidx.core.app;

import X.AnonymousClass0YT;
import X.AnonymousClass0Yg;
import X.AnonymousClass0ZB;
import X.C06860Yf;
import X.C07670aj;
import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;

public final class NotificationCompat$BigPictureStyle extends AnonymousClass0Yg {
    public IconCompat A00;
    public IconCompat A01;
    public boolean A02;
    public boolean A03;

    public final void A07(AnonymousClass0YT r9) {
        Context context;
        AnonymousClass0ZB r5 = (AnonymousClass0ZB) r9;
        Notification.BigPictureStyle bigContentTitle = new Notification.BigPictureStyle(r5.A04).setBigContentTitle(this.A01);
        IconCompat iconCompat = this.A01;
        Context context2 = null;
        if (iconCompat != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                if (r9 instanceof AnonymousClass0ZB) {
                    context = r5.A05;
                } else {
                    context = null;
                }
                C06860Yf.A01(bigContentTitle, C07670aj.A00(context, iconCompat));
            } else {
                int i = iconCompat.mType;
                if (i == -1) {
                    i = ((Icon) iconCompat.mObj1).getType();
                }
                if (i == 1) {
                    bigContentTitle = bigContentTitle.bigPicture(this.A01.getBitmap());
                }
            }
        }
        if (this.A02) {
            IconCompat iconCompat2 = this.A00;
            if (iconCompat2 == null) {
                bigContentTitle.bigLargeIcon((Bitmap) null);
            } else {
                if (r9 instanceof AnonymousClass0ZB) {
                    context2 = r5.A05;
                }
                bigContentTitle.bigLargeIcon(C07670aj.A00(context2, iconCompat2));
            }
        }
        if (this.A03) {
            bigContentTitle.setSummaryText(this.A02);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            C06860Yf.A02(bigContentTitle, this.A03);
            C06860Yf.A00(bigContentTitle);
        }
    }

    public final void A02(Bundle bundle) {
        super.A02(bundle);
        bundle.remove("android.largeIcon.big");
        bundle.remove("android.picture");
        bundle.remove("android.pictureIcon");
        bundle.remove("android.showBigPictureWhenCollapsed");
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }

    public final void A06(Bundle bundle) {
        IconCompat iconCompat;
        IconCompat iconCompat2;
        super.A06(bundle);
        if (bundle.containsKey("android.largeIcon.big")) {
            Parcelable parcelable = bundle.getParcelable("android.largeIcon.big");
            if (parcelable != null) {
                if (parcelable instanceof Icon) {
                    iconCompat2 = C07670aj.A01(parcelable);
                } else if (parcelable instanceof Bitmap) {
                    iconCompat2 = IconCompat.createWithBitmap((Bitmap) parcelable);
                }
                this.A00 = iconCompat2;
                this.A02 = true;
            }
            iconCompat2 = null;
            this.A00 = iconCompat2;
            this.A02 = true;
        }
        Parcelable parcelable2 = bundle.getParcelable("android.picture");
        if (parcelable2 == null) {
            parcelable2 = bundle.getParcelable("android.pictureIcon");
        }
        if (parcelable2 != null) {
            if (parcelable2 instanceof Icon) {
                iconCompat = C07670aj.A01(parcelable2);
            } else if (parcelable2 instanceof Bitmap) {
                iconCompat = IconCompat.createWithBitmap((Bitmap) parcelable2);
            }
            this.A01 = iconCompat;
            this.A03 = bundle.getBoolean("android.showBigPictureWhenCollapsed");
        }
        iconCompat = null;
        this.A01 = iconCompat;
        this.A03 = bundle.getBoolean("android.showBigPictureWhenCollapsed");
    }
}
