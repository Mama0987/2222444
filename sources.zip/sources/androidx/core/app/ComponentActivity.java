package androidx.core.app;

import X.AnonymousClass00Q;
import X.AnonymousClass0BS;
import X.AnonymousClass0PN;
import X.AnonymousClass0XY;
import X.AnonymousClass0YJ;
import X.C06460Wi;
import X.C09740eO;
import X.C09750eP;
import X.C09780eT;
import X.C15800sA;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import kotlin.Deprecated;

public abstract class ComponentActivity extends Activity implements C06460Wi, AnonymousClass0PN {
    public final AnonymousClass0XY extraDataMap = AnonymousClass0XY.A02();
    public final C09780eT lifecycleRegistry = new C09780eT(this, true);

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final boolean shouldSkipDump(java.lang.String[] r4) {
        /*
            r3 = this;
            r2 = 0
            if (r4 == 0) goto L_0x000f
            int r0 = r4.length
            if (r0 == 0) goto L_0x000f
            r1 = r4[r2]
            int r0 = r1.hashCode()
            switch(r0) {
                case -645125871: goto L_0x0010;
                case 100470631: goto L_0x001d;
                case 472614934: goto L_0x0020;
                case 1159329357: goto L_0x0036;
                case 1455016274: goto L_0x002d;
                default: goto L_0x000f;
            }
        L_0x000f:
            return r2
        L_0x0010:
            java.lang.String r0 = "--translation"
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x000f
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 31
            goto L_0x0042
        L_0x001d:
            java.lang.String r0 = "--dump-dumpable"
            goto L_0x0022
        L_0x0020:
            java.lang.String r0 = "--list-dumpables"
        L_0x0022:
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x000f
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 33
            goto L_0x0042
        L_0x002d:
            java.lang.String r0 = "--autofill"
            boolean r0 = r1.equals(r0)
            if (r0 != 0) goto L_0x0044
            return r2
        L_0x0036:
            java.lang.String r0 = "--contentcapture"
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x000f
            int r1 = android.os.Build.VERSION.SDK_INT
            r0 = 29
        L_0x0042:
            if (r1 < r0) goto L_0x000f
        L_0x0044:
            r2 = 1
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.ComponentActivity.shouldSkipDump(java.lang.String[]):boolean");
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        C15800sA.A0D(keyEvent, 0);
        C15800sA.A09(getWindow().getDecorView());
        return superDispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        C15800sA.A0D(keyEvent, 0);
        C15800sA.A09(getWindow().getDecorView());
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    @Deprecated(message = "Use {@link View#getTag(int)} with the window's decor view.")
    public AnonymousClass0YJ getExtraData(Class cls) {
        C15800sA.A0D(cls, 0);
        this.extraDataMap.get(cls);
        return null;
    }

    public abstract C09750eP getLifecycle();

    public void onSaveInstanceState(Bundle bundle) {
        C15800sA.A0D(bundle, 0);
        this.lifecycleRegistry.A08(C09740eO.CREATED);
        super.onSaveInstanceState(bundle);
    }

    @Deprecated(message = "Use {@link View#setTag(int, Object)} with the window's decor view.")
    public void putExtraData(AnonymousClass0YJ r3) {
        C15800sA.A0D(r3, 0);
        this.extraDataMap.put(r3.getClass(), r3);
    }

    public boolean superDispatchKeyEvent(KeyEvent keyEvent) {
        C15800sA.A0D(keyEvent, 0);
        return super.dispatchKeyEvent(keyEvent);
    }

    public final boolean shouldDumpInternalState(String[] strArr) {
        boolean z;
        if (strArr == null || strArr.length == 0) {
            z = false;
        } else {
            z = shouldSkipDump(strArr);
        }
        return !z;
    }

    public void onCreate(Bundle bundle) {
        int A00 = AnonymousClass0BS.A00(-1405646941);
        super.onCreate(bundle);
        AnonymousClass00Q.A00(this);
        AnonymousClass0BS.A07(1408521919, A00);
    }
}
