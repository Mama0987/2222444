package androidx.core.app;

import X.AnonymousClass001;
import X.AnonymousClass0YT;
import X.AnonymousClass0YY;
import X.AnonymousClass0Yg;
import X.AnonymousClass0ZB;
import X.AnonymousClass0ZP;
import X.AnonymousClass0ZR;
import X.C06820Yb;
import X.C06940Yq;
import X.C07670aj;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Iterator;

public final class NotificationCompat$CallStyle extends AnonymousClass0Yg {
    public int A00;
    public PendingIntent A01;
    public PendingIntent A02;
    public PendingIntent A03;
    public AnonymousClass0ZR A04;
    public Integer A05;
    public Integer A06;
    public boolean A07;
    public IconCompat A08;
    public CharSequence A09;

    private C06820Yb A01(PendingIntent pendingIntent, Integer num, int i, int i2, int i3) {
        if (num == null) {
            num = Integer.valueOf(this.A00.A0E.getColor(i3));
        }
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        spannableStringBuilder.append(this.A00.A0E.getResources().getString(i2));
        spannableStringBuilder.setSpan(new ForegroundColorSpan(num.intValue()), 0, spannableStringBuilder.length(), 18);
        Context context = this.A00.A0E;
        if (context != null) {
            C06820Yb A012 = new AnonymousClass0YY(pendingIntent, IconCompat.createWithResource(context.getResources(), context.getPackageName(), i), (CharSequence) spannableStringBuilder).A01();
            A012.A08.putBoolean("key_action_priority", true);
            return A012;
        }
        throw AnonymousClass001.A0S();
    }

    public final void A07(AnonymousClass0YT r4) {
        CharSequence charSequence;
        Resources resources;
        int i;
        Notification.CallStyle A012;
        CharSequence charSequence2 = null;
        if (Build.VERSION.SDK_INT >= 31) {
            int i2 = this.A00;
            if (i2 == 1) {
                A012 = C06940Yq.A01(AnonymousClass0ZP.A00(this.A04), this.A02, this.A01);
            } else if (i2 == 2) {
                A012 = C06940Yq.A00(AnonymousClass0ZP.A00(this.A04), this.A03);
            } else if (i2 == 3) {
                A012 = C06940Yq.A02(AnonymousClass0ZP.A00(this.A04), this.A03, this.A01);
            } else {
                return;
            }
            if (A012 != null) {
                A012.setBuilder(((AnonymousClass0ZB) r4).A04);
                Integer num = this.A05;
                if (num != null) {
                    C06940Yq.A03(A012, num.intValue());
                }
                Integer num2 = this.A06;
                if (num2 != null) {
                    C06940Yq.A04(A012, num2.intValue());
                }
                C06940Yq.A06(A012, this.A09);
                IconCompat iconCompat = this.A08;
                if (iconCompat != null) {
                    C06940Yq.A05(A012, C07670aj.A00(this.A00.A0E, iconCompat));
                }
                C06940Yq.A07(A012, this.A07);
                return;
            }
            return;
        }
        Notification.Builder builder = ((AnonymousClass0ZB) r4).A04;
        AnonymousClass0ZR r0 = this.A04;
        if (r0 != null) {
            charSequence2 = r0.A01;
        }
        builder.setContentTitle(charSequence2);
        Bundle bundle = this.A00.A0F;
        if (bundle == null || !bundle.containsKey("android.text") || (charSequence = this.A00.A0F.getCharSequence("android.text")) == null) {
            int i3 = this.A00;
            if (i3 == 1) {
                resources = this.A00.A0E.getResources();
                i = 2132020340;
            } else if (i3 == 2) {
                resources = this.A00.A0E.getResources();
                i = 2132020341;
            } else if (i3 != 3) {
                charSequence = null;
            } else {
                resources = this.A00.A0E.getResources();
                i = 2132020342;
            }
            charSequence = resources.getString(i);
        }
        builder.setContentText(charSequence);
        AnonymousClass0ZR r02 = this.A04;
        if (r02 != null) {
            IconCompat iconCompat2 = r02.A00;
            if (iconCompat2 != null) {
                builder.setLargeIcon(C07670aj.A00(this.A00.A0E, iconCompat2));
            }
            builder.addPerson(AnonymousClass0ZP.A00(this.A04));
        }
        builder.setCategory("call");
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$CallStyle";
    }

    public final void A05(Bundle bundle) {
        super.A05(bundle);
        bundle.putInt("android.callType", this.A00);
        bundle.putBoolean("android.callIsVideo", this.A07);
        AnonymousClass0ZR r0 = this.A04;
        if (r0 != null) {
            bundle.putParcelable("android.callPerson", AnonymousClass0ZP.A00(r0));
        }
        IconCompat iconCompat = this.A08;
        if (iconCompat != null) {
            bundle.putParcelable("android.verificationIcon", C07670aj.A00(this.A00.A0E, iconCompat));
        }
        bundle.putCharSequence("android.verificationText", this.A09);
        bundle.putParcelable("android.answerIntent", this.A01);
        bundle.putParcelable("android.declineIntent", this.A02);
        bundle.putParcelable("android.hangUpIntent", this.A03);
        Integer num = this.A05;
        if (num != null) {
            bundle.putInt("android.answerColor", num.intValue());
        }
        Integer num2 = this.A06;
        if (num2 != null) {
            bundle.putInt("android.declineColor", num2.intValue());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0087  */
    /* JADX WARNING: Removed duplicated region for block: B:6:0x002f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void A06(android.os.Bundle r4) {
        /*
            r3 = this;
            super.A06(r4)
            java.lang.String r0 = "android.callType"
            int r0 = r4.getInt(r0)
            r3.A00 = r0
            java.lang.String r0 = "android.callIsVideo"
            boolean r0 = r4.getBoolean(r0)
            r3.A07 = r0
            java.lang.String r1 = "android.callPerson"
            boolean r0 = r4.containsKey(r1)
            if (r0 == 0) goto L_0x0098
            android.os.Parcelable r0 = r4.getParcelable(r1)
            android.app.Person r0 = (android.app.Person) r0
            X.0ZR r0 = X.AnonymousClass0ZP.A01(r0)
        L_0x0025:
            r3.A04 = r0
        L_0x0027:
            java.lang.String r1 = "android.verificationIcon"
            boolean r0 = r4.containsKey(r1)
            if (r0 == 0) goto L_0x0087
            android.os.Parcelable r0 = r4.getParcelable(r1)
            androidx.core.graphics.drawable.IconCompat r0 = X.C07670aj.A01(r0)
        L_0x0037:
            r3.A08 = r0
        L_0x0039:
            java.lang.String r0 = "android.verificationText"
            java.lang.CharSequence r0 = r4.getCharSequence(r0)
            r3.A09 = r0
            java.lang.String r0 = "android.answerIntent"
            android.os.Parcelable r0 = r4.getParcelable(r0)
            android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            r3.A01 = r0
            java.lang.String r0 = "android.declineIntent"
            android.os.Parcelable r0 = r4.getParcelable(r0)
            android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            r3.A02 = r0
            java.lang.String r0 = "android.hangUpIntent"
            android.os.Parcelable r0 = r4.getParcelable(r0)
            android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            r3.A03 = r0
            java.lang.String r1 = "android.answerColor"
            boolean r0 = r4.containsKey(r1)
            r2 = 0
            if (r0 == 0) goto L_0x0085
            int r0 = r4.getInt(r1)
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
        L_0x0070:
            r3.A05 = r0
            java.lang.String r1 = "android.declineColor"
            boolean r0 = r4.containsKey(r1)
            if (r0 == 0) goto L_0x0082
            int r0 = r4.getInt(r1)
            java.lang.Integer r2 = java.lang.Integer.valueOf(r0)
        L_0x0082:
            r3.A06 = r2
            return
        L_0x0085:
            r0 = r2
            goto L_0x0070
        L_0x0087:
            java.lang.String r1 = "android.verificationIconCompat"
            boolean r0 = r4.containsKey(r1)
            if (r0 == 0) goto L_0x0039
            android.os.Bundle r0 = r4.getBundle(r1)
            androidx.core.graphics.drawable.IconCompat r0 = androidx.core.graphics.drawable.IconCompat.createFromBundle(r0)
            goto L_0x0037
        L_0x0098:
            java.lang.String r1 = "android.callPersonCompat"
            boolean r0 = r4.containsKey(r1)
            if (r0 == 0) goto L_0x0027
            android.os.Bundle r0 = r4.getBundle(r1)
            X.0ZR r0 = X.AnonymousClass0ZR.A00(r0)
            goto L_0x0025
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.NotificationCompat$CallStyle.A06(android.os.Bundle):void");
    }

    public final ArrayList A08() {
        int i;
        Integer num;
        int i2;
        C06820Yb A012;
        PendingIntent pendingIntent = this.A02;
        if (pendingIntent == null) {
            i = 2132020339;
            num = this.A06;
            i2 = 2131099910;
            pendingIntent = this.A03;
        } else {
            i = 2132020338;
            num = this.A06;
            i2 = 2131099910;
        }
        C06820Yb A013 = A01(pendingIntent, num, 2131230773, i, i2);
        PendingIntent pendingIntent2 = this.A01;
        if (pendingIntent2 == null) {
            A012 = null;
        } else {
            int i3 = 2131230771;
            int i4 = 2132020336;
            if (this.A07) {
                i3 = 2131230772;
                i4 = 2132020337;
            }
            A012 = A01(pendingIntent2, this.A05, i3, i4, 2131099909);
        }
        ArrayList A0u = AnonymousClass001.A0u(3);
        A0u.add(A013);
        char c = 2;
        Iterator it = this.A00.A0Y.iterator();
        while (it.hasNext()) {
            C06820Yb r2 = (C06820Yb) it.next();
            if (r2.A09) {
                A0u.add(r2);
            } else if (!r2.A08.getBoolean("key_action_priority") && c > 1) {
                A0u.add(r2);
                c = 1;
            }
            if (A012 != null && c == 1) {
                A0u.add(A012);
                c = 0;
            }
        }
        if (A012 != null && c >= 1) {
            A0u.add(A012);
        }
        return A0u;
    }
}
