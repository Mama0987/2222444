package androidx.core.app;

import X.AnonymousClass0YT;
import X.AnonymousClass0Yg;
import X.AnonymousClass0ZB;
import android.app.Notification;

public final class NotificationCompat$DecoratedCustomViewStyle extends AnonymousClass0Yg {
    public final void A07(AnonymousClass0YT r3) {
        ((AnonymousClass0ZB) r3).A04.setStyle(new Notification.DecoratedCustomViewStyle());
    }

    public final String A04() {
        return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
    }
}
