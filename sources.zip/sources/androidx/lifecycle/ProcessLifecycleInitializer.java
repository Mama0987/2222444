package androidx.lifecycle;

import X.AnonymousClass001;
import X.AnonymousClass10I;
import X.C06300Vs;
import X.C09730eN;
import X.C09760eR;
import X.C09820eX;
import X.C09860ed;
import X.C10530fl;
import X.C15800sA;
import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

public final class ProcessLifecycleInitializer implements C09820eX {
    /* JADX WARNING: type inference failed for: r0v15, types: [android.app.Application$ActivityLifecycleCallbacks, java.lang.Object] */
    public final /* bridge */ /* synthetic */ Object AQq(Context context) {
        String str;
        C15800sA.A0D(context, 0);
        C10530fl A00 = C10530fl.A00(context);
        C15800sA.A09(A00);
        if (A00.A02.contains(getClass())) {
            if (!C09760eR.A00.getAndSet(true)) {
                Context applicationContext = context.getApplicationContext();
                str = "null cannot be cast to non-null type android.app.Application";
                if (applicationContext != null) {
                    ((Application) applicationContext).registerActivityLifecycleCallbacks(new Object());
                }
                C15800sA.A0J(str);
                throw C06300Vs.createAndThrow();
            }
            C09860ed r2 = C09860ed.A08;
            r2.A02 = new Handler();
            r2.A05.A07(C09730eN.ON_CREATE);
            Context applicationContext2 = context.getApplicationContext();
            str = "null cannot be cast to non-null type android.app.Application";
            if (applicationContext2 != null) {
                ((Application) applicationContext2).registerActivityLifecycleCallbacks(new ProcessLifecycleOwner$attach$1(r2));
                return r2;
            }
            C15800sA.A0J(str);
            throw C06300Vs.createAndThrow();
        }
        throw AnonymousClass001.A0P("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
    }

    public final List AWT() {
        return AnonymousClass10I.A00;
    }
}
