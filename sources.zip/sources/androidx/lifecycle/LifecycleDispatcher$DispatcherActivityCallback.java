package androidx.lifecycle;

import X.AnonymousClass00Q;
import X.C15800sA;
import android.app.Activity;
import android.os.Bundle;

public final class LifecycleDispatcher$DispatcherActivityCallback extends EmptyActivityLifecycleCallbacks {
    public void onActivityCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A00(activity);
    }
}
