package androidx.lifecycle;

import X.AnonymousClass00Q;
import X.AnonymousClass00S;
import X.C09730eN;
import X.C15800sA;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public final class ReportFragment$LifecycleCallbacks implements Application.ActivityLifecycleCallbacks {
    public static final AnonymousClass00S Companion = new Object();

    public void onActivityPostCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_CREATE);
    }

    public void onActivityPostResumed(Activity activity) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_RESUME);
    }

    public void onActivityPostStarted(Activity activity) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_START);
    }

    public void onActivityPreDestroyed(Activity activity) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_DESTROY);
    }

    public void onActivityPrePaused(Activity activity) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_PAUSE);
    }

    public void onActivityPreStopped(Activity activity) {
        C15800sA.A0D(activity, 0);
        AnonymousClass00Q.A01(activity, C09730eN.ON_STOP);
    }

    public static final void registerIn(Activity activity) {
        AnonymousClass00S.A00(activity);
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    public void onActivityResumed(Activity activity) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
