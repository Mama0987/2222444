package androidx.lifecycle;

import X.AnonymousClass00U;
import X.C04010Jt;
import X.C06300Vs;
import X.C09730eN;
import X.C09860ed;
import X.C15800sA;
import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

public final class ProcessLifecycleOwner$attach$1 extends EmptyActivityLifecycleCallbacks {
    public final /* synthetic */ C09860ed this$0;

    public void onActivityCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        if (Build.VERSION.SDK_INT < 29) {
            Fragment findFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            if (findFragmentByTag == null) {
                C15800sA.A0J("null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
                throw C06300Vs.createAndThrow();
            }
            C09860ed r1 = this.this$0;
            C09860ed r0 = C09860ed.A08;
            ((AnonymousClass00U) findFragmentByTag).A00 = r1.A06;
        }
    }

    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        C15800sA.A0D(activity, 0);
        C04010Jt.A00(activity, new ProcessLifecycleOwner$attach$1$onActivityPreCreated$1(this.this$0));
    }

    public ProcessLifecycleOwner$attach$1(C09860ed r1) {
        this.this$0 = r1;
    }

    public void onActivityPaused(Activity activity) {
        C09860ed r1 = this.this$0;
        int i = r1.A00 - 1;
        r1.A00 = i;
        if (i == 0) {
            Handler handler = r1.A02;
            if (handler == null) {
                C15800sA.A0C(handler);
                throw C06300Vs.createAndThrow();
            } else {
                handler.postDelayed(r1.A07, 700);
            }
        }
    }

    public void onActivityStopped(Activity activity) {
        C09860ed r2 = this.this$0;
        int i = r2.A01 - 1;
        r2.A01 = i;
        if (i == 0 && r2.A03) {
            r2.A05.A07(C09730eN.ON_STOP);
            r2.A04 = true;
        }
    }
}
