package androidx.lifecycle;

import X.C09730eN;
import X.C09860ed;
import android.app.Activity;

public final class ProcessLifecycleOwner$attach$1$onActivityPreCreated$1 extends EmptyActivityLifecycleCallbacks {
    public final /* synthetic */ C09860ed this$0;

    public ProcessLifecycleOwner$attach$1$onActivityPreCreated$1(C09860ed r1) {
        this.this$0 = r1;
    }

    public void onActivityPostResumed(Activity activity) {
        this.this$0.A00();
    }

    public void onActivityPostStarted(Activity activity) {
        C09860ed r2 = this.this$0;
        int i = r2.A01 + 1;
        r2.A01 = i;
        if (i == 1 && r2.A04) {
            r2.A05.A07(C09730eN.ON_START);
            r2.A04 = false;
        }
    }
}
